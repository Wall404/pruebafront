create function get_actividades_x_certificado_plan_version(pcertificado integer, pplanversion integer) returns TABLE(plan_version integer, certificado integer, elemento integer)
LANGUAGE plpgsql
AS $$
DECLARE 
  _elemento Integer;
  _certificado integer;
  _plan_version integer;
  _cur1 record;

BEGIN

 
 CREATE TEMP TABLE _temp_planes_certificados(plan_version integer, certificado integer, elemento integer);

 
 FOR _cur1 IN SELECT pc.plan_version, pc.certificado 
                FROM sga_planes_certificados as pc
			   WHERE (pPlanVersion IS NULL OR pc.plan_version = pPlanVersion)	
			     AND (pCertificado IS NULL OR pc.certificado = pCertificado)	
 LOOP
    
    INSERT INTO _temp_planes_certificados (plan_version, certificado, elemento)
       SELECT _cur1.plan_version, _cur1.certificado, e.*
         FROM get_actividades_certificado_plan_version (_cur1.certificado, _cur1.plan_version) as e (integer);
 END LOOP;              

 
 RETURN QUERY (SELECT t.plan_version, t.certificado, t.elemento FROM _temp_planes_certificados as t ORDER BY 1, 2, 3);

  DROP TABLE _temp_planes_certificados;
END;
$$;
