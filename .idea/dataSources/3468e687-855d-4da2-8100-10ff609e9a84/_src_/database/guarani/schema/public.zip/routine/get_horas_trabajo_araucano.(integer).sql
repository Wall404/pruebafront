create function get_horas_trabajo_araucano(ppersona integer) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE _horas_trabajo varchar(4);
 
BEGIN
  _horas_trabajo := '-9';
  
  
  
  
  SELECT
  	CASE
  		WHEN mdp_datos_economicos.trabajo_existe IS NULL OR (mdp_datos_economicos.trabajo_existe = 1 AND mdp_datos_economicos.trabajo_hora_sem IS NULL) THEN '-8' 
  		WHEN mdp_datos_economicos.trabajo_existe = 1 THEN mdp_datos_economicos.trabajo_hora_sem 
  		WHEN mdp_datos_economicos.trabajo_existe = 4 THEN '-8'   
  		ELSE '-9' 
  	END as horas_trabajo
  	INTO _horas_trabajo
  FROM mdp_datos_censales,
  	 mdp_datos_economicos
  WHERE mdp_datos_censales.dato_censal = (SELECT get_ultimo_dato_censal(pPersona))
    AND mdp_datos_censales.dato_censal = mdp_datos_economicos.dato_censal;
        
  
  RETURN _horas_trabajo;

END;
$$;
