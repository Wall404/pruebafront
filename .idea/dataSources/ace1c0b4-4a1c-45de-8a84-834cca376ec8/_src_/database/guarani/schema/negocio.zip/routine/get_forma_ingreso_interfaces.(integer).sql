create function negocio.get_forma_ingreso_interfaces(palumno integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
	_anio_academico_ingreso numeric;
	_fecha_fin_anio_academico_ingreso date;
	_cant_equivalencias integer;
	_cant_reconocimientos integer;
	_codigo_forma_ingreso integer;
BEGIN
	SELECT	sga_propuestas_aspira.anio_academico INTO _anio_academico_ingreso
	FROM	sga_alumnos,
			sga_propuestas_aspira,
			sga_situacion_aspirante
	WHERE	sga_alumnos.persona = sga_propuestas_aspira.persona AND
			sga_alumnos.propuesta = sga_propuestas_aspira.propuesta AND
			sga_propuestas_aspira.situacion_asp = sga_situacion_aspirante.situacion_asp AND
			sga_situacion_aspirante.resultado_asp IN ('A', 'P') AND
			sga_alumnos.alumno = pAlumno;
	_fecha_fin_anio_academico_ingreso := _anio_academico_ingreso + 1 || '-03-31';

	_cant_equivalencias := 0;
	SELECT	COUNT(vw_equivalencias.equivalencia) INTO _cant_equivalencias
	FROM	sga_equiv_tramite,
			vw_equivalencias
	WHERE 	sga_equiv_tramite.equivalencia_tramite = vw_equivalencias.equivalencia_tramite AND
			vw_equivalencias.estado = 'A' AND
			sga_equiv_tramite.alumno = pAlumno AND
			vw_equivalencias.fecha <= _fecha_fin_anio_academico_ingreso;

	_cant_reconocimientos := 0;
	SELECT	COUNT(sga_reconocimiento.nro_tramite) INTO _cant_reconocimientos
	FROM	sga_reconocimiento
	WHERE 	sga_reconocimiento.estado = 'C' AND
			sga_reconocimiento.alumno = pAlumno AND
			sga_reconocimiento.fecha <= _fecha_fin_anio_academico_ingreso;
			
	IF _cant_equivalencias + _cant_reconocimientos > 0 THEN
		_codigo_forma_ingreso := 2;
	ELSE
		_codigo_forma_ingreso := 1;
	END IF;

	RETURN _codigo_forma_ingreso;
END;
$$;
