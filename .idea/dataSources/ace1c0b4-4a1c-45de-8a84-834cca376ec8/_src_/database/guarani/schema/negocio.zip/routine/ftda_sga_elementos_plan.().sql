create function negocio.ftda_sga_elementos_plan() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
	_propuesta integer;
	_plan integer;
	_estado_plan char(1);
	_tipo_plan varchar(15);
BEGIN
	SELECT	sga_planes.propuesta,
			sga_planes.plan,
			sga_planes.estado,
			sga_planes.tipo_plan INTO _propuesta, _plan, _estado_plan, _tipo_plan
	FROM	sga_planes_versiones,
			sga_planes
	WHERE	sga_planes_versiones.plan = sga_planes.plan AND
			sga_planes_versiones.plan_version = OLD.plan_version;

	-- Si se esta quitado un elemento a un plan de tipo "Personalizado" o "Convenio" en estado "Activo no Vigente" o "Activo Vigente"...
	IF (_tipo_plan = 'Personalizado' OR _tipo_plan = 'Convenio') AND (_estado_plan = 'A' OR _estado_plan = 'V') THEN
		-- Se excluye el plan en las comisiones del elemento.
		DELETE
		FROM	sga_comisiones_propuestas
		USING	sga_comisiones,
				sga_elementos_revision
		WHERE	sga_comisiones_propuestas.comision = sga_comisiones.comision AND
				sga_comisiones.elemento = sga_elementos_revision.elemento AND
				sga_comisiones_propuestas.propuesta = _propuesta AND
				sga_comisiones_propuestas.plan = _plan AND
				sga_elementos_revision.elemento_revision = OLD.elemento_revision;

		-- Se excluye el plan en las mesas de examen del elemento.
		DELETE
		FROM	sga_mesas_examen_propuestas
		USING	sga_mesas_examen,
				sga_llamados_mesa,
				sga_elementos_revision
		WHERE	sga_mesas_examen_propuestas.mesa_examen = sga_mesas_examen.mesa_examen AND
				sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen AND
				sga_mesas_examen.elemento = sga_elementos_revision.elemento AND
				sga_mesas_examen_propuestas.propuesta = _propuesta AND
				sga_mesas_examen_propuestas.plan = _plan AND
				sga_elementos_revision.elemento_revision = OLD.elemento_revision;
	END IF;
	RETURN OLD;
END;
$$;
