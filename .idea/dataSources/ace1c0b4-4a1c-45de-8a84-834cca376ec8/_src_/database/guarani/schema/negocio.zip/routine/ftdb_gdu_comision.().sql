create function negocio.ftdb_gdu_comision() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
      -- Quito los derechos a los docentes de la responsabilidad a eliminar
      -- Solo comisiones vigentes
      DELETE FROM gdu_derechos_personas
        USING sga_comisiones,
             sga_periodos_lectivos,
             sga_periodos,
             sga_docentes_comision,
             sga_docentes
        WHERE sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo
         AND sga_periodos.periodo = sga_periodos_lectivos.periodo
         AND sga_periodos.fecha_fin >= CURRENT_DATE
         AND sga_docentes_comision.comision = sga_comisiones.comision
         AND sga_docentes_comision.responsabilidad = OLD.responsabilidad
         AND sga_docentes.docente = sga_docentes_comision.docente
         AND gdu_derechos_personas.derecho = OLD.derecho
         AND gdu_derechos_personas.entidad = sga_comisiones.entidad
         AND gdu_derechos_personas.persona = sga_docentes.persona;
 
    RETURN OLD;
  END;
$$;
