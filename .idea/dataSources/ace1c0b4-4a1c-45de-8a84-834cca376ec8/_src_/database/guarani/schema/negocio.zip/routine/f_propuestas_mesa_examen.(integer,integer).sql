create function negocio.f_propuestas_mesa_examen(pmesaexamen integer, ptiponombre integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   /*
     pTipoNombre =  1 - Nombre Largo  / 2 - Nombre Abreviado de la propuesta /3 - Id de la propuesta / 4 - Codigo de la propuesta.
   */
   cnt := 0;	
   _retorno := '';
		
  -- Recupero el nombre de las propuestas de mesa de examen
  FOR cur1 IN SELECT DISTINCT 
                     sga_propuestas.propuesta as propuesta, 
                     sga_propuestas.codigo as codigo, 
                     sga_propuestas.nombre as nombre, 
                     sga_propuestas.nombre_abreviado as nombre_abreviado
  		FROM sga_mesas_examen_propuestas, sga_propuestas
                WHERE sga_mesas_examen_propuestas.mesa_examen = pMesaExamen
                AND sga_mesas_examen_propuestas.propuesta = sga_propuestas.propuesta
  LOOP
      IF cnt > 0 THEN		
           _retorno :=  _retorno || '/';
      END IF;

      IF pTipoNombre = 1 THEN
         _retorno :=  _retorno || cur1.nombre;
      ELSEIF pTipoNombre = 2 THEN
         _retorno :=  _retorno || cur1.nombre_abreviado;
      ELSEIF pTipoNombre = 3 THEN
         _retorno :=  _retorno || cast(cur1.propuesta as text);
      ELSEIF pTipoNombre = 4 THEN
         _retorno :=  _retorno || cur1.codigo;
      ELSE
         _retorno :=  _retorno || cur1.nombre;
      END IF;
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
