create function negocio.f_tutores_tesis(_tesis integer, pmostrarrol boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _tutores text;
  cur1 record;
        
  BEGIN
  
   _tutores := '';
		
  -- Recupero el nombre de los tutores
  FOR cur1 IN SELECT vw_personas.apellido_nombres,
  					 sga_tesis_roles_tutor.nombre as nombre_rol
  					FROM sga_tesis_tutores, sga_tesis_roles_tutor, vw_personas
  	                WHERE sga_tesis_tutores.tesis = _tesis
  	                AND sga_tesis_tutores.persona = vw_personas.persona
  	                AND sga_tesis_tutores.rol_tutor = sga_tesis_roles_tutor.rol_tutor
			ORDER BY vw_personas.apellido_nombres
  LOOP
		IF pMostrarRol THEN
     		_tutores :=  _tutores || ' - ' || cur1.apellido_nombres || ' (' || cur1.nombre_rol || ')';
   		ELSE
     		_tutores :=  _tutores || ' - ' || cur1.apellido_nombres;
   		END IF;  
      

  END LOOP;

  _tutores := trim(leading ' - ' from _tutores);
	
  RETURN _tutores;
    
END;
$$;
