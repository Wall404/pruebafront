create function negocio.unpaz_f_criterio_cursada_aprobada(_alumno integer, _elemento integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _res character(1);

BEGIN
	_res := 'R';
	
	SELECT sga_actas_detalle.resultado INTO _res
	FROM negocio.sga_comisiones
	JOIN negocio.sga_actas on (sga_comisiones.comision = sga_actas.comision)
	JOIN negocio.sga_actas_detalle on (sga_actas.id_acta = sga_actas_detalle.id_acta)
	where sga_actas_detalle.alumno = _alumno
	and sga_comisiones.elemento = _elemento
	and sga_actas.origen = 'R'
	AND sga_actas_detalle.fecha_vigencia > now()
	and sga_actas_detalle.rectificado = 'N'
	and sga_actas_detalle.estado = 'A'
	ORDER BY fecha DESC
	LIMIT 1;

/*LAURA: acá me parece que está retornando al revés*/
/* Listo */
	IF _res = 'A' THEN
	-- Aprobo la actividad
	RETURN 0;
	ELSE
	-- No la aprobo
	RETURN 1;
	END IF;
END;
$$;
