create function negocio.f_nombre_propuesta_mesa_examen(pmesaexamen integer, ptipo integer, pmostrarcodigo boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _nombre  text;
  cur1 record;
  
        
BEGIN
   cnt := 0;	
   _nombre := '';

  -- Recupero el nombre de la propuesta asociada a la mesa de examen
  FOR cur1 IN SELECT DISTINCT 
                     CASE pTipo
                       WHEN 1 THEN p.nombre
                       WHEN 2 THEN p.nombre_abreviado
                     END as nombre,
                     p.codigo 
                FROM sga_mesas_examen_propuestas as mep,
                     sga_propuestas as p
               WHERE mep.mesa_examen = pMesaExamen
                 AND p.propuesta = mep.propuesta
  LOOP
      IF cnt = 0 THEN
        _nombre := cur1.nombre;
      ELSE
        _nombre := _nombre || ' - ' || cur1.nombre;
      END IF;
      IF pMostrarCodigo THEN
        _nombre := _nombre || ' (' || cur1.codigo || ')';
      END IF;      
      
      cnt := cnt + 1;
  END LOOP;

  RETURN _nombre;
END;
$$;
