create function negocio.f_encuestas_subcomisiones(pperiodolectivo integer, pcomisionin integer, OUT pcomision integer, OUT pcombinaciones integer[]) returns SETOF record
LANGUAGE plpgsql
AS $$
DECLARE 
 cur_comision RECORD;
 cur_tipos RECORD;
 tipos_clase int[];
 combinacion_subc int[];
 i int;

BEGIN

  -- Recorro las comisiones del periodo lectivo o la comision pasada por parametro
  FOR cur_comision IN (SELECT comision 
                         FROM sga_comisiones 
                        WHERE (pComisionIN IS NOT NULL AND sga_comisiones.comision = pComisionIN ) OR
                              (pPeriodoLectivo IS NOT NULL AND sga_comisiones.periodo_lectivo = pPeriodoLectivo)
                       ORDER BY comision)
  LOOP
	i := 1;
	tipos_clase := ARRAY[0];
	
	-- Recupera los distintos tipos de clases de las subcomisiones de una comision ordenadas por tipo de clase
        -- Ordeno descendente por la recursividad, para que luego aparezca en forma ascendente (asi se recuperan las subcomisiones en las que se
        -- inscriben los alumnos y se recuperan con f_encuestas_subcom_alumnos()
	FOR cur_tipos IN (SELECT DISTINCT tipo_clase FROM sga_subcomisiones WHERE sga_subcomisiones.comision = cur_comision.comision ORDER BY tipo_clase DESC)
	LOOP
	  tipos_clase[i] := cur_tipos.tipo_clase;
	  i := i + 1;
	END LOOP;

	-- Devuelvo cada combinacion de subcomisiones por tipo de clase de una comision.
	-- El array estará ordenado por subcomisiones segun el id de tipo de clase de cada una (de menor a mayor)
	FOR combinacion_subc IN SELECT * FROM f_armar_comb(cur_comision.comision, tipos_clase, 1 )
	LOOP
		pComision      := cur_comision.comision;
		pCombinaciones := combinacion_subc;
		RETURN NEXT;
	END LOOP;
  END LOOP;
END
$$;
