CREATE VIEW vw_condiciones AS SELECT sga_propuestas.propuesta,
    sga_propuestas.codigo AS propuesta_codigo,
    sga_propuestas.nombre AS propuesta_nombre,
    sga_planes.plan,
    sga_planes.codigo AS plan_codigo,
    sga_planes.nombre AS plan_nombre,
    sga_planes_versiones.plan_version,
    sga_planes_versiones.version AS version_codigo,
    sga_planes_versiones.nombre AS version_nombre,
    sga_condiciones.condicion,
    sga_condiciones.entidad AS condicion_entidad,
    sga_condiciones.condicion_tipo,
    sga_condiciones_tipos.nombre AS condicion_tipo_nombre,
    sga_condiciones_grupos.grupo_condicion,
    sga_condiciones_grupos.orden AS grupo_orden,
    sga_condiciones_requisitos.requisito_condicion,
    sga_condiciones_requisitos.operador_not,
    sga_condiciones_requisitos.tipo,
    sga_condiciones_requisitos.orden,
    sga_condiciones_requisitos.entidad,
    sga_elementos.elemento,
    sga_elementos.codigo AS elemento_codigo,
    sga_elementos.nombre AS elemento_nombre,
    sga_condiciones_requisitos.estado,
    sga_estados.nombre AS estado_nombre,
    sga_requisitos.requisito,
    sga_requisitos.nombre AS requisito_nombre,
    sga_condiciones_requisitos.regla,
    sga_condiciones_requisitos.parametros
   FROM negocio.sga_condiciones,
    negocio.sga_condiciones_tipos,
    negocio.sga_condiciones_grupos,
    ((((negocio.sga_condiciones_requisitos
     LEFT JOIN negocio.sga_elementos ON (((sga_elementos.entidad = sga_condiciones_requisitos.entidad) AND (sga_condiciones_requisitos.tipo = 'E'::bpchar))))
     LEFT JOIN negocio.sga_requisitos ON (((sga_requisitos.requisito = sga_condiciones_requisitos.requisito) AND (sga_condiciones_requisitos.tipo = 'R'::bpchar))))
     LEFT JOIN negocio.sga_reglas ON ((sga_reglas.regla = sga_condiciones_requisitos.regla)))
     LEFT JOIN negocio.sga_estados ON ((sga_estados.estado = sga_condiciones_requisitos.estado))),
    negocio.sga_planes_versiones,
    negocio.sga_planes,
    negocio.sga_propuestas
  WHERE ((((((sga_condiciones_tipos.condicion_tipo = sga_condiciones.condicion_tipo) AND (sga_planes_versiones.plan_version = sga_condiciones.plan_version)) AND (sga_condiciones_grupos.condicion = sga_condiciones.condicion)) AND (sga_condiciones_requisitos.grupo_condicion = sga_condiciones_grupos.grupo_condicion)) AND (sga_planes.propuesta = sga_propuestas.propuesta)) AND (sga_planes_versiones.plan = sga_planes.plan))
  ORDER BY sga_propuestas.propuesta, sga_planes.plan, sga_condiciones.plan_version, sga_condiciones.condicion_tipo, sga_condiciones_grupos.orden, sga_condiciones_grupos.grupo_condicion, sga_condiciones_requisitos.orden;
