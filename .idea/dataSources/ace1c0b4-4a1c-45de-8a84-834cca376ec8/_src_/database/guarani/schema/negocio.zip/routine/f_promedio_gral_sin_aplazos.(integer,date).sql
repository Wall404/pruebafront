create function negocio.f_promedio_gral_sin_aplazos(_alumno integer, _fecha date) returns numeric
LANGUAGE plpgsql
AS $$
DECLARE 
  _promedio numeric(8,3);
        
BEGIN
  
  -- Recupero el promedio general sin aplazos.
  _promedio := f_promedio(_alumno, _fecha, NULL, 'N');

  -- Retorno el promedio
  RETURN _promedio;
    
END;
$$;
