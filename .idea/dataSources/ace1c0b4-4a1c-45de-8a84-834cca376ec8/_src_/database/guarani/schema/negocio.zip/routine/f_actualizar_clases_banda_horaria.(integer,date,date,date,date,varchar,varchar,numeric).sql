create function negocio.f_actualizar_clases_banda_horaria(pasignacion integer, pfechadesdeant date, pfechahastaant date, pfechadesde date, pfechahasta date, pperiodicidad character varying, pdiasemana character varying, pcantidadhoras numeric) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt  integer;
  cur_bh record;
  _fecha_desde date;
  _fecha_hasta date;
  _cant_clases integer;
    
BEGIN
  cnt := 0;
  

  -- Declaro un cursor para recuperar las bandas horarias asociadas a la asignacion, puede haber mas de una si hay comisiones
  -- que comparten bandas horarias (asignaciones)
  FOR cur_bh IN  SELECT banda_horaria 
                   FROM sga_comisiones_bh
                  WHERE asignacion = pAsignacion
  LOOP    
  
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- BORRO CLASES
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Se corrió la fecha de inicio, debo eliminar las clases anteriores a la fecha de inicio nueva
    IF pFechaDesdeAnt < pFechaDesde THEN
      DELETE FROM sga_clases 
         WHERE sga_clases.banda_horaria = cur_bh.banda_horaria
           AND sga_clases.fecha < pFechaDesde;       
    END IF;

    IF pFechaHasta < pFechaHastaAnt THEN
      DELETE FROM sga_clases 
         WHERE sga_clases.banda_horaria = cur_bh.banda_horaria
           AND sga_clases.fecha > pFechaHasta;       
    END IF;
    
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- CREO CLASES
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Si adelanto la fecha de inicio, entonces creo las clases faltantes.
    IF pFechaDesde < pFechaDesdeAnt THEN
      _fecha_hasta := pFechaDesdeAnt - 1; -- creo clases hasta el dia anterior a la fecha de inicio anterior.
      _cant_clases := f_crear_clases_banda_horaria(cur_bh.banda_horaria, pFechaDesde, _fecha_hasta, pPeriodicidad, pDiaSemana, pCantidadHoras);
    END IF;
    
    -- Si extiendo la asignacion, creo las creo las clases faltantes.
    IF pFechaHasta > pFechaHastaAnt THEN
      _fecha_desde := pFechaHastaAnt + 1; -- sumo un dia a la fecha fin anterior
      _cant_clases := f_crear_clases_banda_horaria(cur_bh.banda_horaria, _fecha_desde, pFechaHasta, pPeriodicidad, pDiaSemana, pCantidadHoras);
    END IF;

    
  END LOOP; -- Bandas horarias
  
  -- Retorno cantidad de clases generadas
  RETURN cnt;
    
END;
$$;
