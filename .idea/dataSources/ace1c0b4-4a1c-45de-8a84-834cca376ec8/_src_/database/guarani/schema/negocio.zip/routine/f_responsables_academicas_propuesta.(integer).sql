create function negocio.f_responsables_academicas_propuesta(ppropuesta integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _ra text;
  cur1 record;

BEGIN
  cnt := 0;
  _ra := NULL;

  -- Recupero el nombre de las RAs
  FOR cur1 IN SELECT sga_responsables_academicas.nombre as nombre
                FROM sga_propuestas_ra,
                     sga_responsables_academicas
               WHERE sga_propuestas_ra.propuesta = pPropuesta
                 AND sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica
  LOOP
      IF cnt = 0 THEN
         _ra :=  cur1.nombre;
      ELSE
         _ra :=  _ra || ', ' || cur1.nombre;
      END IF;   
      cnt := cnt + 1;
  END LOOP;

  RETURN _ra;

END;
$$;
