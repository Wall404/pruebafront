create function negocio.ftua_sga_asignaciones() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _cant_clases Integer;
BEGIN

   -- Si cambió la fecha desde/hasta entonces actualizo las clases de las bandas horarias asociadas
   IF OLD.fecha_desde <> NEW.fecha_desde OR
      OLD.fecha_hasta <> NEW.fecha_hasta THEN
      _cant_clases := f_actualizar_clases_banda_horaria (NEW.asignacion, OLD.fecha_desde, OLD.fecha_hasta, NEW.fecha_desde, NEW.fecha_hasta, NEW.periodicidad, NEW.dia_semana, NEW.cantidad_horas);
   END IF;
   
   RETURN NEW;
END;
$$;
