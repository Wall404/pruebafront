create function negocio.f_generar_folio_fisico_acta(pacta integer) returns smallint
LANGUAGE plpgsql
AS $$
DECLARE 
  max_folio smallint;
  i smallint;
        
BEGIN
   max_folio  := 1;
  
  -- Recupero el maximo valor del folio
  SELECT Max(folio) INTO max_folio
    FROM sga_actas_detalle
   WHERE id_acta = pActa;
   
   IF max_folio IS NULL OR max_folio = 0 THEN
      -- No hay alumnos, entonces genero un folio.
      max_folio := 1;
   END IF;

  -- Inserto registros en sga_actas_folios.
  FOR i IN 1 .. max_folio  LOOP
    INSERT INTO sga_actas_folios (id_acta, folio) VALUES (pActa, i);
  END LOOP;
	
  RETURN max_folio;
    
END;
$$;
