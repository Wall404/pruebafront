create function negocio.f_insc_examen_eliminar(pinscripcion integer, pinterfaz integer) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno  type_retorno_inscripcion;
  _cnt Smallint;
  _fecha_baja Timestamp;
  _nro_transaccion_baja Integer;
  _flag_baja char(1);
  _insc sga_insc_examen%ROWTYPE;
  _MesaExamenNombre varchar(100);
  _puede_eliminarse boolean;


BEGIN
  
  -- Variables 
  cur_retorno.resultado := -1;
  cur_retorno.mensaje_param := NULL;
  _flag_baja := 'B'; 
  _nro_transaccion_baja := NULL;
  _cnt := 0;
  _MesaExamenNombre := '';
  _puede_eliminarse := true;

  -- ********************************************************************
  -- 1. Verifico que exista la inscripcion a dar de baja
  -- ********************************************************************
  SELECT * INTO _insc FROM sga_insc_examen WHERE inscripcion = pInscripcion;
   
  IF NOT FOUND THEN
    -- No existe la inscripción a dar de baja.
    cur_retorno.mensaje_indice := '800EXA_baja_insc_examen_no_existe_insc';
    RETURN cur_retorno;
  END IF;

  -- ********************************************************************
  -- 2. Verifico que este en fecha para ser eliminada 
  -- ********************************************************************
  SELECT f_mesa_con_tope_bajas_vigente(_insc.plan_version, _insc.llamado_mesa) INTO _puede_eliminarse;
  IF NOT _puede_eliminarse THEN
    -- Ya supero la fecha y hora para poder dar de baja la inscripción
    cur_retorno.mensaje_indice := '800EXA_baja_insc_examen_supero_tope_bajas';
    RETURN cur_retorno;
  END IF;  

  -- ********************************************************************
  -- 3. Verifico que no este incluida en un acta de examen
  -- ********************************************************************
  -- Acta Cerrada
  SELECT Count(*) INTO _cnt
    FROM sga_actas, sga_actas_detalle
    WHERE sga_actas.llamado_mesa = _insc.llamado_mesa
      AND sga_actas_detalle.id_acta = sga_actas.id_acta
      AND sga_actas_detalle.alumno = _insc.alumno
	  AND sga_actas.estado = 'C';
	  
  IF _cnt > 0 THEN
    SELECT sga_mesas_examen.nombre INTO _MesaExamenNombre 
      FROM sga_llamados_mesa, sga_mesas_examen
      WHERE sga_llamados_mesa.llamado_mesa = _insc.llamado_mesa
        AND sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen;
    
    cur_retorno.mensaje_indice := '800EXA_baja_insc_examen_acta';
    cur_retorno.mensaje_param  := _MesaExamenNombre;
    RETURN cur_retorno;
  END IF;

  -- Acta de Examen Abierta
  SELECT Count(*) INTO _cnt
    FROM sga_actas, sga_eval_detalle_examenes
    WHERE sga_actas.llamado_mesa = _insc.llamado_mesa
      AND sga_eval_detalle_examenes.id_acta = sga_actas.id_acta
      AND sga_eval_detalle_examenes.alumno = _insc.alumno
	  AND sga_actas.estado = 'A';
	  
  IF _cnt > 0 THEN
    SELECT sga_mesas_examen.nombre INTO _MesaExamenNombre 
      FROM sga_llamados_mesa, sga_mesas_examen
      WHERE sga_llamados_mesa.llamado_mesa = _insc.llamado_mesa
        AND sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen;
    
    cur_retorno.mensaje_indice := '800EXA_baja_insc_examen_acta';
    cur_retorno.mensaje_param  := _MesaExamenNombre;
    RETURN cur_retorno;
  END IF;

  -- ********************************************************************
  -- 3. Verifico que no este incluida en un acta de examen
  -- ********************************************************************
  SELECT Count(*) INTO _cnt
    FROM sga_actas, sga_actas_detalle
    WHERE sga_actas.llamado_mesa = _insc.llamado_mesa
      AND sga_actas_detalle.id_acta = sga_actas.id_acta
      AND sga_actas_detalle.alumno = _insc.alumno;
  IF _cnt > 0 THEN
    SELECT sga_mesas_examen.nombre INTO _MesaExamenNombre 
      FROM sga_llamados_mesa, sga_mesas_examen
      WHERE sga_llamados_mesa.llamado_mesa = _insc.llamado_mesa
        AND sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen;
    
    cur_retorno.mensaje_indice := '800EXA_baja_insc_examen_acta';
    cur_retorno.mensaje_param  := _MesaExamenNombre;
    RETURN cur_retorno;
  END IF;

-- Comienza la Transacción
BEGIN


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Doy de baja la inscripcion
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _fecha_baja := CURRENT_TIMESTAMP;
  _nro_transaccion_baja := (SELECT nextval('aud_nro_transaccion_seq')); 

  -- Inserto el registro en la tabla de log.
  INSERT INTO sga_insc_examen_log (
         inscripcion, llamado_mesa, alumno, plan_version, instancia, fuera_de_termino, autorizado_por, motivo_excepcion, exceptuado,
         estado, interfaz, fecha_inscripcion, nro_transaccion, operacion , nro_transaccion_log, fecha_operacion)
  VALUES (pInscripcion, _insc.llamado_mesa, _insc.alumno, _insc.plan_version, _insc.instancia, _insc.fuera_de_termino, _insc.autorizado_por, _insc.motivo_excepcion, _insc.exceptuado,
         _insc.estado, pInterfaz, _insc.fecha_inscripcion, _insc.nro_transaccion, _flag_baja, _nro_transaccion_baja, _fecha_baja);

  DELETE FROM sga_insc_examen WHERE inscripcion = pInscripcion;

  -- Bloque de excepciones. Sale por error.
  EXCEPTION 
      WHEN OTHERS THEN
        cur_retorno.mensaje_indice := '800EXA_baja_insc_examen_error_db';
        cur_retorno.sqlstate := SQLSTATE;
        cur_retorno.sqlerrm  := SQLERRM;
        RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- BAJA OK.
  -- Seteo valores para retorno
  cur_retorno.resultado       := 1;
  cur_retorno.mensaje_indice  := '800EXA_baja_insc_examen_ok';
  cur_retorno.mensaje_param   := cast(_nro_transaccion_baja as varchar);
  cur_retorno.inscripcion     := pInscripcion;
  cur_retorno.fecha           := _fecha_baja;
  cur_retorno.nro_transaccion := _nro_transaccion_baja;
  
  -- Retorno datos de la baja de la inscripcion
  RETURN cur_retorno;

END;
$$;
