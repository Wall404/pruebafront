create function negocio.f_mesas_vigentes_una_actividad(pactividad integer, ppropuesta integer, pplan integer, pplanversion integer, penperiodoinsc boolean, pubicacion integer) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE 
 cur_llamados_mesa RECORD;
BEGIN
/* Parametros:
  1. Actividad
  2. Propuesta del Alumno
  3. Plan del Alumno
  4. Version de Plan del Alumno
  5. Si debe estar dentro de un período de inscripción activo de mesas futuras
  6. Si solo rinde en la ubicacion del alumno, recibe la ubicacion.

*/
  -- Creo tabla temporal
  CREATE TEMP TABLE tmp_llamados (
     llamado_mesa integer, 
     mesa_examen integer, 
     periodo_insc integer, 
     periodo_inscripcion integer, 
     fecha_inicio timestamp, 
     tipo_fin integer,
     fecha_fin timestamp, 
     dias_previos_fin smallint,
     hs_previas_fin smallint,
     fecha date,
     fecha_hora_mesa timestamp
     ); 
  
  -- lleno tabla temporal con mesas de examen de la actividad, con fecha de examen igual o mayor a la actual
  -- y segun parametro que define que la mesa sea de la ubicación del alumno y si debe estar dentro de un periodo de inscripcion vigente o fuera de un período de insc vigente.
  INSERT INTO tmp_llamados (mesa_examen, llamado_mesa, periodo_insc, fecha_inicio, 
                            tipo_fin, fecha_fin, dias_previos_fin, hs_previas_fin, 
							periodo_inscripcion, fecha, fecha_hora_mesa)
    SELECT sga_mesas_examen.mesa_examen,
           sga_llamados_mesa.llamado_mesa, 
           sga_periodos_inscripcion_fechas.periodo_insc,
           sga_periodos_inscripcion_fechas.fecha_inicio,
           sga_periodos_inscripcion_fechas.tipo_fin,
           sga_periodos_inscripcion_fechas.fecha_fin,
           sga_periodos_inscripcion_fechas.dias_previos_fin,
           sga_periodos_inscripcion_fechas.hs_previas_fin,
           sga_periodos_inscripcion_fechas.periodo_inscripcion,
		   sga_llamados_mesa.fecha,
           CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp)
		   
      FROM sga_llamados_mesa,
           sga_llamados_turno,
           sga_mesas_examen,
           sga_mesas_examen_propuestas,
           sga_periodos_inscripcion_fechas,
           sga_periodos_inscripcion,
           sga_periodos_inscripcion_aplanado,
           sga_per_insc_ubicacion
    WHERE sga_llamados_mesa.fecha >= CURRENT_DATE
       AND sga_llamados_mesa.estado = 'A'
       AND sga_llamados_mesa.mesa_examen = sga_mesas_examen.mesa_examen
       AND sga_llamados_turno.llamado = sga_llamados_mesa.llamado
       AND sga_mesas_examen.elemento  = pActividad
       AND sga_mesas_examen_propuestas.mesa_examen = sga_mesas_examen.mesa_examen
       AND sga_mesas_examen_propuestas.propuesta = pPropuesta
       AND sga_mesas_examen_propuestas.plan      = pPlan
       AND sga_periodos_inscripcion.periodo = sga_llamados_turno.periodo
       AND sga_periodos_inscripcion.periodo_inscripcion = sga_periodos_inscripcion_fechas.periodo_inscripcion
       AND sga_periodos_inscripcion_fechas.habilitado = 'S'
       AND sga_periodos_inscripcion_aplanado.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc
       AND sga_periodos_inscripcion_aplanado.plan_version = pPlanVersion
       AND sga_per_insc_ubicacion.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion
       AND sga_per_insc_ubicacion.ubicacion = sga_mesas_examen.ubicacion
       AND (pUbicacion IS NULL OR (pUbicacion IS NOT NULL AND sga_mesas_examen.ubicacion = pUbicacion));  
       
  -- Verifico periodo de inscripcion del llamado o alguna excepcion de la mesa en el llamado.
  FOR cur_llamados_mesa IN (
    SELECT t.llamado_mesa as llamado_mesa
      FROM tmp_llamados as t
              LEFT JOIN sga_llamados_mesa_excep_perinsc as e ON e.periodo_insc = t.periodo_insc AND e.llamado_mesa = t.llamado_mesa
     WHERE CURRENT_TIMESTAMP >= COALESCE(e.fecha_inicio, t.fecha_inicio)
       AND ((-- fecha y hora actual se encuentre en un período de inscripcion de la mesa
            pEnPeriodoInsc = true AND 
             CURRENT_TIMESTAMP <= COALESCE(-- Excepciones
                                     CASE e.tipo_fin
                                       WHEN 1 THEN (CASE WHEN e.fecha_fin < t.fecha_hora_mesa THEN e.fecha_fin ELSE t.fecha_hora_mesa END)
                                       WHEN 2 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', e.dias_previos_fin, false)
                                       WHEN 3 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', e.dias_previos_fin, true)
                                       WHEN 4 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', e.hs_previas_fin, false)
                                       WHEN 5 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', e.hs_previas_fin, true)
                                       ELSE cast(NULL as timestamp)
                                     END,
                                     -- Periodo de inscripcion
                                     CASE t.tipo_fin
                                       WHEN 1 THEN (CASE WHEN t.fecha_fin < t.fecha_hora_mesa THEN t.fecha_fin ELSE t.fecha_hora_mesa END)
                                       WHEN 2 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', t.dias_previos_fin, false)
                                       WHEN 3 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', t.dias_previos_fin, true)
                                       WHEN 4 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', t.hs_previas_fin, false)
                                       WHEN 5 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', t.hs_previas_fin, true)
                                       ELSE cast(NULL as timestamp)
                                     END	
                                    )
             ) OR
            (-- Fuera de un periodo de inscripción
            pEnPeriodoInsc = false AND 
             CURRENT_TIMESTAMP > COALESCE(-- Excepciones
                                          CASE e.tipo_fin
                                            WHEN 1 THEN (CASE WHEN e.fecha_fin < t.fecha_hora_mesa THEN e.fecha_fin ELSE t.fecha_hora_mesa END)
                                            WHEN 2 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', e.dias_previos_fin, false)
                                            WHEN 3 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', e.dias_previos_fin, true)
                                            WHEN 4 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', e.hs_previas_fin, false)
                                            WHEN 5 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', e.hs_previas_fin, true)
                                            ELSE cast(NULL as timestamp)
                                          END,
                                          -- Periodo de inscripcion
                                          CASE t.tipo_fin
                                            WHEN 1 THEN (CASE WHEN t.fecha_fin < t.fecha_hora_mesa THEN t.fecha_fin ELSE t.fecha_hora_mesa END)
                                            WHEN 2 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', t.dias_previos_fin, false)
                                            WHEN 3 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'D', t.dias_previos_fin, true)
                                            WHEN 4 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', t.hs_previas_fin, false)
                                            WHEN 5 THEN get_fecha_fin_examen(cast(t.fecha_inicio as timestamp), t.fecha_hora_mesa, 'H', t.hs_previas_fin, true)
                                            ELSE cast(NULL as timestamp)
                                          END	
                                          )
             ) -- fuera del periodo de insc.
            ) 
       -- MODALIDAD
       AND EXISTS (SELECT 1 FROM sga_per_insc_modalidad
                    WHERE sga_per_insc_modalidad.periodo_inscripcion = t.periodo_inscripcion
                      AND sga_per_insc_modalidad.modalidad IN (SELECT modalidad FROM sga_mesas_examen_modalidad WHERE sga_mesas_examen_modalidad.mesa_examen = t.mesa_examen)
                   )
  ) LOOP
    
    -- Retorno la mesa de examen instanciada en un llamado. 
    RETURN NEXT cur_llamados_mesa.llamado_mesa;
  END LOOP;
         
  -- Borro la tabla temporal       
  DROP TABLE tmp_llamados;
END
$$;
