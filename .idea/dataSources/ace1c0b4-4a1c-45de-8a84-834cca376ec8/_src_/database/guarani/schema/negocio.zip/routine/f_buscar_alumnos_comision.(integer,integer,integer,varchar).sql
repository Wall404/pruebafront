create function negocio.f_buscar_alumnos_comision(pcomision integer, palumnospagina integer, porden integer, palumno character varying) returns SETOF negocio.type_buscar_alumnos_comision
LANGUAGE plpgsql
AS $$
DECLARE 
	_pagina integer;
	_renglon integer;
	cur record;
	cur_retorno type_buscar_alumnos_comision;
BEGIN
	_pagina := 1;
	_renglon := 1;
	FOR cur IN	SELECT	sga_alumnos.alumno,
						vw_personas.apellido,
						vw_personas.nombres
				FROM	sga_comisiones
						JOIN sga_evaluaciones ON sga_comisiones.entidad = sga_evaluaciones.entidad
						JOIN sga_evaluaciones_tipos ON (sga_evaluaciones.evaluacion_tipo = sga_evaluaciones_tipos.evaluacion_tipo AND sga_evaluaciones_tipos.automatica = 'S' AND sga_evaluaciones_tipos.aplica_a = 'C')
						JOIN sga_eval_detalle_cursadas ON sga_evaluaciones.evaluacion = sga_eval_detalle_cursadas.evaluacion
       					LEFT JOIN sga_insc_cursada ON (sga_comisiones.comision = sga_insc_cursada.comision AND sga_eval_detalle_cursadas.alumno = sga_insc_cursada.alumno),
						sga_alumnos,
						vw_personas
				WHERE	sga_eval_detalle_cursadas.alumno = sga_alumnos.alumno AND
						sga_alumnos.persona = vw_personas.persona AND
						sga_comisiones.comision = pComision AND
						(sga_insc_cursada.estado IS NULL OR sga_insc_cursada.estado = 'A')
	LOOP
		IF _renglon > pAlumnosPagina THEN
			_renglon := 1;
			_pagina := _pagina + 1;
		END IF;
		IF cur.apellido ILIKE '%' || pAlumno || '%' THEN
			cur_retorno.alumno := cur.alumno;
			cur_retorno.apellido := cur.apellido;
			cur_retorno.nombres := cur.nombres;
			cur_retorno.pagina := _pagina;
			RETURN NEXT cur_retorno;
		END IF;
		_renglon := _renglon + 1;
	END LOOP;
END;
$$;
