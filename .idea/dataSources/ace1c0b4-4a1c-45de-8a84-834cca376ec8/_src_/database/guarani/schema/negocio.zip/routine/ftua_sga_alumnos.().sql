create function negocio.ftua_sga_alumnos() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE 
  _rtn_equiv_auto type_retorno_funcion;
  _plan_anterior integer;
  _plan_nuevo integer;
BEGIN
    
    -- Cambio de plan de estudios o de version de plan de estudios.
    IF OLD.plan_version <> NEW.plan_version THEN
    
        -- Recupero plan anterior y plan actual
        SELECT plan INTO _plan_anterior FROM sga_planes_versiones WHERE plan_version = OLD.plan_version;
        SELECT plan INTO _plan_nuevo FROM sga_planes_versiones WHERE plan_version = NEW.plan_version;
        
        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        -- Actualización de asignacion de optativas en genericas en la nueva version del plan de estudios.
        -- Solo para el caso que el plan sea el mismo, solo cambio de version de plan de estudios.
        -- Se asignan las optativas en genericas, si existe la generica en la nueva version del plan de estudios.
        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        IF _plan_anterior = _plan_nuevo THEN

            INSERT INTO sga_alumnos_optativas (alumno, plan_version, generica, optativa)
                 SELECT alumno, NEW.plan_version, generica, optativa
                   FROM sga_alumnos_optativas
                  WHERE alumno = NEW.alumno
                    AND plan_version = OLD.plan_version
                    AND EXISTS (SELECT 1
                                  FROM vw_optativas_plan as opt
                                 WHERE opt.plan_version      = NEW.plan_version
                                   AND opt.elemento_generica = sga_alumnos_optativas.generica
                                   AND opt.elemento          = sga_alumnos_optativas.optativa
                                );
        END IF;

        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        -- Otorgar Equivalencias Automáticas
        -- Si se cambia de plan de estudios o de version de plan de estudios, entonces aplico equivalencias
        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        IF _plan_anterior = _plan_nuevo THEN 
           _rtn_equiv_auto := f_equiv_otorgar_equivalencias('CAMBIO_DE_VERSION', NEW.Alumno, OLD.propuesta, _plan_anterior, OLD.plan_version, NULL);
        ELSE
           _rtn_equiv_auto := f_equiv_otorgar_equivalencias('CAMBIO_DE_PLAN', NEW.Alumno, OLD.propuesta, _plan_anterior, OLD.plan_version, NULL);
        END IF;   
        -- +++++++++++++++++++++++++++ Fin aplicar matrices de equivalencias +++++++++++++++++++++++++++++++

    END IF;
    
    RETURN NEW;
  END;
$$;
