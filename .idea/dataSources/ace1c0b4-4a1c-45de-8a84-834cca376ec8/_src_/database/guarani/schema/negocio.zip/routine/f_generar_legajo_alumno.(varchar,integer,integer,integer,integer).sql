create function negocio.f_generar_legajo_alumno(_unico_legajo character varying, _inscripcion integer, _persona integer, _propuesta integer, _ubicacion integer) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
  otras_propuestas record;
  cursa_otra_propuesta boolean;
  nuevo_legajo varchar(20);
BEGIN

 nuevo_legajo := NULL;
 cursa_otra_propuesta := false;
 
 -- Si el parametro dice que el legajo se repite por cada propuesta del alumno.
 IF _unico_legajo = 'S' THEN
    -- busco otras propuestas en las que este la persona, recupero la primera que encuentre y tomo el nro de legajo
    FOR otras_propuestas IN SELECT legajo FROM sga_alumnos 
                             WHERE persona = _persona 
                               AND propuesta <> _propuesta 
                               AND legajo IS NOT NULL
    LOOP
      nuevo_legajo := otras_propuestas.legajo;
      cursa_otra_propuesta := true;
      EXIT;
    END LOOP;
 END IF;

 -- Genero un nuevo número de legajo.
 IF _unico_legajo = 'N' OR NOT cursa_otra_propuesta  THEN
   nuevo_legajo := (SELECT nextval('nro_legajo_alumno_seq'))::varchar;

   IF nuevo_legajo IS NULL THEN
      nuevo_legajo := '1';
   END IF;
 END IF;

 -- Retorno el Nro de Legajo de Alumno.
 RETURN nuevo_legajo;
END;
$$;
