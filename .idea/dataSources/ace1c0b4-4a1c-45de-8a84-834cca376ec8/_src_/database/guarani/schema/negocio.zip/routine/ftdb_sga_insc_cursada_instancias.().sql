create function negocio.ftdb_sga_insc_cursada_instancias() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _alumno integer;
  DECLARE _comision integer;
  DECLARE _evaluacion integer;
  DECLARE _cursada smallint;
  DECLARE _promocion smallint;
  DECLARE cur_evaluaciones_parciales record;
  BEGIN
  	-- Instancias: 1-Cursadas / 2-Promocion
    
    -- Recupero la evaluacion automatica de la comision.
    SELECT sga_insc_cursada.alumno, sga_insc_cursada.comision, sga_evaluaciones.evaluacion INTO _alumno, _comision, _evaluacion
    FROM sga_insc_cursada,
         sga_comisiones, 
         sga_evaluaciones,
         sga_evaluaciones_tipos
    WHERE sga_insc_cursada.inscripcion = OLD.inscripcion
      AND sga_comisiones.comision     = sga_insc_cursada.comision
      AND sga_evaluaciones.entidad    = sga_comisiones.entidad
      AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
      AND sga_evaluaciones_tipos.automatica = 'S'; -- Generación Automática
            
    IF _evaluacion IS NOT NULL THEN
       -- Verifico si tiene registro en el detalle de las evaluaciones y si esta inscripto a otra instancia
       SELECT instancia_cursada, instancia_promocion
         INTO _cursada, _promocion
         FROM sga_eval_detalle_cursadas
         WHERE sga_eval_detalle_cursadas.evaluacion = _evaluacion
           AND sga_eval_detalle_cursadas.alumno     = _alumno;
       
       -- Borro el registro del detalle de la evaluacion automática.    
       -- Instancas: 1-Regular / 2-Promocion
       IF (_cursada IS NULL AND _promocion IS NULL) OR 
          (OLD.instancia = 1 AND _promocion = 0) OR 
          (OLD.instancia = 2 AND _cursada = 0)	THEN          
          DELETE FROM sga_eval_detalle_cursadas WHERE evaluacion = _evaluacion AND alumno = _alumno; 
       END IF;

       -- Cursadas       
       IF OLD.instancia = 1 THEN
         UPDATE sga_eval_detalle_cursadas
           SET instancia_cursada = 0,
           		 nota_cursada = NULL,	 
           		 resultado_cursada = NULL	 
           WHERE evaluacion = _evaluacion 
             AND alumno     = _alumno; 
       END IF;
       
       -- Promociones
       IF OLD.instancia = 2 THEN
         UPDATE sga_eval_detalle_cursadas
           SET instancia_promocion = 0,
           		 nota_promocion = NULL,	 
           		 resultado_promocion = NULL	 
           WHERE evaluacion = _evaluacion 
             AND alumno     = _alumno; 
       END IF;
          
    END IF;	 -- evaluacion.    

    -- Evaluaciones parciales.
	FOR cur_evaluaciones_parciales IN
		SELECT	sga_evaluaciones.evaluacion,
				sga_evaluaciones.estado
		FROM	sga_comisiones,
				sga_evaluaciones,
				sga_evaluaciones_tipos,
				sga_evaluaciones_instancias,
				sga_eval_detalle
		WHERE	sga_comisiones.entidad = sga_evaluaciones.entidad AND
				sga_evaluaciones.evaluacion_tipo = sga_evaluaciones_tipos.evaluacion_tipo AND
				sga_evaluaciones.evaluacion = sga_evaluaciones_instancias.evaluacion AND
				sga_evaluaciones.evaluacion = sga_eval_detalle.evaluacion AND
				sga_comisiones.comision = _comision AND
				sga_evaluaciones_instancias.instancia = OLD.instancia AND
				NOT EXISTS (SELECT * FROM sga_evaluaciones_instancias as eval_inst WHERE eval_inst.evaluacion = sga_evaluaciones.evaluacion AND eval_inst.instancia <> OLD.instancia) AND
				sga_eval_detalle.alumno = _alumno AND
				sga_evaluaciones.estado <> 'B' AND
				sga_evaluaciones_tipos.automatica = 'N'
	LOOP
		IF cur_evaluaciones_parciales.estado = 'A' THEN
			DELETE
			FROM	sga_eval_detalle
			WHERE	evaluacion = cur_evaluaciones_parciales.evaluacion AND
					alumno = _alumno; 
		ELSE
			UPDATE	sga_eval_detalle
			SET		estado = 'I'
			WHERE	evaluacion = cur_evaluaciones_parciales.evaluacion AND
					alumno = _alumno;
			INSERT INTO	sga_movimientos_ha
				(motivo_movimiento, evaluacion, alumno, observaciones)
			VALUES
				(2, cur_evaluaciones_parciales.evaluacion, _alumno, 'Invalidación por baja de instancia en la inscripción a cursada para el alumno.');
		END IF;
	END LOOP;

    RETURN OLD;
  END;
$$;
