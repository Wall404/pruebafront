create function negocio.f_armar_comb(pcomision integer, ptiposclases integer[], ptiposid integer) returns SETOF integer[]
LANGUAGE plpgsql
AS $$
DECLARE 

cur_subco RECORD;
j int;
k int;
subco2 int[];


BEGIN
  FOR cur_subco IN (SELECT subcomision FROM sga_subcomisiones 
                 WHERE sga_subcomisiones.comision = pComision 
                   AND sga_subcomisiones.tipo_clase = pTiposClases[pTiposId]
                ORDER BY tipo_clase, subcomision)
  LOOP
	IF (pTiposId < array_length(pTiposClases,1)) THEN
	   FOR subco2 IN (SELECT * FROM f_armar_comb(pComision, pTiposClases, pTiposId + 1))
	   LOOP
             k := array_length(subco2,1) + 1;
             subco2[k] := cur_subco.subcomision;
	     RETURN NEXT subco2; 
	     -- RETURN NEXT cur_subco.subcomision::text || ' - ' || subco2::text; 
	   END LOOP;
	ELSE
	   RETURN NEXT array[cur_subco.subcomision]; 
	END IF;
  END LOOP;

END
$$;
