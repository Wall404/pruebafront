create function negocio.get_ultima_cursada_valida(palumno integer, pactividad integer) returns text
LANGUAGE plpgsql
AS $fun$
DECLARE 
  _retorno  text;
  cur1 record;
        
  BEGIN
   _retorno := '$PARAM$$PARAM$$PARAM$$PARAM$$PARAM$$PARAM$$PARAM$';
		
  -- Recupero las cursadas y equivalencias de regularidad del alumno en la actividad
  FOR cur1 IN SELECT  
                      vw_regularidades.anio_academico as anio_academico,
                      vw_regularidades.periodo_lectivo_nombre as periodo_lectivo,
                      to_char(vw_regularidades.fecha, 'DD/MM/YYYY') as fecha_regular ,
                      COALESCE(sga_cond_regularidad.nombre, '') as condicion_regularidad,
                      COALESCE(vw_regularidades.nota, '') as nota,
                      vw_regularidades.resultado_descripcion as resultado_desc,
                      COALESCE(sga_ubicaciones.nombre, '') as ubicacion,
                      COALESCE(sga_catedras.nombre, '') as catedra
                  FROM vw_regularidades 
                          LEFT JOIN sga_cond_regularidad ON vw_regularidades.cond_regularidad = sga_cond_regularidad.cond_regularidad,
                       sga_comisiones
                          LEFT JOIN sga_ubicaciones ON sga_comisiones.ubicacion = sga_ubicaciones.ubicacion
                          LEFT JOIN sga_catedras ON  sga_comisiones.catedra = sga_catedras.catedra
                  WHERE vw_regularidades.alumno = pAlumno
                    AND vw_regularidades.elemento = pActividad
                    AND sga_comisiones.comision = vw_regularidades.comision
                    AND vw_regularidades.es_vigente = 1
                    AND vw_regularidades.resultado = 'A' -- Aprobado
                  ORDER BY vw_regularidades.fecha DESC
  LOOP
      -- Recupero datos de la ultima cursada aprobada vigente
      _retorno := cur1.anio_academico::text || '$PARAM$' || cur1.periodo_lectivo || '$PARAM$' ||cur1.condicion_regularidad || '$PARAM$' ||cur1.fecha_regular || '$PARAM$' || cur1.condicion_regularidad;
      _retorno := _retorno || '$PARAM$' ||cur1.nota || '$PARAM$' || cur1.resultado_desc || '$PARAM$' ||cur1.ubicacion || '$PARAM$' || cur1.catedra;
      EXIT;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$fun$;
