create function negocio.get_horas_trabajo_araucano(ppersona integer, pfecha date) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE _dato_censal_eco INTEGER;
	DECLARE _fecha DATE;
	DECLARE _horas_trabajo VARCHAR(4);
BEGIN
	_dato_censal_eco := NULL;
	_fecha := COALESCE(pFecha, CURRENT_DATE);

	-- Se busca el dato censal más próximo anterior a la fecha.
	SELECT		his_datos_economicos.dato_censal_eco INTO _dato_censal_eco
	FROM		his_datos_censales
				JOIN his_datos_economicos ON his_datos_censales.dato_censal = his_datos_economicos.dato_censal
	WHERE		his_datos_censales.persona = pPersona AND
				DATE(his_datos_economicos.fecha_alta) <= _fecha
	ORDER BY	his_datos_economicos.fecha_alta DESC
	LIMIT		1;

	IF _dato_censal_eco IS NULL THEN
		-- Busco el dato censal más próximo siguiente a la fecha.
			SELECT		his_datos_economicos.dato_censal_eco INTO _dato_censal_eco
			FROM		his_datos_censales
						JOIN his_datos_economicos ON his_datos_censales.dato_censal = his_datos_economicos.dato_censal
			WHERE		his_datos_censales.persona = pPersona AND
						DATE(his_datos_economicos.fecha_alta) > _fecha
			ORDER BY	his_datos_economicos.fecha_alta
			LIMIT		1;
	END IF;

	_horas_trabajo := 'NT';
	IF _dato_censal_eco IS NOT NULL THEN
		SELECT	CASE
					WHEN his_datos_economicos.trabajo_existe IS NULL OR (his_datos_economicos.trabajo_existe = 1 AND his_datos_economicos.trabajo_hora_sem IS NULL) THEN 'NDI'
					WHEN his_datos_economicos.trabajo_existe = 1 AND (his_datos_economicos.trabajo_hora_sem = 1 OR his_datos_economicos.trabajo_hora_sem = 2) THEN '20'
					WHEN his_datos_economicos.trabajo_existe = 1 AND his_datos_economicos.trabajo_hora_sem = 3 THEN '2035'
					WHEN his_datos_economicos.trabajo_existe = 1 AND his_datos_economicos.trabajo_hora_sem = 4 THEN '+35'
					WHEN his_datos_economicos.trabajo_existe = 4 THEN 'NDI'
					ELSE 'NT'
				END INTO _horas_trabajo
		FROM	his_datos_economicos
		WHERE	his_datos_economicos.dato_censal_eco = _dato_censal_eco;
	END IF;

	RETURN _horas_trabajo;
END;
$$;
