create function negocio.ftia_mdp_personas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

   -- Agrego el perfil de acceso "Cursos" a la persona.
   INSERT INTO mdp_personas_tipo_usuario (persona, tipo_usuario) VALUES (NEW.persona, 'Cursos');

   RETURN NEW;
END;
$$;
