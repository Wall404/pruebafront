create function negocio.f_acta_cantidad_alumnos(pacta integer, pdevolver integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _cant_alumnos smallint;
  _estado char(1);
  _origen char(1);
  _query text;
  _cur record;
        
BEGIN
 /* 
   pDevolver: 1-Cantidad de Alumnos / 2- Cantidad de alumnos sin nota / 3-Cantidad de alumnos con notas  
  */

   _cant_alumnos := 0;	
   _query := '';

   -- Datos del acta 
   SELECT estado, origen INTO _estado, _origen FROM sga_actas  WHERE id_acta = pActa;

   -- Acta cerrada o anulada 
   IF _estado = 'C' OR _estado = 'B' THEN
      IF pDevolver = 1 THEN
	    -- todos los alumnos
        _query := 'SELECT COUNT(1) as cant FROM sga_actas_detalle WHERE id_acta = ' || cast(pActa as varchar) || ';';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos sin nota
        _query := 'SELECT COUNT(1) as cant FROM sga_actas_detalle WHERE id_acta = ' || cast(pActa as varchar) || ' AND d.nota IS NULL;';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos con nota
        _query := 'SELECT COUNT(1) as cant FROM sga_actas_detalle WHERE id_acta = ' || cast(pActa as varchar) || ' AND d.nota IS NOT NULL;';
      END IF;	  	
   END IF;   

   -- Acta de examen abierta
   IF _estado = 'A' AND _origen = 'E' THEN
      IF pDevolver = 1 THEN
	    -- todos los alumnos
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_examenes WHERE id_acta = ' || cast(pActa as varchar) || ';';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos sin nota
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_examenes WHERE id_acta = ' || cast(pActa as varchar) || ' AND nota IS NULL;';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos con nota
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_examenes WHERE id_acta = ' || cast(pActa as varchar) || ' AND nota IS NOT NULL;';
      END IF;	  	
   END IF;   

      -- Acta de cursada abierta
   IF _estado = 'A' AND _origen = 'R' THEN
      IF pDevolver = 1 THEN
	    -- todos los alumnos
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_cursadas WHERE id_acta_cursada = ' || cast(pActa as varchar) || ';';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos sin nota
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_cursadas WHERE id_acta_cursada = ' || cast(pActa as varchar) || ' AND nota_promocion IS NULL;';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos con nota
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_cursadas WHERE id_acta_cursada = ' || cast(pActa as varchar) || ' AND nota_promocion IS NOT NULL;';
      END IF;	  	
   END IF;   

   -- Acta de promocion abierta
   IF _estado = 'A' AND _origen = 'P' THEN
      IF pDevolver = 1 THEN
	    -- todos los alumnos
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_cursadas WHERE id_acta_promocion = ' || cast(pActa as varchar) || ';';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos sin nota
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_cursadas WHERE id_acta_promocion = ' || cast(pActa as varchar) || ' AND nota_cursada IS NULL;';
      ELSIF pDevolver = 2 THEN
	    -- Alumnos con nota
        _query := 'SELECT COUNT(1) as cant FROM sga_eval_detalle_cursadas WHERE id_acta_promocion = ' || cast(pActa as varchar) || ' AND nota_cursada IS NOT NULL;';
      END IF;	  	
   END IF;   

  -- Retorno la cantidad de alumnos  
  IF _query <> '' THEN
     FOR _cur IN EXECUTE _query
     LOOP
        _cant_alumnos := _cur.cant;
        RETURN _cant_alumnos;
     END LOOP; 
  END IF;  

  RETURN _cant_alumnos;  
    
  END;
$$;
