create function negocio.f_equiv_evaluar_matriz(pid integer, pmatriz integer, pactividad integer, pesautomatica boolean, palumno integer, pplanversion integer, ppersona integer, ppropuestaorigen integer, pplanorigen integer, pplanversionorigen integer, pparamcontrolarcorrelativas character, pparamajustarnota character, pparampasardesaprobados character, pparamregistrarvencoriginal character, pparampasarregularidad character, pparampasarregularidadconnota character) returns SETOF negocio.type_equivalencias_automaticas
LANGUAGE plpgsql
AS $$
DECLARE 
  rtn  type_equivalencias_automaticas;
  cur_grupo record;
  cur_equiv record;
  _cant_equiv_otorgadas integer;
  _ID integer;
BEGIN

 -- ID unico por cada equivalencia a otorgar...
 _ID := COALESCE(pID, 0) + 1;
 
  -- Para registro en sga_equiv_otorgada
  CREATE TEMP TABLE _Equiv (
    id Integer NOT NULL, -- id que relaciona la equivalencia con las notas internas 
    elemento Integer NOT NULL,
    instancia Integer NOT NULL,
    fecha Date NOT NULL,
    escala_nota Integer,
    nota Varchar(10),
    resultado Char(1) NOT NULL,
    fecha_vigencia Date,
    temas_a_rendir Text,
    grupo_equivalencia Integer NOT NULL,
    matriz Integer NOT NULL);

  -- Para el registro en sga_equiv_internas
  CREATE TEMP TABLE _EquivInt (
    id Integer NOT NULL,
    propuesta Integer NOT NULL,
    elemento Integer NOT NULL,
    fecha Date NOT NULL,
    nota Varchar(10),
    origen Varchar(12) NOT NULL DEFAULT 'Examen',
    resultado Char(1));


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Creo tablas temporales para Historia Académica y Regularidades del Alumno 
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  CREATE TEMP TABLE _TempReg (
    elemento integer,
    origen char(1),
    alumno2 integer,
    propuesta2 integer,
    plan_version integer,
    comision integer,
    equivalencia integer,
    fecha date,
    fecha_vigencia date,
    es_vigente smallint,
    escala_nota integer,
    nota varchar(10),
    resultado char(1),
    origen_otra_propuesta boolean);
  
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Regularidades del alumno en todas las propuestas...
  --    origen    : R = Acta de Regularidad / P = Acta de Promoción (son alumnos que no estan en acta de cursadas de esa comision)  / C = Equivalencia de Regularidad
  --    resultado : A - Aprobado / R - Desaprobado / U - Ausente
  --    vigente   : 1 - Es Vigente / 0 - No esta vigente
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  INSERT INTO _TempReg (elemento, origen, alumno2, propuesta2, plan_version, comision, equivalencia, fecha, fecha_vigencia, es_vigente, escala_nota, nota, resultado, origen_otra_propuesta)
   SELECT DISTINCT v.elemento, v.origen, v.alumno2, a2.propuesta, v.plan_version, v.comision, v.equivalencia, v.fecha, v.fecha_vigencia, v.es_vigente, v.escala_nota, v.nota, v.resultado, v.origen_otra_propuesta 
     FROM vw_regularidades_basica as v,
          sga_alumnos as a2
    WHERE v.alumno2 = a2.alumno
      AND v.persona = pPersona;
     
  
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Historia Academica: 
  --
  -- Valores de los campos:
  --    resultado = A - Aprobado / R - Desaprobado / U - Ausente (examenes ausentes)
  --    origen    = E - Examen / P - Promocion / B - Equivalencia Total / A - Aprob. x Resolucion
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  CREATE TEMP TABLE _TempHA(
    elemento integer,
    origen char(1),
    alumno2 integer, 
    propuesta2 integer,
    plan_version integer,
    instancia integer,
    comision integer,
    llamado_mesa integer,
    equivalencia integer,
    fecha date,
    fecha_vigencia date,
    escala_nota integer,
    nota varchar(10),
    resultado char(1),
    origen_otra_propuesta boolean);

  INSERT INTO _TempHA (elemento, origen, alumno2, propuesta2, plan_version, instancia, comision, llamado_mesa, equivalencia, fecha, fecha_vigencia,  escala_nota, nota, resultado, origen_otra_propuesta )
  SELECT DISTINCT v.elemento, v.origen, v.alumno2, a2.propuesta, v.plan_version, v.instancia, v.comision, v.llamado_mesa, v.equivalencia, v.fecha, v.fecha_vigencia, v.escala_nota, v.nota, v.resultado, v.origen_otra_propuesta
    FROM vw_hist_academica_basica as v,
         sga_alumnos as a2
   WHERE v.alumno2 = a2.alumno
     AND v.persona = pPersona;
 
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Grupos de Equivalencias activos de la matriz de equivalencias
  -- Si viene la actividad, entonces solo busca en grupos de equivalencias que tienen esa actividad en el origen..
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  FOR cur_grupo IN
      SELECT grupo_equivalencia
        FROM sga_equiv_grupos
       WHERE matriz = pMatriz
         AND activo = 'S'  
		 AND (pActividad IS NULL OR 
		      EXISTS (SELECT 1 FROM sga_equiv_actividades as ea 
		               WHERE ea.grupo_equivalencia = sga_equiv_grupos.grupo_equivalencia
		                 AND ea.origen_destino = 'O'
		                 AND ea.elemento = pActividad)
			 )
      ORDER BY orden  
  LOOP
    
    -- Evaluo el grupo de equivalencias y carga tablas temporales _Equiv y _EquivInt con equivalencias a otorgar...
    _cant_equiv_otorgadas := f_equiv_evaluar_grupo (
          _ID, 
          cur_grupo.grupo_equivalencia,
          pEsAutomatica,
          pAlumno,
          pPlanVersion,
          pPersona,
          pPropuestaOrigen,
          pPlanOrigen,
          pPlanVersionOrigen,
          pParamControlarCorrelativas,
          pParamAjustarNota,
          pParamPasarDesaprobados,
          pParamRegistrarVencOriginal,
          pParamPasarRegularidad,
          pParamPasarRegularidadConNota); 
  
    -- Tomo el mayor valor insertado en la tabla temporal
    SELECT MAX(id) INTO _ID FROM _Equiv;
    _ID := COALESCE(_ID, pID);
  END LOOP;
  
  -- Devuelvo las equivalencias otorgadas que fueron cargadas en las tablas temporales
  FOR cur_equiv IN 
       SELECT e.*, 
              i.propuesta as int_propuesta, 
              i.elemento as int_elemento,
              i.fecha as int_fecha,
              i.nota as int_nota,
              i.origen as int_origen,
              i.resultado as int_resultado
         FROM _Equiv as e 
                LEFT JOIN _EquivInt as i ON e.id = i.id
        ORDER BY e.id, e.elemento
  LOOP
  
     -- Seteo la variable de retorno de los datos de equivalencias a otorgar.
     rtn.id                 = cur_equiv.id;
     rtn.matriz             = cur_equiv.matriz;
     rtn.grupo_equivalencia = cur_equiv.grupo_equivalencia;
     rtn.elemento           = cur_equiv.elemento;
     rtn.instancia          = cur_equiv.instancia;
     rtn.fecha              = cur_equiv.fecha;
     rtn.escala_nota        = cur_equiv.escala_nota;
     rtn.nota               = cur_equiv.nota;
     rtn.resultado          = cur_equiv.resultado;
     rtn.fecha_vigencia     = cur_equiv.fecha_vigencia;
     rtn.temas_a_rendir     = cur_equiv.temas_a_rendir;
     rtn.int_propuesta      = cur_equiv.int_propuesta;
     rtn.int_elemento       = cur_equiv.int_elemento;
     rtn.int_fecha          = cur_equiv.int_fecha;
     rtn.int_nota           = cur_equiv.int_nota;
     rtn.int_origen         = cur_equiv.int_origen;
     rtn.int_resultado      = cur_equiv.int_resultado;

     -- Retorno las equivalencias
     RETURN NEXT rtn;
  END LOOP;  

 
  -- Borro tablas temporales  
  DROP TABLE IF EXISTS _TempReg;
  DROP TABLE IF EXISTS _TempHA;
  DROP TABLE IF EXISTS _EquivInt;
  DROP TABLE IF EXISTS _Equiv;

 /* -- Bloque de Excepciones
  EXCEPTION 
      WHEN OTHERS THEN
      -- No retorno nada...   
 */ 
END;
$$;
