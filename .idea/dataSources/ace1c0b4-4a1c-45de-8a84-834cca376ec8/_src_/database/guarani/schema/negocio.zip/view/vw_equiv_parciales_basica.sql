CREATE VIEW vw_equiv_parciales_basica AS SELECT sga_equiv_otorgada.elemento,
    'D'::character(1) AS origen,
    sga_equiv_tramite.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_tramite.tipo_tramite,
    sga_equiv_otorgada.equivalencia,
    sga_alumnos.persona,
    sga_equiv_tramite.alumno,
    sga_equiv_tramite.plan_version,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.fecha_vigencia,
        CASE
            WHEN ((sga_equiv_otorgada.fecha_vigencia IS NULL) OR (sga_equiv_otorgada.fecha_vigencia >= ('now'::text)::date)) THEN 1
            ELSE 0
        END AS es_vigente,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado
   FROM ((negocio.sga_equiv_tramite
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     JOIN negocio.sga_alumnos ON ((sga_alumnos.alumno = sga_equiv_tramite.alumno)))
  WHERE (((((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.instancia = 12)) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar)) AND (sga_equiv_otorgada.estado = 'A'::bpchar)) AND (sga_equiv_otorgada.resultado = ANY (ARRAY['A'::bpchar, 'R'::bpchar])));
