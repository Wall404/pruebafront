create function negocio.f_fin_vigencia_equivalencia(palumno integer, pinstancia integer, pfecha date) returns date
LANGUAGE plpgsql
AS $$
DECLARE
 _f_fin_vigencia DATE;
 _f_equivalencia DATE;

BEGIN
_f_fin_vigencia := NULL;
IF pFecha IS NOT NULL THEN
  _f_equivalencia := pFecha;
ELSE
  _f_equivalencia := CURRENT_DATE;
END IF;

-- Calculo la fecha de fin de vigencia de la equivalencia según la fecha de la equivalencia a otorgar.
IF pInstancia = 11 THEN
  -- Equivalencia de Regularidad
  _f_fin_vigencia := _f_equivalencia + 730;  -- Le suma dos años
 
ELSEIF pInstancia = 12 THEN
  -- Equivalencia Parcial
  _f_fin_vigencia := _f_equivalencia + 730;  -- Le suma dos años

ELSEIF pInstancia = 10 THEN
  -- Equivalencia Total
  _f_fin_vigencia := _f_equivalencia + 730;  -- Le suma dos años
END IF;

RETURN _f_fin_vigencia;

END;
$$;
