create function negocio.ftua_sga_planes_versiones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Si se esta activando la version del plan de estudios, actualizo el aplanado
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	IF OLD.estado = 'N' AND (NEW.estado = 'A' OR NEW.estado = 'V') THEN
		-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		-- Aplanado de períodos de inscripción a propuesta, períodos lectivos y turnos de examen.
		-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		INSERT INTO	sga_periodos_inscripcion_aplanado (periodo_insc, plan_version)
		SELECT		sga_periodos_inscripcion_fechas.periodo_insc,
					NEW.plan_version
		FROM		sga_periodos_inscripcion_fechas,
					sga_periodos_inscripcion_entidad
		WHERE		sga_periodos_inscripcion_fechas.periodo_insc = sga_periodos_inscripcion_entidad.periodo_insc AND
					(NEW.fecha_entrada_vigencia BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR NEW.fecha_entrada_vigencia <= sga_periodos_inscripcion_fechas.fecha_inicio) AND
					sga_periodos_inscripcion_entidad.entidad IN (SELECT * FROM get_entidades_plan_version(NEW.plan_version))
		UNION
		SELECT		sga_periodos_inscripcion_fechas.periodo_insc,
					NEW.plan_version
		FROM		sga_periodos_inscripcion_fechas,
					sga_periodos_inscripcion_subtipos,
					sga_g3entidades,
					sga_propuestas,
					sga_planes,
					sga_planes_versiones
		WHERE		sga_periodos_inscripcion_fechas.periodo_insc = sga_periodos_inscripcion_subtipos.periodo_insc AND
					sga_periodos_inscripcion_subtipos.entidad_subtipo = sga_g3entidades.entidad_subtipo AND
					sga_g3entidades.entidad = sga_propuestas.entidad AND
					sga_propuestas.propuesta = sga_planes.propuesta AND
					sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes_versiones.plan_version = NEW.plan_version AND
					(NEW.fecha_entrada_vigencia BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR NEW.fecha_entrada_vigencia <= sga_periodos_inscripcion_fechas.fecha_inicio);

		-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		-- Aplanado de requisitos de ingreso.
		-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		INSERT INTO	sga_requisitos_ingreso_aplanado (requisito_propuesta, plan_version)
		SELECT		sga_requisitos_ingreso_entidades.requisito_propuesta,
					NEW.plan_version
		FROM		sga_requisitos_ingreso_entidades
		WHERE		sga_requisitos_ingreso_entidades.entidad IN (SELECT * FROM get_entidades_plan_version(NEW.plan_version))
		UNION
		SELECT		sga_requisitos_ingreso_subtipos.requisito_propuesta,
					NEW.plan_version
		FROM		sga_requisitos_ingreso_subtipos,
					sga_g3entidades,
					sga_propuestas,
					sga_planes,
					sga_planes_versiones
		WHERE		sga_requisitos_ingreso_subtipos.entidad_subtipo = sga_g3entidades.entidad_subtipo AND
					sga_g3entidades.entidad = sga_propuestas.entidad AND
					sga_propuestas.propuesta = sga_planes.propuesta AND
					sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes_versiones.plan_version = NEW.plan_version;

		-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		-- Aplanado de requisitos por acción.
		-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		INSERT INTO	sga_requisitos_aplanado (requisito_accion, plan_version)
		SELECT		sga_requisitos_x_accion.requisito_accion,
					NEW.plan_version
		FROM		sga_requisitos_x_accion,
					sga_requisitos_grupos
		WHERE		sga_requisitos_x_accion.grupo_requisito = sga_requisitos_grupos.grupo_requisito AND
					sga_requisitos_grupos.entidad IN (SELECT * FROM get_entidades_plan_version(NEW.plan_version))
		UNION
		SELECT		sga_requisitos_x_accion.requisito_accion,
					NEW.plan_version
		FROM		sga_requisitos_x_accion,
					sga_requisitos_grupos,
					sga_g3entidades,
					sga_propuestas,
					sga_planes,
					sga_planes_versiones
		WHERE		sga_requisitos_x_accion.grupo_requisito = sga_requisitos_grupos.grupo_requisito AND
					sga_requisitos_grupos.entidad_subtipo = sga_g3entidades.entidad_subtipo AND
					sga_g3entidades.entidad = sga_propuestas.entidad AND
					sga_propuestas.propuesta = sga_planes.propuesta AND
					sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes_versiones.plan_version = NEW.plan_version;
	END IF;

	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Saco del aplanado la version del plan de estudios
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	IF NEW.estado = 'B' AND OLD.estado <> 'B' THEN
		-- Aplanado de períodos de inscripción a propuesta, períodos lectivos y turnos de examen.
		DELETE
		FROM	sga_periodos_inscripcion_aplanado
		USING	sga_periodos_inscripcion_fechas
		WHERE	sga_periodos_inscripcion_aplanado.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc AND
				sga_periodos_inscripcion_aplanado.plan_version = NEW.plan_version AND
				(NEW.fecha_baja BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR
				 NEW.fecha_baja <= sga_periodos_inscripcion_fechas.fecha_inicio);

		-- Aplanado de requisitos de ingreso.
		DELETE
		FROM	sga_requisitos_ingreso_aplanado
		WHERE	sga_requisitos_ingreso_aplanado.plan_version = NEW.plan_version;

		-- Aplanado de requisitos por acción.
		DELETE
		FROM	sga_requisitos_aplanado
		WHERE	sga_requisitos_aplanado.plan_version = NEW.plan_version;
	END IF;

	RETURN NEW;
END;
$$;
