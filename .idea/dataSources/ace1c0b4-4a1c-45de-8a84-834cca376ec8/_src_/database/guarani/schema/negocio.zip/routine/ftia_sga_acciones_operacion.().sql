create function negocio.ftia_sga_acciones_operacion() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
      
   -- Inserto los requisitos asociados a la Accion a donde se agrega la operación
   INSERT INTO sga_requisitos_conf_x_oper (operacion, interfaz, requisito_accion, actua_como, activo)
      SELECT NEW.operacion, acc_interfaces.interfaz, sga_requisitos_x_accion.requisito_accion, 'ESTRICTO', 'S'
        FROM sga_requisitos_grupos,
             sga_requisitos_x_accion,
             acc_interfaces
       WHERE sga_requisitos_grupos.accion = NEW.accion
         AND sga_requisitos_x_accion.grupo_requisito = sga_requisitos_grupos.grupo_requisito;

   RETURN NEW;
END;
$$;
