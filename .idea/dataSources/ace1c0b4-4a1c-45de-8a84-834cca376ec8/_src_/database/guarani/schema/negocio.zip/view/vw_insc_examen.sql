CREATE VIEW vw_insc_examen AS SELECT sga_insc_examen.inscripcion,
    sga_insc_examen.alumno,
    sga_insc_examen.llamado_mesa,
    sga_insc_examen.plan_version,
    sga_insc_examen.instancia,
    sga_insc_examen.fecha_inscripcion,
    sga_insc_examen.fuera_de_termino,
    sga_insc_examen.autorizado_por,
    sga_insc_examen.nro_transaccion,
    sga_insc_examen.motivo_excepcion,
    sga_insc_examen.exceptuado,
    sga_insc_examen.interfaz,
    sga_insc_examen.estado
   FROM negocio.sga_insc_examen
UNION ALL
 SELECT his_insc_examen.inscripcion,
    his_insc_examen.alumno,
    his_insc_examen.llamado_mesa,
    his_insc_examen.plan_version,
    his_insc_examen.instancia,
    his_insc_examen.fecha_inscripcion,
    his_insc_examen.fuera_de_termino,
    his_insc_examen.autorizado_por,
    his_insc_examen.nro_transaccion,
    his_insc_examen.motivo_excepcion,
    his_insc_examen.exceptuado,
    his_insc_examen.interfaz,
    his_insc_examen.estado
   FROM negocio.his_insc_examen;
