create function negocio.f_criterio_trabaja(ppersona integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _Trabaja integer;
 
BEGIN
  _Trabaja := 1; -- No trabaja
  
  -- Recupero cantidad de hijos...   
  SELECT mdp_datos_economicos.trabajo_existe 
    INTO _Trabaja
    FROM mdp_datos_censales, 
         mdp_datos_economicos
   WHERE mdp_datos_censales.persona = pPersona
     AND mdp_datos_economicos.dato_censal = mdp_datos_censales.dato_censal;
     
  IF _Trabaja = 1 THEN
    -- 1 = Trabajó al menos una hora (incluye a los que no trabajaron por licencia, vacaciones, enfermedad)
    RETURN 0;
  ELSE  
    -- No trabaja ni trabajó
    RETURN 1;
  END IF;  

END;
$$;
