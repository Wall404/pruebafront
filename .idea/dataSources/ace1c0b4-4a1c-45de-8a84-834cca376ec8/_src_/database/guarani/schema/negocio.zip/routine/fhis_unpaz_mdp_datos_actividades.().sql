create function negocio.fhis_unpaz_mdp_datos_actividades() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		INSERT INTO unpaz_his_datos_actividades (dato_censal, tecnologia_disp_tv, tecnologia_disp_pc, tecnologia_disp_wifi, tecnologia_disp_note, tecnologia_disp_cel, tecnologia_disp_tablet, tecnologia_disp_consola, tecnologia_sw_word,  tecnologia_sw_foto,  tecnologia_sw_video,  tecnologia_sw_disenio,  tecnologia_sw_musica,  tecnologia_sw_prog,  tecnologia_sw_juegos , tecnologia_redes_facebook,  tecnologia_redes_twitter,  tecnologia_redes_instagram,  tecnologia_redes_foros,  tecnologia_redes_whatsapp,  tecnologia_redes_snapchat,  tecnologia_redes_youtube) 
		VALUES (NEW.dato_censal, NEW.tecnologia_disp_tv, NEW.tecnologia_disp_pc, NEW.tecnologia_disp_wifi, NEW.tecnologia_disp_note, NEW.tecnologia_disp_cel, NEW.tecnologia_disp_tablet, NEW.tecnologia_disp_consola, NEW.tecnologia_sw_word,  NEW.tecnologia_sw_foto,  NEW.tecnologia_sw_video,  NEW.tecnologia_sw_disenio,  NEW.tecnologia_sw_musica,  NEW.tecnologia_sw_prog,  NEW.tecnologia_sw_juegos , NEW.tecnologia_redes_facebook,  NEW.tecnologia_redes_twitter,  NEW.tecnologia_redes_instagram,  NEW.tecnologia_redes_foros,  NEW.tecnologia_redes_whatsapp,  NEW.tecnologia_redes_snapchat,  NEW.tecnologia_redes_youtube);
	
		RETURN NEW;
	END;
$$;
