create function negocio.ftdb_sga_docentes_mesa_llamado() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

  -- Borro los derechos asignados al docente en la mesa
  DELETE FROM gdu_derechos_personas
     USING sga_llamados_mesa, 
           sga_docentes
     WHERE sga_llamados_mesa.llamado_mesa = OLD.llamado_mesa
       AND sga_docentes.docente = OLD.docente
       AND gdu_derechos_personas.entidad = sga_llamados_mesa.entidad
       AND gdu_derechos_personas.persona = sga_docentes.persona;

  RETURN OLD;
END;
$$;
