create function negocio.f_instituciones_convenio(_convenio integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	cnt smallint;
	_retorno text;
	cur1 record;
BEGIN
	cnt := 0;
	_retorno := NULL;
	FOR cur1 IN	SELECT		sga_instituciones.nombre
				FROM		sga_convenios_instituciones,
							sga_instituciones
				WHERE		sga_convenios_instituciones.institucion = sga_instituciones.institucion AND
							sga_convenios_instituciones.convenio = _convenio
				ORDER BY	sga_instituciones.nombre
	LOOP
		IF cnt = 0 THEN
			_retorno := cur1.nombre;
		ELSE
			_retorno := _retorno || ', ' || cur1.nombre;
		END IF;
		cnt := cnt + 1;
	END LOOP;

	RETURN _retorno;
END;
$$;
