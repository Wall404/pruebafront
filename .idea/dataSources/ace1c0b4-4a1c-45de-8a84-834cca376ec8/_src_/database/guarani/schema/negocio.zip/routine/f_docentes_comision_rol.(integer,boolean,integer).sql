create function negocio.f_docentes_comision_rol(pcomision integer, pmostrarresponsabilidad boolean, presponsabilidad integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _docentes  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _docentes := NULL;
		
  -- Recupero el nombre de los docentes
  FOR cur1 IN SELECT mdp_personas.apellido as apellido, 
                     mdp_personas.nombres as nombre,
                     r.nombre as responsabilidad
                FROM sga_docentes_comision
                       LEFT JOIN sga_docentes_responsabilidades as r ON r.responsabilidad = sga_docentes_comision.responsabilidad, 
                     sga_docentes, 
                     mdp_personas
               WHERE sga_docentes_comision.comision = pComision
                 AND sga_docentes_comision.responsabilidad = pResponsabilidad
                 AND sga_docentes.docente = sga_docentes_comision.docente
                 AND mdp_personas.persona = sga_docentes.persona
              ORDER BY r.orden_listado, mdp_personas.apellido, mdp_personas.nombres
  LOOP
      IF cnt = 0 THEN
         _docentes :=  cur1.apellido || ' ' || cur1.nombre;
      ELSE
         _docentes :=  _docentes || ', ' || cur1.apellido || ' ' || cur1.nombre;
      END IF;   
      IF pMostrarResponsabilidad AND cur1.responsabilidad IS NOT NULL THEN
         _docentes :=  _docentes || ' (' || cur1.responsabilidad || ')';
      END IF;
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _docentes;
    
END;
$$;
