create function negocio.get_actividades_certificado(pcertificado integer, pplanversion integer, pdevolvermodulos boolean DEFAULT false) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE 
	_condicion integer;
	cur_grupos record;
	cur_elementos record;
	cur_actividades record;
BEGIN
	-- Condiciones para obtener el certificado.
	SELECT	sga_condiciones.condicion INTO _condicion
	FROM	sga_certificados,
			sga_condiciones
	WHERE	sga_certificados.entidad = sga_condiciones.entidad AND
			sga_certificados.certificado = pCertificado AND
			sga_condiciones.plan_version = pPlanVersion AND
			sga_condiciones.condicion_tipo = '3'; -- Condición para obtener un certificado.
	-- Grupos de las condiciones.
	FOR cur_grupos IN
		SELECT		sga_condiciones_grupos.grupo_condicion
		FROM		sga_condiciones_grupos
		WHERE		sga_condiciones_grupos.condicion = _condicion
		ORDER BY	sga_condiciones_grupos.orden
	LOOP
		-- Requisitos de los grupos.
		FOR cur_elementos IN
			SELECT		sga_elementos.elemento,
						sga_g3entidades_subtipos.entidad_tipo,
						sga_elementos_revision.elemento_revision
			FROM		sga_condiciones_requisitos,
						sga_elementos,
						sga_g3entidades_subtipos,
						sga_elementos_revision,
						sga_elementos_plan
			WHERE		sga_condiciones_requisitos.entidad = sga_elementos.entidad AND
						sga_elementos.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo AND
						sga_elementos.elemento = sga_elementos_revision.elemento AND
						sga_elementos_revision.elemento_revision = sga_elementos_plan.elemento_revision AND
						sga_condiciones_requisitos.grupo_condicion = cur_grupos.grupo_condicion AND
						sga_elementos_plan.plan_version = pPlanVersion
			ORDER BY	sga_condiciones_requisitos.orden
		LOOP
			IF pDevolverModulos AND cur_elementos.entidad_tipo = 1 THEN
				-- Devuelvo el id del modulo
				RETURN NEXT cur_elementos.elemento;
			END IF;	
			IF cur_elementos.entidad_tipo = 2 THEN
				-- Devuelvo el id de la actividad
				RETURN NEXT cur_elementos.elemento;
			ELSE
				-- Recorro módulos buscando actividades.
				FOR cur_actividades IN
					SELECT	cast(get_actividades_certificado_det as integer) as elemento
					FROM	get_actividades_certificado_det(cur_elementos.elemento_revision, pDevolverModulos)
				LOOP
					RETURN NEXT cur_actividades.elemento;
				END LOOP; -- Actividades.
			END IF;
		END LOOP; -- Elementos.
	END LOOP; -- Grupos de condiciones.
END;
$$;
