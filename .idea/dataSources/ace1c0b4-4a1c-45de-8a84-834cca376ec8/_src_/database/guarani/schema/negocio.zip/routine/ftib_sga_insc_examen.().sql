create function negocio.ftib_sga_insc_examen() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
       IF NEW.nro_transaccion IS NULL THEN
	     -- Genera un nro de Transaccion
         NEW.nro_transaccion := f_nro_transaccion();
       END IF;  
       RETURN NEW;
  END;
$$;
