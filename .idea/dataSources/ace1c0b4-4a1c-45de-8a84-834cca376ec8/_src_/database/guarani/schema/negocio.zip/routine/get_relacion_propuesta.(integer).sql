create function negocio.get_relacion_propuesta(palumno integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _relacion Integer;
  _anio Integer;
        
BEGIN
 _relacion := NULL;
 _anio := NULL;

 -- Recupero el año de ingreso en la propuesta
 SELECT sga_propuestas_aspira.anio_academico
   INTO _anio
   FROM sga_alumnos,
        sga_propuestas_aspira,
        sga_situacion_aspirante
  WHERE sga_alumnos.persona = sga_propuestas_aspira.persona
    AND sga_alumnos.propuesta = sga_propuestas_aspira.propuesta
    AND sga_situacion_aspirante.situacion_asp = sga_propuestas_aspira.situacion_asp
    AND sga_alumnos.alumno = pAlumno
    AND sga_situacion_aspirante.resultado_asp IN ('A','P');
 IF _anio IS NULL THEN
   RETURN _relacion;
 END IF; 
 

 -- Tomo la relacion entre propuestas que corresponde a la propuesta/plan del alumno y año académico de ingreso. 
 SELECT sga_propuestas_relacion.relacion 
   INTO _relacion
   FROM sga_alumnos,
        sga_planes_versiones,
        sga_propuestas_relacion
  WHERE sga_alumnos.alumno = pAlumno
    AND sga_planes_versiones.plan_version = sga_alumnos.plan_version
    AND sga_propuestas_relacion.propuesta = sga_alumnos.propuesta
    AND (sga_propuestas_relacion.plan IS NULL OR sga_propuestas_relacion.plan = sga_planes_versiones.plan)
    AND (sga_propuestas_relacion.anio_academico IS NULL OR sga_propuestas_relacion.anio_academico <= _anio)
   ORDER BY sga_propuestas_relacion.anio_academico DESC,
   			sga_propuestas_relacion.plan NULLS LAST
 LIMIT 1;       
  
 RETURN _relacion;

END;
$$;
