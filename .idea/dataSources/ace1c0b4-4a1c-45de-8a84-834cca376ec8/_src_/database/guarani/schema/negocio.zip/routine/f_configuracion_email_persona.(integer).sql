create function negocio.f_configuracion_email_persona(ppersona integer) returns negocio.type_configuracion_email
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _existe_registro Char(1);
 DECLARE _email Varchar(100);
 DECLARE _email_temporal Varchar(100);
 DECLARE _email_contacto Varchar(100);
 DECLARE _recibe_mail_mensajes Smallint;
 DECLARE rtn type_configuracion_email;
BEGIN
  _existe_registro := 'S';
  _email := NULL;
  _email_temporal := NULL;
  _recibe_mail_mensajes := 0;

  -- Seteo por default
  rtn.email := NULL;
  rtn.recibe_mail_mensajes := 0;
  
  -- Recupero datos de configuracion de mail y recepcion de mensajes
  SELECT recibe_mail_mensajes
    INTO _recibe_mail_mensajes
    FROM mdp_configuracion
   WHERE persona = pPersona;
  IF NOT FOUND THEN
     _existe_registro := 'N';
     _recibe_mail_mensajes := 0;
  END IF;

  -- Inserto un registro en mdp_confguracion     
  IF _existe_registro = 'N' THEN
     INSERT INTO mdp_configuracion (persona, recibe_mail_mensajes) VALUES (pPersona, _recibe_mail_mensajes);
  END IF;
  
  -- Recupero el mail principal de la persona y el email temporal.
  SELECT p.email_temporal, c.email 
    INTO _email_temporal, _email
    FROM mdp_personas as p
           LEFT JOIN mdp_personas_contactos as c ON c.persona = p.persona  AND c.contacto_tipo = 'MP'
   WHERE p.persona = pPersona;
   
  -- Si la persona no dispone de Mail Principal, se intenta buscar Mail Institucional
  IF _email IS NULL
  THEN
	SELECT 	c.email 
    INTO 	_email
    FROM 	mdp_personas as p
			LEFT JOIN mdp_personas_contactos as c ON c.persona = p.persona  AND c.contacto_tipo = 'MI'
	WHERE 	p.persona = pPersona;
  END IF;
  
  -- Si la persona no dispone de Mail Principal ni Mail Institucional, se intenta buscar Mail Secundario
  IF _email IS NULL
  THEN
	SELECT 	c.email 
    INTO 	_email
    FROM 	mdp_personas as p
			LEFT JOIN mdp_personas_contactos as c ON c.persona = p.persona  AND c.contacto_tipo = 'MS'
	WHERE 	p.persona = pPersona;
  END IF;
    
  -- Retorno el mail y lo demas valores
  rtn.email                := _email;
  rtn.email_temporal       := _email_temporal;
  rtn.recibe_mail_mensajes := _recibe_mail_mensajes;
  
  RETURN rtn;
END;
$$;
