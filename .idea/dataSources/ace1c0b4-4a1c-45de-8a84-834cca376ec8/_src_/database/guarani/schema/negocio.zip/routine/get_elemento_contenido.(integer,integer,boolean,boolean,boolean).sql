create function negocio.get_elemento_contenido(integer, integer, boolean, boolean, boolean) returns SETOF negocio.type_plan_contenido
LANGUAGE plpgsql
AS $$
DECLARE 

id__revision ALIAS for $1;
id__plan_version ALIAS for $2;
mostrarme ALIAS for $3;
mostrar_hijos ALIAS for $4;
mostrar_hijos_mg ALIAS for $5;
es_mg boolean;
elemento_raiz record;
hijos record;
hijos2 record;
cant integer;
BEGIN

SELECT COUNT (relname) INTO cant FROM pg_class WHERE relname = 'temp_seq';
IF (cant = 0) THEN 
	CREATE TEMP sequence temp_seq;
END IF;	

-- Verifica si es una Materia Genérica
SELECT 	CASE 
		WHEN e.entidad_subtipo = 2  then
			true
		ELSE
			false
		END
		INTO es_mg
FROM sga_elementos_revision as m,
	sga_elementos as e
WHERE	m.elemento_revision = id__revision
	AND m.elemento = e.elemento;


IF mostrarme = true then
        -- Si el elemento no existe en la version de plan de estudios pasada como parámetro entonces recupera 
        -- el nombre del elemento genérico, y no el nombre en el plan de estudios.
		SELECT 	nextval('temp_seq')  			as orden_arbol,
				id__revision 					as elemento_revision,
				m.elemento 						as elemento,
				e.codigo 						as codigo,
				COALESCE(ep.nombre,e.nombre) 	as nombre,
				est.entidad_tipo 				as entidad_tipo,
				est.entidad_subtipo 			as entidad_subtipo,
				est.php_clase_gui 				as entidad_clase_gui,
				cast(null as integer) 			as elemento_comp,
				cast(null as integer) 			as elemento_revision_padre,
				cast(null as integer) 			as elemento_padre,
				cast(0 as smallint) 			as orden
			INTO	elemento_raiz
			FROM 	sga_elementos_revision as m
					LEFT JOIN sga_elementos_plan as ep ON ep.elemento_revision = m.elemento_revision AND ep.plan_version = id__plan_version,
					sga_elementos as e,
					sga_g3entidades_subtipos as est
			WHERE	m.elemento_revision		= id__revision
			AND		m.elemento 				= e.elemento
			AND		e.entidad_subtipo 		= est.entidad_subtipo;
		RETURN NEXT elemento_raiz;
	end if;
	
	-- Verifica si tiene que mostrar los hijos.
	-- if mostrar_hijos = true or (mostrar_hijos = false and hijos.entidad_subtipo <> 2) then
	if mostrar_hijos = true and (es_mg = false or (es_mg = true and mostrar_hijos_mg = true)) then
		-- Contenido del Modulo/Actividad
		FOR hijos IN(
			SELECT 	nextval('temp_seq')  				as orden_arbol,
					c.elemento_hijo 					as elemento_revision,
					er_hijo.elemento 					as elemento,
					e.codigo 							as codigo,
					COALESCE(ep.nombre,e.nombre) 		as nombre,
					est.entidad_tipo 					as entidad_tipo,
					est.entidad_subtipo 				as entidad_subtipo,
					est.php_clase_gui 					as entidad_clase_gui,
					c.elemento_comp 					as elemento_comp,
					er_padre.elemento_revision			as elemento_revision_padre,
					er_padre.elemento 					as elemento_padre,
					c.orden 							as orden
			FROM 	sga_elementos_comp as c,
					sga_elementos_revision as er_padre,
					sga_elementos_revision as er_hijo
					LEFT JOIN sga_elementos_plan as ep ON ep.elemento_revision = er_hijo.elemento_revision AND ep.plan_version = id__plan_version,
					sga_elementos as e,
					sga_g3entidades_subtipos as est
			WHERE	c.elemento_padre	    	= id__revision
			AND		er_padre.elemento_revision 	= id__revision
			AND		er_hijo.elemento_revision 	= c.elemento_hijo
			AND		e.elemento 					= er_hijo.elemento
			AND		e.entidad_subtipo 			= est.entidad_subtipo
		) LOOP
		RETURN NEXT hijos;
			
		FOR hijos2 IN (	
			SELECT 	orden_arbol,
				elemento_revision,
				elemento,
				codigo,
				nombre,
				entidad_tipo,
				entidad_subtipo,
				entidad_clase_gui,
				elemento_comp,
				elemento_revision_padre,
				elemento_padre,
				orden
			FROM get_elemento_contenido( hijos.elemento_revision, id__plan_version, false, mostrar_hijos, mostrar_hijos_mg)
			) LOOP
			RETURN NEXT hijos2;
		END LOOP;
	  END LOOP; -- Hijos
	END IF; -- Contenido.

IF (cant = 0) THEN 
	DROP sequence temp_seq;	
END IF;	

END
$$;
