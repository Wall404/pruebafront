create function negocio.f_propuestas_comision(pcomision integer, ptiponombre integer DEFAULT 1) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _retorno := '';
		
  -- Recupero los datos de las propuestas de la comision
  FOR cur1 IN SELECT DISTINCT
                     sga_propuestas.propuesta as propuesta, 
                     sga_propuestas.codigo as codigo, 
                     sga_propuestas.nombre as nombre, 
                     sga_propuestas.nombre_abreviado as nombre_abreviado
		        FROM sga_comisiones_propuestas, sga_propuestas
               WHERE sga_comisiones_propuestas.comision = pComision
                 AND sga_comisiones_propuestas.propuesta = sga_propuestas.propuesta
			ORDER BY sga_propuestas.nombre	 
  LOOP
      IF cnt > 0 THEN		
           _retorno :=  _retorno || '/';
      END IF;

      IF pTipoNombre = 1 THEN
         _retorno :=  _retorno || cur1.nombre;
      ELSEIF pTipoNombre = 2 THEN
         _retorno :=  _retorno || cur1.nombre_abreviado;
      ELSEIF pTipoNombre = 3 THEN
         _retorno :=  _retorno || cast(cur1.propuesta as text);
      ELSEIF pTipoNombre = 4 THEN
         _retorno :=  _retorno || cur1.codigo;
      ELSE
         _retorno :=  _retorno || cur1.nombre;
      END IF;
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
