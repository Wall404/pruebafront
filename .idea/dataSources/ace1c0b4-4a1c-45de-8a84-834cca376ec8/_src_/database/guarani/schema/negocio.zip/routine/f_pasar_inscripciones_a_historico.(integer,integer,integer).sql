create function negocio.f_pasar_inscripciones_a_historico(_anio_academico integer, _cursadas integer, _examenes integer) returns void
LANGUAGE plpgsql
AS $$
BEGIN
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- INSCRIPCIONES A EXAMENES
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
IF _examenes = 1 THEN
   -- Deshabilito triggers para que no actuen sobre las tablas de evaluaciones
   ALTER TABLE sga_insc_examen DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_examen_log DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_examen_log_requisitos DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_examen DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_examen_log DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_examen_log_requisitos DISABLE TRIGGER ALL;
   
   -- Inscripciones aceptadas/pendientes/exceptuadas
   INSERT INTO his_insc_examen
         (inscripcion, alumno, llamado_mesa, plan_version, instancia, fecha_inscripcion, fuera_de_termino, autorizado_por, nro_transaccion, motivo_excepcion, exceptuado, interfaz, estado)
    SELECT i.inscripcion, i.alumno, i.llamado_mesa, i.plan_version, i.instancia, i.fecha_inscripcion, i.fuera_de_termino, i.autorizado_por, i.nro_transaccion, i.motivo_excepcion, i.exceptuado, i.interfaz, i.estado
      FROM sga_insc_examen as i,
           sga_llamados_mesa as llm,
           sga_llamados_turno as ll,
           sga_periodos as p
      WHERE i.llamado_mesa = llm.llamado_mesa
        AND ll.llamado = llm.llamado
        AND ll.periodo = p.periodo
        AND p.anio_academico = _anio_academico;        
        
   -- Requisitos que fallaron en los rechazos de inscripciones a examenes
   INSERT INTO his_insc_examen_log_requisitos
         (inscripcion_requisito, inscripcion, mensaje_validacion)
    SELECT a.inscripcion_requisito, a.inscripcion, a.mensaje_validacion
      FROM sga_insc_examen_log_requisitos as a,
           sga_insc_examen_log as i,
           sga_llamados_mesa as llm,
           sga_llamados_turno as ll,
           sga_periodos as p
      WHERE i.inscripcion = a.inscripcion
        AND llm.llamado_mesa = i.llamado_mesa
        AND ll.llamado = llm.llamado
        AND ll.periodo = p.periodo
        AND p.anio_academico = _anio_academico;

   -- inscripciones dadas de baja o rechazadas
   INSERT INTO his_insc_examen_log
         (inscripcion, alumno, llamado_mesa, plan_version, instancia, fecha_inscripcion, fuera_de_termino, autorizado_por, nro_transaccion, motivo_excepcion, exceptuado, interfaz, estado, motivo_rechazo, operacion, fecha_operacion, nro_transaccion_log)
    SELECT i.inscripcion, i.alumno, i.llamado_mesa, i.plan_version, i.instancia, i.fecha_inscripcion, i.fuera_de_termino, i.autorizado_por, i.nro_transaccion, i.motivo_excepcion, i.exceptuado, i.interfaz, i.estado, i.motivo_rechazo, i.operacion, i.fecha_operacion, i.nro_transaccion_log
      FROM sga_insc_examen_log as i,
           sga_llamados_mesa as llm,
           sga_llamados_turno as ll,
           sga_periodos as p
      WHERE llm.llamado_mesa = i.llamado_mesa
        AND ll.llamado = llm.llamado
        AND ll.periodo = p.periodo
        AND p.anio_academico = _anio_academico;
   
   -- Borro todos los registros de las tablas originales
   DELETE FROM sga_insc_examen_log_requisitos
         WHERE inscripcion_requisito IN (
                         SELECT h.inscripcion_requisito
                          FROM his_insc_examen_log_requisitos as h,
                               sga_insc_examen_log as i,
                               sga_llamados_mesa as llm,
                               sga_llamados_turno as ll,
                               sga_periodos as p
                          WHERE i.inscripcion = h.inscripcion
                            AND llm.llamado_mesa = i.llamado_mesa
                            AND ll.llamado = llm.llamado
                            AND ll.periodo = p.periodo
                            AND p.anio_academico = _anio_academico);
                            
   DELETE FROM sga_insc_examen_log
         WHERE inscripcion IN (
        SELECT h.inscripcion
          FROM his_insc_examen_log as h,
               sga_llamados_mesa as llm,
               sga_llamados_turno as ll,
               sga_periodos as p
          WHERE llm.llamado_mesa = h.llamado_mesa
            AND ll.llamado = llm.llamado
            AND ll.periodo = p.periodo
            AND p.anio_academico = _anio_academico);

   DELETE FROM sga_insc_examen
      WHERE inscripcion IN (
           SELECT h.inscripcion
             FROM his_insc_examen as h,
                  sga_llamados_mesa as llm,
                  sga_llamados_turno as ll,
                  sga_periodos as p
             WHERE h.llamado_mesa = llm.llamado_mesa
               AND ll.llamado = llm.llamado
               AND ll.periodo = p.periodo
               AND p.anio_academico = _anio_academico);

   -- Habilito nuevamente los triggers
   ALTER TABLE sga_insc_examen ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_examen_log ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_examen_log_requisitos ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_examen ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_examen_log ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_examen_log_requisitos ENABLE TRIGGER ALL;
   
END IF;

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- INSCRIPCIONES A CURSADAS
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
IF _cursadas = 1 THEN
   -- Deshabilito triggers para que no actuen sobre las tablas de evaluaciones
   ALTER TABLE sga_insc_cursada DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_instancias DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_subcomision DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_log DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_instancias_log DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_log_requisitos DISABLE TRIGGER ALL;
   ALTER TABLE sga_insc_subcomision_log DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_instancias DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_instancias_log DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_subcomision DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_subcomision_log DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_log DISABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_log_requisitos DISABLE TRIGGER ALL;

  -- Recupero comisiones involucradas
  CREATE TEMP TABLE temp_com (comision integer);
  INSERT INTO temp_com (comision)
    SELECT c.comision
    FROM sga_periodos as p,
         sga_periodos_lectivos as pl,
         sga_comisiones as c
    WHERE p.anio_academico = _anio_academico  
      AND pl.periodo = p.periodo
      AND c.periodo_lectivo = pl.periodo_lectivo;


  -- Inscripciones a cursadas
  INSERT INTO his_insc_cursada
        (inscripcion, comision, alumno, tipo, prioridad, estado_preinscripcion, plan_version, fecha_inscripcion, 
         fuera_de_termino, autorizado_por, nro_transaccion, motivo_excepcion, exceptuado, interfaz, estado, sq_token)
  SELECT i.inscripcion, i.comision, i.alumno, i.tipo, i.prioridad, i.estado_preinscripcion, i.plan_version, i.fecha_inscripcion, 
         i.fuera_de_termino, i.autorizado_por, i.nro_transaccion, i.motivo_excepcion, i.exceptuado, i.interfaz, i.estado, i.sq_token
    FROM sga_insc_cursada as i, 
         temp_com as c
    WHERE i.comision = c.comision;  

  -- Inscripcion a subcomisiones
  INSERT INTO his_insc_subcomision (inscripcion, subcomision)
    SELECT s.inscripcion, s.subcomision
      FROM sga_insc_subcomision as s, 
           sga_insc_cursada as i, 
           temp_com as c
    WHERE s.inscripcion = i.inscripcion
      AND i.comision = c.comision;

  -- Instancias de la inscripcion
  INSERT INTO his_insc_cursada_instancias (inscripcion, instancia)
    SELECT s.inscripcion, s.instancia
      FROM sga_insc_cursada_instancias as s, 
           sga_insc_cursada as i, 
           temp_com as c
    WHERE s.inscripcion = i.inscripcion
      AND i.comision = c.comision;


   -- Requisitos relacionados con los rechazos de Inscripciones
   INSERT INTO his_insc_cursada_log_requisitos
         (inscripcion_requisito, inscripcion, mensaje_validacion)
    SELECT r.inscripcion_requisito, r.inscripcion, r.mensaje_validacion
    FROM sga_insc_cursada_log_requisitos as r,
         sga_insc_cursada_log as i, 
         temp_com as c
    WHERE i.inscripcion = r.inscripcion
      AND c.comision = i.comision;

  -- Log de Instancias de Bajas y Rechazos de Inscripciones
  INSERT INTO his_insc_cursada_instancias_log (inscripcion, instancia)
   SELECT inst.inscripcion, inst.instancia
    FROM temp_com as c,
         sga_insc_cursada_log as i, 
         sga_insc_cursada_instancias_log as inst 
    WHERE i.comision = c.comision
      AND inst.inscripcion = i.inscripcion;

  -- Log de inscripcion a subcomisiones de Bajas y Rechazos de Inscripciones
  INSERT INTO his_insc_subcomision_log (inscripcion, subcomision)
   SELECT s.inscripcion, s.subcomision
    FROM temp_com as c,
         sga_insc_cursada_log as i, 
         sga_insc_subcomision_log as s 
    WHERE i.comision = c.comision
      AND s.inscripcion = i.inscripcion;


  -- Bajas y Rechazos de Inscripciones
  INSERT INTO his_insc_cursada_log
   (inscripcion, alumno, comision, plan_version, tipo, prioridad, estado_preinscripcion, fecha_inscripcion, fuera_de_termino, autorizado_por, nro_transaccion, 
    motivo_excepcion, exceptuado, interfaz, estado, sq_token, motivo_rechazo, operacion, fecha_operacion, nro_transaccion_log)
   SELECT 
    i.inscripcion, i.alumno, i.comision, i.plan_version, i.tipo, i.prioridad, i.estado_preinscripcion, i.fecha_inscripcion, i.fuera_de_termino, i.autorizado_por, i.nro_transaccion, 
    i.motivo_excepcion, i.exceptuado, i.interfaz, i.estado, i.sq_token, i.motivo_rechazo, i.operacion, i.fecha_operacion, i.nro_transaccion_log
    FROM sga_insc_cursada_log as i, 
         temp_com as c
    WHERE i.comision = c.comision;

  -- Borro registros de las tablas de inscripciones
  DELETE FROM sga_insc_subcomision
    WHERE inscripcion IN (
              SELECT h.inscripcion
                FROM his_insc_subcomision as h, 
                     sga_insc_cursada as i, 
                     temp_com as c
              WHERE h.inscripcion = i.inscripcion
                AND i.comision = c.comision);

  DELETE FROM sga_insc_cursada_instancias
    WHERE inscripcion IN (
                   SELECT h.inscripcion
                    FROM his_insc_cursada_instancias as h, 
                         sga_insc_cursada as i, 
                         temp_com as c
                  WHERE h.inscripcion = i.inscripcion
                    AND i.comision = c.comision);

   DELETE FROM sga_insc_cursada_log_requisitos
       WHERE inscripcion_requisito IN (
                     SELECT h.inscripcion_requisito
                     FROM his_insc_cursada_log_requisitos as h,
                          sga_insc_cursada_log as i, 
                          temp_com as c
                     WHERE i.inscripcion = h.inscripcion
                       AND c.comision = i.comision);
  
  DELETE FROM sga_insc_subcomision_log
     WHERE inscripcion IN (
                    SELECT h.inscripcion
                     FROM his_insc_cursada_log as h, 
                          temp_com as c
                     WHERE c.comision = h.comision);

  DELETE FROM sga_insc_cursada_instancias_log
     WHERE inscripcion IN (
                    SELECT h.inscripcion
                     FROM his_insc_cursada_log as h, 
                          temp_com as c
                     WHERE c.comision = h.comision);
      
  DELETE FROM sga_insc_cursada_log
     WHERE inscripcion IN (
                    SELECT h.inscripcion
                     FROM his_insc_cursada_log as h, 
                          temp_com as c
                     WHERE c.comision = h.comision);

  DELETE FROM sga_insc_cursada
     WHERE inscripcion IN (
                   SELECT h.inscripcion
                     FROM his_insc_cursada as h, 
                          temp_com as c
                     WHERE c.comision = h.comision);
   
   -- Borro tabla temporal   
   DROP TABLE temp_com;
   
   -- Habilito triggers 
   ALTER TABLE sga_insc_cursada ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_instancias ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_subcomision ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_log ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_instancias_log ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_cursada_log_requisitos ENABLE TRIGGER ALL;
   ALTER TABLE sga_insc_subcomision_log ENABLE TRIGGER ALL;
   
   ALTER TABLE his_insc_cursada ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_instancias ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_subcomision ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_log ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_log_requisitos ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_cursada_instancias_log ENABLE TRIGGER ALL;
   ALTER TABLE his_insc_subcomision_log ENABLE TRIGGER ALL;

END IF;

RETURN;
END
$$;
