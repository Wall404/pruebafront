CREATE VIEW vw_optativas AS SELECT e_generica.elemento AS elemento_generica,
    er_generica.elemento_revision AS elemento_revision_generica,
    e_optativa.elemento,
    er_optativa.elemento_revision,
    e_optativa.codigo,
    e_optativa.nombre,
    e_optativa.nombre_abreviado,
    e_optativa.entidad_subtipo,
    sga_g3entidades_subtipos.nombre AS entidad_subtipo_nombre,
    e_optativa.estado,
    sga_elementos_comp.puntaje,
    sga_elementos_comp.orden
   FROM (((((negocio.sga_elementos e_generica
     JOIN negocio.sga_elementos_revision er_generica ON ((er_generica.elemento = e_generica.elemento)))
     JOIN negocio.sga_elementos_comp ON ((sga_elementos_comp.elemento_padre = er_generica.elemento_revision)))
     JOIN negocio.sga_elementos_revision er_optativa ON ((sga_elementos_comp.elemento_hijo = er_optativa.elemento_revision)))
     JOIN negocio.sga_elementos e_optativa ON ((e_optativa.elemento = er_optativa.elemento)))
     JOIN negocio.sga_g3entidades_subtipos ON ((sga_g3entidades_subtipos.entidad_subtipo = e_optativa.entidad_subtipo)))
  WHERE (e_generica.entidad_subtipo = 2);
