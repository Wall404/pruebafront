create function negocio.f_generar_mesa(_turno_destino integer, _tipo_generacion_fecha character, _docentes character, _nombre character varying, _elemento integer, _catedra integer, _ubicacion integer, _instancia integer[], _escala_nota integer[], _plan integer[], _modalidad character[]) returns SETOF negocio.type_mesa_examen_llamado
LANGUAGE plpgsql
AS $$
DECLARE
  mesa_examen_nueva integer;
  llamado_mesa_nuevo integer;
  _llamado_mesa_nueva integer;
  _fecha_mesa date;
  _hora_inicio time;
  _def_hora_inicio time;
  _hora_fin time;
  _def_hora_fin time;
  _dia_examen varchar(10);
  i smallint;
  n integer;
  _division integer;
  docentes record;
  llamados record;
  cur_retorno   type_mesa_examen_llamado; -- para retornar datos de la mesa-llamado.
BEGIN

-- Valores default
_def_hora_inicio := time '08:00:00';
_def_hora_fin    := NULL;
_division        := NULL;

-- Creo el registro en la tabla de Mesas de Examen
INSERT INTO sga_mesas_examen (nombre, elemento, catedra, ubicacion, division) 
     VALUES (_nombre, _elemento, _catedra, _ubicacion, _division);

-- Recupero el Serial de la Mesa de Examen
mesa_examen_nueva := (SELECT currval('sga_mesas_examen_seq'));

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- Registro la Mesa de Examen en todos los llamados del turno destino
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FOR llamados IN SELECT sga_llamados_turno.llamado, sga_periodos.nombre as nombre_llamado, sga_periodos.fecha_inicio, sga_periodos.fecha_fin
     FROM sga_llamados_turno,
     	  sga_periodos
    WHERE sga_llamados_turno.turno_examen	= _turno_destino
      AND sga_llamados_turno.periodo = sga_periodos.periodo
LOOP
  -- Genero la Fecha y hora de inicio y finalización de la mesa de examen.
  IF _tipo_generacion_fecha = 'D' THEN
    -- Valor Default, se define la fecha de inicio del llamado
    _fecha_mesa  := llamados.fecha_inicio;
    _hora_inicio := _def_hora_inicio;
    _hora_fin    := _def_hora_fin;
  
  ELSEIF  _tipo_generacion_fecha = 'A' THEN
    -- Fecha definida en la Actividad
    SELECT dia_examen, hora_inicio_examen, hora_fin_examen
      INTO _dia_examen, _hora_inicio, _hora_fin
      FROM sga_elementos_atrib
      WHERE sga_elementos_atrib.elemento = _elemento;
    
    IF _dia_examen IS NULL THEN
      _fecha_mesa  := llamados.fecha_inicio;
    ELSE
      -- Mínima fecha del llamado correspondiente al dia de la semana definido para la actividad
      _fecha_mesa := f_minfechadia(llamados.fecha_inicio, llamados.fecha_fin, _dia_examen);
      IF _fecha_mesa IS NULL THEN
         _fecha_mesa  := llamados.fecha_inicio;
      END IF;
    END IF; 

    IF _hora_inicio IS NULL THEN
       _hora_inicio := _def_hora_inicio;
    END IF; 
    IF _hora_fin IS NULL THEN
       _hora_fin := _def_hora_fin;
    END IF; 
    
  ELSEIF  _tipo_generacion_fecha = 'C' THEN
    -- Fecha definida en la cátedra de la materia.
    IF _catedra IS NULL THEN
      _fecha_mesa  := llamados.fecha_inicio;
      _hora_inicio := _def_hora_inicio;
      _hora_fin    := _def_hora_fin;
    ELSE
       -- Recupero la fecha definida en la catedra y actividad dela mesa
    SELECT dia_examen, hora_inicio_examen, hora_fin_examen
      INTO _dia_examen, _hora_inicio, _hora_fin
      FROM 	sga_catedras_actividades,
      		sga_elementos
      WHERE sga_catedras_actividades.elemento = sga_elementos.elemento
      	AND	sga_catedras_actividades.catedra = _catedra
        AND sga_elementos.elemento = _elemento;
    END IF;

    IF _dia_examen IS NULL THEN
      _fecha_mesa  := llamados.fecha_inicio;
    ELSE  
      -- Mínima fecha del llamado correspondiente al dia de la semana definido para la actividad
      _fecha_mesa := f_minfechadia(llamados.fecha_inicio, llamados.fecha_fin, _dia_examen);
      IF _fecha_mesa IS NULL THEN
         _fecha_mesa  := llamados.fecha_inicio;
      END IF;
    END IF; 
    
    IF _hora_inicio IS NULL THEN
       _hora_inicio := _def_hora_inicio;
    END IF; 
    IF _hora_fin IS NULL THEN
       _hora_fin := _def_hora_fin;
    END IF; 
  END IF;
  
  -- Asocio la Mesa de Examen en el Llamado
  INSERT INTO sga_llamados_mesa (llamado, mesa_examen, fecha, hora_inicio, hora_finalizacion)
      VALUES (llamados.llamado, mesa_examen_nueva, _fecha_mesa, _hora_inicio, _hora_fin);
  llamado_mesa_nuevo := (SELECT currval('sga_llamados_mesa_seq'));

  -- Retorno los datos de la mesa en el llamado que fue copiado.
  SELECT 1,  -- ok
  		 mesa_examen_nueva,
         llamados.llamado, 
         llamados.nombre_llamado, 
         llamado_mesa_nuevo, 
         to_char(_fecha_mesa, 'dd/mm/yyyy'), 
         to_char(_hora_inicio, 'hh:mm'), 
         to_char(_hora_fin, 'hh:mm'), 
         NULL
       INTO cur_retorno;
  RETURN NEXT cur_retorno;
  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
  -- Defino los docentes en la Mesa de Examen.
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
  IF _docentes = 'C' THEN
   -- Recupero los docentes del tribunal de examen asociado a la CATEDRA y ACTIVIDAD.
   FOR docentes IN SELECT sga_tribunal_docentes.docente, sga_tribunal_docentes.rol
       FROM	 sga_catedras, 
             sga_catedras_actividades, 
             sga_tribunal_examen,
             sga_tribunal_actividades,
             sga_tribunal_docentes
       WHERE sga_catedras.catedra = _catedra
         AND sga_catedras.estado  = 'A'
         AND sga_catedras.catedra_tipo IN ('E','A')  -- Examen, Cursada y Examen.
         AND sga_catedras_actividades.catedra = sga_catedras.catedra
         AND sga_catedras_actividades.elemento = _elemento
         AND sga_catedras_actividades.estado = 'A'
         AND sga_tribunal_examen.tribunal = sga_catedras_actividades.tribunal
         AND sga_tribunal_actividades.tribunal = sga_tribunal_examen.tribunal
         AND sga_tribunal_docentes.tribunal = sga_tribunal_examen.tribunal 
         AND sga_tribunal_actividades.estado = 'A'
         AND sga_tribunal_docentes.estado = 'A'
         
   LOOP
     -- Inserto el Docente del Tribunal asociado a la catedra.
     INSERT INTO sga_docentes_mesa_llamado (llamado_mesa, docente, rol) VALUES (llamado_mesa_nuevo, docentes.docente, docentes.rol);
   END LOOP;
  
  ELSEIF _docentes = 'T' THEN
   
   -- *********************************************************************
   -- Recupero los docentes del Tribunal de la ACTIVIDAD
   -- *********************************************************************
   FOR docentes IN SELECT	sga_tribunal_docentes.docente, sga_tribunal_docentes.rol
      FROM sga_tribunal_actividades,
           sga_tribunal_examen,
           sga_tribunal_docentes
      WHERE sga_tribunal_actividades.elemento = _elemento
        AND sga_tribunal_actividades.estado = 'A'
        AND sga_tribunal_actividades.tribunal = sga_tribunal_examen.tribunal
        AND sga_tribunal_examen.tribunal = sga_tribunal_docentes.tribunal
        AND sga_tribunal_examen.estado = 'A'
        AND sga_tribunal_docentes.estado = 'A'
   LOOP
     -- Inserto el Docente del tribunal
     INSERT INTO sga_docentes_mesa_llamado (llamado_mesa, docente, rol)  VALUES (llamado_mesa_nuevo, docentes.docente, docentes.rol);
   END LOOP;
   
  END IF;
    
END LOOP;
  

-- Creo el registro en la tabla de Instancias de la Mesa. Uno por cada instancia recibida.
-- Cuando se pase a 8.4 o superior usar la funcion array_lenght(array[]) para sacar el valor n.
n := (select array_upper( _instancia, 1) - array_lower( _instancia ,1) + 1);
FOR i IN 1 .. n 
LOOP
  INSERT INTO sga_mesas_examen_instancias (mesa_examen, instancia, escala_nota) VALUES (mesa_examen_nueva, _instancia[i], _escala_nota[i]);
END LOOP;

-- Creo el registro en la tabla de Propuestas de la Mesa.
-- Solo Planes y versiones donde se encuentra la actividad de la mesa y que fue pasado como parámetro.
-- Se supone que en el array vienen planes activos (vigentes y no vigentes)
INSERT INTO sga_mesas_examen_propuestas (mesa_examen, propuesta, plan)  
   SELECT DISTINCT mesa_examen_nueva, propuesta, plan
     FROM vw_actividades_plan
     WHERE elemento = _elemento
       AND plan = ANY (_plan);

-- Creo el o los registros en la tabla de Modalidades de la Mesa
INSERT INTO sga_mesas_examen_modalidad (mesa_examen, modalidad)
   SELECT DISTINCT mesa_examen_nueva, sga_elementos_plan_modalidad.modalidad
     FROM vw_actividades_plan, sga_elementos_plan_modalidad
    WHERE vw_actividades_plan.elemento = _elemento
      AND vw_actividades_plan.plan = ANY (_plan)
      AND vw_actividades_plan.elemento_plan = sga_elementos_plan_modalidad.elemento_plan
      AND sga_elementos_plan_modalidad.modalidad = ANY (_modalidad);

RETURN;

END;
$$;
