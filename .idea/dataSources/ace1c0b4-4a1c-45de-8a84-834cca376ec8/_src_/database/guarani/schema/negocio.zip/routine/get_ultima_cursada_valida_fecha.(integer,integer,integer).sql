create function negocio.get_ultima_cursada_valida_fecha(palumno integer, pactividad integer, pvigente integer) returns text
LANGUAGE plpgsql
AS $$
-- Recibe:
-- pVigente: 0 - Regularidad Vencida  / 1 - Regularidad Vigente / NULL - No controla la vigencia de la regularidad.
DECLARE 
  _fecha_regularidad date;
  cur1 record;
        
  BEGIN
   _fecha_regularidad := NULL;

  -- Recupero la fecha de ultima regularidad aprobada y vigente de un alumno
  FOR cur1 IN SELECT  vw_regularidades_basica.fecha
                FROM vw_regularidades_basica 
               WHERE vw_regularidades_basica.alumno   = pAlumno
                 AND vw_regularidades_basica.elemento = pActividad
                 AND (pVigente IS NULL OR vw_regularidades_basica.es_vigente = pVigente)
                 AND vw_regularidades_basica.resultado = 'A'
            ORDER BY vw_regularidades_basica.fecha DESC
  LOOP
    -- Retorno la fecha de regularidad
    _fecha_regularidad :=  cur1.fecha;
    EXIT;
  END LOOP;
	
  RETURN _fecha_regularidad;
    
END;
$$;
