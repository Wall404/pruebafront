CREATE VIEW vw_componentes_modulo_plan AS SELECT ep.plan_version,
    COALESCE(ep.nombre, e_modulo.nombre) AS modulo_nombre,
    e_modulo.codigo AS modulo_codigo,
    e_modulo.elemento AS modulo_elemento,
    er_modulo.elemento_revision AS modulo_elemento_revision,
    e_modulo.entidad_subtipo AS modulo_entidad_subtipo,
    e_componente.elemento,
    er_componente.elemento_revision,
    e_componente.codigo,
    COALESCE(ep_componente.nombre, e_componente.nombre) AS nombre,
    COALESCE(ep_componente.nombre_abreviado, e_componente.nombre_abreviado) AS nombre_abreviado,
    e_componente.entidad_subtipo,
    es_componente.nombre AS entidad_subtipo_nombre,
    e_componente.estado,
    sga_elementos_comp.puntaje,
    sga_elementos_comp.orden
   FROM ((((((((negocio.sga_elementos_plan ep
     JOIN negocio.sga_elementos_revision er_modulo ON ((er_modulo.elemento_revision = ep.elemento_revision)))
     JOIN negocio.sga_elementos e_modulo ON ((e_modulo.elemento = er_modulo.elemento)))
     JOIN negocio.sga_g3entidades_subtipos es_modulo ON ((es_modulo.entidad_subtipo = e_modulo.entidad_subtipo)))
     JOIN negocio.sga_elementos_comp ON ((sga_elementos_comp.elemento_padre = er_modulo.elemento_revision)))
     JOIN negocio.sga_elementos_revision er_componente ON ((er_componente.elemento_revision = sga_elementos_comp.elemento_hijo)))
     JOIN negocio.sga_elementos e_componente ON ((e_componente.elemento = er_componente.elemento)))
     JOIN negocio.sga_g3entidades_subtipos es_componente ON ((es_componente.entidad_subtipo = e_componente.entidad_subtipo)))
     JOIN negocio.sga_elementos_plan ep_componente ON (((ep_componente.plan_version = ep.plan_version) AND (ep_componente.elemento_revision = er_componente.elemento_revision))))
  WHERE (es_modulo.entidad_tipo = 1);
