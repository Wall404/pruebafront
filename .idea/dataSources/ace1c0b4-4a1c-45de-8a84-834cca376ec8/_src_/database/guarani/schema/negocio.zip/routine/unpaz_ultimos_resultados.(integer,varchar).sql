create function negocio.unpaz_ultimos_resultados(_persona integer, _codigomat character varying) returns character varying
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _res character varying;

BEGIN
	_res := 'No cursó!';

	SELECT case when (h.resultado='A') then 'Aprobado' else 
	case when (r.resultado='A' and (h.resultado is null or h.resultado not in ('A'))) then 'Regular' else 
	case when(r.resultado='R') then 'Reprobado' else 
	case when (r.resultado='U') then 'Ausente' else 'No cursó' end end end end as Resultado INTO _res
	from negocio.mdp_personas as p
	LEFT JOIN negocio.vw_regularidades as r on (p.persona=r.persona and r.actividad_codigo = _codigomat)
	left join negocio.vw_hist_academica as h on (p.persona=h.persona and h.actividad_codigo = _codigomat)
	WHERE p.persona = _persona
	group by p.persona, r.resultado, r.fecha, h.fecha, h.resultado
	order by r.fecha desc, h.fecha desc
	Limit 1;

	RETURN _res;
END;
$$;
