create function negocio.f_clases_banda_horaria(pfechadesde date, pfechahasta date, pperiodicidad character varying, pdiasemana character varying) returns SETOF date
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt  integer;
  _fecha date;
  _dia_semana_fecha smallint;
  _fecha_no_valida smallint;
  
BEGIN
 
  -- Recorro todos los dias desde la fecha de inicio y fecha de finalizacion de la asignacion
  _fecha := pFechaDesde;
  cnt := 0;
  WHILE _fecha <= pFechaHasta LOOP
    
    -- 0 = Domingo.... 6 = Sabado
   _dia_semana_fecha := (SELECT EXTRACT(DOW FROM _fecha));
   IF (pDiaSemana = 'Domingo' and _dia_semana_fecha = 0) OR   
       (pDiaSemana = 'Lunes' and _dia_semana_fecha = 1) OR   
       (pDiaSemana = 'Martes' and _dia_semana_fecha = 2) OR   
       (pDiaSemana = 'Miercoles' and _dia_semana_fecha = 3) OR   
       (pDiaSemana = 'Jueves' and _dia_semana_fecha = 4) OR   
       (pDiaSemana = 'Viernes' and _dia_semana_fecha = 5) OR   
       (pDiaSemana = 'Sabado' and _dia_semana_fecha = 6) THEN
    
      -- Verifico si la clase cae en un dia no laborable.
      SELECT COUNT(*) INTO _fecha_no_valida FROM sga_dias_no_laborables WHERE fecha = _fecha;
       
      IF _fecha_no_valida > 0 THEN
          -- No retorno la fecha de la clase.
      ELSE
         -- Retorno la fecha que corresponderia a la clase de la banda horaria
         RETURN NEXT _fecha;
      END IF; 

      cnt := cnt + 1;
      
      -- sumo dias segun la periodicidad
      IF pPeriodicidad = 'Semanal' THEN
        _fecha := _fecha + 7;
      ELSEIF pPeriodicidad = 'Quincenal' THEN
        _fecha := _fecha + 14;
      ELSEIF pPeriodicidad = 'Mensual' THEN
        _fecha := _fecha + 28;
      ELSE 
        _fecha := _fecha + 1;
      END IF;
    ELSE
      -- sumo un dia
      _fecha := _fecha + 1;
    END IF;
      
  END LOOP;
    
END;
$$;
