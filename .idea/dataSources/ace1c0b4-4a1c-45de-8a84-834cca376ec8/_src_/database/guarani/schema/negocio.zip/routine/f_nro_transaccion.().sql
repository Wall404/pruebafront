create function negocio.f_nro_transaccion() returns integer
LANGUAGE plpgsql
AS $$
BEGIN
    -- Inserto registro en tabla de nros de transacciones
    --INSERT INTO sga_nros_transacciones DEFAULT VALUES;
    -- nro_transaccion := (SELECT currval('sga_nros_transacciones_seq'));
    
    -- Retorno el siguiente número de la Secuencia.
    RETURN (SELECT nextval('aud_nro_transaccion_seq'));
  END;
$$;
