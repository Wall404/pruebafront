create function negocio.ftda_sga_alumnos_optativas() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _cnt smallint;
BEGIN

  INSERT INTO sga_alumnos_optativas_mov (alumno, plan_version, generica, optativa, accion)
	   VALUES (OLD.alumno, OLD.plan_version, OLD.generica, OLD.optativa, 'D');

  RETURN OLD;
END;
$$;
