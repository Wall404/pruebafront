create function negocio.f_anular_rechazo_insc_cursada(pinscripcion integer) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno type_retorno_inscripcion;
  _con_subcomisiones boolean;
  _cnt Smallint;
  logs sga_insc_cursada_log%ROWTYPE;
BEGIN
  
  -- Variables de retorno
  cur_retorno.resultado := -1;
  cur_retorno.mensaje_indice := '800CUR_anular_rechazo_insc_cursada_ok';
  cur_retorno.mensaje_param  := NULL;
  cur_retorno.inscripcion    := pInscripcion;
  
  _con_subcomisiones := false;
  _cnt := 0;

  -- ********************************************************************
  -- 1. Verifico que exista la inscripcion rechazada
  -- ********************************************************************
  SELECT * INTO logs
    FROM sga_insc_cursada_log 
   WHERE inscripcion = pInscripcion;
   
  IF NOT FOUND THEN
    cur_retorno.mensaje_indice := '800CUR_anular_rechazo_insc_cursada_no_existe';
    cur_retorno.mensaje_param  := cast(pInscripcion as text);
    RETURN cur_retorno;
  END IF;
   
  
  -- Verifico si tiene subcomisiones
  SELECT COUNT(*) INTO _cnt FROM sga_subcomisiones WHERE comision = logs.comision;
  IF _cnt > 0 THEN
     _con_subcomisiones := true;
  END IF;
 
-- Comienzo transacción.
BEGIN

  -- ********************************************************************
  -- Control de Cupo
  -- Si tiene subcomisiones controla el cupo en cada subcomision a la que se inscribe.
  -- Si no tiene subcomisiones, controla el cupo en la comisión.
  -- ********************************************************************
     IF _con_subcomisiones THEN
         -- Actualizo el cupo en las subcomisiones si hay subcomisiones
         UPDATE sga_subcomisiones_cupo
            SET cant_inscriptos = cant_inscriptos + 1
          WHERE subcomision IN (SELECT subcomision FROM sga_insc_subcomision_log WHERE inscripcion = pInscripcion);
     END IF; -- con subcomisiones

     -- Actualizo el cupo en comision
     UPDATE sga_comisiones_cupo
        SET cant_inscriptos = cant_inscriptos + 1
      WHERE comision = logs.comision;
  -- ****************** FIN Actualizacion cupo **************************


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Vuelvo a registrar la inscripcion rechazada
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO sga_insc_cursada (
           inscripcion, comision, alumno, plan_version, tipo, prioridad, estado_preinscripcion, 
           fuera_de_termino, estado, interfaz, fecha_inscripcion, nro_transaccion, motivo_excepcion, exceptuado, autorizado_por)
   VALUES (logs.inscripcion, logs.comision, logs.alumno, logs.plan_version, logs.tipo, logs.prioridad, logs.estado_preinscripcion, logs.fuera_de_termino, 
           logs.estado, logs.interfaz, logs.fecha_inscripcion, logs.nro_transaccion, logs.motivo_excepcion, logs.exceptuado, logs.autorizado_por);
 

  -- Log de Instancias de la inscripcion
  INSERT INTO sga_insc_cursada_instancias (inscripcion, instancia)
    SELECT inscripcion, instancia
      FROM sga_insc_cursada_instancias_log
     WHERE inscripcion = pInscripcion;
     
  -- Log de insc a Subcomisiones
  INSERT INTO sga_insc_subcomision (inscripcion, subcomision)
    SELECT inscripcion, subcomision
      FROM sga_insc_subcomision_log
     WHERE inscripcion = pInscripcion;
     

  -- Borro las inscripciones
  DELETE FROM sga_insc_subcomision_log WHERE inscripcion = pInscripcion;
  DELETE FROM sga_insc_cursada_instancias_log WHERE inscripcion = pInscripcion;
  DELETE FROM sga_insc_cursada_log WHERE inscripcion = pInscripcion;

  -- Bloque de excepciones. Sale por error.
  EXCEPTION 
      WHEN OTHERS THEN
        cur_retorno.mensaje_indice := '800CUR_anular_rechazo_insc_cursada_error_db';
        cur_retorno.sqlstate := SQLSTATE;
        cur_retorno.sqlerrm  := SQLERRM;
        RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- Rechazo OK.
  -- Seteo valores para retorno
  cur_retorno.resultado       := 1;
  cur_retorno.mensaje_indice  := '800CUR_anular_rechazo_insc_cursada_ok';

  
  -- Retorno datos de la baja de la inscripcion
  RETURN cur_retorno;

END;
$$;
