create function negocio.ftua_sga_comisiones_instancias() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion Integer;
BEGIN

   -- Si se modifico la escala de notas, actualizo la misma en los alumnos de la comision
   IF NEW.escala_nota <> OLD.escala_nota THEN
     SELECT sga_evaluaciones.evaluacion INTO _evaluacion
      FROM sga_comisiones,
           sga_evaluaciones,
           sga_evaluaciones_tipos
     WHERE sga_comisiones.comision = NEW.comision
       AND sga_evaluaciones.entidad = sga_comisiones.entidad
       AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
       AND sga_evaluaciones_tipos.automatica = 'S';

     -- Regulares      
     IF NEW.instancia = 1 THEN 
       -- Actualizo la escala de notas a los alumnos 
       UPDATE sga_eval_detalle_cursadas 
          SET escala_nota_cursada = NEW.escala_nota,
              nota_cursada = NULL, 
              resultado_cursada = NULL 
        WHERE evaluacion = _evaluacion;
     END IF;   

     -- Promociones
     IF NEW.instancia = 2 THEN 
       -- Actualizo la escala de notas a los alumnos 
       UPDATE sga_eval_detalle_cursadas
          SET escala_nota_promocion = NEW.escala_nota,
              nota_promocion = NULL,
              resultado_promocion = NULL 
        WHERE evaluacion = _evaluacion;
     END IF;   
     
     -- Actualizo en el acta de cursadas/promocion de la comision.
     -- Solo en actas abiertas (se supone que no se permite cambiar la escala de notas si hay algun acta cerrada)
     UPDATE sga_actas_instancias
        SET escala_nota = NEW.escala_nota
       FROM sga_actas
       WHERE sga_actas.comision = NEW.comision
         AND sga_actas_instancias.id_acta = sga_actas.id_acta
         AND sga_actas_instancias.instancia = NEW.instancia   
         AND sga_actas.estado = 'A';
 
   END IF;
   
   RETURN NEW;
END;
$$;
