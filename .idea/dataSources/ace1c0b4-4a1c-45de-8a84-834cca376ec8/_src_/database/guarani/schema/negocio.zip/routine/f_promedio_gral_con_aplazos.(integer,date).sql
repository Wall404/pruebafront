create function negocio.f_promedio_gral_con_aplazos(_alumno integer, _fecha date) returns numeric
LANGUAGE plpgsql
AS $$
DECLARE 
  _promedio numeric(8,3);
        
BEGIN
  
  -- Recupero el promedio general con aplazos.
  _promedio := f_promedio(_alumno, _fecha, NULL, 'S');

  -- Retorno el promedio
  RETURN _promedio;
    
END;
$$;
