create function negocio.get_escala_nota(pplanversion integer, pactividad integer, palcance character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
 _escala_nota integer;

BEGIN

--  pAlcance: EXAMEN / CURSADA / PROMOCION / EQUIVALENCIA_TOTAL / EQUIVALENCIA_PARCIAL / EQUIVALENCIA_REGULARIDAD

 _escala_nota := NULL;

 -- Busco la escala de notas en la version del plan de estudios
 SELECT 
    CASE pAlcance
      WHEN 'EXAMEN'    THEN sga_elementos_plan.escala_nota_examen
      WHEN 'CURSADA'   THEN sga_elementos_plan.escala_nota_cursada_regular
      WHEN 'PROMOCION' THEN sga_elementos_plan.escala_nota_cursada_promocion
      WHEN 'EQUIVALENCIA_TOTAL'       THEN sga_elementos_plan.escala_nota_equivalencia
      WHEN 'EQUIVALENCIA_PARCIAL'     THEN sga_elementos_plan.escala_nota_equivalencia
      WHEN 'EQUIVALENCIA_REGULARIDAD' THEN sga_elementos_plan.escala_nota_cursada_regular
    END
    INTO _escala_nota
 FROM sga_elementos_plan,
      sga_elementos_revision
 WHERE plan_version = pPlanVersion
   AND sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision
   AND sga_elementos_revision.elemento = pActividad;
   
 IF NOT FOUND THEN
    SELECT 
       CASE pAlcance
         WHEN 'EXAMEN'    THEN escala_nota_examen
         WHEN 'CURSADA'   THEN escala_nota_cursada_regular
         WHEN 'PROMOCION' THEN escala_nota_cursada_promocion
         WHEN 'EQUIVALENCIA_TOTAL'       THEN escala_nota_equivalencia
         WHEN 'EQUIVALENCIA_PARCIAL'     THEN escala_nota_equivalencia
         WHEN 'EQUIVALENCIA_REGULARIDAD' THEN escala_nota_cursada_regular
       END
       INTO _escala_nota
    FROM sga_elementos_atrib
    WHERE sga_elementos_atrib.elemento = pActividad;
 END IF;  
 
 -- Retorno la escala de notas
 RETURN _escala_nota; 
 
END;
$$;
