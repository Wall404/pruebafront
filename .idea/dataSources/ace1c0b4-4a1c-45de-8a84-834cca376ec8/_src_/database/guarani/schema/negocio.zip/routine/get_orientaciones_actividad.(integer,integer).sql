create function negocio.get_orientaciones_actividad(pplanversion integer, pactividad integer) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE 
  cur1 record;
  cnt integer;
        
BEGIN
   cnt := 0;	
		
  -- Recupera los modulos de tipo orientacion que se encuentran en el plan de estudios
  -- Las orientaciones pueden pertenecer a mas de un certificado/titulo
  FOR cur1 IN SELECT elemento, elemento_revision
                FROM vw_elementos_plan
               WHERE plan_version = pPlanVersion
                 AND entidad_subtipo = 3
  LOOP
     -- Por cada orientacion, verifico si se encuentra la actividad y si existe entonces devuelvo el id del modulo orientacion
     cnt := 0;
     SELECT COUNT(1) INTO cnt
       FROM get_elemento_contenido(cur1.elemento_revision, pPlanVersion, false, true)
      WHERE elemento = pActividad;	
     IF cnt > 0 THEN
        -- La actividad existe en la orientacion, devuelvo el id del modulo que corresponde a la orientacion.	
	RETURN NEXT cur1.elemento;
     END IF;

  END LOOP;
    
END;
$$;
