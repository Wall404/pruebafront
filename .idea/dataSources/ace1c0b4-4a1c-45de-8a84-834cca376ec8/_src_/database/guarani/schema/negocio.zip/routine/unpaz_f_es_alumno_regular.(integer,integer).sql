create function negocio.unpaz_f_es_alumno_regular(palumno integer, panioacademico integer) returns boolean
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _propuesta integer;
 DECLARE _responsable_academica integer;
 DECLARE _fecha_fin date;
 DECLARE _fecha_inicio date;
 DECLARE _plan_version integer;
 DECLARE _cant_no_aprobadas integer;
 DECLARE _no_regularizadas_aprobadas integer;
 DECLARE _anio_ingreso integer;
 DECLARE _duracion_en_anios integer;
 DECLARE _es_activo_anio_1 INTEGER;
 DECLARE _es_activo_anio_2 INTEGER;
 DECLARE _es_activo_anio_3 INTEGER;
 DECLARE _es_activo_anio_ingreso INTEGER;
 DECLARE _cant_total_elementos INTEGER;
 DECLARE _anio_academico_activo_primera_vez INTEGER;

BEGIN

  
  --Obtengo la propuesta y responsable academica y el plan version del alumno. La primera RA que esté asociada
  SELECT alu.propuesta, responsable_academica, alu.plan_version, anio_academico, duracion_en_anios INTO _propuesta, _responsable_academica, _plan_version, _anio_ingreso, _duracion_en_anios
	FROM 	sga_alumnos alu
	JOIN	sga_propuestas_aspira asp ON asp.persona = alu.persona AND asp.propuesta = alu.propuesta
	JOIN	sga_propuestas_ra pra ON pra.propuesta = alu.propuesta
	JOIN	sga_planes_versiones pv ON pv.plan_version = alu.plan_version
	JOIN 	sga_planes pl ON pl.plan = pv.plan
	WHERE	alumno = palumno
	ORDER BY situacion_asp
	LIMIT 1;

  /*
  El siguiente control se realiza según lo especificado en el artículo 4 del RÉGIMEN DE REGULARIDAD DE LOS/AS ESTUDIANTES del reglamento de estudiantes vigente en Oct-2018
  
  ARTÍCULO 4°.  Los/as estudiantes revisten una situación activa desde el momento de su inscripción inicial en una unidad curricular (UC) de las Carreras de Pregrado 
		y Grado de la UNPAZ, y la mantienen en la medida en que cumplan al menos uno los siguientes requisitos:
			a.  Haber aprobado al menos 2 (dos) UUCC en el transcurso de los 2 (dos) últimos años académicos;
			b.  Haber cumplido con un mínimo de 75% de asistencia de al menos 2 (dos) UUCC en el año académico anterior;
			c.  Haber aprobado todas las UUCC del Plan de Estudios y tener pendiente de aprobación el trabajo final de la Carrera;
			d.  Haber regularizado todas las UUCC del Plan de Estudios, y tener pendiente la aprobación de una o más de ellas o el trabajo final.
			
  ARTÍCULO 5°:  Los/as  estudiantes  que  no  cumplan  con  los requisitos  establecidos en el artículo anterior serán considerados/as estudiantes inactivos.
  ARTÍCULO 6°:  Los/as  estudiantes  que  hayan  quedado  inactivos  por  un  período igual o mayor a 3 (tres) años, 
	        o que no hayan completado el Plan de Estudios de su Carrera en  el  doble  del  plazo  estimado  por  
	        el  mismo  para  su  egreso,  perderán  su condición de regulares.
  */

 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- a.  Haber aprobado al menos 2 (dos) UUCC en el transcurso de los 2 (dos) últimos años académicos;
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  --Si el año de ingreso es el actual o el anterior el alumno es regular, ya que sólo deja de ser regular luego de 3 años
  IF (panioacademico = _anio_ingreso OR panioacademico - 1 = _anio_ingreso) THEN
	RETURN TRUE;
  END IF;

  --Verifico el año en que se inscribió por primera vez a materias
  SELECT MIN(anio_academico) INTO _anio_academico_activo_primera_vez
	FROM	sga_insc_cursada cur
	JOIN	sga_comisiones com On com.comision = cur.comision
	JOIN	vw_periodos_lectivos lect ON lect.periodo_lectivo = com.periodo_lectivo
	WHERE	alumno = palumno;

  --Si se inscribió por primera vez en alguno de los últimos 3 años lo considero activo ese año y por lo tanto regular
  IF(panioacademico - _anio_academico_activo_primera_vez < 3 ) THEN
	RETURN TRUE;
  END IF;

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  /*ARTÍCULO 6º Los/as estudiantes que no hayan completado el Plan de Estudios de su Carrera en el doble del plazo
	    estimado por el mismo para su egreso, perderán su condición de regulares. 
	    CONTROLO que no haya pasado el doble del plazo estimado para egreso*/
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  IF (panioacademico - _anio_ingreso >= (_duracion_en_anios * 2)) THEN
	RETURN FALSE;
  END IF;
  
  --Cuento la cantidad de materias aprobadas en los 2 años anteriores de los 3 últimos años académicos y la cantidad total de materias
   SELECT       COUNT(DISTINCT case when panioacademico - anios_aprobacion.anio_academico <= 2 AND panioacademico - anios_aprobacion.anio_academico >  0 THEN elemento end) AS es_activo_anio_1,
		COUNT(DISTINCT case when panioacademico - anios_aprobacion.anio_academico >= 2 AND panioacademico - anios_aprobacion.anio_academico <= 3 THEN elemento end) AS es_activo_anio_2 ,
		COUNT(DISTINCT case when panioacademico - anios_aprobacion.anio_academico >= 3 AND panioacademico - anios_aprobacion.anio_academico <= 4 THEN elemento end) AS es_activo_anio_3,
		COUNT(DISTINCT elemento) AS cant_total_elementos
			INTO _es_activo_anio_1, _es_activo_anio_2, _es_activo_anio_3, _cant_total_elementos
	FROM 	vw_hist_academica_basica
	JOIN	(SELECT fecha_inicio, fecha_fin, anio_academico
			FROM sga_anios_academicos_fechas af
			JOIN sga_anios_academicos_ra ra ON ra.id_fecha = af.id_fecha 
			AND  responsable_academica = 2) anios_aprobacion On vw_hist_academica_basica.fecha between fecha_inicio AND fecha_fin
	WHERE	vw_hist_academica_basica.resultado = 'A'
	AND	vw_hist_academica_basica.origen_otra_propuesta = false
	AND	vw_hist_academica_basica.alumno = palumno
	AND	elemento IN (SELECT elemento FROM get_plan_contenido(_plan_version) WHERE entidad_tipo = 2);

  --si aprobó dos o más materias en alguno de esos rangos el alumno es regular
  IF(_es_activo_anio_1 >= 2 OR _es_activo_anio_2 >= 2 OR _es_activo_anio_3 >= 2) THEN
	RETURN TRUE;
  ELSE
     
	--SI Nunca aprobó ninguna materia NO es regular. Hago este control acá para no seguir con los siguientes
	IF(_cant_total_elementos = 0) THEN
		RETURN FALSE;
	END IF;

	 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 -- b.  Haber cumplido con un mínimo de 75% de asistencia de al menos 2 (dos) UUCC en el año académico anterior;
	 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	  --No se implementa esta condición por el momento ya que no existen datos fidedignos que cumplan con esta condición

	 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 -- d.  Haber regularizado todas las UUCC del Plan de Estudios, y tener pendiente la aprobación de una o más de ellas o el trabajo final.
	 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	 --25/10/2018: Como por el momento no se cuenta con informacion del trabajo final, se decide modificar esta condicion y tomar:
	 --HABER AL MENOS REGULARIZADO TODAS LAS UUCC DEL PLAN DE ESTUDIOS y tener pendiente la aprobación de una o más de ellas

	--Obtengo la fecha de fin del año academico anterior al año procesar
	  _fecha_fin := (SELECT fecha_fin 
				FROM sga_anios_academicos_fechas af
				JOIN sga_anios_academicos_ra ra ON ra.id_fecha = af.id_fecha 
				AND  anio_academico = panioacademico - 1
				AND  responsable_academica = _responsable_academica);

	  --Obtengo la fecha de inicio del año academico anterior al año procesar
	  _fecha_inicio := (SELECT fecha_inicio 
				FROM sga_anios_academicos_fechas af
				JOIN sga_anios_academicos_ra ra ON ra.id_fecha = af.id_fecha 
				AND  anio_academico = panioacademico - 1
				AND  responsable_academica = _responsable_academica);

	 --Cuento la cantidad de materias no regularizadas / aprobadas
	 SELECT count(1) INTO _no_regularizadas_aprobadas
		FROM (
			 SELECT elemento
				FROM get_plan_contenido(_plan_version) 
				WHERE entidad_tipo = 2
			 EXCEPT 
			 SELECT DISTINCT elemento 
				FROM (
					 SELECT elemento
						FROM  	vw_hist_academica_basica
						WHERE	vw_hist_academica_basica.resultado = 'A'
						AND	vw_hist_academica_basica.alumno = palumno
						AND	fecha < _fecha_fin
					 UNION ALL
					 SELECT elemento
						FROM  	vw_regularidades_basica
						WHERE	vw_regularidades_basica.resultado = 'A'
						AND	vw_regularidades_basica.fecha_vigencia >= _fecha_fin
						AND	vw_regularidades_basica.alumno = palumno
						AND	fecha < _fecha_fin
				     ) as regularizadas_aprobadas
		     ) as regularizadas_aprobadas;

	  --Cumple condicion (d) . ES REGULAR
	  IF (_no_regularizadas_aprobadas = 0 AND _cant_no_aprobadas > 0) THEN
		RETURN TRUE;
	  END IF;

	  --Si el alumno DEBE la aprobación/regularización de MÁS de Una no entra en la siguiente condición y es NO REGULAR
	  IF (_no_regularizadas_aprobadas > 0) THEN
		RETURN FALSE;
	  END IF;

	 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	 -- c.  Haber aprobado todas las UUCC del Plan de Estudios y tener pendiente de aprobación el trabajo final de la Carrera;
	 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	 --25/10/2018: Como por el momento no se cuenta con informacion del trabajo final, se decide modificar esta condicion y tomar:
	 --HABER APROBADO TODAS LAS UUCC DEL PLAN DE ESTUDIOS MENOS UNA (LA QUE LE FALTA PUEDE ESTAR REGULARIZADA O NO)

	 --Cuento la cantidad de materias no aprobadas
	 SELECT count(1) INTO _cant_no_aprobadas
		FROM (
			 SELECT elemento
				FROM get_plan_contenido(_plan_version) 
				WHERE entidad_tipo = 2
			 EXCEPT 
			 SELECT elemento
				FROM  	vw_hist_academica_basica
				WHERE	vw_hist_academica_basica.resultado = 'A'
				AND	vw_hist_academica_basica.alumno = palumno
				AND	fecha < _fecha_fin
		      ) as no_aprobadas;

	  --Cumple condicion (c) . ES REGULAR
	  IF (_cant_no_aprobadas = 1) THEN
		RETURN TRUE;
	  END IF;

  END IF;
  

RETURN FALSE;
 
END;
$$;
