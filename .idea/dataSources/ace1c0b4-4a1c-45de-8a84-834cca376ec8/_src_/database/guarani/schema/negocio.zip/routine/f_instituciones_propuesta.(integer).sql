create function negocio.f_instituciones_propuesta(_propuesta integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	cnt smallint;
	_retorno text;
	cur1 record;

BEGIN
	cnt := 0;
	_retorno := NULL;
	FOR cur1 IN	SELECT		DISTINCT sga_instituciones.nombre
				FROM		sga_propuestas_ra,
							sga_responsables_academicas,
							sga_instituciones
				WHERE		sga_propuestas_ra.responsable_academica = sga_responsables_academicas.responsable_academica AND
							sga_responsables_academicas.institucion = sga_instituciones.institucion AND
							sga_propuestas_ra.propuesta = _propuesta
				ORDER BY	sga_instituciones.nombre
	LOOP
		IF cnt = 0 THEN
			_retorno := cur1.nombre;
		ELSE
			_retorno := _retorno || ', ' || cur1.nombre;
		END IF;
		cnt := cnt + 1;
	END LOOP;

	RETURN _retorno;
END;
$$;
