create function negocio.unpaz_f_criterio_reprobo_cursada(_alumno integer, _elemento integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _res character(1);
 DECLARE _vigen integer;
 
BEGIN
	_res := 'U';

	SELECT  sga_actas_detalle.resultado, (CASE WHEN sga_actas_detalle.fecha_vigencia > now() THEN 1 ELSE 0 END) as vigente INTO _res, _vigen
	FROM negocio.sga_comisiones
	JOIN negocio.sga_actas on (sga_comisiones.comision = sga_actas.comision)
	JOIN negocio.sga_actas_detalle on (sga_actas.id_acta = sga_actas_detalle.id_acta)
	where sga_actas_detalle.alumno = _alumno
	and sga_comisiones.elemento = _elemento
	and sga_actas.origen = 'R'
	and sga_actas_detalle.rectificado = 'N'
	and sga_actas_detalle.estado = 'A'
	--AND sga_actas_detalle.fecha_vigencia > now()
	ORDER BY fecha DESC
	LIMIT 1;
/*LAURA: acá me parece que habria que sacar la restricción de que se encuentre vigente la reprobación, ya que sino el alumno no entraría en ningún grupo. quizás buscar que el último resultado sea una reprobación*/
/* Listo */
/*LAURA: falta agregar la última actualización de David para que tome también a aquellos que alguna vez la regularizaron y perdieron la regularidad*/
/* Listo */

	IF ((_res = 'R') OR (_res = 'A' AND _vigen = 0)) THEN
	-- Reprobo la actividad, o perdio la regularidad?
	RETURN 0;
	ELSE
	-- No la reprobo, ni perdio la regularidad
	RETURN 1;
	END IF;
END;
$$;
