create function negocio.ftdb_sga_propuestas_ra() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
	_periodos_insc record;
	_requisitos_ingreso record;
	_requisitos_x_accion record;
	_entidad_ra integer;
BEGIN
	-- Recupero la entidad de la RA.
	SELECT	entidad INTO _entidad_ra
	FROM	sga_responsables_academicas
	WHERE	responsable_academica = OLD.responsable_academica;

	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de períodos de inscripción a propuesta, períodos lectivos y turnos de examen.
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	FOR _periodos_insc IN	SELECT	sga_periodos_inscripcion_entidad.periodo_insc
							FROM	sga_periodos_inscripcion_entidad
							WHERE	sga_periodos_inscripcion_entidad.entidad = _entidad_ra
	LOOP
		-- Borro los datos del periodo de inscripcion
		DELETE
		FROM	sga_periodos_inscripcion_aplanado
		WHERE	sga_periodos_inscripcion_aplanado.periodo_insc = _periodos_insc.periodo_insc;

		-- Inserto en el aplanado las versiones de planes de las propuestas
		INSERT INTO	sga_periodos_inscripcion_aplanado (periodo_insc, plan_version)
		SELECT		_periodos_insc.periodo_insc,
					sga_planes_versiones.plan_version
		FROM		sga_periodos_inscripcion_entidad,
					sga_responsables_academicas,
					sga_propuestas_ra,
					sga_planes,
					sga_planes_versiones
		WHERE		sga_periodos_inscripcion_entidad.periodo_insc = _periodos_insc.periodo_insc AND
					sga_periodos_inscripcion_entidad.entidad = sga_responsables_academicas.entidad AND
					sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica AND
					sga_propuestas_ra.propuesta = sga_planes.propuesta AND
					sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes_versiones.estado IN ('V','A');
	END LOOP;

	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de requisitos de ingreso.
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	FOR _requisitos_ingreso IN	SELECT	sga_requisitos_ingreso_entidades.requisito_propuesta
								FROM	sga_requisitos_ingreso_entidades
								WHERE	sga_requisitos_ingreso_entidades.entidad = _entidad_ra
	LOOP
		DELETE
		FROM	sga_requisitos_ingreso_aplanado
		WHERE	sga_requisitos_ingreso_aplanado.requisito_propuesta = _requisitos_ingreso.requisito_propuesta;

		INSERT INTO	sga_requisitos_ingreso_aplanado (requisito_propuesta, plan_version)
		SELECT		_requisitos_ingreso.requisito_propuesta,
					sga_planes_versiones.plan_version
		FROM		sga_requisitos_ingreso_entidades,
					sga_responsables_academicas,
					sga_propuestas_ra,
					sga_planes,
					sga_planes_versiones
		WHERE		sga_requisitos_ingreso_entidades.requisito_propuesta = _requisitos_ingreso.requisito_propuesta AND
					sga_requisitos_ingreso_entidades.entidad = sga_responsables_academicas.entidad AND
					sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica AND
					sga_propuestas_ra.propuesta = sga_planes.propuesta AND
					sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes_versiones.estado IN ('V','A');
	END LOOP;

	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de requisitos por acción.
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	FOR _requisitos_x_accion IN	SELECT	sga_requisitos_x_accion.requisito_accion
								FROM	sga_requisitos_x_accion,
										sga_requisitos_grupos
								WHERE	sga_requisitos_x_accion.grupo_requisito = sga_requisitos_grupos.grupo_requisito AND
										sga_requisitos_grupos.entidad = _entidad_ra
	LOOP
		DELETE
		FROM	sga_requisitos_aplanado
		WHERE	sga_requisitos_aplanado.requisito_accion = _requisitos_x_accion.requisito_accion;

		INSERT INTO	sga_requisitos_aplanado (requisito_accion, plan_version)
		SELECT	_requisitos_x_accion.requisito_accion,
				sga_planes_versiones.plan_version
		FROM	sga_requisitos_x_accion,
				sga_requisitos_grupos,
				sga_responsables_academicas,
				sga_propuestas_ra,
				sga_planes,
				sga_planes_versiones
		WHERE	sga_requisitos_x_accion.requisito_accion = _requisitos_x_accion.requisito_accion AND
				sga_requisitos_x_accion.grupo_requisito = sga_requisitos_grupos.grupo_requisito AND
				sga_requisitos_grupos.entidad = sga_responsables_academicas.entidad AND
				sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica AND
				sga_propuestas_ra.propuesta = sga_planes.propuesta AND
				sga_planes.plan = sga_planes_versiones.plan AND
				sga_planes_versiones.estado IN ('V','A');
	END LOOP;

	RETURN OLD;
END;
$$;
