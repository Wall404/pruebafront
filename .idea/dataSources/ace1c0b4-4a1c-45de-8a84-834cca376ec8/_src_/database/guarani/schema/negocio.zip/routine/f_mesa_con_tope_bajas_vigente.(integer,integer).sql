create function negocio.f_mesa_con_tope_bajas_vigente(pplanversion integer, pllamadomesa integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE 
_cur RECORD;
_fecha_hora_tope timestamp;

BEGIN
  -- Recorre los periodos de inscripcion para buscar la fecha-hora tope de bajas.
  FOR _cur IN (
    SELECT 
         COALESCE(-- Excepciones al periodo de inscripcion
                  CASE e.tipo_tope_bajas
                    WHEN 1 THEN (CASE 
                                   WHEN e.fecha_tope_bajas < CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp) THEN e.fecha_tope_bajas 
                                   ELSE CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp) 
                                 END)
                    WHEN 2 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'D', e.dias_previos_tope_bajas, false)
                    WHEN 3 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'D', e.dias_previos_tope_bajas, true)
                    WHEN 4 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'H', e.hs_previas_tope_bajas, false)
                    WHEN 5 THEN get_fecha_fin_examen(cast(e.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'H', e.hs_previas_tope_bajas, true)
                    ELSE cast(NULL as timestamp)
                  END,
                  -- Periodo de inscripcion
                  CASE pif.tipo_tope_bajas
                    WHEN 1 THEN (CASE 
                                   WHEN pif.fecha_tope_bajas < CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp) THEN pif.fecha_tope_bajas
                                   ELSE CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp) 
                                 END)
                    WHEN 2 THEN get_fecha_fin_examen(cast(pif.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'D', pif.dias_previos_tope_bajas, false)
                    WHEN 3 THEN get_fecha_fin_examen(cast(pif.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'D', pif.dias_previos_tope_bajas, true)
                    WHEN 4 THEN get_fecha_fin_examen(cast(pif.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'H', pif.hs_previas_tope_bajas, false)
                    WHEN 5 THEN get_fecha_fin_examen(cast(pif.fecha_inicio as timestamp), CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp), 'H', pif.hs_previas_tope_bajas, true)
                    ELSE cast(NULL as timestamp)
                  END	
                 )  as fecha_hora_tope,
        CAST(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp) as fecha_hora_mesa				 
    FROM
           sga_llamados_mesa,
           sga_llamados_turno,
           sga_periodos_inscripcion,
           sga_periodos_inscripcion_aplanado,
           sga_periodos_inscripcion_fechas as pif
              LEFT JOIN sga_llamados_mesa_excep_perinsc as e ON (e.periodo_insc = pif.periodo_insc AND e.llamado_mesa = pLlamadoMesa)
    WHERE
           sga_llamados_mesa.llamado_mesa   = pLlamadoMesa AND
           sga_llamados_mesa.estado = 'A' AND
           sga_llamados_turno.llamado       = sga_llamados_mesa.llamado AND
           sga_periodos_inscripcion.periodo = sga_llamados_turno.periodo AND
           pif.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion  AND
           pif.habilitado = 'S' AND
           sga_periodos_inscripcion_aplanado.periodo_insc      = pif.periodo_insc AND
           sga_periodos_inscripcion_aplanado.plan_version      = pPlanVersion
           ) LOOP
           
           -- Si la fecha-hora tope de bajas es mayor a la fecha-hora del examen, asigno esta fecha-hora.
		   _fecha_hora_tope := _cur.fecha_hora_tope;
           IF _fecha_hora_tope > _cur.fecha_hora_mesa THEN
              _fecha_hora_tope := _cur.fecha_hora_mesa;
           END IF;               
           
           IF (current_timestamp <= _fecha_hora_tope) THEN 
              RETURN TRUE;
           END IF;    

  END LOOP;
         
  RETURN FALSE;
END
$$;
