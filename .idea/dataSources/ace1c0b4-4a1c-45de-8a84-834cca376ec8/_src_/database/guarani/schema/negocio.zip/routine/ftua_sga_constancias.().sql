create function negocio.ftua_sga_constancias() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Si cambia la vigencia, entonces actualizo la fecha de fin de vigencia de las solicitudes 
   -- Solo solicitudes aun vigentes y que son de tipo ONLINE
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   IF OLD.vigencia <> NEW.vigencia AND NEW.vigencia IS NOT NULL THEN
     UPDATE sga_constancias_solicitud
        SET fecha_fin_vigencia = cast(fecha_solicitud as date) + NEW.vigencia
      WHERE constancia = NEW.constancia
        AND (fecha_fin_vigencia IS NULL OR fecha_fin_vigencia >= CURRENT_DATE)
        AND estado = 'Online';
   END IF;
   
   RETURN NEW;
END;
$$;
