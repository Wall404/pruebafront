create function negocio.unpaz_f_fecha_a_texto_analitico(pfecha date, pformato integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
     idia INTEGER;
     iMes INTEGER;
     iAnio INTEGER;
     lcRetorno TEXT;
     lcDia TEXT;
     lcMes TEXT;
     lcAnio TEXT;
     _dia TEXT;
     _anio TEXT;
BEGIN

  iDia := extract(day from pFecha);
  iMes := extract(month from pFecha);
  iAnio := extract(year from pFecha);
  
  lcMes := CASE extract(month from pFecha)
             WHEN 1 THEN 'enero'
             WHEN 2 THEN 'febrero'
             WHEN 3 THEN 'marzo'
             WHEN 4 THEN 'abril'
             WHEN 5 THEN 'mayo'
             WHEN 6 THEN 'junio'
             WHEN 7 THEN 'julio'
	     WHEN 8 THEN 'agosto'	
             WHEN 9 THEN 'septiembre'
             WHEN 10 THEN 'octubre'
             WHEN 11 THEN 'noviembre'
             WHEN 12 THEN 'diciembre'
           END;

  _dia := f_numero_a_texto(iDia, pFormato);
  _anio := f_numero_a_texto(iAnio, pFormato);
  --convierto el 1
  IF (_dia = 'uno') THEN
	_dia:= 'un';
  END IF;

  lcRetorno := _dia || ' días del mes de ' ||  lcMes || ' de ' ||  _anio;
  IF pFormato = 1 THEN
     -- Mayúscula
     lcRetorno := upper(lcRetorno);
  ELSEIF pFormato = 2 THEN
     -- Minúscula. El mes se muestra siempre con la primer letra mayúscula
     lcRetorno := lcRetorno;
  ELSEIF pFormato = 3 THEN
     -- Minúscula
     lcRetorno := initcap(lcRetorno);
  END IF;

  -- Retorno el texto de la fecha
  RETURN lcRetorno;
END;
$$;
