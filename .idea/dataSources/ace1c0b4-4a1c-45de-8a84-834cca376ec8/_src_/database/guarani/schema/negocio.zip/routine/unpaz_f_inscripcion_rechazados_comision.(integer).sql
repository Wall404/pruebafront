create function negocio.unpaz_f_inscripcion_rechazados_comision(_comision integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _resultado integer;
 
BEGIN

	select count (alumno) into _resultado
	from negocio.sga_insc_cursada_log where operacion not in ('B', 'C') and comision = _comision;

	RETURN _resultado;
END;
$$;
