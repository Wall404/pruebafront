create function negocio.ftia_sga_insc_cursada() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _rtn_encuestas smallint;
  BEGIN
    -- Si la inscripción esta aceptada
    IF NEW.estado = 'A' THEN
      -- Actualizo encuestas. Alta de encuestas vigentes relacionadas con la comision.
      _rtn_encuestas := f_encuestas_sync_alumno (NEW.alumno, NEW.comision, 'A', NULL, NEW.estado);
    END IF;
     
    RETURN NEW;
  END;
$$;
