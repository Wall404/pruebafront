create function negocio.get_fecha_ingreso_alumno(palumno integer) returns date
LANGUAGE plpgsql
AS $$
DECLARE 
 _anio_academico_ingreso integer;
 _periodo_insc_propuesta integer;
 _fecha_ingreso date;
 _fecha_inscripcion date;
 _fecha_inicio_aa date;
 _propuesta integer;
 
BEGIN
  _anio_academico_ingreso := NULL;
  _fecha_ingreso := NULL;
  _fecha_inscripcion := NULL;
  _fecha_inicio_aa := NULL;
  _propuesta := NULL;
  
  -- Recupero el año academico y fecha de inscripcion
  -- Recupera la inscripcion aceptada o pendiente.
 SELECT pa.anio_academico, pa.fecha_inscripcion, pi.periodo_inscripcion 
   INTO _anio_academico_ingreso, _fecha_inscripcion, _periodo_insc_propuesta
   FROM sga_alumnos as a,
		sga_planes_versiones as plan_actual,
        sga_propuestas_aspira as pa, 
        sga_planes_versiones as plan_insc,
        sga_situacion_aspirante as sa,
        sga_periodos_inscripcion_fechas as pif, 
        sga_periodos_inscripcion as pi
  WHERE a.alumno = pAlumno
    AND plan_actual.plan_version = a.plan_version
    AND pa.propuesta = a.propuesta
    AND pa.persona   = a.persona
    AND plan_insc.plan_version = pa.plan_version
    AND sa.situacion_asp = pa.situacion_asp 
    AND sa.resultado_asp IN ('P','A') 
    AND pif.periodo_insc = pa.periodo_insc
    AND pi.periodo_inscripcion = pif.periodo_inscripcion;

  -- Por default la fecha de ingreso como fecha de inscripcion en la propuesta.
  _fecha_ingreso := _fecha_inscripcion;

  -- Recupero la fecha de inicio del año academico de ingreso a la propuesta.
  SELECT fecha_inicio INTO _fecha_inicio_aa
    FROM sga_propuestas_ra,
	     sga_anios_academicos_ra,
		 sga_anios_academicos_fechas
   WHERE sga_propuestas_ra.propuesta = _propuesta
     AND sga_anios_academicos_ra.responsable_academica = sga_propuestas_ra.responsable_academica
	 AND sga_anios_academicos_fechas.id_fecha = sga_anios_academicos_ra.id_fecha
	 AND sga_anios_academicos_fechas.anio_academico = _anio_academico_ingreso
	 ORDER BY sga_propuestas_ra.responsable_academica   
	 LIMIT 1;

  IF FOUND AND _fecha_inicio_aa IS NOT NULL THEN
     _fecha_ingreso := _fecha_inicio_aa;
  END IF;  
	
  
  -- Retorno la fecha de ingreso en la propuesta
  RETURN _fecha_ingreso;
END;
$$;
