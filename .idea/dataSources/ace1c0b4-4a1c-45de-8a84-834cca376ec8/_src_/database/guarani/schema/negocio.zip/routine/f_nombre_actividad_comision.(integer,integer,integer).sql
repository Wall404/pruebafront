create function negocio.f_nombre_actividad_comision(pcomision integer, pelemento integer, ptipo integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _distinto boolean;
  _nombre  text;
  _nombre_ant text;
  cur1 record;
  
        
BEGIN
   _distinto := false;
   cnt := 0;	
   _nombre := '';
   _nombre_ant := '';

  -- Recupero el nombre de la actividad de la comision
  FOR cur1 IN SELECT CASE pTipo
                       WHEN 1 THEN ep.nombre
                       WHEN 2 THEN ep.nombre_abreviado
                     END as nombre 
                FROM sga_comisiones_propuestas as c,
                     sga_planes_versiones as v,
                     sga_elementos_plan as ep,
                     sga_elementos_revision as er
               WHERE c.comision = pComision
                 AND v.plan = c.plan
                 AND er.elemento = pElemento
                 AND ep.plan_version = v.plan_version
                 AND ep.elemento_revision = er.elemento_revision
  LOOP
      _nombre :=  cur1.nombre;
      IF cnt > 0 THEN		
        IF _nombre <> _nombre_ant THEN
           -- Nombre generico
           SELECT CASE pTipo
                   WHEN 1 THEN nombre
                   WHEN 2 THEN nombre_abreviado
                  END
             INTO _nombre        
          FROM sga_elementos
          WHERE elemento = pElemento;
          EXIT;
        END IF ;
      END IF;   
      _nombre_ant := _nombre;
      cnt := cnt + 1;
  END LOOP;

  RETURN _nombre;
END;
$$;
