CREATE VIEW vw_insc_cursada_log_requisitos AS SELECT sga_insc_cursada_log_requisitos.inscripcion_requisito,
    sga_insc_cursada_log_requisitos.inscripcion,
    sga_insc_cursada_log_requisitos.mensaje_validacion
   FROM negocio.sga_insc_cursada_log_requisitos
UNION ALL
 SELECT his_insc_cursada_log_requisitos.inscripcion_requisito,
    his_insc_cursada_log_requisitos.inscripcion,
    his_insc_cursada_log_requisitos.mensaje_validacion
   FROM negocio.his_insc_cursada_log_requisitos;
