create function negocio.ftib_sga_reinscripciones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
        -- Genera un nro de Transaccion
        IF NEW.nro_transaccion IS NULL THEN
           NEW.nro_transaccion := f_nro_transaccion();
        END IF;          
       RETURN NEW;
  END;
$$;
