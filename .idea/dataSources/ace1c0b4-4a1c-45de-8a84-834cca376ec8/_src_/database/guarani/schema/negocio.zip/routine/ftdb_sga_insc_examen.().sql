create function negocio.ftdb_sga_insc_examen() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion integer;
  BEGIN
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Borro el registro del detalle de la evaluacion automática.    
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    SELECT sga_evaluaciones.evaluacion  INTO _evaluacion
    FROM sga_llamados_mesa, sga_evaluaciones, sga_evaluaciones_tipos
    WHERE sga_llamados_mesa.llamado_mesa = OLD.llamado_mesa
      AND sga_evaluaciones.entidad       = sga_llamados_mesa.entidad
      AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
      AND sga_evaluaciones_tipos.automatica = 'S'; -- Generación Automática
            
    IF _evaluacion IS NOT NULL THEN
       -- Borro el registro del detalle de la evaluacion automática.    
       DELETE FROM sga_eval_detalle_examenes 
             WHERE evaluacion = _evaluacion 
               AND alumno = OLD.alumno; 
    END IF;	     

    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Borro las evaluaciones de generación manual.
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    DELETE FROM sga_eval_detalle 
      WHERE evaluacion IN (SELECT evaluacion FROM sga_llamados_mesa, sga_evaluaciones, sga_evaluaciones_tipos
                              WHERE sga_llamados_mesa.llamado_mesa = OLD.llamado_mesa
                                AND sga_evaluaciones.entidad       = sga_llamados_mesa.entidad
                                AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
                                AND sga_evaluaciones_tipos.automatica = 'N') -- Generación Manual
        AND alumno = OLD.alumno; 

     
    RETURN OLD;
  END;
$$;
