create function negocio.ftub_sga_eval_detalle_cursadas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   NEW.ultimo_cambio = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$;
