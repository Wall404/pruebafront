create function negocio.f_diadelasemana(fecha date, lenguaje smallint) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
 DAY_OF_WEEK_CONST varchar(15) := 'dow';

dayOfWeek Integer := 0;
dayName  varchar(15) := 'Test';

BEGIN
dayOfWeek := date_part(DAY_OF_WEEK_CONST, fecha);

IF lenguaje = 1 THEN
   -- Español
   IF dayOfWeek = 0 THEN
       dayName := 'Domingo';
   ELSEIF dayOfWeek = 1 THEN
     dayName := 'Lunes';
   ELSEIF dayOfWeek = 2 THEN
     dayName := 'Martes';
   ELSEIF dayOfWeek = 3 THEN
     dayName := 'Miercoles';
   ELSEIF dayOfWeek = 4 THEN
     dayName := 'Jueves';
   ELSEIF dayOfWeek = 5 THEN
     dayName := 'Viernes';
   ELSEIF dayOfWeek = 6 THEN
     dayName := 'Sabado';
   END IF;
  
ELSEIF lenguaje = 2 THEN
   -- Ingles
   IF dayOfWeek = 0 THEN
       dayName := 'Sunday';
   ELSEIF dayOfWeek = 1 THEN
     dayName := 'Monday';
   ELSEIF dayOfWeek = 2 THEN
     dayName := 'Tuesday';
   ELSEIF dayOfWeek = 3 THEN
     dayName := 'Wednesday';
   ELSEIF dayOfWeek = 4 THEN
     dayName := 'Thursday';
   ELSEIF dayOfWeek = 5 THEN
     dayName := 'Friday';
   ELSEIF dayOfWeek = 6 THEN
     dayName := 'Saturday';
   END IF;
ELSE
  dayName := '';
END IF;

RETURN dayName;

END;
$$;
