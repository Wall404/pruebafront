create function negocio.ftdb_sga_insc_cursada() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE 
 _rtn_encuestas Integer;
  BEGIN
     -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     -- Actualizo el cupo de la subcomision
     -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     UPDATE sga_comisiones_cupo 
        SET cant_inscriptos = cant_inscriptos -1 
      WHERE comision = OLD.comision;
       
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- Actualizo encuestas
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      _rtn_encuestas := f_encuestas_sync_alumno (OLD.alumno, OLD.comision, 'B', OLD.estado, OLD.estado);
 
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- Saco al alumno de las evaluaciones parciales de la comision. Solo de las evaluaciones que no esten cerradas.
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      DELETE FROM sga_eval_detalle
       WHERE alumno = OLD.alumno
         AND evaluacion IN (SELECT sga_evaluaciones.evaluacion 
                              FROM sga_comisiones, sga_evaluaciones, sga_evaluaciones_tipos
                             WHERE sga_comisiones.comision = OLD.comision
                               AND sga_evaluaciones.entidad = sga_comisiones.entidad
                               AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
                               AND sga_evaluaciones_tipos.automatica = 'N'
                               AND sga_evaluaciones.estado <> 'C'
                            );   
      -- ***********************************************************************************************
      -- Saco al alumno de las clases de la comision
      -- El registro de sga_clases_asistencia_acum se realiza por trigger de delete de sga_clases_asistencia
      -- ***********************************************************************************************
      DELETE FROM sga_clases_asistencia_acum
       WHERE alumno = OLD.alumno
         AND comision = OLD.comision;
         
      ALTER TABLE sga_clases_asistencia DISABLE TRIGGER tdb_sga_clases_asistencia;   
      DELETE FROM sga_clases_asistencia
       WHERE alumno = OLD.alumno
         AND clase IN (SELECT sga_clases.clase 
                         FROM sga_comisiones_bh, sga_clases
                        WHERE sga_comisiones_bh.comision = OLD.comision
                          AND sga_clases.banda_horaria = sga_comisiones_bh.banda_horaria
                       );   
      ALTER TABLE sga_clases_asistencia ENABLE TRIGGER tdb_sga_clases_asistencia;   
      -- *********************************** Asistencia **********************************
      
    RETURN OLD;
  END;
$$;
