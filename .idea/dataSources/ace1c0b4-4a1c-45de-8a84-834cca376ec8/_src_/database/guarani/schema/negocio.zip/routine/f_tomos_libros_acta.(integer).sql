create function negocio.f_tomos_libros_acta(pidacta integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _retorno := '';
		
  -- Recupero el nombre de los tomos donde se encuentra el acta
  FOR cur1 IN SELECT sga_libros_tomos.nro_tomo as nro_tomo
                FROM sga_actas_folios,
                     sga_libros_tomos
               WHERE sga_actas_folios.id_acta = pIdActa
                 AND sga_libros_tomos.libro_tomo = sga_actas_folios.libro_tomo
  LOOP
      IF cnt > 0 THEN		
         _retorno := _retorno || '/';
      END IF;   
      _retorno := _retorno || 'Tomo ' || cast(cur1.nro_tomo as text);
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
