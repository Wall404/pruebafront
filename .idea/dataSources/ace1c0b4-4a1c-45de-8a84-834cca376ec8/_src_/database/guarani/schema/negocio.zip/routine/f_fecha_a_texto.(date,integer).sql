create function negocio.f_fecha_a_texto(pfecha date, pformato integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
     idia INTEGER;
     iMes INTEGER;
     iAnio INTEGER;
     lcRetorno TEXT;
     lcDia TEXT;
     lcMes TEXT;
     lcAnio TEXT;
BEGIN

  iDia := extract(day from pFecha);
  iMes := extract(month from pFecha);
  iAnio := extract(year from pFecha);
  
  lcMes := CASE extract(month from pFecha)
             WHEN 1 THEN 'Enero'
             WHEN 2 THEN 'Febrero'
             WHEN 3 THEN 'Marzo'
             WHEN 4 THEN 'Abril'
             WHEN 5 THEN 'Mayo'
             WHEN 6 THEN 'Junio'
             WHEN 7 THEN 'Julio'
             WHEN 9 THEN 'Septiembre'
             WHEN 10 THEN 'Octubre'
             WHEN 11 THEN 'Noviembre'
             WHEN 12 THEN 'Diciembre'
           END;
  
  lcRetorno := f_numero_a_texto(iDia, pFormato) || ' de ' ||  lcMes || ' de ' ||  f_numero_a_texto(iAnio, pFormato);
  IF pFormato = 1 THEN
     -- Mayúscula
     lcRetorno := upper(lcRetorno);
  ELSEIF pFormato = 2 THEN
     -- Minúscula. El mes se muestra siempre con la primer letra mayúscula
     lcRetorno := lcRetorno;
  ELSEIF pFormato = 3 THEN
     -- Minúscula
     lcRetorno := initcap(lcRetorno);
  END IF;

  -- Retorno el texto de la fecha
  RETURN lcRetorno;
END;
$$;
