create function negocio.ftua_sga_docentes_comision() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

  -- Si cambia la responsabilidad, reasigno derechos al docente sobre la comision
  IF OLD.responsabilidad <> NEW.responsabilidad THEN
     -- Borro los derechos asignados al docente en la comision en el rol anterior
     DELETE FROM gdu_derechos_personas
        USING sga_comisiones, 
              sga_docentes
        WHERE sga_comisiones.comision = OLD.comision
          AND sga_docentes.docente = OLD.docente
          AND gdu_derechos_personas.entidad = sga_comisiones.entidad
          AND gdu_derechos_personas.persona = sga_docentes.persona;
      
      -- Pego los derechos del rol del docente.    
      INSERT INTO gdu_derechos_personas (entidad, derecho, persona)
           SELECT sga_comisiones.entidad, 
                  gdu_comision.derecho, 
                  sga_docentes.persona
             FROM sga_comisiones,
                  gdu_comision,
                  sga_docentes
            WHERE sga_comisiones.comision = NEW.comision
              AND gdu_comision.responsabilidad = NEW.responsabilidad
              AND sga_docentes.docente = NEW.docente;
  END IF;     

  RETURN NEW;
END;
$$;
