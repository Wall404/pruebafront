create function negocio.f_mesa_examen_alta(pnombre character varying, pelemento integer, pcatedra integer, pubicacion integer, pobservaciones character varying, pmesa_en_turno_examen character, panio_academico integer, pdivision integer, pfecha character varying, phorainicio character varying, phorafinalizacion character varying, pespacio integer, pinstancias text[], pmodalidad text[], pdocente text[]) returns negocio.type_retorno_creacion_mesa
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno	type_retorno_creacion_mesa;
  _mesa_examen Integer;
  _llamado_mesa Integer;
  _entidad Integer;
  _evaluacion Integer;
  vFecha Date;
  vHI Time;
  vHF Time;

  i Integer;
  _cant_instancias Integer;
  _cant_planes Integer;
  _cant_modalidad Integer;
  _cant_docentes Integer;

BEGIN
/* Formato de los datos:
   pFecha      = DD/MM/YYYY
   pHoraInicio = HH:MM
   pHoraFinalizacion    = HH:MM
*/  

  -- Variables de retorno
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800EXA_mesa_examen_acta_alta_ok';
  cur_retorno.mensaje_param  := NULL;
  
    
  -- Recupero valores de los arreglos
  _cant_instancias := 0;
  IF pInstancias IS NOT NULL THEN
    -- _cant_instancias := array_lenght(pInstancias[]); -- Para version 9.0 en adelante
    _cant_instancias := (select array_upper(pInstancias , 1) - array_lower(pInstancias ,1) + 1);
  END IF;
  IF _cant_instancias = 0 THEN 
    -- Error
  END IF;
  
  _cant_modalidad := 0;
  IF pModalidad IS NOT NULL THEN
    -- _cant_modalidad := array_lenght(pModalidad[]); -- Para version 9.0 en adelante
    _cant_modalidad := (select array_upper(pModalidad , 1) - array_lower(pModalidad ,1) + 1);
  END IF;
  IF _cant_modalidad = 0 THEN 
    -- Error
  END IF;

  _cant_docentes := 0;
  IF pDocente IS NOT NULL THEN
    -- _cant_docentes := array_lenght(pDocente[]); -- Para version 9.0 en adelante
    _cant_docentes := (select array_upper(pDocente , 1) - array_lower(pDocente ,1) + 1);
  END IF;

  -- Seteo Variables
  vFecha := to_date(pFecha, 'DD/MM/YYYY');
  vHI := pHoraInicio::time;
  vHF := pHoraFinalizacion::time;

-- Comienzo transacción.
BEGIN


  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Genero la mesa de examen
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO sga_mesas_examen (nombre, elemento, catedra, ubicacion, observaciones, mesa_en_turno_examen, anio_academico, division)
    VALUES (pNombre, pElemento, pCatedra, pUbicacion, pObservaciones, pMesa_en_turno_examen, pAnio_academico, pDivision);

  _mesa_examen = (SELECT currval('sga_mesas_examen_seq'));

  -- 2. Inserto la mesa en un llamado
  INSERT INTO sga_llamados_mesa (mesa_examen, fecha, hora_inicio, hora_finalizacion, espacio)
    VALUES (_mesa_examen, vFecha, vHI, vHF, pEspacio);

  _llamado_mesa = (SELECT currval('sga_llamados_mesa_seq'));

  -- Recupero evaluacion y entidad de la mesa en el llamado  
  SELECT sga_evaluaciones.entidad, sga_evaluaciones.evaluacion 
    INTO _entidad, _evaluacion  
    FROM sga_llamados_mesa,
         sga_evaluaciones 
    WHERE sga_llamados_mesa.llamado_mesa = _llamado_mesa
      AND sga_evaluaciones.entidad = sga_llamados_mesa.entidad ;
      

  -- Inserto las instancias
  FOR i IN 1 .. _cant_instancias 
  LOOP
	INSERT INTO sga_mesas_examen_instancias (mesa_examen, instancia, escala_nota) VALUES (_mesa_examen, pInstancias[i][1]::smallint, pInstancias[i][2]::integer);
  END LOOP;

  
 -- Inserto los docentes
  FOR i IN 1 .. _cant_docentes
  LOOP
     INSERT INTO sga_docentes_mesa_llamado (llamado_mesa, docente, rol) VALUES (_llamado_mesa, pDocente[i][1]::integer, pDocente[i][2]::integer);
  END LOOP;

  -- Inserto las modalidades
  FOR i IN 1 .. _cant_modalidad
  LOOP
     INSERT INTO sga_mesas_examen_modalidad (mesa_examen, modalidad) VALUES (_mesa_examen, pModalidad[i]);
  END LOOP;

  -- Inserto los planes en la mesa de examen de todos los planes donde se encuentra la actividad.
  INSERT INTO sga_mesas_examen_propuestas (mesa_examen, propuesta, plan)
	 SELECT DISTINCT _mesa_examen, propuesta, plan
	   FROM vw_actividades_plan
      WHERE elemento = pElemento;


  -- Error.
  EXCEPTION WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800EXA_mesa_examen_alta_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800EXA_mesa_examen_alta_ok';
  
  cur_retorno.evaluacion = _evaluacion;  
  cur_retorno.llamado_mesa = _llamado_mesa;  
  
  
  RETURN cur_retorno;

END;
$$;
