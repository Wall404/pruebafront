create function negocio.get_entidad_id_nombre(pentidad integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
 _retorno text;
 _parametro_contexto text;
 _query text;
 _query2 text;
 _subtipo integer;
 rs RECORD;

BEGIN
  _retorno := ',,,';
  
  -- Obtengo nombre de la tabla del subtipo de la entidad
  SELECT sga_g3entidades.entidad_subtipo, 
         sga_g3entidades_subtipos.tabla_id, 
         sga_g3entidades_subtipos.query_id_nombre 
    INTO _subtipo, _parametro_contexto, _query
    FROM sga_g3entidades, 
         sga_g3entidades_subtipos 
   WHERE sga_g3entidades.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo 
     AND sga_g3entidades.entidad = pEntidad;

  -- Obtengo el nombre de la entidad
  FOR rs IN EXECUTE _query || pEntidad::text 
  LOOP
    _retorno := _parametro_contexto || ',' || rs.id::text || ',' || rs.nombre || ',' || _subtipo::text ;
  END LOOP;
  
  -- Retorno el nombre de la entidad
  RETURN _retorno;
END;
$$;
