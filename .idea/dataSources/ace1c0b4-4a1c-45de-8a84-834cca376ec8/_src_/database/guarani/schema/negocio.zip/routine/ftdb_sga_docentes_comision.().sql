create function negocio.ftdb_sga_docentes_comision() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

  -- Borro los derechos asignados al docente en la comision
  DELETE FROM gdu_derechos_personas
     USING sga_comisiones, 
           sga_docentes
     WHERE sga_comisiones.comision = OLD.comision
       AND sga_docentes.docente = OLD.docente
       AND gdu_derechos_personas.entidad = sga_comisiones.entidad
       AND gdu_derechos_personas.persona = sga_docentes.persona;

  RETURN OLD;
END;
$$;
