create function negocio.get_fecha_fin_examen(pfechadesde timestamp without time zone, pfechahoraexamen timestamp without time zone, ptipo character, pcantidad integer, pconsideradiashabiles boolean) returns timestamp without time zone
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _FechaHora timestamp;
 DECLARE _FechaHoraAux timestamp;
 DECLARE dFechaExamen date;
 DECLARE _dias integer;
 

BEGIN
  -- Dias no hábiles:
  --   Sabados (dow = 0) y Domingos (dow = 6)
  --   Dias feriados registrados en la tabla de dias no laborables.
  dFechaExamen := cast(pFechaHoraExamen as date);
  
  IF pTipo = 'D' THEN 
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
    -- DIAS
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
    IF pConsideraDiasHabiles THEN
      -- Se consideran solo dias hábiles
      SELECT MIN(min_fecha.a) INTO _FechaHora
        FROM (SELECT fecha FROM generate_series(pFechaDesde, dFechaExamen,'1 day') as fechas(fecha)
               WHERE extract(dow from fecha) not in (0,6)
                 AND fecha NOT IN (SELECT dnl.fecha FROM sga_dias_no_laborables as dnl WHERE dnl.fecha BETWEEN pFechaDesde AND dFechaExamen)
               ORDER BY fecha DESC
               LIMIT pCantidad + 1
             ) as min_fecha (a);

      IF _FechaHora IS NOT NULL THEN
         -- Agrego las horas (sumo un dia y le resto un segundo asi quedan las 23:59:59)	
         _FechaHora := date_trunc('day', _FechaHora) + interval '1 day' - interval '1 second';
      END IF;
    END IF;
    
    IF NOT pConsideraDiasHabiles OR _FechaHora IS NULL THEN
       -- Desde la Fecha resto los dias seguidos
       -- Retorna x dias antes con el horario 23:59:59
       _FechaHora := date_trunc('day', pFechaHoraExamen) - cast(cast(pCantidad - 1 as varchar) || ' day' as interval) - interval '1 second';
	END IF;   

  ELSIF pTipo = 'H' THEN
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- HORAS
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    _dias := cast(pCantidad / 24 as integer); -- convierto hs a dias
	
    IF pConsideraDiasHabiles THEN
        -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- HORAS DE DIAS HABILES
        -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++
        -- Saco cual seria la fecha y hora en dias corridos 
        _FechaHoraAux := pFechaHoraExamen - cast((COALESCE(cast(pCantidad AS text), '0') || ' hours') AS interval);
        
        -- Saco la cantidad de dias hacia atras
        _dias := dFechaExamen - cast(_FechaHoraAux as date);

	
         -- No considera horas de dias hábiles.
         SELECT MIN(min_fecha.a) INTO _FechaHora
         FROM (SELECT fecha FROM generate_series(pFechaDesde, dFechaExamen,'1 day') as fechas(fecha)
                WHERE extract(dow from fecha) not in (0,6)
                  AND fecha NOT IN (SELECT dnl.fecha FROM sga_dias_no_laborables as dnl WHERE dnl.fecha BETWEEN pFechaDesde AND dFechaExamen)
                ORDER BY fecha DESC
                LIMIT _dias + 1
              ) as min_fecha (a);

	  IF _FechaHora IS NOT NULL THEN
              -- Agrego las horas  	
              _FechaHora := date_trunc('day', _FechaHora) + cast(_FechaHoraAux as time);
          END IF;
    END IF;
    
    IF NOT pConsideraDiasHabiles OR _FechaHora IS NULL THEN
       -- Retorna x horas antes del examen sin considerar dias habiles
       _FechaHora := pFechaHoraExamen - cast((COALESCE(cast(pCantidad AS text), '0') || ' hours') AS interval);
    END IF;   
  ELSE
    -- Se paso otro parametro. Devuelvo la fecha del examen
    _FechaHora := pFechaHoraExamen;	
  END IF;

  -- Retorno la fecha y hora tope de inscripcion/baja
  RETURN _FechaHora;
		
END;
$$;
