create function negocio.f_insc_cursada_mover(pinscripcionorigen integer, pcomisiondestino integer, pestadoinsc character, pinstancias integer[], psubcomisiones integer[]) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno type_retorno_inscripcion;
  _insc sga_insc_cursada%ROWTYPE;
  _inscripcion Integer;
  _con_subcomisiones boolean;
  n Smallint;
  _ComisionNombre varchar(100);
  _fecha Timestamp;
  _nro_transaccion_cambio Integer;
  _fecha_actual Varchar(10);
  _flag_cambio_comision char(1);
  _nro_transaccion Integer;


BEGIN
  
  -- Variables 
  cur_retorno.resultado := -1;
  cur_retorno.mensaje_param  := NULL;
  
  _flag_cambio_comision := 'C';  -- Cambio de Comision
  _nro_transaccion   := NULL;
  _inscripcion := NULL;
  _con_subcomisiones := false;
  n := 0;
  _ComisionNombre := '';

  -- ********************************************************************
  -- 1. Verifico que exista la inscripcion a dar de baja
  -- ********************************************************************
  SELECT * INTO _insc FROM sga_insc_cursada WHERE inscripcion = pInscripcionOrigen;
   
  IF NOT FOUND THEN
    -- No existe la inscripción a mover de comision.
    cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_no_existe_insc';
    RETURN cur_retorno;
  END IF;

  -- Verifico si tiene subcomisiones la comision origen.
  SELECT (COUNT(*) > 0) INTO _con_subcomisiones FROM sga_subcomisiones WHERE comision = _insc.comision;
  
-- Comienza la Transacción
BEGIN

  -- Se paso la actualizacion del CUPO al trigger de delete de sga_insc_cursada y sga_insc_subcomision
/*
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Actualiza el cupo en la comision y subcomisiones origen
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF _con_subcomisiones THEN
      -- Actualizo el cupo en las subcomisiones que doy de baja
      UPDATE sga_subcomisiones_cupo
         SET cant_inscriptos = cant_inscriptos - 1
       WHERE subcomision IN (SELECT subcomision FROM sga_insc_subcomision WHERE inscripcion = pInscripcionOrigen);
  END IF; -- con subcomisiones

  UPDATE sga_comisiones_cupo SET cant_inscriptos = cant_inscriptos - 1 WHERE comision = _insc.comision;
*/

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto en el log de cambio de comision la inscripcion origen
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _fecha := CURRENT_TIMESTAMP;
  _nro_transaccion   := (SELECT nextval('aud_nro_transaccion_seq')); 
  INSERT INTO sga_insc_cursada_log (
              inscripcion, comision, alumno, plan_version, tipo, prioridad, estado_preinscripcion, 
              estado, sq_token, fuera_de_termino, interfaz, fecha_inscripcion, nro_transaccion, autorizado_por,
              operacion, nro_transaccion_log, fecha_operacion)
      VALUES (pInscripcionOrigen, _insc.comision, _insc.alumno, _insc.plan_version, _insc.tipo, _insc.prioridad, _insc.estado_preinscripcion, 
              _insc.estado, _insc.sq_token, _insc.fuera_de_termino, _insc.interfaz, _insc.fecha_inscripcion, _insc.nro_transaccion, _insc.autorizado_por,
              _flag_cambio_comision, _nro_transaccion, _fecha);

  -- Log de Instancias de la inscripcion
  INSERT INTO sga_insc_cursada_instancias_log (inscripcion, instancia)
       SELECT inscripcion, instancia FROM sga_insc_cursada_instancias WHERE inscripcion = pInscripcionOrigen;
     
  -- Log de insc a Subcomisiones
  IF _con_subcomisiones THEN
    INSERT INTO sga_insc_subcomision_log (inscripcion, subcomision)
         SELECT inscripcion, subcomision FROM sga_insc_subcomision  WHERE inscripcion = pInscripcionOrigen;
  END IF;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Borro la inscripcion origen
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF _con_subcomisiones THEN
     DELETE FROM sga_insc_subcomision WHERE inscripcion = pInscripcionOrigen;
  END IF;
  DELETE FROM sga_insc_cursada_instancias WHERE inscripcion = pInscripcionOrigen;
  DELETE FROM sga_insc_cursada WHERE inscripcion = pInscripcionOrigen;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto la inscripción en la nueva comision
  -- Genero un nuevo id de inscripcion y nro de transacción del cambio de comision.
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto la inscripción a cursada en la nueva comision.
  INSERT INTO sga_insc_cursada (comision, alumno, plan_version, tipo, prioridad, estado_preinscripcion, fuera_de_termino, interfaz, fecha_inscripcion, autorizado_por, estado, nro_transaccion)
       VALUES (pComisionDestino, _insc.alumno, _insc.plan_version, _insc.tipo, _insc.prioridad, _insc.estado_preinscripcion, _insc.fuera_de_termino, _insc.interfaz, _insc.fecha_inscripcion, _insc.autorizado_por, pEstadoInsc, _nro_transaccion);

  _inscripcion := (SELECT currval('sga_insc_cursada_seq'));

  UPDATE sga_comisiones_cupo SET cant_inscriptos = cant_inscriptos + 1 WHERE comision = pComisionDestino;

  -- Inserto las instancias en las que se inscribe
  -- n := array_lenght(pInstancias[]);
  IF pInstancias IS NOT NULL THEN
    n := (select array_upper(pInstancias,1) - array_lower(pInstancias,1) + 1);

    FOR i IN 1 .. n
    LOOP
      INSERT INTO sga_insc_cursada_instancias (inscripcion, instancia) VALUES (_inscripcion, pInstancias[i]);
    END LOOP;
  END IF;  

  -- Inserto las inscripciones a subcomisiones
  IF pSubcomisiones IS NOT NULL THEN
  -- n := array_lenght(pSubcomisiones[]); 
  	n := (select array_upper(pSubcomisiones, 1) - array_lower(pSubcomisiones,1) + 1);
  
  	FOR i IN 1 .. n 
  	LOOP
    	INSERT INTO sga_insc_subcomision (inscripcion, subcomision) VALUES (_inscripcion, pSubcomisiones[i]);
    	UPDATE sga_subcomisiones_cupo SET cant_inscriptos = cant_inscriptos + 1  WHERE subcomision = pSubcomisiones[i];
  	END LOOP;
  END IF;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Se dan de baja los registros de asistencias del alumno en las clases de la comisión de la inscripción origen
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  UPDATE	sga_clases_asistencia
  SET		estado = 'B'
  WHERE		sga_clases_asistencia.alumno = _insc.alumno
	    	AND sga_clases_asistencia.clase IN (SELECT sga_clases.clase
					    						FROM   sga_clases,
						   							   sga_comisiones_bh
					    						WHERE  sga_clases.banda_horaria = sga_comisiones_bh.banda_horaria
						   							   AND sga_comisiones_bh.comision = _insc.comision
						   						);
				
						   							   
  -- Error.
  EXCEPTION
      WHEN unique_violation THEN
        cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_existe_insc';
        cur_retorno.mensaje_param  := NULL;
        cur_retorno.sqlstate := SQLSTATE;
        cur_retorno.sqlerrm  := SQLERRM;
        RETURN cur_retorno;

     WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_error_db';
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_error_db';
        cur_retorno.mensaje_param  := NULL;
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- Cambio de comision OK. Seteo valores para retorno
  cur_retorno.resultado        := 1;
  cur_retorno.mensaje_indice   := '800CUR_insc_cursada_mover_ok';
  -- cur_retorno.mensaje_param := ;
  cur_retorno.inscripcion      := _inscripcion;
  cur_retorno.fecha            := _fecha;
  cur_retorno.nro_transaccion  := _nro_transaccion;
  
  -- Retorno datos del cambio de comision de la inscripcion a actividad.
  RETURN cur_retorno;

END;
$$;
