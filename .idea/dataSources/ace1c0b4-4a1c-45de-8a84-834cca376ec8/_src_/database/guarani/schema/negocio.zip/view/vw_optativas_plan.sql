CREATE VIEW vw_optativas_plan AS SELECT ep_generica.plan_version,
    COALESCE(ep_generica.nombre, e_generica.nombre) AS nombre_generica,
    e_generica.codigo AS codigo_generica,
    e_generica.elemento AS elemento_generica,
    er_generica.elemento_revision AS elemento_revision_generica,
    e_optativa.elemento,
    er_optativa.elemento_revision,
    e_optativa.codigo,
    COALESCE(ep_optativa.nombre, e_optativa.nombre) AS nombre,
    e_optativa.nombre_abreviado,
    e_optativa.entidad_subtipo,
    es_optativa.nombre AS entidad_subtipo_nombre,
    e_optativa.estado,
    ep_optativa.creditos,
    sga_elementos_comp.puntaje,
    sga_elementos_comp.orden
   FROM (((((((negocio.sga_elementos_plan ep_generica
     JOIN negocio.sga_elementos_revision er_generica ON ((er_generica.elemento_revision = ep_generica.elemento_revision)))
     JOIN negocio.sga_elementos e_generica ON ((e_generica.elemento = er_generica.elemento)))
     JOIN negocio.sga_elementos_comp ON ((sga_elementos_comp.elemento_padre = er_generica.elemento_revision)))
     JOIN negocio.sga_elementos_revision er_optativa ON ((er_optativa.elemento_revision = sga_elementos_comp.elemento_hijo)))
     JOIN negocio.sga_elementos e_optativa ON ((e_optativa.elemento = er_optativa.elemento)))
     JOIN negocio.sga_g3entidades_subtipos es_optativa ON ((es_optativa.entidad_subtipo = e_optativa.entidad_subtipo)))
     JOIN negocio.sga_elementos_plan ep_optativa ON (((ep_optativa.plan_version = ep_generica.plan_version) AND (ep_optativa.elemento_revision = er_optativa.elemento_revision))))
  WHERE (e_generica.entidad_subtipo = 2);
