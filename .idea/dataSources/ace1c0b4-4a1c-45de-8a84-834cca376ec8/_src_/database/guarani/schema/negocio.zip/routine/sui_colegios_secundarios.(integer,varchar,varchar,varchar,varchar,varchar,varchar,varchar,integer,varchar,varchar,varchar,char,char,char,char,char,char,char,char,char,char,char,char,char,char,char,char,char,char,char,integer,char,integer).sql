create function negocio.sui_colegios_secundarios(p_colegio integer, p_nombre character varying, p_calle character varying, p_numero character varying, p_piso character varying, p_depto character varying, p_unidad character varying, p_referencia character varying, p_localidad integer, p_codigo_postal character varying, p_telefono character varying, p_email character varying, p_sector character, p_co_med character, p_co_pol character, p_es_med character, p_es_pol character, p_ad_med character, p_ad_pol character, p_ar_med character, p_ar_pol character, p_jar_mat character, p_talleres character, p_es_temp character, p_artistica character, p_for_prof character, p_ttp character, p_i_for character, p_s_compl character, p_integra character, p_ambito character, p_computadoras integer, p_conex_internet character, p_colegio_original integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE _cue Integer;

BEGIN

  -- El CUE corresponde al colegio original
  _cue := COALESCE(p_colegio_original, p_colegio);
  
  -- Actualizo el registro, si no existe lo inserta.
  UPDATE sga_colegios_secundarios
     SET (cue, nombre, localidad, calle, nro, codigo_postal, sector, ambito) = (_cue, p_nombre, p_localidad, p_calle, p_numero, p_codigo_postal, p_sector, p_ambito)
   WHERE colegio = p_colegio;

  IF NOT FOUND THEN
    -- Inserta el colegio
    INSERT INTO sga_colegios_secundarios (colegio, cue, nombre, localidad, calle, nro, codigo_postal, sector, ambito)
         VALUES (p_colegio, _cue, p_nombre, p_localidad, p_calle, p_numero, p_codigo_postal, p_sector, p_ambito);
  END IF;

  -- Falla el update o el insert
  EXCEPTION 
    WHEN unique_violation THEN
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Colegio: % - %. Error: %. %',p_colegio, p_nombre, SQLSTATE, SQLERRM;   

END;
$$;
