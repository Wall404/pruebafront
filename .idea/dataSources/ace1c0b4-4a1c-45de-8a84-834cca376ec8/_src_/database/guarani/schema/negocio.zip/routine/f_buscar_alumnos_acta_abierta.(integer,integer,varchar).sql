create function negocio.f_buscar_alumnos_acta_abierta(pacta integer, pordenacta integer, palumno character varying) returns SETOF negocio.type_buscar_alumnos_acta_abierta
LANGUAGE plpgsql
AS $$
DECLARE 
  _origen char(1);
  _renglones_folio integer;
  _sql_acta text;
  _order_by  varchar(100);
  _where_acta  text;
  _from_acta varchar(100);
  _folio integer;
  _renglon integer;
  cur_det  record;
  cur_retorno type_buscar_alumnos_acta_abierta;
BEGIN

/*
 Argumentos de la funcion:
 - pActa = Nro de acta en donde se busca al alumno
 - pOrdenActa: se obtiene del parámetro "cur_orden_detalle_actas": 1 - Legajo / 2 - Apellido y Nombre / 3 - Nro de Documento
*/

-- Recupero origen y cantidad de renglones por folio a mostrar
SELECT origen, renglones_folio INTO _origen, _renglones_folio FROM sga_actas WHERE id_acta = pActa;
IF NOT FOUND THEN
  RETURN;
END IF; 

_from_acta  := ' sga_eval_detalle_cursadas as acta, ';
IF _origen = 'R' THEN
  _where_acta := ' WHERE acta.id_acta_cursada = ' || pActa::text; 
Elseif _origen = 'P' THEN
  _where_acta := ' WHERE acta.id_acta_promocion = ' || pActa::text; 
Elseif _origen = 'E' THEN
  _from_acta  := ' sga_eval_detalle_examenes as acta, ';
  _where_acta := ' WHERE acta.id_acta = ' || pActa::text; 
Else
  RETURN;
END IF;

-- Orden de los alumnos en el acta.
IF pOrdenActa = 1 THEN
   _order_by := ' ORDER BY sga_alumnos.legajo ';
ELSEIF pOrdenActa = 2 THEN
   _order_by := ' ORDER BY vw_personas.apellido, vw_personas.nombres ';
ELSEIF pOrdenActa = 3 THEN
   _order_by := ' ORDER BY vw_personas.nro_documento ';
END IF;


-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   
-- Detalle del Acta   
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   
 _sql_acta :=  'SELECT '
  || '   vw_personas.apellido as apellido, '
  || '   vw_personas.nombres as nombres, '
  || '   vw_personas.tipo_nro_documento as tipo_nro_documento, '
  || '   sga_alumnos.alumno as alumno, '
  || '   sga_alumnos.legajo as legajo '
  || ' FROM '
  || _from_acta
  || '   sga_alumnos, '
  || '   vw_personas '
  || _where_acta
  || '   AND sga_alumnos.alumno = acta.alumno '
  || '   AND vw_personas.persona = sga_alumnos.persona '
  || _order_by;


-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   
-- Detalle del Acta de Regularidades/Promoción  en estado Abierta   
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   

-- Recorro el cursor y devuelvo los datos del acta.
_folio := 1;
_renglon := 1;

FOR cur_det IN EXECUTE _sql_acta
LOOP
  -- Calculo folio y renglon
  IF _renglon > _renglones_folio THEN
     _renglon := 1;
     _folio   := _folio + 1;
  END IF;  
  
  -- Retorno todos los alumnos o los alumnos de un folio o los alumnos que coincidan con la busqueda por apellido
  IF cur_det.apellido ILIKE '%' || pAlumno || '%' THEN
     -- DETALLE
     cur_retorno.alumno             := cur_det.alumno;
     cur_retorno.apellido           := cur_det.apellido;
     cur_retorno.nombres            := cur_det.nombres;
     cur_retorno.tipo_nro_documento := cur_det.tipo_nro_documento;
     cur_retorno.legajo             := cur_det.legajo;
     cur_retorno.folio              := _folio;
     cur_retorno.renglon            := _renglon;
     
     -- Retorno la fila
     RETURN NEXT cur_retorno;
 END IF;

 _renglon := _renglon + 1;
END LOOP;
   
END
$$;
