create function negocio.ftdb_sga_insc_subcomision() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Actualizo el cupo de la subcomision
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   UPDATE sga_subcomisiones_cupo 
      SET cant_inscriptos = cant_inscriptos -1 
    WHERE subcomision = OLD.subcomision;
       
  RETURN OLD;
END;
$$;
