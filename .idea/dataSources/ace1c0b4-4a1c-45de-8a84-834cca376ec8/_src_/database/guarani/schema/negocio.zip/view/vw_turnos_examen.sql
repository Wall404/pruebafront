CREATE VIEW vw_turnos_examen AS SELECT periodo_turno.anio_academico,
    sga_turnos_examen.turno_examen,
    periodo_turno.periodo AS turno_examen_periodo,
    periodo_turno.nombre AS turno_examen_nombre,
    periodo_turno.fecha_inicio AS turno_examen_fecha_inicio,
    periodo_turno.fecha_fin AS turno_examen_fecha_fin,
    sga_turnos_examen.fecha_publicacion_mesas AS turno_examen_fecha_publicacion_mesas,
    sga_turnos_examen.fecha_inactivacion AS turno_examen_fecha_inactivacion,
    sga_llamados_turno.llamado,
    periodo_llamado.periodo AS llamado_periodo,
    periodo_llamado.nombre AS llamado_nombre,
    periodo_llamado.fecha_inicio AS llamado_fecha_inicio,
    periodo_llamado.fecha_fin AS llamado_fecha_fin
   FROM negocio.sga_turnos_examen,
    negocio.sga_llamados_turno,
    negocio.sga_periodos periodo_turno,
    negocio.sga_periodos periodo_llamado
  WHERE (((sga_llamados_turno.turno_examen = sga_turnos_examen.turno_examen) AND (sga_llamados_turno.periodo = periodo_llamado.periodo)) AND (sga_turnos_examen.periodo = periodo_turno.periodo));
