CREATE VIEW vw_insc_cursada_instancias_log AS SELECT sga_insc_cursada_instancias_log.inscripcion,
    sga_insc_cursada_instancias_log.instancia
   FROM negocio.sga_insc_cursada_instancias_log
UNION ALL
 SELECT his_insc_cursada_instancias_log.inscripcion,
    his_insc_cursada_instancias_log.instancia
   FROM negocio.his_insc_cursada_instancias_log;
