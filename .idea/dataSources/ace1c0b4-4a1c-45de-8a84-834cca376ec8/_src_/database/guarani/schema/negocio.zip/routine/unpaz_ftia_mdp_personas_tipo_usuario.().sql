create function negocio.unpaz_ftia_mdp_personas_tipo_usuario() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _cnt smallint;   
BEGIN

   -- Si es alumno o docente inserto los grupos de acceso asociados al tipo de usuario
   IF NEW.tipo_usuario = 'Alumno' OR NEW.tipo_usuario = 'Docente' OR NEW.tipo_usuario = 'Cursos' THEN
	--consulto si la persona ya existe para que no arroje error
	   SELECT COUNT(*) INTO _cnt 
		FROM mdp_personas_grupo_acc 
		WHERE persona = NEW.persona 
		AND tipo_usuario = NEW.tipo_usuario
		AND usuario_grupo_acc IN (SELECT usuario_grupo_acc FROM negocio.acc_grupo_acc_x_tipo_usuario WHERE tipo_usuario = NEW.tipo_usuario);   

	   IF _cnt = 0 THEN
		   INSERT INTO mdp_personas_grupo_acc (persona, tipo_usuario, usuario_grupo_acc, grupo_acceso_default)
			  SELECT NEW.persona, g.tipo_usuario, g.usuario_grupo_acc, g.grupo_acc_default
			    FROM acc_grupo_acc_x_tipo_usuario as g
			   WHERE g.tipo_usuario = NEW.tipo_usuario;
	   END IF;
   END IF;        

   RETURN NEW;
END;
$$;
