create function negocio.get_equiv_nota(pescalaorigen integer[], pnotaorigen character varying[], presultadoorigen character, pescaladestino integer, pconsideraresultado boolean, pcoincidenotadestino boolean) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
 _porcentaje decimal(10,3);
 _porcentaje_origen decimal(10,3);
 _porcentaje_destino decimal(10,3);
 _porcentaje_max decimal(10,3);
 _porcentaje_min decimal(10,3);
 _porcentaje_aux decimal(10,3);
 _resultado_nota char(1);
 _cant_notas_escala decimal(10,3);
 _cant_notas_origen integer;
 _NotaDestino varchar(10);
 _cant_notas  decimal(10,3);
 _posicion decimal(10,3);
 _cant_notas_destino decimal(10,3);
 _orden Integer;
 _existe_nota_origen boolean;
 _cur record; 
 
BEGIN
 /*
  pResultadoOrigen = Define que resultado busca. 
        Valores: A - Aprobado / R - Desaprobado
  pConsideraResultado = Define si considera el resultado de la nota origen para el calculo del promedio o no..
        Valores: false - No considera el resultado, se basa en todas las notas de la escala de notas
                 true - Considera el resultado, entonces solo verifica el % respecto de notas con el mismo resultado

  pCoincideNotaDestino = Define si se devuelve la nota solo si encuentra una nota que coincida exactamente con la nota promedio del origen
        Valores: true - Solo devuelve la nota si la nota destino coincide con el promedio de las notas origen
                     Si no encuentra nota devuelve NULL
                 false - Devuelve la nota mas cercana que coincida con la nota promedio origen y el mismo resultado
 */
 _existe_nota_origen := false;
 _cant_notas_destino := 0;
 _NotaDestino        := NULL;
 _cant_notas_origen  := COALESCE(array_length(pEscalaOrigen, 1), 0);
 
--------------
--PERSONALIZACION 2602. PARA QUE TOME LA NOTA CORRESPONDIENTE
--------------
pcoincidenotadestino := FALSE;
pconsideraresultado := FALSE;


 -- Si alguna de las escalas es nula o la nota es nula, retorna null.
 IF pEscalaDestino IS NULL OR pResultadoOrigen IS NULL OR _cant_notas_origen = 0 THEN
    RETURN _NotaDestino;
 END IF; 

 FOR i IN 1 .. _cant_notas_origen LOOP
   IF pEscalaOrigen[i] IS NULL OR pNotaOrigen[i] IS NULL THEN
     RETURN _NotaDestino;
   END IF; 
 END LOOP;
 
 
 -- Si es la misma escala, devuelve la misma nota. Solo en el caso que sea una sola nota origen 
 IF _cant_notas_origen = 1 THEN
   IF pEscalaOrigen[1] = pEscalaDestino THEN
     _NotaDestino := pNotaOrigen[1];
     RETURN _NotaDestino;
   END IF;  
 END IF;

 _porcentaje_origen := 0;
 _porcentaje := 0;
 _porcentaje_destino := 0;
 _porcentaje_aux := 0;
 
 -- **************************************************************************************
 -- Recorro la notas de las actividades del grupo origen (solo de las que pasaban nota) y
 -- calculo el % promedio de acuerdo al orden que tiene la nota en la escala de notas
 -- **************************************************************************************
 FOR i IN 1 .. _cant_notas_origen LOOP

  SELECT resultado, orden  INTO _resultado_nota, _orden  
    FROM sga_escalas_notas_det 
   WHERE escala_nota = pEscalaOrigen[i] 
     AND nota = pNotaOrigen[i];
  
  IF pConsideraResultado THEN
    -- Solo las notas de la escala de notas con el mismo resultado
    SELECT COUNT(*) INTO _cant_notas_escala FROM sga_escalas_notas_det WHERE escala_nota = pEscalaOrigen[i] AND resultado = pResultadoOrigen;
    SELECT COUNT(*) INTO _posicion FROM sga_escalas_notas_det WHERE escala_nota = pEscalaOrigen[i] AND orden <= _orden AND resultado = pResultadoOrigen;
  ELSE  
    -- Todas las notas de la escala de notas
    SELECT COUNT(*) INTO _cant_notas_escala FROM sga_escalas_notas_det WHERE escala_nota = pEscalaOrigen[i];
    _posicion := _orden; -- la posicion de la nota dentro de la escala de notas es la misma que la definida en el campo "orden".
  END IF;
    
  IF _posicion > 0 THEN  
    -- Recupero el porcentaje relacionado con el nro de orden dentro de la escala de notas.
    _porcentaje := _porcentaje + round((_posicion * 100 / _cant_notas_escala), 3);
    _existe_nota_origen := true;
  END IF;

 END LOOP;

 IF NOT _existe_nota_origen THEN
   -- Retorna NULL porque no encontro las notas en las escalas de notas origen
   RETURN _NotaDestino;
 END IF;
 
 -- Saco el promedio de los porcentajes de las notas origen
 _porcentaje_origen := trunc(_porcentaje / _cant_notas_origen, 3);

 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- Busco el % de las notas del origen en la escala de notas destino
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 _porcentaje_max := NULL;
 _porcentaje_min := NULL;
 _porcentaje_aux := NULL;

 -- Cantidad de notas de toda la escala de notas o solo de las notas con el mismo resultado.
 SELECT COUNT(*) INTO _cant_notas_destino
    FROM sga_escalas_notas_det 
   WHERE escala_nota = pEscalaDestino
     AND (NOT pConsideraResultado OR (pConsideraResultado AND resultado = pResultadoOrigen)); 
  
  CREATE TEMP TABLE _TNotasDestino (nota varchar(10), orden integer, porcentaje decimal(10,3));

  _posicion := 1;
  FOR _cur IN SELECT nota, orden  
               FROM sga_escalas_notas_det 
               WHERE escala_nota = pEscalaDestino
                 AND (NOT pConsideraResultado OR (pConsideraResultado AND resultado = pResultadoOrigen))  
               ORDER BY orden  
   LOOP
      _porcentaje_aux := round(_posicion * 100 / _cant_notas_destino,3);
      INSERT INTO _TNotasDestino (nota, orden, porcentaje) VALUES (_cur.nota, _cur.orden, _porcentaje_aux);
      _posicion := _posicion + 1;
   END LOOP;

  -- La nota debe existir en el destino
  IF pCoincideNotaDestino  THEN
     -- Verifico que exista una nota con el mismo % que el porcentaje del promedio de las notas origen
     SELECT nota INTO _NotaDestino FROM _TNotasDestino WHERE porcentaje = _porcentaje_origen;
  ELSE
    SELECT MIN(porcentaje) INTO _porcentaje_max FROM _TNotasDestino  WHERE porcentaje >= _porcentaje_origen;
    SELECT MAX(porcentaje) INTO _porcentaje_min FROM _TNotasDestino  WHERE porcentaje <= _porcentaje_origen;
 
    IF _porcentaje_max IS NULL THEN
	_porcentaje_destino := _porcentaje_min;
    ELSEIF _porcentaje_min IS NULL THEN
	_porcentaje_destino := _porcentaje_max;
    ELSEIF _porcentaje_min = _porcentaje_max THEN
	_porcentaje_destino := _porcentaje_max;
    ELSE
 
      -- Busco la nota mas cercana. Saco el valor absoluto de la diferencia respecto del porcentaje promedio de las notas del origen. 
      IF abs(_porcentaje_max - _porcentaje_origen) <= abs(_porcentaje_min - _porcentaje_origen) THEN
         _porcentaje_destino := _porcentaje_max;
      ELSE
         _porcentaje_destino := _porcentaje_min;
      END IF;
    END IF;

    SELECT  nota INTO _NotaDestino FROM _TNotasDestino WHERE porcentaje = _porcentaje_destino;
  END IF;

  DROP TABLE _TNotasDestino;

  RETURN _NotaDestino;
 
END;
$$;
