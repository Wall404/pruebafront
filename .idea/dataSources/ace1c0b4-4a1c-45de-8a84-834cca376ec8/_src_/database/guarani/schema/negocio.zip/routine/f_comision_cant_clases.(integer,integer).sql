create function negocio.f_comision_cant_clases(_alumno integer, _comision integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _subcom integer;      
  _cantidad_clases integer;      
  
BEGIN
  
  _subcom := 0;
  _cantidad_clases := 0;
  
  -- Si la fecha es nula le paso la fecha actual.
  SELECT COUNT(*) INTO _subcom
    FROM sga_subcomisiones 
    WHERE comision = _comision;
    
  IF _subcom > 0 THEN 
    -- Hay subcomisiones
    -- Recupero cantidad de clases de las bandas horarias de las subcomisiones en donde esta inscripto el alumno.
    SELECT COUNT(*) INTO _cantidad_clases
      FROM sga_insc_cursada,
           sga_subcomisiones,
           sga_insc_subcomision,
           sga_subcomisiones_bh,
           sga_clases
      WHERE sga_insc_cursada.alumno = _alumno
        AND sga_insc_cursada.comision = _comision
        AND sga_insc_subcomision.inscripcion = sga_insc_cursada.inscripcion
        AND sga_subcomisiones_bh.subcomision = sga_insc_subcomision.subcomision
        AND sga_clases.banda_horaria = sga_subcomisiones_bh.banda_horaria
        AND sga_clases.valido = 1;     
  ELSE
    -- Sin subcomisiones
    -- Recupero cantidad de clases de las bandas horarias de la comision
    SELECT COUNT(*) INTO _cantidad_clases
      FROM sga_comisiones_bh,
           sga_clases
      WHERE sga_comisiones_bh.comision = _comision
        AND sga_clases.banda_horaria = sga_comisiones_bh.banda_horaria
        AND sga_clases.valido = 1;     
  END IF;
  
  -- Retorno cantidad de clases que le corresponde al alumno
  RETURN _cantidad_clases;
    
END;
$$;
