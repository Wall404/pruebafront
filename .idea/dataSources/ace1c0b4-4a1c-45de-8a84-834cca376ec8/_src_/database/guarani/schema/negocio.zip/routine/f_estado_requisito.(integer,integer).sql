create function negocio.f_estado_requisito(idpersona integer, idrequisito integer) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE
		_fecha_presentacion	DATE;
		_fecha_vencimiento	DATE;

	BEGIN
		SELECT	sga_requisitos_presentados.fecha_presentacion,
				sga_requisitos_presentados.fecha_vencimiento
		INTO	_fecha_presentacion,
				_fecha_vencimiento

		FROM sga_requisitos_presentados
		WHERE sga_requisitos_presentados.requisito_presentado = (	SELECT		sga_requisitos_presentados.requisito_presentado
																	FROM		sga_requisitos_presentados
																	WHERE		persona		= idpersona
																	AND			requisito	= idrequisito
																	ORDER BY	fecha_presentacion DESC
																	LIMIT		1 );

		IF NOT FOUND THEN
			RETURN 'PENDIENTE';
		END IF;

		IF _fecha_vencimiento >= CURRENT_DATE OR _fecha_vencimiento IS NULL THEN
			RETURN 'VIGENTE';
		ELSE
			RETURN 'VENCIDO';
		END IF;

	END;
$$;
