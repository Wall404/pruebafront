create function negocio.get_plan_version_anterior_alumno(palumno integer, pplanversion character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _plan_version_anterior  integer;
  _plan_actual integer;
  _plan_version_actual integer;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _plan_version_anterior := NULL;
   _plan_actual := NULL;
   _plan_version_actual := NULL;

  -- Recupero plan y version actual del alumno
  SELECT sga_planes_versiones.plan, sga_planes_versiones.plan_version 
    INTO _plan_actual, _plan_version_actual
    FROM sga_alumnos,
         sga_planes_versiones
   WHERE sga_alumnos.alumno = pAlumno
     AND sga_alumnos.plan_version = sga_planes_versiones.plan_version;
           
  		
  -- Recupero los cambios de plan y version del alumno 
  FOR cur1 IN SELECT v.plan, h.plan_version
                FROM sga_alumnos_hist_planes as h,
                     sga_planes_versiones as v
               WHERE h.alumno = pAlumno
                 AND v.plan_version = h.plan_version
               ORDER BY h.fecha DESC
  LOOP
      IF pPlanVersion = 'PLAN' THEN		
         -- Busco el plan inmediato anterior
         IF cur1.plan <> _plan_actual THEN
            _plan_version_anterior := cur1.plan_version;
            EXIT;
         END IF;
      END IF;

      IF pPlanVersion = 'VERSION' THEN		
         -- Busco la version del mismo plan inmediato anterior
         IF cur1.plan = _plan_actual AND cur1.plan_version <> _plan_version_actual THEN
            _plan_version_anterior := cur1.plan_version;
            EXIT;
         END IF;
      END IF;
  END LOOP;
	
  RETURN _plan_version_anterior;
    
  END;
$$;
