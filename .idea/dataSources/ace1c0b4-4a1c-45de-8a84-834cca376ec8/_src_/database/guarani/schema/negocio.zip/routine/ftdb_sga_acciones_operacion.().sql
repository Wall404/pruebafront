create function negocio.ftdb_sga_acciones_operacion() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

   -- Borro tabla de configuracion de requisitos por operacion para los requisitos de la acción.
   DELETE FROM sga_requisitos_conf_x_oper
     WHERE operacion = OLD.operacion
       AND requisito_accion IN 
        (SELECT sga_requisitos_x_accion.requisito_accion 
           FROM  sga_requisitos_grupos, sga_requisitos_x_accion   
         WHERE sga_requisitos_grupos.grupo_requisito = sga_requisitos_x_accion.grupo_requisito
           AND sga_requisitos_grupos.accion = OLD.accion);

   RETURN OLD;
END;
$$;
