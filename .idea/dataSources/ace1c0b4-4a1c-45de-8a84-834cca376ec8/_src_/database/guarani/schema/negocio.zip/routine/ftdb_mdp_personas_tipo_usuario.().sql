create function negocio.ftdb_mdp_personas_tipo_usuario() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

  -- Borro los grupos de acceso al sistema relacionados con esta persona
  DELETE FROM mdp_personas_grupo_acc
    WHERE persona = OLD.persona
     AND tipo_usuario = OLD.tipo_usuario;
  
  -- Limpio el acceso por defecto a Autogestion si este tipo de usuario estaba definido
  UPDATE mdp_personas SET tipo_usuario_inicial = NULL 
   WHERE persona = OLD.persona AND tipo_usuario_inicial = OLD.tipo_usuario;

  RETURN OLD;
END;
$$;
