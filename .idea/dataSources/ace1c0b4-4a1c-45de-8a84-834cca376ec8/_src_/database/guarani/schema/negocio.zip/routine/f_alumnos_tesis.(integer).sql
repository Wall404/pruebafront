create function negocio.f_alumnos_tesis(_tesis integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _alumnos text;
  cur1 record;
        
  BEGIN
   _alumnos := '';
		
  -- Recupero el nombre de los alumnos
  FOR cur1 IN SELECT vw_personas.apellido_nombres
  					FROM sga_tesis_alumnos, sga_alumnos, vw_personas
  	                WHERE sga_tesis_alumnos.tesis = _tesis
  	                AND sga_alumnos.alumno = sga_tesis_alumnos.alumno
  	                AND sga_alumnos.persona = vw_personas.persona
			ORDER BY vw_personas.apellido_nombres
  LOOP
         _alumnos :=  _alumnos || ' - ' || cur1.apellido_nombres;
  END LOOP;

  _alumnos := trim(leading ' - ' from _alumnos);
	
  RETURN _alumnos;
    
END;
$$;
