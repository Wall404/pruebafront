create function negocio.f_horario_comision_aula(pcomision integer, pmostrartipoclase boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _horario text; 
  i smallint;     
  cur_bh record;
BEGIN
  
  _horario := '';
  i := 0;
  FOR cur_bh IN 
   (
   SELECT sga_asignaciones.dia_semana as dia_semana,
          to_char(sga_asignaciones.hora_inicio, 'HH24:MI') as inicio,
          to_char(sga_asignaciones.hora_finalizacion, 'HH24:MI') as fin,
          sga_clases_tipos.nombre as desc_tipo_clase,
          sga_espacios.nombre as espacio_nombre
     FROM sga_comisiones_bh,
          sga_clases_tipos,
          sga_asignaciones
            LEFT JOIN sga_espacios ON sga_espacios.espacio = sga_asignaciones.espacio
      WHERE sga_comisiones_bh.comision = pComision
        AND sga_clases_tipos.tipo_clase = sga_comisiones_bh.tipo_clase
        AND sga_asignaciones.asignacion = sga_comisiones_bh.asignacion
     ORDER BY CASE sga_asignaciones.dia_semana
                WHEN 'Lunes' THEN 1
                WHEN 'Martes' THEN 2
                WHEN 'Miercoles' THEN 3
                WHEN 'Jueves' THEN 4
                WHEN 'Viernes' THEN 5
                WHEN 'Sabado' THEN 6
                WHEN 'Domingo' THEN 7
                ELSE 0
              END, 2   
        
   )
  LOOP
   IF i > 0 THEN
    _horario := _horario || ' / ' ;
   END IF;
   IF pMostrarTipoClase THEN
     _horario := _horario || substring(cur_bh.dia_semana from 1 for 3) || ' ' || cur_bh.inicio || ' a ' || cur_bh.fin || ' - ' || cur_bh.desc_tipo_clase || COALESCE( ' (' || cur_bh.espacio_nombre || ')', '');
   ELSE
     _horario := _horario || substring(cur_bh.dia_semana from 1 for 3) || ' ' || cur_bh.inicio || ' a ' || cur_bh.fin || COALESCE( ' (' || cur_bh.espacio_nombre || ')', '');
   END IF;  
   i := i + 1;
  END LOOP;
    
  -- Retorno los dias y horarios de la subcomision
  RETURN _horario;
    
END;
$$;
