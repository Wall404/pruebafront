create function negocio.ftia_sga_propuestas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de períodos de inscripción a propuesta.
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	INSERT INTO	sga_periodos_inscripcion_aplanado (periodo_insc, propuesta)
	SELECT		sga_periodos_inscripcion_fechas.periodo_insc,
				NEW.propuesta
	FROM		sga_periodos_inscripcion_fechas,
				sga_periodos_inscripcion,
				sga_periodos_inscripcion_subtipos,
				sga_g3entidades,
				sga_propuestas
	WHERE		sga_periodos_inscripcion_fechas.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion AND
				sga_periodos_inscripcion_fechas.periodo_insc = sga_periodos_inscripcion_subtipos.periodo_insc AND
				sga_periodos_inscripcion_subtipos.entidad_subtipo = sga_g3entidades.entidad_subtipo AND
				sga_g3entidades.entidad = sga_propuestas.entidad AND
				-- Sólo períodos de inscripción a propuesta.
				sga_periodos_inscripcion.periodo_generico_tipo = 4 AND
				sga_propuestas.propuesta = NEW.propuesta AND
				-- Sólo períodos vigentes o futuros de acuerdo a la fecha de alta de la propuesta.
				(NEW.fecha_alta BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR NEW.fecha_alta <= sga_periodos_inscripcion_fechas.fecha_inicio);

	RETURN NEW;
END;
$$;
