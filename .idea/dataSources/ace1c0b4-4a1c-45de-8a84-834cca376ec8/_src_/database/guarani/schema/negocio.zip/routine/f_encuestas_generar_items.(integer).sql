create function negocio.f_encuestas_generar_items(phabilitacion integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE 
  _item Integer;
  _formulario Integer;
  cur_item RECORD;
  cur_form RECORD;
  cur_com RECORD;
  cur_subcom RECORD;
  cur_alu RECORD; 
  hab  gde_habilitaciones%ROWTYPE;
  _nombre_actividad varchar(255);
  _codigo_actividad varchar(20);
  _nombre_comision varchar(100);
  _nombre_certificado varchar(255);
  _nombre_propuesta varchar(255);
  _nombre_propuesta_abreviado varchar(50);
  _titulo_formulario text;
  _titulo_item text;
  _tiene_subcomisiones Integer;
  _cant_items_nuevos Integer;
  _cant_items integer;
  _cant_formularios_nuevos Integer;
  
BEGIN

  /*
  Tipos de Encuestas:
    1 - Evaluación docente
    2 - Evaluación académica
    3 - Evaluación docente y académica
    4 - Genérica
	5 - Egresados (3.13.3)

  Alcances:
    1 - Toda la Institucion 
    2 - Responsables Académicas
    3 - Tipos de Propuestas
    4 - Propuestas
    5 - Actividades
  */


  -- Nuevos items a crear.
  CREATE TEMP TABLE temp_items (
      titulo Text NOT NULL,
      encuesta Integer NOT NULL,
      anio_academico Integer,
      periodo_lectivo Integer,
      propuesta Integer,
      elemento Integer,
      comision Integer,
      subcomision Integer,
      docente Integer,
	  certificado Integer,
      estado char(1));
      
  -- Items originales de la Habilitacion
  CREATE TEMP TABLE temp_items_orig (
      titulo Text NOT NULL,
      encuesta Integer NOT NULL,
      anio_academico Integer,
      propuesta Integer,
      periodo_lectivo Integer,
      elemento Integer,
      comision Integer,
      subcomision Integer,
      docente Integer,
	  certificado Integer,
      estado char(1));

  -- Recupero lo items originales de la habilitacion.
  INSERT INTO temp_items_orig (titulo, encuesta, anio_academico, propuesta, periodo_lectivo, elemento, comision, subcomision, docente, certificado, estado)
     SELECT titulo, encuesta, anio_academico, propuesta, periodo_lectivo, elemento, comision, subcomision, docente, certificado, estado
       FROM gde_items
      WHERE habilitacion = pHabilitacion;
      
  -- Items a dar de baja    
  CREATE TEMP TABLE temp_items_baja (
      titulo Text NOT NULL,
      encuesta Integer NOT NULL,
      anio_academico Integer,
      periodo_lectivo Integer,
      elemento Integer,
      comision Integer,
      subcomision Integer,
      docente Integer,
	  certificado Integer);

  -- Formularios Nuevos de la Habilitacion
  CREATE TEMP TABLE temp_form (formulario Integer NOT NULL, titulo Text NOT NULL, habilitacion Integer NOT NULL, comision integer, subcomisiones Integer[], estado char(1));

  -- Formularios Originales de la habilitacion
  CREATE TEMP TABLE temp_form_orig (formulario Integer NOT NULL, titulo Text NOT NULL, habilitacion Integer NOT NULL, comision integer, subcomisiones Integer[], estado char(1));
  INSERT INTO temp_form_orig (formulario, titulo, habilitacion, comision, subcomisiones, estado) 
    SELECT formulario, titulo, habilitacion, comision, subcomisiones, estado 
      FROM gde_formularios
     WHERE habilitacion = pHabilitacion;
  
  -- Encuestas pendientes originales.
  CREATE TEMP TABLE temp_pend_orig (respuesta Integer Not Null, persona Integer Not Null, formulario Integer Not Null); 
  INSERT INTO temp_pend_orig (respuesta, persona, formulario)
       SELECT p.respuesta, p.persona, p.formulario
         FROM gde_formularios as f,
              gde_encuestas_pendientes as p
        WHERE p.formulario = f.formulario
          AND f.habilitacion = pHabilitacion;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Recupero los datos de la habilitación
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  SELECT * INTO hab FROM gde_habilitaciones WHERE habilitacion = pHabilitacion;

 
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 --  5 - Evaluación egresados
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 IF hab.tipo = 5  THEN
   CREATE TEMP TABLE temp_alumnos_cert_orig (certificado Integer Not Null, alumno Integer, persona Integer Not Null, formulario integer); 
   CREATE TEMP TABLE temp_alumnos_cert_new  (certificado Integer Not Null, alumno Integer, persona Integer Not Null); 

   CREATE TEMP TABLE temp_cert_orig (certificado Integer Not Null); 
   CREATE TEMP TABLE temp_cert (certificado Integer Not Null); 

   -- Certificados originales - Certificados registrados en los formularios de la habilitacion
   INSERT INTO temp_cert_orig (certificado)
      SELECT i.certificado
        FROM gde_formularios as f,
		     gde_formulario_items as fd,
             gde_items as i,
             gde_encuestas_pendientes as p
       WHERE f.habilitacion = pHabilitacion
	     AND fd.formulario = f.formulario
         AND i.item = fd.item
		 AND i.certificado IS NOT NULL;


   -- Inserto todos los certificados que deben ir en la habilitacion
   IF hab.egresados = 'T' THEN
    
		-- Inserto todas las certificaciones (Toda la Institucion)
		IF hab.alcance = 1 THEN
		   INSERT INTO temp_cert (certificado)
			  SELECT certificado
				FROM sga_certificados;
		END IF;
		
		-- Inserto todos los certificados de la responsable academica
		IF hab.alcance = 2 THEN
		   INSERT INTO temp_cert (certificado)
			  SELECT DISTINCT pc.certificado
				FROM gde_responsables_academicas as ra,
					 sga_propuestas_ra as pr,
					 vw_planes as vp,
					 sga_planes_certificados as pc
			   WHERE ra.habilitacion = pHabilitacion 
				 AND ra.responsable_academica = pr.responsable_academica
				 AND pr.propuesta = vp.propuesta
				 AND vp.plan_version = pc.plan_version;
		END IF;
	  
		-- Inserto todos los certificados de las propuestas-planes de los tipos de propuestas
		IF hab.alcance = 3 THEN
		   INSERT INTO temp_cert (certificado)
			  SELECT DISTINCT pc.certificado
				FROM gde_propuestas_tipos as tp,
					 vw_planes as vp,
					 sga_planes_certificados as pc
			   WHERE vp.habilitacion = pHabilitacion 
				 AND vp.propuesta_tipo = tp.propuesta_tipo
				 AND pc.plan_version = vp.plan_version;
		END IF;
	  
		-- Inserto todos los certificados de las propuestas seleccionadas.
		IF hab.alcance = 4 THEN
		   INSERT INTO temp_cert (certificado)
			  SELECT DISTINCT pc.certificado
				FROM gde_propuestas as p,
					 vw_planes as vp,
					 sga_planes_certificados as pc
			   WHERE p.habilitacion = pHabilitacion 
				 AND vp.propuesta = p.propuesta
				 AND pc.plan_version = vp.plan_version;
		END IF; 
	END IF; -- hab.egresados = T 
	
	-- Solo egresados de los certificados seleccionados
	IF hab.egresados = 'A' THEN
        INSERT INTO temp_cert (certificado)
             SELECT c.certificado
               FROM gde_certificados as c
              WHERE c.habilitacion = pHabilitacion;
	END IF;	 

   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   --                          ENCUESTADOS - ALUMNOS 
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

   -- Alumnos que estan actualmente en la habilitacion
   INSERT INTO temp_alumnos_cert_orig (certificado, persona, formulario)
      SELECT i.certificado, p.persona, f.formulario
        FROM gde_formularios as f,
             gde_formulario_items as fd,
             gde_items as i,
             gde_encuestas_pendientes as p
       WHERE f.habilitacion = pHabilitacion
	     AND fd.formulario = f.formulario
	     AND i.item = fd.item
	     AND p.formulario   = f.formulario;
   
   -- Todos los egresados en el rango de fechas seleccionado de los certificados de la habilitacion
   INSERT INTO temp_alumnos_cert_new  (certificado, alumno, persona)
             SELECT co.certificado , co.alumno, co.persona
               FROM temp_cert as t,
                    sga_certificados_otorg as co
              WHERE co.certificado = t.certificado
                AND co.anulado = 0
                AND co.fecha_egreso >= hab.fecha_egreso_desde 
                AND (hab.fecha_egreso_hasta IS NULL OR co.fecha_egreso <= hab.fecha_egreso_hasta);
	
 
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- ITEMS. Registro un item por cada certificado que va en la habilitacion
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   INSERT INTO temp_items (titulo, encuesta, certificado)
      SELECT C.nombre, G.encuesta, T.certificado
       FROM gde_grupos as G,
            gde_encuestas as E, 
            temp_cert as T,
            sga_certificados as C
      WHERE G.habilitacion = pHabilitacion
        AND G.encuesta     = E.encuesta
        AND E.subtipo      = 'E' -- Egresados
        AND C.certificado  = T.certificado;

   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- FORMULARIOS. Creo solo formularios de items nuevos. Creo el item y el formulario asociado.
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   FOR cur_item IN 
      SELECT certificado, encuesta, titulo FROM temp_items
      EXCEPT  
      SELECT certificado, encuesta, titulo FROM temp_items_orig
   LOOP
     -- Inserto el Item
	 _titulo_item := cur_item.titulo; -- El nombre del item es el nombre del certificado
     INSERT INTO gde_items (titulo, habilitacion, encuesta, certificado, estado) 
	     VALUES (_titulo_item, pHabilitacion, cur_item.encuesta, cur_item.certificado, 'A');
     _item := (SELECT currval('gde_items_seq'));
    
     -- Inserto el formulario. El concepto sería el formulario.
	 _titulo_formulario := _titulo_item;
     INSERT INTO gde_formularios (titulo, habilitacion, estado) VALUES (_titulo_formulario, pHabilitacion, 'A');
     _formulario := (SELECT currval('gde_formularios_seq'));

     -- inserto el formulario agregado en el temporal
     INSERT INTO temp_form (formulario, titulo, habilitacion, estado) VALUES (_formulario, _titulo_formulario, pHabilitacion, 'A');
    
     -- Items x Formulario
     INSERT INTO gde_formulario_items (formulario, item) VALUES (_formulario, _item);

  END LOOP; -- fin creacion de nuevos formularios en la habilitacion
  
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Items y formularios que estaban dados de baja y que vuelven a activarse
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  UPDATE gde_items
     SET estado = 'A'
   WHERE habilitacion = pHabilitacion
     AND estado = 'B'
     AND item IN (SELECT i.item 
                    FROM gde_items as i, 
                         temp_items as t
                   WHERE i.habilitacion = pHabilitacion
                     AND t.encuesta     = i.encuesta
                     AND t.certificado  = i.certificado
                 );
 
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- ITEMS Y FORMULARIOS A DAR DE BAJA PORQUE NO VAN MAS.
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Items que debo dar de baja porque ya no van mas		
  INSERT INTO temp_items_baja (titulo, encuesta, certificado)
     SELECT titulo, encuesta, certificado FROM temp_items_orig
     EXCEPT
     SELECT titulo, encuesta, certificado FROM temp_items;
       
  UPDATE gde_items
     SET estado = 'B'
   WHERE habilitacion = pHabilitacion
     AND estado = 'A'
     AND item IN (SELECT i.item 
                    FROM gde_items as i, 
                         temp_items_baja as b
                   WHERE i.habilitacion = pHabilitacion
                     AND b.encuesta     = i.encuesta
                     AND b.certificado  = i.certificado
                 );

  -- FORMULARIOS - Activo formularios que estaban dados de baja y ahora tienen algun item activo.
  UPDATE gde_formularios
     SET estado = 'A'
   WHERE habilitacion = pHabilitacion
     AND estado = 'B'
     AND EXISTS (SELECT 1 
                   FROM gde_formulario_items as fi, gde_items as i 
                  WHERE fi.formulario = gde_formularios.formulario
                    AND i.item = fi.item
					AND i.habilitacion = pHabilitacion
                    AND i.estado = 'A'
				);
				 
  -- FORMULARIOS... Doy de baja formularios que ya no tienen items activos
  UPDATE gde_formularios
     SET estado = 'B'
   WHERE habilitacion = pHabilitacion
     AND estado = 'A'
     AND NOT EXISTS (SELECT 1 
                       FROM gde_formulario_items as fi, 
                            gde_items as i
                      WHERE fi.formulario = gde_formularios.formulario
                        AND i.item = fi.item
					    AND i.habilitacion = pHabilitacion
                        AND i.estado = 'A'
                     );

  -- Borro encuestas que ya no deben contestarse por los alumnos por haberse dado de baja el formulario
  DELETE FROM gde_encuestas_pendientes
    WHERE fecha_respuesta IS NULL
      AND formulario IN (SELECT formulario FROM gde_formularios as f WHERE f.habilitacion = pHabilitacion AND f.estado = 'B');

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- ENCUESTADOS  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Personas que deben responder la encuesta para el certificado agregado a la habilitacion.
  INSERT INTO gde_encuestas_pendientes (persona, formulario)
       -- Alumnos alcanzados por el alcance de la encuesta...
       SELECT DISTINCT p.persona, f.formulario 
	     FROM gde_items as i,
		      temp_alumnos_cert_new as p, 
			  gde_formularios as f, 
			  gde_formulario_items as fi
	    WHERE i.habilitacion = pHabilitacion
		  AND p.certificado = i.certificado
		  AND fi.item = i.item
		  AND f.formulario = fi.formulario
		  AND f.habilitacion = pHabilitacion
     EXCEPT 
		-- Alumnos que ya existen en esos formularios
		SELECT	e.persona,
				f.formulario 
		FROM	gde_encuestas_pendientes as e,
				gde_formularios as f
		WHERE	e.formulario = f.formulario AND
				f.habilitacion = pHabilitacion;

   -- Borro tablas temporales
   DROP TABLE IF EXISTS temp_alumnos_cert_orig;
   DROP TABLE IF EXISTS temp_alumnos_cert_new;
   DROP TABLE IF EXISTS temp_cert_orig;
   DROP TABLE IF EXISTS temp_cert;
		
 END IF; 
 -- ***************************** FIN Tipo = 5 ********************************************
 
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 --  1 - Evaluación docente / 2 - Evaluación académica / 3 - Evaluación docente y académica
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 IF hab.tipo = 1 OR hab.tipo = 2 OR hab.tipo = 3 THEN
   CREATE TEMP TABLE temp_alumnos_com (comision Integer Not Null, alumno Integer Not Null, persona Integer Not Null, subcomisiones integer[]); 
   CREATE TEMP TABLE temp_alumnos_com_orig (comision Integer Not Null, alumno Integer Not Null, persona Integer Not Null, subcomisiones integer[]); 
   CREATE TEMP TABLE temp_alumnos_com_new  (comision Integer Not Null, alumno Integer Not Null, persona Integer Not Null, subcomisiones integer[]); 
   CREATE TEMP TABLE temp_com (comision Integer Not Null, tiene_subcomisiones integer NOT NULL DEFAULT 0); 
   CREATE TEMP TABLE temp_com2 (comision Integer Not Null, tiene_subcomisiones integer NOT NULL DEFAULT 0);  
   CREATE TEMP TABLE temp_doc  (comision Integer Not Null, subcomision Integer, docente Integer Not Null, responsabilidad Integer); 
   CREATE TEMP TABLE temp_com_orig (comision Integer, tiene_subcomisiones integer NOT NULL DEFAULT 0); 


   -- Recupero los alumnos originales que ya estan para contestar las encuestas...
   INSERT INTO temp_alumnos_com_orig (comision, alumno, persona, subcomisiones)
      SELECT f.comision, a.alumno, p.persona, f.subcomisiones
        FROM gde_formularios as f,
             gde_encuestas_pendientes as p,
             sga_alumnos as a,
             sga_insc_cursada as i
       WHERE f.habilitacion = pHabilitacion
         AND p.formulario = f.formulario
         AND a.persona = p.persona
         AND i.comision = f.comision
         AND i.alumno   = a.alumno;

   -- Comisiones que estan alcanzadas por la habilitacion
   INSERT INTO temp_com_orig (comision) 
    SELECT DISTINCT comision  FROM gde_formularios WHERE habilitacion = pHabilitacion AND comision IS NOT NULL;
   UPDATE temp_com_orig
       SET tiene_subcomisiones = (SELECT count(*) FROM sga_subcomisiones WHERE comision = temp_com_orig.comision);

    -- Inserto todas las comisiones del año académico y periodo lectivo (si fue definido)
    IF hab.alcance = 1 THEN
       -- comisiones
       INSERT INTO temp_com (comision)
          SELECT comision 
            FROM sga_comisiones,
                 sga_periodos_lectivos as pl,
                 sga_periodos as p
           WHERE pl.periodo_lectivo = sga_comisiones.periodo_lectivo
             AND p.periodo = pl.periodo
             AND p.anio_academico = hab.anio_academico
             AND (hab.periodo_lectivo IS NULL OR pl.periodo_lectivo = hab.periodo_lectivo);
    END IF;
    
    -- Inserto todas las comisiones de actividades de las responsables academicas
    IF hab.alcance = 2 THEN
       INSERT INTO temp_com (comision)
          SELECT comision
            FROM sga_comisiones,
                 sga_periodos_lectivos as pl,
                 sga_periodos as p
           WHERE pl.periodo_lectivo = sga_comisiones.periodo_lectivo
             AND p.periodo = pl.periodo
             AND p.anio_academico = hab.anio_academico
             AND (hab.periodo_lectivo IS NULL OR pl.periodo_lectivo = hab.periodo_lectivo)
             AND elemento IN (SELECT e.elemento
                                FROM gde_responsables_academicas as ra,
                                     sga_elementos_ra as e
                               WHERE ra.habilitacion = pHabilitacion 
                                 AND e.responsable_academica = ra.responsable_academica) ;
    END IF;
  
    -- Inserto todas las comisiones de actividades de las propuestas-planes de los tipos de propuestas
    IF hab.alcance = 3 THEN
       INSERT INTO temp_com (comision)
          SELECT comision
            FROM sga_comisiones,
                 sga_periodos_lectivos as pl,
                 sga_periodos as p
           WHERE pl.periodo_lectivo = sga_comisiones.periodo_lectivo
             AND p.periodo = pl.periodo
             AND p.anio_academico = hab.anio_academico
             AND (hab.periodo_lectivo IS NULL OR pl.periodo_lectivo = hab.periodo_lectivo)
             AND elemento IN (SELECT v.elemento
                                FROM gde_propuestas_tipos as t,
                                     sga_propuestas as p,
                                     vw_actividades_plan as v
                               WHERE t.habilitacion = pHabilitacion 
                                 AND p.propuesta_tipo = p.propuesta_tipo
                                 AND v.propuesta = p.propuesta);
    END IF;
  
    -- Inserto todas las comisiones de actividades de las propuestas seleccionadas
    IF hab.alcance = 4 THEN
       INSERT INTO temp_com (comision)
          SELECT DISTINCT comision
            FROM sga_comisiones,
                 sga_periodos_lectivos as pl,
                 sga_periodos as p
           WHERE pl.periodo_lectivo = sga_comisiones.periodo_lectivo
             AND p.periodo = pl.periodo
             AND p.anio_academico = hab.anio_academico
             AND ( hab.periodo_lectivo IS NULL OR pl.periodo_lectivo = hab.periodo_lectivo)
             AND elemento IN (SELECT v.elemento
                                FROM gde_propuestas as p,
                                     vw_actividades_plan as v
                               WHERE p.habilitacion = pHabilitacion 
                                 AND v.propuesta = p.propuesta);
    END IF;

    -- Actividades
    IF hab.alcance = 5 THEN
       -- Inserto todas las comisiones de las actividades seleccionadas
       INSERT INTO temp_com (comision)
          SELECT comision
            FROM sga_comisiones,
                 gde_actividades
           WHERE sga_comisiones.periodo_lectivo = hab.periodo_lectivo
             AND gde_actividades.habilitacion = hab.habilitacion
             AND gde_actividades.elemento = sga_comisiones.elemento;
    END IF;

    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- COMISIONES
    -- Recupero solo comisiones de las ubicaciones y modalidad de cursada seleccionadas.
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    INSERT INTO temp_com2 (comision)
      SELECT DISTINCT c.comision
        FROM temp_com as t,
             sga_comisiones as c,
             sga_comisiones_modalidad as cm,
             gde_modalidades as gm,
             gde_ubicaciones as gu
        WHERE c.comision  = t.comision
          AND cm.comision = c.comision
          AND gm.habilitacion = hab.habilitacion
          AND gu.ubicacion    = c.ubicacion
          AND gu.habilitacion = hab.habilitacion
          AND gm.modalidad    = cm.modalidad;


    -- Paso las comisiones a la tabla temp_com.
    DELETE FROM temp_com;
    INSERT INTO temp_com (comision) SELECT comision FROM temp_com2;

    -- Actualizo el campo de si tiene o no subcomisiones la comision
    UPDATE temp_com
       SET tiene_subcomisiones = (SELECT count(*) FROM sga_subcomisiones WHERE comision = temp_com.comision);

   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- ALUMNOS
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   IF hab.inscriptos_comision = 'T' THEN
      -- Todos los alumnos inscriptos en las comisiones seleccionadas (no importa el resultado en la cursada)
      -- Inscripciones Aceptadas
      INSERT INTO temp_alumnos_com (comision, alumno, persona)
             SELECT t.comision , i.alumno, a.persona
               FROM temp_com as t,
                    sga_insc_cursada as i,
                    sga_alumnos as a
              WHERE i.comision = t.comision
                AND a.alumno = i.alumno
                AND i.estado = 'A';
   ELSE
     -- Algunos alumnos de la comision
     IF hab.cursada_aprobada = 'S' OR hab.cursada_desaprobada = 'S' THEN
        -- Para los que desaprobaron el resultado puede ser R-Desaprobado o U-Ausente/libre
        INSERT INTO temp_alumnos_com (comision, alumno, persona)
             SELECT t.comision , sga_alumnos.alumno, sga_alumnos.persona
               FROM temp_com as t,
                    sga_actas,
                    sga_actas_detalle,
                    sga_alumnos
              WHERE sga_actas.comision = t.comision
                AND sga_actas.origen = 'R' -- Acta de Regulares
                AND sga_actas.estado = 'C' -- Cerrada
                AND sga_actas_detalle.id_acta = sga_actas.id_acta
                AND sga_alumnos.alumno = sga_actas_detalle.alumno
                AND sga_actas_detalle.rectificado = 'N' -- No rectificado
                AND sga_actas_detalle.estado = 'A' -- Activo
                AND ((sga_actas_detalle.resultado = 'A' AND hab.cursada_aprobada = 'S') OR
                     (sga_actas_detalle.resultado <> 'A' AND hab.cursada_desaprobada = 'S') 
                    );

          -- Incluyo alumnos que no promocionaron de comisiones que solo tienen instancia de promocion          
          IF hab.cursada_desaprobada = 'S' THEN
             INSERT INTO temp_alumnos_com (comision, alumno, persona)
                  SELECT sga_actas.comision , sga_alumnos.alumno, sga_alumnos.persona
                    FROM temp_com as t,
                         sga_actas,
                         sga_actas_detalle,
                         sga_alumnos
                   WHERE sga_actas.comision = t.comision
                     AND NOT EXISTS (SELECT 1 FROM sga_actas_instancias as ai WHERE ai.id_acta = sga_actas.id_acta AND ai.instancia = 1)
                     AND sga_actas.origen = 'P' -- Acta de Promocion
                     AND sga_actas.estado = 'C' -- Cerrada
                     AND sga_actas_detalle.id_acta = sga_actas.id_acta
                     AND sga_alumnos.alumno = sga_actas_detalle.alumno
                     AND sga_actas_detalle.rectificado = 'N' -- No rectificado
                     AND sga_actas_detalle.estado      = 'A' -- Activo
                     AND sga_actas_detalle.resultado   <> 'A'; -- No Promocionados
          
          END IF;  -- comisiones solo con instancia promocion para alumnos que no regularizaron la materia.       
                    
     END IF;  -- Cursada aprobada o desaprobada
    
     -- Alumnos de la comision que promocionaron la cursada.
     IF hab.cursada_promocionada = 'S' THEN
        INSERT INTO temp_alumnos_com (comision, alumno, persona)
             SELECT t.comision , sga_alumnos.alumno, sga_alumnos.persona
               FROM temp_com as t,
                    sga_actas,
                    sga_actas_detalle,
                    sga_alumnos
              WHERE sga_actas.comision = t.comision
                AND sga_actas.origen = 'P' -- Acta de Promocion
                AND sga_actas.estado = 'C' -- Cerrada
                AND sga_actas_detalle.id_acta = sga_actas.id_acta
                AND sga_alumnos.alumno = sga_actas_detalle.alumno
                AND sga_actas_detalle.rectificado = 'N' -- No rectificado
                AND sga_actas_detalle.estado = 'A' -- Activo
                AND sga_actas_detalle.resultado = 'A';
     END IF;  -- Cursada promocionada
   END IF; -- Alumnos inscriptos con algun resultado en la cursada.

  
   -- Actualizo el listado de subcomisiones en las que esta inscripto el alumno en cada comision.
   -- Solo para las comisiones que tienen subcomisiones
   UPDATE temp_alumnos_com 
      SET subcomisiones = f_encuestas_subcom_alumnos(temp_alumnos_com.alumno, temp_alumnos_com.comision)
    FROM temp_com
   WHERE temp_com.comision = temp_alumnos_com.comision
     AND temp_com.tiene_subcomisiones > 0;

 
   -- ++++++++++++++++++++++++ Fin Alumnos +++++++++++++++++++++++++++++++++++++++++++

   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- ITEMS
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Si es evaluación es académica, genero un item por cada actividad
   IF hab.tipo = 2 OR hab.tipo = 3 THEN  
        -- Genero los Items para cada actividad
        INSERT INTO temp_items (titulo, encuesta, anio_academico, periodo_lectivo, comision, elemento, estado)
           SELECT 
                 sga_elementos.nombre,
                 gde_grupos.encuesta,
                 hab.anio_academico,
                 hab.periodo_lectivo,
                 temp_com.comision,
                 sga_comisiones.elemento,
                 'A'
            FROM gde_grupos,
                 gde_encuestas,
                 temp_com,
                 sga_comisiones,
                 sga_elementos
           WHERE gde_grupos.habilitacion = pHabilitacion
             AND gde_grupos.encuesta     = gde_encuestas.encuesta
             AND gde_encuestas.subtipo   = 'A' -- Actuación académica
             AND sga_comisiones.comision = temp_com.comision
             AND sga_elementos.elemento  = sga_comisiones.elemento;
   END IF;

   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Si es EVALUACION DOCENTE entonces recupero los docentes de las comisiones resultantes del alcance
   -- Solo recupero los docentes segun las resposabilidades seleccionadas.
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   IF hab.tipo = 1 OR hab.tipo = 3 THEN  
   
     -- Selecciono los docentes sobre los que se responderan encuestas
     IF hab.docentes = 'R' THEN 
       -- Docentes segun responsabilidades
       INSERT INTO temp_doc (comision, docente, responsabilidad)
          SELECT t.comision , d.docente, d.responsabilidad
            FROM temp_com as t,
                 sga_docentes_comision as d,
                 gde_docentes_resp as r
           WHERE d.comision = t.comision
             AND r.habilitacion = hab.habilitacion 
             AND d.responsabilidad = r.responsabilidad
             AND t.tiene_subcomisiones = 0;  

       -- Docentes segun responsabilidades x subcomision
       INSERT INTO temp_doc (comision, subcomision, docente, responsabilidad)
          SELECT t.comision, ds.subcomision, d.docente, d.responsabilidad
            FROM temp_com as t,
                 sga_subcomisiones as s,
                 sga_docentes_comision as d,
                 sga_docentes_subcomision as ds,
                 gde_docentes_resp as r
           WHERE d.comision = t.comision
             AND s.comision = t.comision
             AND ds.subcomision = s.subcomision
             AND ds.docente = d.docente
             AND r.habilitacion = hab.habilitacion 
             AND d.responsabilidad = r.responsabilidad
             AND t.tiene_subcomisiones = 1;  
     ELSE
       -- Todos los docentes de las comisiones
       INSERT INTO temp_doc (comision, docente, responsabilidad)
          SELECT t.comision , d.docente, d.responsabilidad
            FROM temp_com as t,
                 sga_docentes_comision as d
           WHERE d.comision = t.comision
             AND t.tiene_subcomisiones = 0;  

       -- Todos los docentes de las comisiones x subcomision
       INSERT INTO temp_doc (comision, subcomision, docente, responsabilidad)
          SELECT t.comision, ds.subcomision, d.docente, d.responsabilidad
            FROM temp_com as t,
                 sga_subcomisiones as s, 
                 sga_docentes_comision as d,
                 sga_docentes_subcomision as ds
           WHERE d.comision = t.comision
             AND s.comision = t.comision 
             AND ds.subcomision = s.subcomision
             AND ds.docente = d.docente;  

     END IF; -- Docentes de las Comisiones             

     -- Genero los Items de los docentes de cada comision/subcomision
     INSERT INTO temp_items (titulo, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision, docente, estado)
        SELECT 
              CASE 
                WHEN temp_doc.subcomision IS NULL THEN  mdp_personas.apellido || ' ' || mdp_personas.nombres || ' (' || r.nombre || ')'
                -- WHEN temp_doc.subcomision IS NULL THEN  'DOCENTE: ' || mdp_personas.apellido || ' ' || mdp_personas.nombres || ' (' || r.nombre || ')'
                WHEN temp_doc.subcomision IS NOT NULL THEN  sc.nombre || ' - ' || mdp_personas.apellido || ' ' || mdp_personas.nombres || ' (' || r.nombre || ')'
                -- WHEN temp_doc.subcomision IS NOT NULL THEN  tc.nombre  || ' - ' || mdp_personas.apellido || ' ' || mdp_personas.nombres || ' (' || r.nombre || ')'
              END,
              gde_grupos.encuesta,
              hab.anio_academico,
              sga_comisiones.periodo_lectivo,
              temp_doc.comision,
              sga_comisiones.elemento,
              temp_doc.subcomision,
              temp_doc.docente,
              'A'
         FROM gde_grupos,
              gde_encuestas,
              temp_doc
                LEFT JOIN sga_subcomisiones as sc ON sc.comision = temp_doc.comision AND sc.subcomision = temp_doc.subcomision,
              --  LEFT JOIN sga_clases_tipos as tc ON tc.tipo_clase = sc.tipo_clase,
              sga_comisiones,
              sga_docentes_responsabilidades as r,
              sga_docentes,
              mdp_personas
         WHERE gde_grupos.habilitacion = pHabilitacion
           AND gde_grupos.encuesta     = gde_encuestas.encuesta
           AND gde_encuestas.subtipo   = 'D' -- Actuación docente
           AND sga_comisiones.comision = temp_doc.comision
           AND r.responsabilidad    = temp_doc.responsabilidad
           AND sga_docentes.docente = temp_doc.docente
           AND mdp_personas.persona = sga_docentes.persona;

  END IF; -- Tipo 1 o 3. Docentes de las comisiones 

  -- Inserto Nuevos Items.
  INSERT INTO gde_items (titulo, habilitacion, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision, docente, estado)
       SELECT titulo, pHabilitacion, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision, docente, 'A'
         FROM temp_items
       EXCEPT
       SELECT titulo, pHabilitacion, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision, docente, 'A'
         FROM temp_items_orig;

  
  -- Por cada comision nueva, genero el formulario y sus items asociados
  FOR cur_com IN 
         SELECT comision FROM temp_com 
         EXCEPT
         SELECT DISTINCT comision FROM temp_items_orig
  LOOP
     -- Verifico si la comision tiene subcomisiones.
     SELECT tiene_subcomisiones INTO _tiene_subcomisiones
         FROM temp_com WHERE comision = cur_com.comision;

    -- Asigno al formulario el nombre de la actividad.  
    SELECT sga_elementos.nombre, sga_elementos.codigo, sga_comisiones.nombre 
      INTO _nombre_actividad, _codigo_actividad, _nombre_comision
      FROM sga_comisiones, sga_elementos
     WHERE sga_comisiones.comision = cur_com.comision
       AND sga_elementos.elemento = sga_comisiones.elemento;

     IF _tiene_subcomisiones = 0 THEN
          
       -- Solo inserto el formulario si el mismo tiene al menos un item
       SELECT COUNT(*) INTO _cant_items
           FROM gde_items
          WHERE gde_items.habilitacion = pHabilitacion
            AND gde_items.comision     = cur_com.comision;
      
       IF _cant_items > 0 THEN      
          
          -- Inserto el formulario para la nueva comision
		  _titulo_formulario := _nombre_actividad || ' (' || _codigo_actividad || ') - Comisión: ' || _nombre_comision;
          INSERT INTO gde_formularios (titulo, habilitacion, comision, estado) VALUES (_titulo_formulario, pHabilitacion, cur_com.comision, 'A');
          _formulario := (SELECT currval('gde_formularios_seq'));
          
          -- inserto los items de la comision
          INSERT INTO gde_formulario_items (formulario, item) 
            SELECT _formulario, gde_items.item
              FROM gde_items
             WHERE gde_items.habilitacion = pHabilitacion
               AND gde_items.comision     = cur_com.comision;
          
          
	      -- Personas que deben responder la encuesta por cada comision y TODOS los docentes
	      INSERT INTO gde_encuestas_pendientes (persona, formulario)
	           SELECT DISTINCT temp_alumnos_com.persona, _formulario
	             FROM temp_alumnos_com
	            WHERE comision = cur_com.comision;
               
	   END IF; -- _cant_items > 0         
     END IF; -- Comision sin subcomisiones
     
     
     --  La Comision tiene subcomisiones.
     --  Se generan un formulario para la comision por cada combinacion de subcomisiones por diferente tipo de clase exista  en las inscripciones de los alumnos
     
     IF _tiene_subcomisiones > 0 THEN
     
        -- Genero tantos formularios como combinaciones de subcomisiones por tipo de clase hay en cada comision
        FOR cur_subcom IN SELECT pComision, pCombinaciones
                            FROM f_encuestas_subcomisiones(NULL, cur_com.comision)
        LOOP
        
           -- Solo inserto el formulario si el mismo tiene al menos un item
           SELECT COUNT(*) INTO _cant_items
               FROM gde_items
              WHERE gde_items.habilitacion = pHabilitacion
                AND gde_items.comision     = cur_com.comision
                AND (gde_items.subcomision = ANY (cur_subcom.pCombinaciones) OR   -- Items de los docentes por subcomision (docente)
                     (gde_items.subcomision IS NULL AND gde_items.docente IS NULL)     -- Item de la comision (academica) 
                    );
           
           IF _cant_items > 0 THEN      
       
              -- Inserto el formulario para la nueva comision
		      _titulo_formulario := _nombre_actividad || ' (' || _codigo_actividad || ') - Comisión: ' || _nombre_comision;
              INSERT INTO gde_formularios (titulo, habilitacion, comision, subcomisiones, estado) 
                   VALUES (_titulo_formulario, pHabilitacion, cur_com.comision, cur_subcom.pCombinaciones, 'A');
              _formulario := (SELECT currval('gde_formularios_seq'));
              
              -- inserto los items de la comision y subcomisiones involucradas
              INSERT INTO gde_formulario_items (formulario, item) 
                   SELECT _formulario, gde_items.item
                     FROM gde_items
                    WHERE gde_items.habilitacion = pHabilitacion
                      AND gde_items.comision     = cur_com.comision
                      AND (gde_items.subcomision = ANY (cur_subcom.pCombinaciones) OR   -- Items de los docentes por subcomision (docente)
                           (gde_items.subcomision IS NULL AND gde_items.docente IS NULL)     -- Item de la comision (academica) 
                          );
              
              -- Alumnos que esten inscriptos a esas mismas subcomisiones
              INSERT INTO gde_encuestas_pendientes (persona, formulario)
                   SELECT DISTINCT temp_alumnos_com.persona, _formulario
                     FROM temp_alumnos_com
                    WHERE comision = cur_com.comision
                      AND temp_alumnos_com.subcomisiones = cur_subcom.pCombinaciones;
                      
                      
          END IF; -- _cant_items > 0
        END LOOP; 

     END IF; -- Comision con subcomisiones


  END LOOP; -- Comisiones Nuevas - Formularios
  -- ++++++++++++++++++++++++++++++++++++++++ Fin nuevas comisiones de la habilitacion +++++++++++++++++++++++++++++

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Agrego Items NUEVOS de comisiones existentes
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  FOR cur_com IN 
         SELECT comision
           FROM temp_com 
         INTERSECT
         SELECT DISTINCT comision FROM temp_items_orig
  LOOP

     -- Verifico si la comision tiene subcomisiones.
     SELECT tiene_subcomisiones INTO _tiene_subcomisiones FROM temp_com WHERE comision = cur_com.comision;

     -- Comision sin subcomisiones
     IF _tiene_subcomisiones = 0 THEN
       -- Recupero el formulario asociado a la comision
       SELECT formulario INTO _formulario
         FROM gde_formularios
         WHERE habilitacion = pHabilitacion
           AND comision = cur_com.comision;
         
       -- inserto los items de la comision faltantes en el formulario
       INSERT INTO gde_formulario_items (formulario, item) 
            SELECT _formulario, gde_items.item
              FROM gde_items
             WHERE habilitacion = pHabilitacion
               AND comision = cur_com.comision
               AND item NOT IN (SELECT item FROM gde_formulario_items WHERE formulario = _formulario);
     END IF;

     -- Comision con subcomisiones
     IF _tiene_subcomisiones > 0 THEN
        -- FALTA: Los item son docentes de una subcomision existente?
        --        Los item son docentes de una nueva subcomision
     END IF;

  END LOOP; -- comisiones


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Items que dejan de tener efecto. 
  -- Marco como dados de baja los items que dejan de tener efecto
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO temp_items_baja (titulo, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision,docente)
     SELECT titulo, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision, docente
       FROM temp_items_orig
     EXCEPT
     SELECT titulo, encuesta, anio_academico, periodo_lectivo, comision, elemento, subcomision, docente
       FROM temp_items;
       
  UPDATE gde_items
     SET estado = 'B'
   WHERE habilitacion = pHabilitacion
     AND estado = 'A'
     AND item IN (SELECT i.item 
                    FROM gde_items as i, 
                         temp_items_baja as b
                   WHERE i.habilitacion = pHabilitacion
                     AND b.encuesta = i.encuesta
                     AND (b.anio_academico = i.anio_academico OR (b.anio_academico IS NULL AND i.anio_academico IS NULL))
                     AND (b.periodo_lectivo = i.periodo_lectivo OR (b.periodo_lectivo IS NULL AND i.periodo_lectivo IS NULL))
                     AND (b.comision = i.comision OR (b.comision IS NULL AND i.comision IS NULL))
                     AND (b.elemento = i.elemento OR (b.elemento IS NULL AND i.elemento IS NULL))
                     AND (b.subcomision = i.subcomision OR (b.subcomision IS NULL AND i.subcomision IS NULL))
                     AND (b.docente  = i.docente OR (b.docente IS NULL AND i.docente IS NULL))
                 );

  -- FORMULARIOS... Doy de baja formularios que ya no tienen items activos
  UPDATE gde_formularios
     SET estado = 'B'
   WHERE habilitacion = pHabilitacion
     AND estado = 'A'
     AND NOT EXISTS (SELECT 1 
                       FROM gde_formulario_items as fi, 
                            gde_items as i
                      WHERE fi.formulario = gde_formularios.formulario
                        AND i.item = fi.item
                        AND i.estado = 'A'
                     );

  -- FALTA ACTUALIZAR el array gde_formularios.subcomisiones si es que hay items de subcomisiones que ya no estan mas.


  -- Borro encuestas que ya no deben contestarse por los alumnos por haberse dado de baja el formulario
  DELETE FROM gde_encuestas_pendientes
    WHERE fecha_respuesta IS NULL
      AND formulario IN (SELECT gde_formularios.formulario
                           FROM gde_formularios
                          WHERE gde_formularios.habilitacion = pHabilitacion
                            AND gde_formularios.estado = 'B');


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Items y formularios que estaban dados de baja y que vuelven a activarse
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  UPDATE gde_items
     SET estado = 'A'
   WHERE habilitacion = pHabilitacion
     AND estado = 'B'
     AND item IN (SELECT i.item 
                    FROM gde_items as i, 
                         temp_items as n
                   WHERE i.habilitacion = pHabilitacion
                     AND n.encuesta = i.encuesta
                     AND (n.anio_academico  = i.anio_academico  OR (n.anio_academico IS NULL AND i.anio_academico IS NULL))
                     AND (n.periodo_lectivo = i.periodo_lectivo OR (n.periodo_lectivo IS NULL AND i.periodo_lectivo IS NULL))
                     AND (n.comision = i.comision OR (n.comision IS NULL AND i.comision IS NULL))
                     AND (n.elemento = i.elemento OR (n.elemento IS NULL AND i.elemento IS NULL))
                     AND (n.subcomision = i.subcomision OR (n.subcomision IS NULL AND i.subcomision IS NULL))
                     AND (n.docente  = i.docente  OR (n.docente IS NULL AND i.docente IS NULL))
                 );
  -- Activo formularios que estaban dados de baja y ahora tienen algun item activo.
  UPDATE gde_formularios
     SET estado = 'A'
   WHERE habilitacion = pHabilitacion
     AND estado = 'B'
     AND EXISTS (SELECT 1 
                       FROM gde_formulario_items as fi, 
                            gde_items as i
                      WHERE fi.formulario = gde_formularios.formulario
                        AND i.item = fi.item
                        AND i.estado = 'A');

   -- Personas que debo agregar porque se activaron formularios que estaban dados de baja y tambien de personas nuevas de formularios originales.
   -- FALTA!!!



  -- ********************************************************************
  -- NUEVOS ALUMNOS de comisiones existentes
  -- ********************************************************************
  -- Recupero alumnos nuevos de las comisiones originales
  INSERT INTO temp_alumnos_com_new (alumno, persona, comision, subcomisiones)
       SELECT a.alumno, a.persona, a.comision, a.subcomisiones
         FROM temp_alumnos_com as a, 
              temp_com_orig as c
        WHERE a.comision = c.comision 
       EXCEPT
       SELECT a.alumno, a.persona, a.comision, a.subcomisiones
         FROM temp_alumnos_com_orig as a, 
              temp_com_orig as c
        WHERE a.comision = c.comision; 

  -- Recorro las comisiones originales
  FOR cur_com IN SELECT comision, tiene_subcomisiones FROM temp_com_orig

  LOOP
     IF cur_com.tiene_subcomisiones = 0 THEN
        -- Sin subcomisiones
        SELECT formulario INTO _formulario FROM gde_formularios WHERE comision = cur_com.comision;

        INSERT INTO gde_encuestas_pendientes (persona, formulario)
             SELECT DISTINCT persona, _formulario
               FROM temp_alumnos_com_new
              WHERE comision = cur_com.comision
             EXCEPT   
             SELECT persona, formulario 
               FROM temp_pend_orig;

 
     ELSE
       -- Con subcomisiones. Debo buscar en que formulario de la comision segun la combinacion de subcomisiones lo asigno al alumno
       
       -- Asigno el nombre de la actividad al formulario  
       SELECT sga_elementos.nombre, sga_elementos.codigo, sga_comisiones.nombre 
	     INTO _nombre_actividad, _codigo_actividad, _nombre_comision
         FROM sga_comisiones, sga_elementos
        WHERE sga_comisiones.comision = cur_com.comision
          AND sga_elementos.elemento = sga_comisiones.elemento;

       -- 1ro veo si debo generar nuevos formularios para la comision por la combinación de subcomisiones de los nuevos alumnos.
       FOR cur_alu IN 
                   SELECT DISTINCT subcomisiones FROM temp_alumnos_com_new WHERE comision = cur_com.comision AND subcomisiones IS NOT NULL
                   EXCEPT 
                   SELECT DISTINCT subcomisiones FROM gde_formularios WHERE comision = cur_com.comision AND subcomisiones IS NOT NULL
       LOOP

       
         -- Solo inserto el formulario si el mismo tiene al menos un item
         SELECT COUNT(*) INTO _cant_items
           FROM gde_items
          WHERE gde_items.habilitacion = pHabilitacion
            AND gde_items.comision     = cur_com.comision
            AND (gde_items.subcomision = ANY (cur_alu.subcomisiones) OR   -- Items de los docentes por subcomision (docente)
                 (gde_items.subcomision IS NULL AND gde_items.docente IS NULL) -- Item de la comision (academica) 
                );
       
          IF _cant_items > 0 THEN               
             -- Inserto el formulario para la nueva comision y combinacion de subcomisiones
		     _titulo_formulario := _nombre_actividad || ' (' || _codigo_actividad || ') - Comisión: ' || _nombre_comision;
             INSERT INTO gde_formularios (titulo, habilitacion, comision, subcomisiones, estado) 
                  VALUES (_titulo_formulario, pHabilitacion, cur_com.comision, cur_alu.subcomisiones, 'A');
             _formulario := (SELECT currval('gde_formularios_seq'));
             
             
             -- inserto los items de la comision y subcomisiones involucradas
             INSERT INTO gde_formulario_items (formulario, item) 
                  SELECT _formulario, gde_items.item
                    FROM gde_items
                   WHERE gde_items.habilitacion = pHabilitacion
                     AND gde_items.comision     = cur_com.comision
                     AND (gde_items.subcomision = ANY (cur_alu.subcomisiones) OR   -- Items de los docentes por subcomision (docente)
                          (gde_items.subcomision IS NULL AND gde_items.docente IS NULL) -- Item de la comision (academica) 
                         );
          END IF; -- _cant_items > 0            
       END LOOP; -- Nuevos formularios de comisiones originales (x subcomisiones).            
       
       -- 2do Agrego nuevos alumnos
       INSERT INTO gde_encuestas_pendientes (persona, formulario)
         SELECT DISTINCT a.persona, f.formulario
           FROM temp_alumnos_com_new as a,
                gde_formularios as f
          WHERE a.comision = cur_com.comision
            AND f.comision = cur_com.comision
            AND a.subcomisiones = f.subcomisiones
         EXCEPT   
         SELECT persona, formulario 
           FROM temp_pend_orig;


     END IF; -- con/sin subcomisiones


  END LOOP;  
  -- +++++++++++++++++ Fin Nuevos alumnos de comisiones originales ++++++++++++++++++++



   -- Borro tablas temporales
   DROP TABLE temp_com;
   DROP TABLE temp_com2;
   DROP TABLE temp_com_orig;
   DROP TABLE temp_doc;
   DROP TABLE temp_alumnos_com;
   DROP TABLE temp_alumnos_com_orig;
   DROP TABLE temp_alumnos_com_new;

 END IF;  -- Tipo 1, 2 o 3


 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- 4 - Encuesta General (un solo formulario de encuesta o 1 por propuesta si se selecciono esta opcion)
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 IF hab.tipo = 4 THEN

  CREATE TEMP TABLE temp_alumnos (alumno Integer Not Null, persona Integer Not Null); 
  CREATE TEMP TABLE temp_generica (persona Integer Not Null, alumno Integer);  -- El "alumno" solo se usa en caso de encuestas x propuesta.
  CREATE TEMP TABLE temp_generica2 (alumno Integer Not Null, persona Integer Not Null); 
  CREATE TEMP TABLE temp_propuestas (propuesta Integer Not Null); 
  
  
  
  -- Inserto todos los alumnos activos de la Institucion
  IF hab.alcance = 1 THEN
     INSERT INTO temp_generica2 (alumno, persona)
        SELECT alumno, persona
          FROM sga_alumnos
         WHERE calidad = 'A';
  END IF;
  
  -- Inserto todas los alumnos de las propuestas de las responsables academicas
  IF hab.alcance = 2 THEN
     INSERT INTO temp_generica2 (alumno, persona)
        SELECT alumno, persona
          FROM sga_alumnos
         WHERE calidad = 'A'
           AND propuesta IN (SELECT p.propuesta
                              FROM gde_responsables_academicas as ra,
                                   sga_propuestas_ra as p
                             WHERE ra.habilitacion = pHabilitacion 
                               AND ra.responsable_academica = p.responsable_academica) ;
							   
     IF hab.encuesta_por_propuesta = 'S' THEN 							   
	    INSERT INTO temp_propuestas (propuesta)
		   SELECT p.propuesta 
		     FROM gde_responsables_academicas as ra
                  JOIN sga_propuestas_ra as p ON ra.responsable_academica = p.responsable_academica
            WHERE ra.habilitacion = pHabilitacion; 
	 END IF;
  END IF;

  -- Inserto los alumnos de las propuestas de los tipos de propuestas seleccionado
  IF hab.alcance = 3 THEN
     INSERT INTO temp_generica2 (alumno, persona)
        SELECT alumno, persona
          FROM sga_alumnos
         WHERE calidad = 'A'
           AND propuesta IN (SELECT p.propuesta
                              FROM gde_propuestas_tipos as t,
                                   sga_propuestas as p
                             WHERE t.habilitacion = pHabilitacion 
                               AND p.propuesta_tipo = t.propuesta_tipo);
     IF hab.encuesta_por_propuesta = 'S' THEN 							   
	    INSERT INTO temp_propuestas (propuesta)
		   SELECT p.propuesta
             FROM gde_propuestas_tipos as t
                  JOIN sga_propuestas as p ON p.propuesta_tipo = t.propuesta_tipo
            WHERE t.habilitacion = pHabilitacion; 
	 END IF;
  END IF;

  -- Inserto todos los alumnos de las propuestas seleccionadas
  IF hab.alcance = 4 THEN
     INSERT INTO temp_generica2 (alumno, persona)
        SELECT a.alumno, a.persona
          FROM sga_alumnos as a,
               gde_propuestas as p
         WHERE p.habilitacion = pHabilitacion 
           AND a.propuesta = p.propuesta
           AND a.calidad = 'A'; 
     IF hab.encuesta_por_propuesta = 'S' THEN 							   
	    INSERT INTO temp_propuestas (propuesta)
             SELECT propuesta FROM gde_propuestas WHERE gde_propuestas.habilitacion = pHabilitacion; 
     END IF;
  END IF;

  -- De los alumno seleccionados, solo recupero aquellos de las ubicaciones y modalidad de cursada indicadas.
  INSERT INTO temp_alumnos (alumno, persona)
    SELECT DISTINCT a.alumno, a.persona
      FROM temp_generica2 as g2,
           sga_alumnos as a,
           gde_modalidades as gm,
           gde_ubicaciones as gu
     WHERE a.alumno = g2.alumno
       AND gm.habilitacion = hab.habilitacion
       AND gm.modalidad    = a.modalidad
       AND gu.habilitacion = hab.habilitacion
       AND gu.ubicacion    = a.ubicacion;

  
  -- Verifico el filtro de Alumnos
  IF hab.alumnos = 'T' THEN
      -- Todos los Alumnos
	 IF hab.encuesta_por_propuesta = 'N' THEN
	    -- Solo una encuesta por persona.
        INSERT INTO temp_generica (persona) 
		     SELECT DISTINCT persona  FROM temp_alumnos;
	 ELSEIF hab.encuesta_por_propuesta = 'S' THEN	
	    -- Registro la persona y alumno (propuesta)
        INSERT INTO temp_generica (persona, alumno) 
		     SELECT persona, alumno FROM temp_alumnos;
	 END IF; 	

 		
  ELSEIF hab.alumnos = 'A' THEN

     -- Algunos alumnos. 
     -- Inscriptos en los años académicos seleccionados.
     IF hab.alumnos_inscriptos = 'S' THEN
	   IF hab.encuesta_por_propuesta = 'N' THEN
	    INSERT INTO temp_generica (persona)
	       SELECT DISTINCT a.persona
		 FROM temp_alumnos as ta,
		      sga_alumnos as a,
		      sga_propuestas_aspira as pa,
		      sga_situacion_aspirante as sa
		WHERE a.alumno = ta.alumno
		  AND pa.propuesta = a.propuesta
		  AND pa.persona   = a.persona
		  AND pa.anio_academico IN (SELECT anio_academico FROM gde_anios_academicos WHERE habilitacion = pHabilitacion)
		  AND sa.situacion_asp = pa.situacion_asp
		  AND sa.resultado_asp <> 'R';

      ELSEIF hab.encuesta_por_propuesta = 'S' THEN	
	    INSERT INTO temp_generica (persona, alumno)
	       SELECT a.persona, a.alumno
		 FROM temp_alumnos as ta,
		      sga_alumnos as a,
		      sga_propuestas_aspira as pa,
		      sga_situacion_aspirante as sa
		WHERE a.alumno = ta.alumno
		  AND pa.propuesta = a.propuesta
		  AND pa.persona   = a.persona
		  AND pa.anio_academico IN (SELECT anio_academico FROM gde_anios_academicos WHERE habilitacion = pHabilitacion)
		  AND sa.situacion_asp = pa.situacion_asp
		  AND sa.resultado_asp <> 'R';
      END IF;		  
     END IF;   	
    
     -- Alumnos reinscriptos
     IF hab.alumnos_reinscriptos = 'S' THEN
      IF hab.encuesta_por_propuesta = 'N' THEN	
        INSERT INTO temp_generica (persona)
	       SELECT DISTINCT ta.persona
	         FROM temp_alumnos as ta,
		          sga_reinscripciones as r
	        WHERE r.alumno = ta.alumno
		      AND r.anio_academico IN (SELECT anio_academico FROM gde_anios_academicos WHERE habilitacion = pHabilitacion);
      ELSEIF hab.encuesta_por_propuesta = 'S' THEN	
        INSERT INTO temp_generica (persona, alumno)
	       SELECT ta.persona, ta.alumno
	         FROM temp_alumnos as ta,
		          sga_reinscripciones as r
	        WHERE r.alumno = ta.alumno
		      AND r.anio_academico IN (SELECT anio_academico FROM gde_anios_academicos WHERE habilitacion = pHabilitacion);
      END IF;
     END IF;          

  ELSEIF hab.alumnos = 'E' THEN
    -- Alumnos que se encuentran cursando la tesis y estan en los estados del circuito de tesis indicado.
    IF hab.encuesta_por_propuesta = 'N' THEN	
      INSERT INTO temp_generica (persona)
           SELECT DISTINCT temp_alumnos.persona
             FROM temp_alumnos,
                  sga_tesis_alumnos as ta,
                  sga_tesis as t
            WHERE ta.alumno = temp_alumnos.alumno
              AND t.tesis   = ta.tesis
              AND t.estado_actual IN (SELECT estado FROM gde_tesis_estados WHERE habilitacion = pHabilitacion);
    ELSEIF hab.encuesta_por_propuesta = 'S' THEN	
      INSERT INTO temp_generica (persona, alumno)
           SELECT a.persona, a.alumno
             FROM temp_alumnos as a,
                  sga_tesis_alumnos as ta,
                  sga_tesis as t
            WHERE ta.alumno = a.alumno
              AND t.tesis   = ta.tesis
              AND t.estado_actual IN (SELECT estado FROM gde_tesis_estados WHERE habilitacion = pHabilitacion);
    END IF;
			  
  END IF;
  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- ALTA de ITEMS, FORMULARIOS y PERSONAS que deben responder la encuesta
  -- Se genera un formulario por cada item.
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF hab.encuesta_por_propuesta = 'N' THEN	
    -- Genero un solo item para la encuesta generica.
    INSERT INTO temp_items (encuesta, titulo)
         SELECT gde_encuestas.encuesta,
                gde_encuestas.nombre 
           FROM gde_grupos,
                gde_encuestas
          WHERE gde_grupos.habilitacion = pHabilitacion
            AND gde_encuestas.encuesta = gde_grupos.encuesta;
			
  ELSEIF hab.encuesta_por_propuesta = 'S' THEN	
    -- Genero un item por cada propuesta
    INSERT INTO temp_items (encuesta, titulo, propuesta)
         SELECT gde_encuestas.encuesta,
                -- gde_encuestas.nombre || ' - ' || 
				sga_propuestas.nombre,
				sga_propuestas.propuesta
           FROM gde_grupos,
                gde_encuestas,
				temp_propuestas,
				sga_propuestas
          WHERE gde_grupos.habilitacion = pHabilitacion
            AND gde_encuestas.encuesta = gde_grupos.encuesta
			AND temp_propuestas.propuesta = sga_propuestas.propuesta;
			
  END IF;  -- Generacion de Items..


  -- Recorro solo nuevos items y genero un formulario por cada item.
  FOR cur_item IN 
     SELECT gde_encuestas.encuesta as encuesta,
            -- gde_encuestas.nombre as nombre,
            temp_items.titulo as nombre,			
            temp_items.propuesta as propuesta			
       FROM temp_items,
            gde_encuestas
      WHERE gde_encuestas.encuesta = temp_items.encuesta
     EXCEPT  
     SELECT gde_encuestas.encuesta as encuesta,
            -- gde_encuestas.nombre as nombre,
            temp_items_orig.titulo as nombre,			
            temp_items_orig.propuesta as propuesta			
       FROM temp_items_orig,
            gde_encuestas
      WHERE gde_encuestas.encuesta = temp_items_orig.encuesta
      
  LOOP

    -- Inserto el Item
	_titulo_item := cur_item.nombre; -- El nombre del item es el nombre de la propuesta
    INSERT INTO gde_items (titulo, habilitacion, encuesta, propuesta, estado) VALUES (_titulo_item, hab.habilitacion, cur_item.encuesta, cur_item.propuesta, 'A');
    _item := (SELECT currval('gde_items_seq'));
    
    -- Inserto el formulario
	_titulo_formulario := _titulo_item;
    INSERT INTO gde_formularios (titulo, habilitacion, estado) VALUES (_titulo_formulario, hab.habilitacion, 'A');
    _formulario := (SELECT currval('gde_formularios_seq'));

    -- inserto en temporal los nuevos formularios.
    INSERT INTO temp_form (formulario, titulo, habilitacion, estado) VALUES (_formulario, cur_item.nombre, hab.habilitacion, 'A');
    
    -- Items x Formulario
    INSERT INTO gde_formulario_items (formulario, item) VALUES (_formulario, _item);

    -- Personas que deben responder la encuesta
	IF hab.encuesta_por_propuesta = 'N' THEN 
       INSERT INTO gde_encuestas_pendientes (persona, formulario)
            SELECT DISTINCT persona, _formulario FROM temp_generica;
			
    ELSEIF hab.encuesta_por_propuesta = 'S' THEN 
	   -- Solo asigno el formulario de encuesta de la persona segun la propuesta del item
       INSERT INTO gde_encuestas_pendientes (persona, formulario)
            SELECT t.persona, _formulario 
			  FROM temp_generica as t 
			       JOIN sga_alumnos as a ON a.alumno = t.alumno AND a.propuesta = cur_item.propuesta;
    END IF;	

  END LOOP;

  -- De los formularios originales, veo que alumnos debo dar de baja y cuales debo agregar
  FOR cur_form IN 
     SELECT formulario FROM temp_form_orig
     EXCEPT  
     SELECT formulario FROM temp_form  -- Nuevos formularios de encuestas.
  LOOP
  
     -- Alta de encuestados
	IF hab.encuesta_por_propuesta = 'N' THEN 
       INSERT INTO gde_encuestas_pendientes (persona, formulario)
          SELECT DISTINCT persona, cur_form.formulario FROM temp_generica
          EXCEPT   
          SELECT persona, formulario FROM temp_pend_orig WHERE formulario = cur_form.formulario; -- encuestados originales que ya estaban.
		  
	ELSEIF hab.encuesta_por_propuesta = 'S' THEN 
      -- Una encuesta por formulario = propuesta.
      INSERT INTO gde_encuestas_pendientes (persona, formulario)
          SELECT t.persona, cur_form.formulario  -- alumnos de la propuesta relacionada con el item del formulario.
		    FROM temp_generica as t
			     JOIN sga_alumnos as a ON a.alumno = t.alumno
				 JOIN gde_formulario_items as fi ON fi.formulario = cur_form.formulario
				 JOIN gde_items as i ON i.item = fi.item AND i.propuesta = a.propuesta
          EXCEPT   
          SELECT persona, formulario FROM temp_pend_orig WHERE formulario = cur_form.formulario; -- Saco los alumnos que ya estan asociados al formulario.
	
	END IF; -- Fin Alta de encuestados faltantes
   
	
    -- BAJA de personas que ya no entran dentro del alcance definido en la encuesta y que no han respondido las encuestas.     
	IF hab.encuesta_por_propuesta = 'N' THEN 
	   -- Saco las personas que ya no entran dentro del alcance de la encuesta. 
       DELETE FROM gde_encuestas_pendientes
	     WHERE formulario = cur_form.formulario
	       AND persona NOT IN (SELECT persona FROM temp_generica)
	       AND fecha_respuesta IS NULL;
	
	ELSEIF hab.encuesta_por_propuesta = 'S' THEN 

	   -- Saco las personas que ya no entran dentro del alcance de la encuesta relacionada con la propuesta del item/formulario.
       DELETE FROM gde_encuestas_pendientes
	     WHERE formulario = cur_form.formulario
	       AND persona NOT IN (SELECT t.persona 
		                         FROM temp_generica as t
			                          JOIN sga_alumnos as a ON a.alumno = t.alumno
				                      JOIN gde_formulario_items as fi ON fi.formulario = cur_form.formulario
				                      JOIN gde_items as i ON i.item = fi.item AND i.propuesta = a.propuesta
							   )
	       AND fecha_respuesta IS NULL;
	END IF; -- Fin Baja de encuestados
		 
         
  END LOOP; -- Formularios originales (alta/baja de encuestados).
  
  
  -- Borro Tablas temporales.
  DROP TABLE temp_alumnos;
  DROP TABLE temp_generica;
  DROP TABLE temp_generica2;
  DROP TABLE temp_propuestas;

 END IF; -- 4 - Genérica  

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Si se generaron nuevos items, entonces marco como que hay que re-sincronizar con Kolla
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _cant_items_nuevos := 0;
  _cant_formularios_nuevos := 0;
  SELECT COUNT(*) INTO _cant_items_nuevos
    FROM gde_items
   WHERE habilitacion = pHabilitacion
     AND item NOT IN (SELECT item FROM temp_items_orig);

  SELECT COUNT(*) INTO _cant_formularios_nuevos
    FROM gde_formularios
   WHERE habilitacion = pHabilitacion
     AND formulario NOT IN (SELECT formulario FROM temp_form_orig);
     
  IF _cant_items_nuevos > 0 OR _cant_formularios_nuevos > 0 THEN
    UPDATE gde_habilitaciones 
       SET kolla_sincronizado = 'N' 
     WHERE habilitacion = pHabilitacion
       AND kolla_sincronizado = 'S';
  END IF;
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  -- Borro tablas temporales generales.
  DROP TABLE temp_pend_orig;
  DROP TABLE temp_items;
  DROP TABLE temp_items_orig;
  DROP TABLE temp_items_baja;
  DROP TABLE temp_form_orig;
  DROP TABLE temp_form;
  
 -- Error.
 -- EXCEPTION WHEN OTHERS THEN

END;
$$;
