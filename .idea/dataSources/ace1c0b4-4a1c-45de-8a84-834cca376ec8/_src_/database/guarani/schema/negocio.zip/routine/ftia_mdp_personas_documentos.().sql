create function negocio.ftia_mdp_personas_documentos() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;   
  _documento integer;
  _orden1 smallint;
  _orden2 smallint;
BEGIN
   -- Cambio el documento principal de la persona
   _documento := NULL;
   SELECT documento_principal INTO _documento
     FROM mdp_personas
     WHERE persona = NEW.persona;
   
   IF _documento IS NULL THEN
      -- Actualizo el documento principal de la persona.
      UPDATE mdp_personas 
         SET documento_principal = NEW.documento
       WHERE persona = NEW.persona;
   ELSE
     -- Ya existe otro documento de la persona, veo si este es de mayor prioridad que el anterior.    
     SELECT mdp_tipo_documento.orden_principal INTO _orden1
       FROM mdp_tipo_documento 
       WHERE mdp_tipo_documento.tipo_documento = NEW.tipo_documento;

     SELECT mdp_tipo_documento.orden_principal INTO _orden2
       FROM mdp_personas_documentos, 
            mdp_tipo_documento 
       WHERE mdp_personas_documentos.documento = _documento
         AND mdp_tipo_documento.tipo_documento = mdp_personas_documentos.tipo_documento;
       
     IF _orden1 < _orden2 THEN
      -- Actualizo el documento principal de la persona.
      UPDATE mdp_personas 
         SET documento_principal = NEW.documento
       WHERE persona = NEW.persona;
     END IF;  
   END IF;   
   

   RETURN NEW;
END;
$$;
