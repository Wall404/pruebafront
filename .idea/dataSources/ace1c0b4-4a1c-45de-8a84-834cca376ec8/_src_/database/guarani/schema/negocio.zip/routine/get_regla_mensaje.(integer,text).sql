create function negocio.get_regla_mensaje(pregla integer, pparametros text) returns text
LANGUAGE plpgsql
AS $fun$
DECLARE 
  _valores text[];
  _valor text;
  _param text[];
  _mensaje_compuesto text;
  _i smallint;
  _cant smallint;
  cur_parametros record;
  
BEGIN

-- Mensaje al usuario
SELECT mensaje_usuario 
  INTO _mensaje_compuesto 
  FROM sga_reglas 
  WHERE regla = pRegla;

_i := 0;
FOR cur_parametros IN SELECT parametro FROM sga_reglas_parametros WHERE regla = pRegla
LOOP
   _i := _i + 1;
   _param[_i] := cur_parametros.parametro; 
END LOOP;

IF _i = 0 THEN 
    -- Retorno el mensaje. No tiene parametros.
   RETURN _mensaje_compuesto;

ELSE
   _cant := _i;
   
   -- Paso a un array los valores del 2do parametro de la funcion
   SELECT regexp_split_to_array( pParametros, $$\|$$) INTO _valores;
   
   -- Reemplazo los valores de los parametros en el mensaje para el usuario. Busco los %i%
   FOR _i IN 1 .. _cant LOOP
     _valor := _valores[_i];
     
     IF array_upper(_param, 1) >= _i THEN
       IF _param[_i] = 'anio' THEN

         IF _valores[_i] = '1' THEN
             _valor := _valores[_i] || 'er';
          ELSEIF _valores[_i] = '2' THEN
             _valor := _valores[_i] || 'do';
          ELSEIF _valores[_i] = '3' THEN
             _valor := _valores[_i] || 'er';
          ELSEIF _valores[_i] = '4' THEN
             _valor := _valores[_i] || 'to';
          ELSEIF _valores[_i] = '5' THEN
             _valor := _valores[_i] || 'to';
          ELSEIF _valores[_i] = '6' THEN
             _valor := _valores[_i] || 'to';
          ELSEIF _valores[_i] = '7' THEN
             _valor := _valores[_i] || 'mo';
          ELSEIF _valores[_i] = '8' THEN
             _valor := _valores[_i] || 'vo';
          ELSEIF _valores[_i] = '9' THEN
             _valor := _valores[_i] || 'no';
          ELSEIF _valores[_i] = '10' THEN
             _valor := _valores[_i] || 'mo';
          END IF;   
       END IF;
     END IF;
    
     _mensaje_compuesto := regexp_replace(_mensaje_compuesto, '%' || _i::text || '%', _valor);
   END LOOP;
   
   -- Retorno el mensaje compuesto
   RETURN _mensaje_compuesto;
END IF;	
END
$fun$;
