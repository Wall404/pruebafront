create function negocio.f_nombre_entidad(_entidad integer) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE 
	_nombre_tabla text;
	_nombre_entidad text;
	rs RECORD;
  BEGIN
  	-- Obtengo nombre de la tabla del subtipo de la entidad
  	SELECT 	tabla 
	INTO 	_nombre_tabla
  	 FROM 	sga_g3entidades, 
		sga_g3entidades_subtipos 
  	 WHERE 	sga_g3entidades.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo 
  	 AND 	sga_g3entidades.entidad = _entidad;

	-- Obtengo el nombre de la entidad
	FOR rs IN
	 EXECUTE 'SELECT 	nombre 
		FROM 	' || _nombre_tabla || '
		WHERE 	entidad = ' || _entidad
	   LOOP
	     _nombre_entidad := rs.nombre;
	END LOOP;
  	
    -- Retorno el nombre de la entidad
    RETURN _nombre_entidad;
  END;
$$;
