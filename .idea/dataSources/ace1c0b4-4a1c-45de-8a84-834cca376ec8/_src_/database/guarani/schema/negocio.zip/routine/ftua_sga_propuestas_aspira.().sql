create function negocio.ftua_sga_propuestas_aspira() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _tipo integer;
  _tipo_cursos integer;
  _cant integer;
  _resultado_asp char(1);
  
BEGIN
   
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Si se rechaza la inscripcion a propuesta y el alumno no tiene mas inscripciones a
   -- propuestas en estado Aceptado o Pendiente, entonces se saca el acceso a autogestion como alumno.
   -- No se consideran las propuestas de tipo Curso, debido a que a estas propuesta se accede con el perfil de acceso "Curso".
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   IF OLD.situacion_asp <> NEW.situacion_asp THEN  
      _tipo_cursos := 208;  -- Propuestas de tipo "Cursos"
	  _resultado_asp := '';
	  _tipo := NULL;
	  _cant := 0;
	  
	  SELECT resultado_asp INTO _resultado_asp FROM sga_situacion_aspirante WHERE situacion_asp = NEW.situacion_asp;
	  SELECT propuesta_tipo INTO _tipo  FROM sga_propuestas WHERE propuesta = NEW.propuesta;

	  -- Si es un rechazo de la inscripcion a propuesta y la propuesta no es de tipo "Cursos"
	  IF _resultado_asp = 'R' AND _tipo <> _tipo_cursos THEN 
	  
         -- Verifico si existen otras inscripciones a propuestas en estado pendiente/aceptado
		 SELECT count(1) INTO _cant
		   FROM sga_propuestas_aspira
		        JOIN sga_situacion_aspirante ON sga_situacion_aspirante.situacion_asp = sga_propuestas_aspira.situacion_asp
				JOIN sga_propuestas ON sga_propuestas.propuesta = sga_propuestas_aspira.propuesta
		  WHERE sga_propuestas_aspira.persona = NEW.persona
		    AND sga_propuestas_aspira.propuesta <> NEW.propuesta
			AND sga_situacion_aspirante.resultado_asp IN ('A','P')
			AND sga_propuestas.propuesta_tipo <> _tipo_cursos;
			
        IF _cant = 0 THEN  
	        -- Borro el acceso a autogestion con perfil Alumno.
	        DELETE FROM mdp_personas_tipo_usuario  WHERE persona = NEW.persona AND tipo_usuario = 'Alumno';
        END IF;
      END IF;
		
   END IF;
   -- +++++++++++++++++++ Fin Cambio de estado de la inscripcion ++++++++++++++++++++++++++++++++++++   
   
   RETURN NEW;
END;
$$;
