create function negocio.sui_provincias(p_provincia integer, p_nombre character varying, p_pais integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE vPartidoIndet  Integer;

BEGIN

  -- Genera el número de partido indeterminado para la provincia
  vPartidoIndet := p_provincia * 1000 + 998;

  -- Inserta la provincia
  INSERT INTO mug_provincias (provincia, nombre, pais ) VALUES (p_provincia, p_nombre, p_pais);

  -- Cataloga el partido indeterminado, sin permitir actualizaciones
  -- ya que, si existía el partido, no podía ser el inteterminado de la provincia, porque esta no existía
  PERFORM sui_departamentos_partidos (vPartidoIndet, 'Indeterminado', p_provincia, 'A');
 
 -- Existe la provincia, entonces actualizo los datos y genero el departamento indeterminado
 EXCEPTION 
     WHEN unique_violation THEN
        UPDATE mug_provincias SET (nombre, pais) = (p_nombre, p_pais)  WHERE provincia = p_provincia;

        -- Actualiza el partido indeterminado
        -- PERFORM sui_departamentos_partidos (vPartidoIndet, 'Indeterminado', p_provincia, 'A');  --> porque? ya deberia existir este depto.
     WHEN OTHERS THEN
       RAISE EXCEPTION 'Provincia: % - %.Error Nro: %. %',p_provincia, p_nombre, SQLSTATE, SQLERRM;   
END;
$$;
