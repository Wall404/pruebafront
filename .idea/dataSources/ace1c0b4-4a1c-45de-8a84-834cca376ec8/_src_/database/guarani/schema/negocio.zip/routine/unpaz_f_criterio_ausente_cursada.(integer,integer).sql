create function negocio.unpaz_f_criterio_ausente_cursada(_alumno integer, _elemento integer) returns numeric
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _res character(1);
 DECLARE _ausen numeric;
 DECLARE _insc numeric;
 DECLARE _result numeric;

BEGIN
	_res := 'A';
	-- Busca el ultimo resultado de la actividad
	SELECT sga_actas_detalle.resultado INTO _res
	FROM negocio.sga_comisiones
	JOIN negocio.sga_actas on (sga_comisiones.comision = sga_actas.comision)
	JOIN negocio.sga_actas_detalle on (sga_actas.id_acta = sga_actas_detalle.id_acta)
	WHERE sga_actas_detalle.alumno = _alumno
	AND sga_comisiones.elemento = _elemento
	AND sga_actas.origen = 'R'
	and sga_actas_detalle.estado = 'A'
	--AND sga_actas_detalle.fecha_vigencia > now()
	ORDER BY fecha DESC
	LIMIT 1;

/*LAURA: acá David aclaró que sería para ausente en el pasado (se entiende que en cualquier momento). No iría fecha de vigencia, sino quizás la última. pensemos si esto nos deja gente afuera*/	
/* Listo */
	IF _res = 'U' THEN
	-- Ausente en la actividad
		SELECT COUNT(DISTINCT sga_comisiones.comision) INTO _ausen
		FROM negocio.sga_comisiones
		JOIN negocio.sga_actas on (sga_comisiones.comision = sga_actas.comision)
		JOIN negocio.sga_actas_detalle on (sga_actas.id_acta = sga_actas_detalle.id_acta)
		where sga_actas_detalle.alumno = _alumno
		and sga_actas.origen = 'R'
		and sga_actas_detalle.rectificado = 'N'
		and sga_actas_detalle.estado = 'A'
		and sga_actas_detalle.resultado = 'U';
/*LAURA: quizás sea mejor contar el total de notas en actas en vez de el total de inscripciones, para trabajar sobre la misma base*/
/* Listo */
/*LAURA: para esta y todas las otras consultas sobre actas, falta verificar que el registro no se encuentre rectificado. RECTIFICADO = N y ESTADO = A*/
/* Listo */
		/*SELECT COUNT(DISTINCT inscripcion) INTO _insc
		FROM negocio.sga_insc_cursada
		WHERE sga_insc_cursada.estado = 'A'
		AND sga_insc_cursada.alumno = _alumno;*/

		SELECT COUNT(DISTINCT sga_actas_detalle.id_acta) INTO _insc
		FROM negocio.sga_comisiones
		JOIN negocio.sga_actas on (sga_comisiones.comision = sga_actas.comision)
		JOIN negocio.sga_actas_detalle on (sga_actas.id_acta = sga_actas_detalle.id_acta)
		where sga_actas_detalle.alumno = _alumno
		and sga_actas.origen = 'R'
		and sga_actas_detalle.rectificado = 'N'
		and sga_actas_detalle.estado = 'A'
		;

		SELECT (_ausen / _insc) INTO _result;

		RETURN _result;
	ELSE
	-- No estuvo ausente
	RETURN 0;
	END IF;
END;
$$;
