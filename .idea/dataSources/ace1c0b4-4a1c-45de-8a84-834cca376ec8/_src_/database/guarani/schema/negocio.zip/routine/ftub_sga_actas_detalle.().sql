create function negocio.ftub_sga_actas_detalle() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _estado char(1);
BEGIN
   -- No se permite modificar datos del detalle del acta si la misma esta Cerrada y/o Anulada
   SELECT estado INTO _estado
      FROM sga_actas
      WHERE id_acta = NEW.id_acta;
      
   -- Alumno, instancia, fecha, escala de notas, nota, resultado.
   IF (_estado = 'C' OR _estado = 'B') AND  
      (OLD.alumno <> NEW.alumno OR
       OLD.instancia <> NEW.instancia OR
       OLD.escala_nota <> NEW.escala_nota OR
       OLD.nota <> NEW.nota OR
       OLD.resultado <> NEW.resultado OR
       OLD.fecha <> NEW.fecha) THEN
       
       IF _estado = 'C' THEN
          raise exception 'No se puede modificar datos del acta porque esta Cerrada';
       ELSEIF _estado = 'B' THEN
          raise exception 'No se puede modificar datos del acta porque esta Anulada';
       END IF ;
   END IF;
   
   RETURN NEW;
END;
$$;
