create function negocio.unpaz_f_inscripcion_aceptados_comision(_comision integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _resultado integer;
 
BEGIN

	select count (alumno) into _resultado
	from negocio.sga_insc_cursada where estado = 'A' and comision = _comision;

	RETURN _resultado;
END;
$$;
