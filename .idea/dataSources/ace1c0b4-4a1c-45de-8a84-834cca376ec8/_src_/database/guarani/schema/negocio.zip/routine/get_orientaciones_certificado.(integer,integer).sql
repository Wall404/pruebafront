create function negocio.get_orientaciones_certificado(pcertificado integer, pplanversion integer) returns SETOF negocio.type_orientacion
LANGUAGE plpgsql
AS $$
DECLARE 
  _condicion integer;
  cur_orient record;
  cur_grupos record;
  cur_elementos record;

BEGIN
	-- Recupera los datos del Módulo Raiz de la Versiòn del Plan.
	SELECT sga_condiciones.condicion INTO _condicion
	FROM sga_certificados,
	     sga_condiciones
	WHERE sga_certificados.certificado = pCertificado
	  AND sga_condiciones.plan_version = pPlanVersion 
	  AND sga_condiciones.entidad = sga_certificados.entidad
	  AND sga_condiciones.condicion_tipo = '3'; -- Condicion para obtener un certificado.

  -- Recorro los grupos de las condiciones para obtener el certificado.
  FOR cur_grupos IN 
   SELECT sga_condiciones_grupos.grupo_condicion
    FROM sga_condiciones_grupos
    WHERE sga_condiciones_grupos.condicion = _condicion
    ORDER BY sga_condiciones_grupos.orden
  LOOP 
  
    FOR cur_elementos IN 
      SELECT e.elemento, ep.elemento_revision, e.entidad_subtipo
        FROM sga_condiciones_requisitos as cr, 
             sga_elementos as e, 
             sga_g3entidades_subtipos as est,
             sga_elementos_plan as ep,
             sga_elementos_revision as er
        WHERE cr.grupo_condicion = cur_grupos.grupo_condicion
          AND cr.entidad IS NOT NULL
          AND e.entidad = cr.entidad
          AND est.entidad_subtipo = e.entidad_subtipo
          AND est.entidad_tipo = 1  -- Modulos.
          AND er.elemento = e.elemento
          AND ep.plan_version = pPlanVersion
          AND ep.elemento_revision = er.elemento_revision
        ORDER BY cr.orden
          
      LOOP
         IF cur_elementos.entidad_subtipo = 3 THEN
           RETURN NEXT cur_elementos;
         ELSE			
         -- Recorro el modulo buscando orientaciones
         FOR cur_orient IN SELECT elemento, elemento_revision, entidad_subtipo FROM get_orientaciones_certificado_det (cur_elementos.elemento, cur_elementos.elemento_revision, cur_elementos.entidad_subtipo)
         LOOP
            -- Devuelve los modulos que son orientaciones (entidad_subtipo = 3)
            RETURN NEXT cur_orient;
         END LOOP;
       END IF;
    END LOOP; -- Elementos
   END LOOP; -- Grupos de Condiciones.
  
END
$$;
