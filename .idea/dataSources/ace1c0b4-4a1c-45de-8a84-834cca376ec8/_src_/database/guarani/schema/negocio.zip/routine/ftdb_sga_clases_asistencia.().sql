create function negocio.ftdb_sga_clases_asistencia() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Actualizo registro acumulado de inasistencias o inasist justificadas si fue modificado.
  PERFORM f_asistencia_actualizar_acumulado('D', OLD.alumno, OLD.clase, OLD.cant_inasistencias, OLD.cant_justificadas, 0, 0); 

  RETURN OLD;
END;
$$;
