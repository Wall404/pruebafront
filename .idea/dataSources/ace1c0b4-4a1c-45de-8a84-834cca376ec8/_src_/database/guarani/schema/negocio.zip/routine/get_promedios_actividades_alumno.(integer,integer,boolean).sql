create function negocio.get_promedios_actividades_alumno(palumno integer, pplanversion integer, ppropuestasvinculadas boolean DEFAULT false) returns TABLE(alumno integer, promedio numeric, promedio_sin_aplazos numeric, cant_actividades_aprobadas integer, cant_actividades_plan integer)
LANGUAGE plpgsql
AS $$
DECLARE 
  _promedio numeric(8,3);
  _promedio_sin_aplazos numeric(8,3);
  _cant_genericas integer;
  _cant_optativas integer;
  _cant_actividades_plan integer;
  _cant_actividades integer;      
  _cant_actividades_aprobadas integer;      
  _total_notas decimal(10,3);
  _total_notas_sin_aplazos decimal(10,3);
  _fecha_promedio date;
  _PropuestaAlumno Integer;
  _PlanVersionAlumno Integer;
  _PlanAlumno Integer;
  _Persona Integer;
  cur_prop record;
  cur_ele record;
  _elementos Integer[];

BEGIN

  -- Inicializo variables. 
  _cant_actividades := 0;
  _cant_genericas := 0;
  _cant_optativas := 0;
  _cant_actividades_plan := 0;
  _cant_actividades_aprobadas := 0;
  _promedio := 0;
  _promedio_sin_aplazos := 0;

  
  
  -- Si la fecha hasta la que se evaluan las actividades aprobadas es nula entonces se tomala fecha actual.
 -- _fecha_promedio := COALESCE(pFecha, CURRENT_DATE);
  _fecha_promedio := CURRENT_DATE;

  -- Recupero datos del alumno a la fecha a evaluar
  IF pPlanVersion IS NOT NULL THEN
    _PlanVersionAlumno := pPlanVersion;
  ELSE
    _PlanVersionAlumno := (SELECT * FROM get_plan_version_alumno(pAlumno, to_char(_fecha_promedio, 'YYYY-MM-DD'))) ;
  END IF;
  SELECT a.persona, a.propuesta INTO _Persona, _PropuestaAlumno FROM sga_alumnos as a WHERE a.alumno = pAlumno;  
  SELECT v.plan INTO _PlanAlumno FROM sga_planes_versiones as v WHERE v.plan_version = _PlanVersionAlumno;

  -- Elimino registros del alumno anterior..
  TRUNCATE _Tactividades;
  TRUNCATE _Tactividades_aux;
  TRUNCATE _temp_prop_alumno;
  TRUNCATE _temp_relacion;


  -- Cargo la propuesta del alumno por la que se consulta el promedio
  INSERT INTO _temp_prop_alumno (alumno, propuesta, plan, plan_version) VALUES (pAlumno, _PropuestaAlumno, _PlanAlumno, _PlanVersionAlumno); 

  -- Actividades del plan del alumno
  SELECT COUNT(*) INTO _cant_actividades FROM vw_actividades_plan WHERE plan_version = _PlanVersionAlumno;
  SELECT COUNT(elemento_generica), COUNT(DISTINCT elemento) 
    INTO _cant_genericas, _cant_optativas
	 FROM vw_optativas_plan WHERE plan_version = _PlanVersionAlumno;

  -- Sumo las genericas y resto las optativas que ya habian sido contadas.	 
  _cant_actividades_plan := _cant_actividades + _cant_genericas - _cant_optativas;	 
  
  IF pPropuestasVinculadas THEN 
     -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     -- PROPUESTAS VINCULADAS
     -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     INSERT INTO _temp_relacion (relacion) SELECT * FROM get_relacion_propuesta(pAlumno);
        
        -- Recupera todos los planes de estudio de propuestas vinculadas de cada grupo
     -- Saca el distinct porque puede estar el mismo plan de estudios en diferentes grupos
     INSERT INTO _temp_prop_alumno (alumno, propuesta, plan, plan_version)
           SELECT DISTINCT sga_alumnos.alumno, sga_planes.propuesta, sga_planes.plan, sga_alumnos.plan_version
             FROM _temp_relacion as t,
                  sga_propuestas_relacion_grupo,
                  sga_propuestas_relacion_plan,
                  sga_planes, 
                  sga_alumnos  
            WHERE sga_propuestas_relacion_grupo.relacion = t.relacion
              AND sga_propuestas_relacion_grupo.incluir_en_analitico = 'S'
              AND sga_propuestas_relacion_plan.relacion_grupo = sga_propuestas_relacion_grupo.relacion_grupo
              AND sga_planes.plan = sga_propuestas_relacion_plan.plan
              AND sga_alumnos.persona = _Persona
              AND sga_alumnos.propuesta = sga_planes.propuesta;
  END IF;
             

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Actividades del Plan Actual del Alumno en cada propuesta. 
  -- Actividades realizadas en la misma propuesta o en otra propuesta (actividades comunes)
  -- Actividades de la version actual del alumno en cada plan de estudios de cada propuesta
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Recupero actividades:
  --  * Aprobadas/reprobadas de la version actual del alumno
  --  * Con fecha menor o igual a la fecha pasada por parametro.
  --  * Solo actividades que son promediables
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 FOR cur_prop IN SELECT t.alumno, t.propuesta, t.plan, t.plan_version FROM _temp_prop_alumno as t
 LOOP
 
    -- Recupero actividades que pertenecen a la version del plan de estudios en cada propuesta del alumno
    -- Las actividades pueden haber sido aprobadas en esa version/plan o en versiones/planes anteriores o en otra propuesta...
  
   INSERT INTO _Tactividades_aux (elemento, id_acta, origen, equivalencia_tramite,equivalencia, fecha, escala_nota, nota, resultado)
       SELECT elemento, id_acta, origen, equivalencia_tramite,equivalencia, fecha, escala_nota, nota, resultado
         FROM vw_hist_academica_basica as v
        WHERE v.alumno = cur_prop.alumno
          AND v.fecha <= _fecha_promedio
          AND v.resultado IN ('A','R')
          AND v.elemento IN (SELECT vw_elementos_plan.elemento 
                             FROM vw_elementos_plan,
                                  sga_elementos_plan
                             WHERE vw_elementos_plan.plan_version = cur_prop.plan_version
                               AND sga_elementos_plan.elemento_plan = vw_elementos_plan.elemento_plan
                               AND sga_elementos_plan.promediable = 'S');
  END LOOP; -- Propuestas del alumno

  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Saco las materias duplicadas (mismo origen)
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO _Tactividades (elemento, id_acta, origen, equivalencia_tramite, equivalencia, fecha, escala_nota, nota, resultado)
     SELECT DISTINCT elemento, id_acta, origen, equivalencia_tramite, equivalencia, fecha, escala_nota, nota, resultado
      FROM _Tactividades_aux;
   
  	   
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Calculo promedios y cantidad de actividades
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    
    -- Recupero el total de notas y la cantidad de examenes/promociones/equivalencias consideradas en el calculo.  
    SELECT SUM(e.valor_numerico), 
	       COUNT(*), 
	       SUM(CASE t.resultado WHEN 'A' THEN e.valor_numerico ELSE 0 END), 
		   SUM(CASE t.resultado WHEN 'A' THEN 1 ELSE 0 END) 
      INTO _total_notas, _cant_actividades, _total_notas_sin_aplazos, _cant_actividades_aprobadas
      FROM _Tactividades as t
           JOIN sga_escalas_notas_det as e ON (e.escala_nota = t.escala_nota AND e.nota = t.nota)
     WHERE t.nota IS NOT NULL
       AND e.valor_numerico IS NOT NULL;
          
    -- Promedio
	_cant_actividades := COALESCE(_cant_actividades, 0);
	_cant_actividades_aprobadas := COALESCE(_cant_actividades_aprobadas, 0);
	_total_notas_sin_aplazos := COALESCE(_total_notas_sin_aplazos, 0);
	_total_notas := COALESCE(_total_notas, 0);
	
    IF _cant_actividades <> 0 THEN
    	_promedio := _total_notas / _cant_actividades;
    END IF;
    IF _cant_actividades_aprobadas <> 0 THEN
       _promedio_sin_aplazos := _total_notas_sin_aplazos / _cant_actividades_aprobadas;
    END IF;   


  -- Retorno el promedio
  RETURN QUERY SELECT pAlumno, _promedio, _promedio_sin_aplazos, _cant_actividades_aprobadas, _cant_actividades_plan;
    
END;
$$;
