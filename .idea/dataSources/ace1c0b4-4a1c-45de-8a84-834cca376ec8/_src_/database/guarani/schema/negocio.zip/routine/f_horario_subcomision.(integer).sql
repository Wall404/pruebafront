create function negocio.f_horario_subcomision(_subcomision integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _horario text; 
  i smallint;     
  cur_bh record;
BEGIN
  
  _horario := '';
  i := 0;
  FOR cur_bh IN 
   (
   SELECT sga_asignaciones.dia_semana as dia_semana,
          to_char(sga_asignaciones.hora_inicio, 'HH24:MI') as inicio,
          to_char(sga_asignaciones.hora_finalizacion, 'HH24:MI') as fin
     FROM sga_subcomisiones_bh,
          sga_comisiones_bh,
          sga_asignaciones
      WHERE sga_subcomisiones_bh.subcomision = _subcomision
        AND sga_comisiones_bh.banda_horaria = sga_subcomisiones_bh.banda_horaria
        AND sga_asignaciones.asignacion = sga_comisiones_bh.asignacion
     ORDER BY CASE sga_asignaciones.dia_semana
                WHEN 'Lunes' THEN 1
                WHEN 'Martes' THEN 2
                WHEN 'Miercoles' THEN 3
                WHEN 'Jueves' THEN 4
                WHEN 'Viernes' THEN 5
                WHEN 'Sabado' THEN 6
                WHEN 'Domingo' THEN 7
                ELSE 0
              END, 2   
   )
  LOOP
   IF i > 0 THEN
    _horario := _horario || ' - ' ;
   END IF;

   _horario := _horario || substring(cur_bh.dia_semana from 1 for 3) || ' ' || cur_bh.inicio || ' a ' || cur_bh.fin;
   i := i + 1;
  END LOOP;
    
  -- Retorno los dias y horarios de la subcomision
  RETURN _horario;
    
END;
$$;
