create function negocio.ftia_sga_llamados_mesa() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _evaluacion_tipo integer;
   _evaluacion integer;
   _nombre varchar(100);
   
BEGIN
   
   -- Recupero el tipo de evaluacion automática para las Mesas de Examen
   SELECT evaluacion_tipo INTO _evaluacion_tipo
      FROM sga_evaluaciones_tipos
      WHERE sga_evaluaciones_tipos.automatica = 'S'
      AND sga_evaluaciones_tipos.aplica_a = 'M';

   -- Si no encontro ningun registro entonces salgo con error.
   IF _evaluacion_tipo IS NULL THEN
      RAISE EXCEPTION 'No esta definido el tipo de evaluación automática para las Mesas de Examen.';
   END IF;

   SELECT nombre INTO _nombre
     FROM sga_mesas_examen
    WHERE mesa_examen = NEW.mesa_examen;

   -- Inserto una evaluacion automática. 
   -- Estado "Abierta", Generación "Automática", Fecha Actual, Visible al Alumno = NO.
   INSERT INTO sga_evaluaciones (nombre, descripcion, entidad, evaluacion_tipo, visible_al_alumno, fecha, estado)
      VALUES(_nombre, 'Evaluación automática para generación de acta de examen',
              NEW.entidad, _evaluacion_tipo, 'N', CURRENT_DATE, 'A');

   RETURN NEW;
END;
$$;
