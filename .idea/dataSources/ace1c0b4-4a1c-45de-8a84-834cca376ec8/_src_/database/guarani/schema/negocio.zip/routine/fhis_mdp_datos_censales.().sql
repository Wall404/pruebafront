create function negocio.fhis_mdp_datos_censales() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		INSERT INTO his_datos_censales (dato_censal, persona, fecha_relevamiento, fecha_actualizacion) 
		VALUES (NEW.dato_censal, NEW.persona, NEW.fecha_relevamiento, NEW.fecha_actualizacion);
	
		RETURN NEW;
	END;
$$;
