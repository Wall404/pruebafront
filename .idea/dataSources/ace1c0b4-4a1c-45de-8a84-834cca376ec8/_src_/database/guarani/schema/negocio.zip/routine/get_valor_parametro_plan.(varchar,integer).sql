create function negocio.get_valor_parametro_plan(pparametro character varying, pplan integer) returns character varying
LANGUAGE plpgsql
AS $$
DECLARE 
 _valor_default varchar(150);
 _valor varchar(150);
 _nivel integer;
 
BEGIN
  _valor_default := NULL;
  _valor := NULL;
  _nivel := NULL;
  
  -- Recupero el valor default del parámetro.
  SELECT valor_default, nivel 
    INTO _valor_default, _nivel
    FROM par_parametros_sistema
   WHERE parametro = pParametro;

  -- Plan
  IF _valor IS NULL AND _nivel >= 5 THEN
    -- Busco el valor para ese plan...
    SELECT par_param_sist_valores.valor
      INTO _valor
      FROM sga_planes,
           par_param_sist_valores,
           par_param_sist_valores_entidad
     WHERE sga_planes.plan = pPlan
       AND par_param_sist_valores_entidad.entidad = sga_planes.entidad
       AND par_param_sist_valores.param_valor = par_param_sist_valores_entidad.param_valor 
       AND par_param_sist_valores.parametro = pParametro;
  END IF;

  -- Propuesta  
  IF _valor IS NULL AND _nivel >= 4 THEN

     SELECT par_param_sist_valores.valor
       INTO _valor
       FROM sga_planes,
            sga_propuestas,
            par_param_sist_valores,
            par_param_sist_valores_entidad
      WHERE sga_planes.plan = pPlan
        AND sga_propuestas.propuesta = sga_planes.propuesta
        AND par_param_sist_valores_entidad.entidad = sga_propuestas.entidad
        AND par_param_sist_valores.param_valor = par_param_sist_valores_entidad.param_valor
        AND par_param_sist_valores.parametro = pParametro;
  END IF;

  -- Tipo de Propuesta
  IF _valor IS NULL AND _nivel >= 3 THEN
     SELECT par_param_sist_valores.valor
       INTO _valor
       FROM sga_planes,
            sga_propuestas,
            par_param_sist_valores,
            par_param_sist_valores_subtipo
      WHERE sga_planes.plan = pPlan
        AND sga_propuestas.propuesta = sga_planes.propuesta
        AND par_param_sist_valores_subtipo.entidad_subtipo = sga_propuestas.propuesta_tipo
        AND par_param_sist_valores.param_valor = par_param_sist_valores_subtipo.param_valor
        AND par_param_sist_valores.parametro = pParametro;
  END IF;

  -- Recupero el valor según responsable académica de la propuesta del plan del alumno
  IF _valor IS NULL AND _nivel >= 2 THEN
    -- En el caso que la propueta tenga mas de una resp. academica, toma la 1ra que encuentra.
    SELECT par_param_sist_valores.valor
       INTO _valor
       FROM sga_planes,
            sga_propuestas_ra,
            sga_responsables_academicas,
            par_param_sist_valores,
            par_param_sist_valores_entidad
      WHERE sga_planes.plan = pPlan
        AND sga_propuestas_ra.propuesta = sga_planes.propuesta
        AND sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica
        AND par_param_sist_valores_entidad.entidad = sga_responsables_academicas.entidad 
        AND par_param_sist_valores.param_valor = par_param_sist_valores_entidad.param_valor 
        AND par_param_sist_valores.parametro = pParametro
      LIMIT 1;
  END IF;

  -- Nivel Institucion.
  IF _valor IS NULL AND _nivel >= 1 THEN
    SELECT par_param_sist_valores.valor
       INTO _valor
       FROM sga_planes,
            sga_propuestas_ra,
            sga_responsables_academicas,
            sga_instituciones,
            par_param_sist_valores,
            par_param_sist_valores_entidad
      WHERE sga_planes.plan = pPlan
        AND sga_propuestas_ra.propuesta = sga_planes.propuesta
        AND sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica
        AND sga_instituciones.institucion = sga_responsables_academicas.institucion
        AND par_param_sist_valores_entidad.entidad = sga_instituciones.entidad 
        AND par_param_sist_valores.param_valor = par_param_sist_valores_entidad.param_valor 
        AND par_param_sist_valores.parametro = pParametro;
  END IF;

  -- Retorno el valor del parametro
  IF _valor IS NOT NULL THEN
    RETURN _valor;
  ELSE
    RETURN _valor_default;
  END IF;

END;
$$;
