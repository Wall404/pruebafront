create function negocio.fhis_mdp_datos_actividades() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		INSERT INTO his_datos_actividades (dato_censal, tecnologia_pc_casa, tecnologia_pc_trabajo, tecnologia_pc_universidad, tecnologia_pc_otro_lugar, tecnologia_int_casa, tecnologia_int_trabajo, tecnologia_int_universidad, tecnologia_int_otro_lugar, deportes, deportes_universidad, deportes_gimnasio, deportes_particular, deportes_otro_lugar, deportes_basquet, deportes_futbol, deportes_gimnasia, deportes_handball, deportes_natacion, deportes_tenis, deportes_voley, deportes_otros, nivel_idioma_ingles, nivel_idioma_aleman, nivel_idioma_frances, nivel_idioma_italiano, nivel_idioma_portugues, nivel_idioma_chino, idioma_otro, nivel_idioma_otro, tecnologia_int_movil) 
		VALUES (NEW.dato_censal, NEW.tecnologia_pc_casa, NEW.tecnologia_pc_trabajo, NEW.tecnologia_pc_universidad, NEW.tecnologia_pc_otro_lugar, NEW.tecnologia_int_casa, NEW.tecnologia_int_trabajo, NEW.tecnologia_int_universidad, NEW.tecnologia_int_otro_lugar, NEW.deportes, NEW.deportes_universidad, NEW.deportes_gimnasio, NEW.deportes_particular, NEW.deportes_otro_lugar, NEW.deportes_basquet, NEW.deportes_futbol, NEW.deportes_gimnasia, NEW.deportes_handball, NEW.deportes_natacion, NEW.deportes_tenis, NEW.deportes_voley, NEW.deportes_otros, NEW.nivel_idioma_ingles, NEW.nivel_idioma_aleman, NEW.nivel_idioma_frances, NEW.nivel_idioma_italiano, NEW.nivel_idioma_portugues, NEW.nivel_idioma_chino, NEW.idioma_otro, NEW.nivel_idioma_otro, NEW.tecnologia_int_movil);
	
		RETURN NEW;
	END;
$$;
