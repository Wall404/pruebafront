create function negocio.unpaz_get_actividades_certificado_det(_elemento_revision integer) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE 
	hijos record;
	cur_actividades record;
BEGIN

set search_path = negocio;
	-- Elementos que contiene el módulo.
	FOR hijos IN 
		SELECT	sga_elementos.elemento,
				sga_g3entidades_subtipos.entidad_tipo,
				sga_elementos_revision.elemento_revision
		FROM	sga_elementos_comp,
				sga_elementos_revision,
				sga_elementos,
				sga_g3entidades_subtipos
		WHERE	sga_elementos_comp.elemento_hijo = sga_elementos_revision.elemento_revision AND
				sga_elementos_revision.elemento = sga_elementos.elemento AND
				sga_elementos.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo AND
				sga_elementos_comp.elemento_padre = _elemento_revision
	LOOP
		IF hijos.entidad_tipo = 2 THEN
			RETURN NEXT hijos.elemento;
		ELSE
			-- Llamo de nuevo a la funcion para ver si alguno de los hijos del modulo es una orientacion.
			FOR cur_actividades IN
				SELECT	cast(unpaz_get_actividades_certificado_det as integer) as elemento
				FROM	unpaz_get_actividades_certificado_det(hijos.elemento_revision)
			LOOP
				RETURN NEXT cur_actividades.elemento;
			END LOOP; -- Actividades.
		END IF;
	END LOOP; -- Componentes del módulo.
END;
$$;
