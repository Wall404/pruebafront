create function negocio.f_evaluacion_baja(pevaluacion integer) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE 
  _evaluacion  sga_evaluaciones%ROWTYPE;
  _cant Integer;
  cur_retorno type_retorno_funcion;

BEGIN
  
  -- Variables 
  cur_retorno.resultado := -1;
  cur_retorno.mensaje_param  := NULL;
  
  -- 1. Verifico que la evaluacion no este cerrada 
  SELECT * INTO _evaluacion FROM sga_evaluaciones WHERE evaluacion = pEvaluacion;
   
  IF NOT FOUND THEN
    -- No existe la evaluacion a dar de baja
    cur_retorno.mensaje_indice := '800CUR_evaluacion_baja_no_existe';
    RETURN cur_retorno;
  END IF;
  
  -- 2. Verifico que la evaluacion no este cerrada 
  IF _evaluacion.estado = 'C' THEN
    cur_retorno.mensaje_indice := '800CUR_evaluacion_baja_cerrada';
    RETURN cur_retorno;
  END IF;
  
  /* Este control NO SE HACE
  -- 3. Si hay alumnos que no tengan nota cargada
  SELECT COUNT(*) INTO _cant
    FROM sga_eval_detalle
   WHERE evaluacion = pEvaluacion
     AND nota IS NOT NULL;
     
  IF _cant > 0 THEN
    cur_retorno.mensaje_indice := '800CUR_evaluacion_baja_alumnos_con_nota';
    RETURN cur_retorno;
  END IF;
  */
  
  -- 4. Si hay alguna evaluacion que esta relacionada con esta, no la permito borrar
  SELECT COUNT(*) INTO _cant
    FROM sga_evaluaciones_relacion
   WHERE evaluacion_hijo = pEvaluacion;
     
  IF _cant > 0 THEN
    cur_retorno.mensaje_indice := '800CUR_evaluacion_baja_relacion';
    RETURN cur_retorno;
  END IF;
  
-- Comienza la Transacción
BEGIN

  -- Borro los datos de la evaluacion
  DELETE FROM sga_eval_detalle WHERE evaluacion = pEvaluacion;
  DELETE FROM sga_evaluaciones_instancias WHERE evaluacion = pEvaluacion;
  DELETE FROM sga_evaluaciones_relacion   WHERE evaluacion_padre = pEvaluacion;
  DELETE FROM sga_evaluaciones WHERE evaluacion = pEvaluacion;
						   							   
  -- Error.
  EXCEPTION
     WHEN OTHERS THEN
        -- El error se produjo en los inserts...
        cur_retorno.mensaje_indice := '800CUR_evaluacion_baja_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- La evaluacion se dio de baja
  cur_retorno.resultado        := 1;
  cur_retorno.mensaje_indice   := '800CUR_evaluacion_baja_ok';
  
  RETURN cur_retorno;

END;
$$;
