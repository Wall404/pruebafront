create function negocio.f_asistencia_actualizar_acumulado(paccion character, palumno integer, pclase integer, pold_cant_inasistencias numeric, pold_cant_justificadas numeric, pnew_cant_inasistencias numeric, pnew_cant_justificadas numeric) returns void
LANGUAGE plpgsql
AS $$
DECLARE 
   -- _inasistencias numeric(5,2);
   -- _justificadas numeric(5,2);
   _tot_inasistencias numeric(5,2);
   _tot_justificadas numeric(5,2);
   _tot_inasistencias_tramo numeric(5,2);
   _tot_justificadas_tramo numeric(5,2);
   _comision integer;
   _porc_asistencia_comision DECIMAL(5,2);
   _porc_asistencia DECIMAL(5,2);
   _porc_inasis_alumno DECIMAL(5,2);
   _cant_horas DECIMAL(5,2);
   _cant_horas_tramo DECIMAL(5,2);
   _cant_clases integer;
   _cant_clases_tramo integer;
   _acum sga_clases_asistencia_acum%ROWTYPE;
   _libre integer;
   _id_tramo integer;
   _nro_tramo integer;
   _tramo_quedo_libre integer;
   _cant_subc integer;
   _par_asistencia_por_horas char(1);
   _par_indicar_cantidad_inasistencias char(1);
   _porc_promo_alumno decimal(5,2);
  
BEGIN
  -- pAccion = U (Update) / I (Insert) / D (delete) 
  -- Si no hay cambios de los datos de inasistencias o justificadas entonces salgo sin actualizar..
  IF (pAccion = 'U' AND (pNEW_cant_inasistencias = pOLD_cant_inasistencias AND pNEW_cant_justificadas = pOLD_cant_justificadas)) OR 
     (pAccion = 'D' AND (pOLD_cant_inasistencias = 0 AND pOLD_cant_justificadas = 0)) OR
     (pAccion = 'I' AND (pNEW_cant_inasistencias = 0 AND pNEW_cant_justificadas = 0)) THEN
    RETURN;
  END IF;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Actualizo registro acumulado de inasistencias o inasist justificadas si fue modificado.
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

  -- Hay cambios de inasistencias o justificaciones
  _tot_inasistencias := 0;
  _tot_justificadas  := 0;
  _tot_inasistencias_tramo := 0;
  _tot_justificadas_tramo  := 0;
  _porc_inasis_alumno := 0;
  _libre := 0;
  _tramo_quedo_libre := NULL;
  _porc_asistencia_comision := NULL;
  _id_tramo := NULL;
  _nro_tramo := NULL;
  _cant_horas := 0;
  _cant_horas_tramo := 0;
  _cant_clases := 0;
  _cant_clases_tramo := 0;
  _porc_asistencia := NULL;
  
 
  -- Obtengo datos de la comision
  SELECT sga_comisiones_bh.comision, 
         sga_clases.id_tramo,
         sga_comisiones.asistencia_cantidad_inasist, -- parametro: asist_indicar_cantidad_inasist
         sga_comisiones.asistencia_por_horas        -- parametro: asist_computa_inasist_por_horas
    INTO _comision,
         _id_tramo, 
         _par_indicar_cantidad_inasistencias, 
         _par_asistencia_por_horas
    FROM sga_clases, sga_comisiones_bh, sga_comisiones
    WHERE sga_clases.clase = pClase
      AND sga_comisiones_bh.banda_horaria = sga_clases.banda_horaria
      AND sga_comisiones.comision = sga_comisiones_bh.comision;

  IF _id_tramo IS NULL THEN
    RETURN;
  ELSE
     -- Recupero el nro de tramo que corresponde a la clase.
     SELECT nro_tramo INTO _nro_tramo FROM sga_periodos_lectivos_tramos WHERE id_tramo = _id_tramo;
  END IF;
  
  -- Obtengo el dato del registro actual de inasistencias acumuladas del alumno en la comision
  SELECT * INTO _acum FROM sga_clases_asistencia_acum WHERE comision = _comision AND alumno = pAlumno;
  
  IF NOT FOUND THEN
    -- Genero un registro con el acumulado de inasistencias por cada tramo de asistencia del Período lectivo.
    INSERT INTO sga_clases_asistencia_acum (comision, alumno, total_inasistencias, total_justificadas, libre, tramo_quedo_libre)
       VALUES (_comision, pAlumno, 0, 0, 0, NULL);
    
    SELECT * INTO _acum FROM sga_clases_asistencia_acum WHERE comision = _comision AND alumno = pAlumno;
  END IF;

  _libre             := _acum.libre;
  _tramo_quedo_libre := _acum.tramo_quedo_libre;
  _tot_inasistencias := _acum.total_inasistencias;
  _tot_justificadas  := _acum.total_justificadas;
  _porc_asistencia   := _acum.porc_asistencia;
	
  -- Verifico si el alumno tiene alguna excepcion en el porcentaje de asistencia en la cursada
  SELECT porcentaje_regular, porcentaje_promocion 
    INTO _porc_asistencia_comision, _porc_promo_alumno
    FROM sga_alumnos_excep_asistencia 
   WHERE comision = _comision AND alumno = pAlumno;
  
  IF FOUND THEN
     -- El alumno tiene una excepcion. Verifico si la de la instancia regular esta definida.
     IF _porc_asistencia_comision IS NULL OR _porc_asistencia_comision <= 0 THEN
          _porc_asistencia_comision := _porc_promo_alumno; -- Asigno la de la instancia promocion
     END IF;   
  ELSE
    -- No existe excepcion para el alumno
    -- Recupero el porcentaje de asistencia mínimo a cumplir por el alumno en la cursada en la instancia de REGULARIDAD
    SELECT porc_asistencia INTO _porc_asistencia_comision FROM sga_comisiones_instancias WHERE comision = _comision AND instancia = 1; -- Regular
  
    IF NOT FOUND THEN
       -- No existe instancia de regularidad. 
       -- Busco el porcentaje de asistencia en la instancia promoción (Caso de cursadas solo promocionales...).
       SELECT porc_asistencia INTO _porc_asistencia_comision FROM sga_comisiones_instancias WHERE comision = _comision AND instancia = 2; -- Promocion
    END IF;
  END IF;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Recupero la cantidad de clases y cantidad de horas en la comision o en las subcomisiones del alumno
  -- Clases que corresponden al tramo de la clase que se esta registrando la asistencia/inasistencia.
  -- El % de inasistencia se calcula por tramo para saber si quedo libre o no..
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _cant_clases := 0;
  _cant_horas := 0;
  
  _porc_asistencia_comision := COALESCE(_porc_asistencia_comision,0);  -- Si es NULL asigna el %0
  
  -- IF _porc_asistencia_comision IS NOT NULL AND _porc_asistencia_comision > 0 THEN
     SELECT COUNT(*) INTO _cant_subc FROM sga_subcomisiones WHERE comision = _comision;
     IF _cant_subc > 0 THEN
        -- Solo clases de las subcomisiones del alumno
        SELECT SUM(c.cantidad_horas_dictadas), 
               SUM(CASE WHEN c.id_tramo = _id_tramo THEN c.cantidad_horas_dictadas ELSE 0 END), 
               COUNT(*),
               SUM(CASE WHEN c.id_tramo = _id_tramo THEN 1 ELSE 0 END)
          INTO _cant_horas, _cant_horas_tramo, _cant_clases, _cant_clases_tramo
          FROM sga_insc_cursada as i,
               sga_insc_subcomision as subc,
               sga_subcomisiones_bh as bh,
               sga_clases as c
         WHERE i.comision = _comision
           AND i.alumno   = pAlumno
           AND subc.inscripcion = i.inscripcion
           AND bh.subcomision   = subc.subcomision
           AND c.banda_horaria  = bh.banda_horaria
           AND c.valido = 1;      
     ELSE
        -- todas las clases de la comision
        SELECT SUM(c.cantidad_horas_dictadas), 
               SUM(CASE WHEN c.id_tramo = _id_tramo THEN c.cantidad_horas_dictadas ELSE 0 END), 
               COUNT(*),
               SUM(CASE WHEN c.id_tramo = _id_tramo THEN 1 ELSE 0 END)
          INTO _cant_horas, _cant_horas_tramo, _cant_clases, _cant_clases_tramo
          FROM sga_comisiones_bh as bh,
               sga_clases as c
         WHERE bh.comision = _comision
           AND c.banda_horaria = bh.banda_horaria
           AND c.valido = 1;      
     END IF;
     
     IF _cant_clases = 0 THEN 
        RETURN; 
     END IF; 

     -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     -- Recupero total de inasistencias y justificadas del alumno en el tramo incluyendo la clase actual...
     -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     IF _cant_subc > 0 THEN
       -- Solo clases de las subcomisiones del alumno
       SELECT
             SUM(ca.cant_inasistencias), 
             SUM(ca.cant_justificadas), 
             SUM(CASE WHEN c.id_tramo = _id_tramo THEN ca.cant_inasistencias ELSE 0 END), 
             SUM(CASE WHEN c.id_tramo = _id_tramo THEN ca.cant_justificadas ELSE 0 END) 
         INTO _tot_inasistencias, _tot_justificadas, _tot_inasistencias_tramo, _tot_justificadas_tramo
         FROM sga_insc_cursada as i,
              sga_insc_subcomision as subc,
              sga_subcomisiones_bh as bh,
              sga_clases as c, 
              sga_clases_asistencia as ca
         WHERE i.comision = _comision
           AND i.alumno   = pAlumno
           AND subc.inscripcion = i.inscripcion
           AND bh.subcomision   = subc.subcomision
           AND c.banda_horaria  = bh.banda_horaria
           AND c.valido  = 1
           AND ca.clase  = c.clase
           AND ca.estado = 'A'
           AND ca.alumno = pAlumno;
      ELSE
       -- Todas las clases de la comision
       SELECT 
             SUM(ca.cant_inasistencias), 
             SUM(ca.cant_justificadas), 
             SUM(CASE WHEN c.id_tramo = _id_tramo THEN ca.cant_inasistencias ELSE 0 END), 
             SUM(CASE WHEN c.id_tramo = _id_tramo THEN ca.cant_justificadas ELSE 0 END) 
         INTO _tot_inasistencias, _tot_justificadas, _tot_inasistencias_tramo, _tot_justificadas_tramo
         FROM sga_comisiones_bh as bh, sga_clases as c, sga_clases_asistencia as ca
        WHERE bh.comision = _comision
          AND c.banda_horaria = bh.banda_horaria
          AND c.valido = 1
          AND ca.clase = c.clase
          AND ca.estado = 'A'
          AND ca.alumno = pAlumno;
      END IF; -- Calculo de inasistencias

      IF pAccion = 'D' THEN
         -- Resto las inasistencias y justificadas de la clase que estoy borrando al alumno porque en la consulta anterior se cuenta la clase
         -- Esta funcion se corre antes de borrar el registro (BEFORE DELETE)
         _tot_inasistencias_tramo := _tot_inasistencias_tramo - pOld_cant_inasistencias;
         _tot_justificadas_tramo  := _tot_justificadas_tramo - pOld_cant_justificadas;
         _tot_inasistencias := _tot_inasistencias - pOld_cant_inasistencias;
         _tot_justificadas  := _tot_justificadas - pOld_cant_justificadas;
      END IF;	

      IF _tot_inasistencias < 0 OR _tot_inasistencias IS NULL THEN
         _tot_inasistencias := 0;
      END IF;
      IF _tot_justificadas < 0 OR _tot_justificadas IS NULL THEN
         _tot_justificadas := 0;
      END IF;
	 
      
      -- Verifico el porcentaje y si debe o no quedar libre
	  IF _par_indicar_cantidad_inasistencias = 'S' THEN
	     -- El computo de inasistencias es por cantidad de horas en la clase (asist_indicar_cantidad_inasistencias = S). 
		 
         IF _par_asistencia_por_horas = 'S' THEN
		   IF _cant_horas_tramo > 0 AND _cant_horas > 0 THEN -- Para evitar error por division por 0
		     -- Se registran las horas que el alumno estuvo ausente/presente (asist_computa_inasis_por_horas = S)
             _porc_inasis_alumno := (_tot_inasistencias_tramo - _tot_justificadas_tramo) / _cant_horas_tramo * 100;  -- Asistencia por Horas
             _porc_asistencia    := 100 - ((_tot_inasistencias - _tot_justificadas) / _cant_horas * 100);
		   END IF;	 
         ELSE
		   IF _cant_clases_tramo > 0 AND _cant_clases > 0 THEN  -- Para evitar error por division por 0
		     -- Se registra el porcentaje de inasistencia que el Alumno estuvo ausente (0.5 si estuvo ausente la mitad de la clase y 1 si no asistió). (asist_computa_inasis_por_horas = N)
             _porc_inasis_alumno := (_tot_inasistencias_tramo - _tot_justificadas_tramo) / _cant_clases_tramo * 100; -- Asistencia por Clase
             _porc_asistencia    := 100 - ((_tot_inasistencias - _tot_justificadas) / _cant_clases * 100);
		   END IF;	 
         END IF;  
	  ELSE
		 IF _cant_clases_tramo > 0 AND _cant_clases > 0 THEN  -- Para evitar error por division por 0
	        -- El computo de inasistencias es la clase. Asistió o estuvo ausente en la clase (asist_indicar_cantidad_inasistencias = N)
            _porc_inasis_alumno := (_tot_inasistencias_tramo - _tot_justificadas_tramo) / _cant_clases_tramo * 100; -- Asistencia por Clase
            _porc_asistencia    := 100 - ((_tot_inasistencias - _tot_justificadas) / _cant_clases * 100);
		 END IF;	
	  END IF;
      

      IF (100 - _porc_inasis_alumno) < _porc_asistencia_comision THEN
         -- El alumno queda libre porque iguala o supera el porcentaje de inasistencias permitido
         IF _libre = 0 THEN
           _libre := 1;
         END IF;
         IF _nro_tramo IS NOT NULL AND (_tramo_quedo_libre IS NULL OR _tramo_quedo_libre > _nro_tramo) THEN
           -- Si no tenia registro del tramo en que quedo libre o tenia registro pero era de un tramo de mas adelante en la cursada
           -- registro el nro de tramo en el que queda libre ...
           _tramo_quedo_libre := _nro_tramo; 
         END IF;
      ELSE
         -- Deja de estar libre si habia quedado libre en el mismo tramo
         IF _libre = 1 AND (_tramo_quedo_libre IS NULL OR _tramo_quedo_libre = _nro_tramo) THEN
           _libre := 0; 
           _tramo_quedo_libre := NULL; 
         END IF;
      END IF;
      
  -- END IF; -- _porc_asistencia_comision = 0


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
  -- Actualizo el acumulado.    
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++  
  UPDATE sga_clases_asistencia_acum
     SET total_inasistencias = _tot_inasistencias,
         total_justificadas  = _tot_justificadas,
         porc_asistencia     = _porc_asistencia,
         libre = _libre,
         tramo_quedo_libre = _tramo_quedo_libre
   WHERE alumno   = pAlumno
     AND comision = _comision;


  RETURN;
END;
$$;
