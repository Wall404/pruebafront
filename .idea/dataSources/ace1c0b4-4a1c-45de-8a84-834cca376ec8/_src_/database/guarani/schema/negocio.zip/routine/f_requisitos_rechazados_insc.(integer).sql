create function negocio.f_requisitos_rechazados_insc(pprop_aspira integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _req text;
  cur1 record;

BEGIN
  _req := '';

  -- Recupero el nombre de las RAs
  FOR cur1 IN SELECT sga_requisitos.nombre as nombre,
			sga_requisitos.descripcion as desc
                FROM sga_propuestas_aspira_rechazo,
                     sga_requisitos
               WHERE sga_propuestas_aspira_rechazo.propuesta_aspira = pProp_aspira
                 AND sga_propuestas_aspira_rechazo.requisito = sga_requisitos.requisito
  LOOP
     IF (_req <> '') THEN
	_req :=  _req || ' / ';
     END IF;
     _req :=  _req || cur1.nombre;
	
  END LOOP;

  RETURN _req;
END;
$$;
