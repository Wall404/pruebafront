create function negocio.ftia_sga_subcomisiones() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _cupo smallint;   
BEGIN
   -- Inserto el dato del cupo de la comision. Si es null entonces inserto 0. 
   _cupo := COALESCE(NEW.cupo, 0);
   INSERT INTO sga_subcomisiones_cupo (subcomision, cupo) VALUES (NEW.subcomision, _cupo);

   RETURN NEW;
END;
$$;
