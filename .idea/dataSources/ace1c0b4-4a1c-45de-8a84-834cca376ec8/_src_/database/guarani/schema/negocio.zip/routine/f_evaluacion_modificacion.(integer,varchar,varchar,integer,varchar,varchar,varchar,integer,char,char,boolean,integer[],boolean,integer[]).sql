create function negocio.f_evaluacion_modificacion(pevaluacion integer, pnombre character varying, pdescripcion character varying, pevaluaciontipo integer, pfecha character varying, phorainicio character varying, phorafin character varying, pescalanota integer, pvisiblealalumno character, ppromediable character, pinstanciasupd boolean, pinstancias integer[], pevaluacionesrelupd boolean, pevaluacionesrel integer[]) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno	type_retorno_funcion;
  _datos  sga_evaluaciones%ROWTYPE;
  _escala_nota_modif boolean;
  _relacion_modif boolean;
  _instancias_modif boolean;
  i Integer;
  _cant_instancias Integer;
  _cant_relacion Integer;
  vFecha Date;
  vHI Time;
  vHF Time;

BEGIN
/* Formato de los datos:
   pFecha      = DD/MM/YYY
   pHoraInicio = HH:MM
   pHoraFin    = HH:MM
*/  

  -- Variables de retorno
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800CUR_evaluacion_upd_ok';
  cur_retorno.mensaje_param  := NULL;
  _escala_nota_modif := false;
  _relacion_modif := false;
  _instancias_modif := false;

  -- recupero la evaluacion
  SELECT * INTO _datos FROM sga_evaluaciones WHERE evaluacion = pEvaluacion;
 
  IF NOT FOUND THEN
    cur_retorno.resultado      := -1;
    cur_retorno.mensaje_indice := '800CUR_evaluacion_upd_no_existe';
    RETURN cur_retorno;
  END IF; 
  
  -- La evaluacion esta cerrada no puede modificarse   
  IF _datos.estado = 'C' THEN
    cur_retorno.resultado      := -1;
    cur_retorno.mensaje_indice := '800CUR_evaluacion_estado_cerrada';
    RETURN cur_retorno;
  END IF;
  
  -- No permito modificar la escala de notas si existen alumnos con notas.
  IF _datos.escala_nota <> pEscalaNota THEN
    SELECT COUNT(*) INTO i FROM sga_eval_detalle WHERE evaluacion = pEvaluacion AND nota IS NOT NULL;  
  
    IF i > 0 THEN 
      cur_retorno.resultado      := -1;
      cur_retorno.mensaje_indice := '800CUR_evaluacion_upd_escala';
      RETURN cur_retorno;
    ELSE
      _escala_nota_modif := true;
    END IF;  
  END IF;
    
  _cant_instancias := 0;
  IF pInstancias IS NOT NULL THEN
    -- _cant_instancias := array_lenght(pInstancias[]); -- Para version 9.0 en adelante
    _cant_instancias := (select array_upper( pInstancias , 1) - array_lower( pInstancias ,1) + 1);
  END IF;

  _cant_relacion := 0;
  IF pEvaluacionesRel IS NOT NULL THEN
    -- _cant_relacion := array_lenght(pEvaluacionesRel[]); -- Para version 9.0 en adelante
    _cant_relacion := (select array_upper( pEvaluacionesRel , 1) - array_lower( pEvaluacionesRel ,1) + 1);
  END IF;

  vFecha := to_date(pFecha, 'DD/MM/YYYY');
  vHI := pHoraInicio::time;
  vHF := pHoraFin::time;

  
-- Comienzo transacción.
BEGIN

  -- Actualizo datos de la evaluacion
  UPDATE sga_evaluaciones 
     SET (nombre, descripcion, evaluacion_tipo, visible_al_alumno, promediable, fecha, hora_inicio, hora_fin, escala_nota) =
         (pNombre, pDescripcion, pEvaluacionTipo, pVisibleAlAlumno, pPromediable, vFecha, vHI, vHF, pEscalaNota)
  WHERE evaluacion = pEvaluacion;

  IF _escala_nota_modif THEN
    UPDATE sga_eval_detalle SET escala_nota = pEscalaNota WHERE evaluacion = pEvaluacion;
  END IF;

  IF pInstanciasUpd THEN
     DELETE FROM sga_evaluaciones_instancias WHERE evaluacion = pEvaluacion;
     
     -- Inserto las instancias de la evaluacion
     FOR i IN 1 .. _cant_instancias 
     LOOP
       INSERT INTO  sga_evaluaciones_instancias (evaluacion, instancia) VALUES (pEvaluacion, pInstancias[i]);
     END LOOP;
  END IF;
  
  IF pEvaluacionesRelUpd THEN
     DELETE FROM sga_evaluaciones_relacion WHERE evaluacion_hijo = pEvaluacion;
     
     -- Inserto las evluaciones relacionadas
     FOR i IN 1 .. _cant_relacion
     LOOP
       INSERT INTO  sga_evaluaciones_relacion (evaluacion_hijo, evaluacion_padre) VALUES (pEvaluacion, pEvaluacionesRel[i]);
     END LOOP;
  END IF;

  -- Error.
  EXCEPTION WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800CUR_evaluacion_upd_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800CUR_evaluacion_upd_ok';
  
  RETURN cur_retorno;

END;
$$;
