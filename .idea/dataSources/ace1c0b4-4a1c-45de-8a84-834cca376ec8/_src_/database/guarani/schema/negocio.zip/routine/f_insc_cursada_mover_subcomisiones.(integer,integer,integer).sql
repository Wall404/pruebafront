create function negocio.f_insc_cursada_mover_subcomisiones(pinscripcioncomision integer, psubcomisionorigen integer, psubcomisiondestino integer) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno type_retorno_inscripcion;
  _tipo_clase_origen INTEGER;
  _insc sga_insc_cursada%ROWTYPE;
  _cant integer;


BEGIN
  
  -- Variables 
  cur_retorno.resultado := -1;
  cur_retorno.mensaje_param  := NULL;
  _cant := 0;
  _tipo_clase_origen := NULL;
  
  

  -- 1. Verifico que exista la inscripcion a cursada
  SELECT * INTO _insc FROM sga_insc_cursada WHERE inscripcion = pInscripcionComision;
   
  IF NOT FOUND THEN
    -- No existe la inscripción a mover de comision.
    cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_no_existe_insc';
    RETURN cur_retorno;
  END IF;

  -- 2. Verifico que existan las subcomisiones
  SELECT sc.tipo_clase INTO _tipo_clase_origen
    FROM sga_insc_subcomision as ic, sga_subcomisiones as sc 
   WHERE ic.inscripcion = pInscripcionComision
     AND ic.subcomision = pSubcomisionOrigen
	 AND sc.subcomision = ic.subcomision
   LIMIT 1;
  IF NOT FOUND THEN
    -- No existe la inscripción a subcomision a mover
    cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_no_existe_subcom_origen';
    RETURN cur_retorno;
  END IF;  
  
  -- 3. Verifico que exista la subcomision destino y sea del mismo tipo
  SELECT count(*) INTO _cant 
    FROM sga_subcomisiones
   WHERE comision    = _insc.comision
     AND subcomision = pSubcomisionDestino
	 AND tipo_clase  = _tipo_clase_origen;
  
  IF _cant = 0 THEN
    -- No existe la subcomision destino o no es del mismo tipo de clase que la de origen.
    cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_no_existe_subcom_destino';
    RETURN cur_retorno;
  END IF;  

  -- Si el origen y destino son el mismo falla
  IF pSubcomisionOrigen = pSubcomisionDestino THEN
    cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_subcom_misma_subcom';
    RETURN cur_retorno;
  END IF;  
  
-- Comienza la Transacción
BEGIN


  -- Borro la inscripcion de la subcomision origen y actualizo el cupo
  DELETE FROM sga_insc_subcomision WHERE inscripcion = pInscripcionComision AND subcomision = pSubcomisionOrigen;
  UPDATE sga_subcomisiones_cupo SET cant_inscriptos = cant_inscriptos - 1  WHERE subcomision = pSubcomisionOrigen;

  -- Inserto la inscripcion en la subcomision destino y actualizo el cupo
  INSERT INTO sga_insc_subcomision (inscripcion, subcomision) VALUES (pInscripcionComision, pSubcomisionDestino);
  UPDATE sga_subcomisiones_cupo SET cant_inscriptos = cant_inscriptos + 1  WHERE subcomision = pSubcomisionDestino;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Se dan de baja los registros de asistencias del alumno en las clases de la subcomision origen
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  UPDATE	sga_clases_asistencia
  SET		estado = 'B'
  WHERE		sga_clases_asistencia.alumno = _insc.alumno
	    	AND sga_clases_asistencia.clase IN (SELECT sga_clases.clase
					    						FROM   sga_clases,
						   							   sga_comisiones_bh,
													   sga_subcomisiones_bh
					    						WHERE  sga_clases.banda_horaria = sga_comisiones_bh.banda_horaria
												  AND sga_comisiones_bh.comision = _insc.comision
												  AND sga_subcomisiones_bh.banda_horaria = sga_comisiones_bh.banda_horaria
												  AND sga_subcomisiones_bh.subcomision = pSubcomisionOrigen
						   						);
				
						   							   
  -- Error.
  EXCEPTION
      WHEN unique_violation THEN
        cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_existe_insc_subcom';
        cur_retorno.mensaje_param  := NULL;
        cur_retorno.sqlstate := SQLSTATE;
        cur_retorno.sqlerrm  := SQLERRM;
        RETURN cur_retorno;

     WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_error_db';
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.mensaje_indice := '800CUR_insc_cursada_mover_error_db';
        cur_retorno.mensaje_param  := NULL;
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- Cambio de comision OK. Seteo valores para retorno
  cur_retorno.resultado        := 1;
  cur_retorno.mensaje_indice   := '800CUR_insc_cursada_mover_ok';
  cur_retorno.inscripcion      := pInscripcionComision;
  
  -- Retorno datos del cambio de comision de la inscripcion a actividad.
  RETURN cur_retorno;

END;
$$;
