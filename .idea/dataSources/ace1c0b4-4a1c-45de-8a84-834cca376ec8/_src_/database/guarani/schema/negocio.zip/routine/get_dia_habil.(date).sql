create function negocio.get_dia_habil(pfecha date) returns date
LANGUAGE plpgsql
AS $$
DECLARE
 _fecha_retorno date;
 _i integer;
 _cur_dia record; 
 _flag boolean;
 _dia_de_la_semana integer;

BEGIN

 _flag := false;
 _fecha_retorno := pFecha;
 
 
 WHILE _flag = false
 LOOP
    SELECT COUNT(*) INTO _i FROM sga_dias_no_laborables WHERE fecha = _fecha_retorno;
	IF _i = 0 THEN
	  -- Es un dia laborable. Verifico que no caiga un Sabado o Domingo.
	  _dia_de_la_semana := date_part('dow', _fecha_retorno);
	  
	  IF _dia_de_la_semana = 0 THEN
	    -- Es un Domingo, sumo uno para que sea un Lunes y vuelvo a verificar si es no laborable  
		_fecha_retorno := _fecha_retorno + 1;
	  ELSEIF _dia_de_la_semana = 6 THEN	
	    -- Es un sabado, le sumo dos dias asi lo paso a un Lunes.
		_fecha_retorno := _fecha_retorno + 2;
	  ELSE 
        -- Salgo, es un dia habil laborable. 	  
	    _flag := true;
		EXIT;
	  END IF;
	ELSE
	   -- Continuo con el proximo dia.
	   _fecha_retorno := _fecha_retorno + 1;
	END IF;
 END LOOP;

  
 -- Retorno la fecha de un dia habil laborable.
 RETURN _fecha_retorno; 
 
END;
$$;
