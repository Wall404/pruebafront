create function negocio.f_periodos_inscripcion_comision(pcomision integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _periodo_insc  text;
  cur1 record;
        
BEGIN
   cnt := 0;	
   _periodo_insc := NULL;
		
  -- Recupero los periodos de inscripcion
  FOR cur1 IN 
       SELECT to_char(COALESCE(e.fecha_inicio,sga_periodos_inscripcion_fechas.fecha_inicio),'DD/MM/YYYY') as inicio,
              to_char(COALESCE(e.fecha_fin,sga_periodos_inscripcion_fechas.fecha_fin),'DD/MM/YYYY') as fin
         FROM sga_comisiones,
              sga_periodos_lectivos,
              sga_periodos,
              sga_periodos_inscripcion,
              sga_periodos_inscripcion_fechas
              LEFT JOIN sga_comisiones_excep_perinsc as e ON e.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc AND e.comision = pComision
        WHERE sga_comisiones.comision = pComision
          AND sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo
          AND sga_periodos.periodo = sga_periodos_lectivos.periodo
          AND sga_periodos_inscripcion.periodo = sga_periodos_lectivos.periodo
          AND sga_periodos_inscripcion_fechas.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion
          AND sga_periodos_inscripcion_fechas.habilitado = 'S'
  LOOP
      IF cnt = 0 THEN		
         _periodo_insc := cur1.inicio || ' al ' || cur1.fin;
      ELSE
         _periodo_insc :=  _periodo_insc || '|' || cur1.inicio || ' al ' || cur1.fin;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _periodo_insc;
    
END;
$$;
