create function negocio.f_copiar_escala_notas(pescalaorigen integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _escala_nueva integer;
  
BEGIN
	-- Se inserta la cabecera de la escala. Estado Activo.
	INSERT INTO sga_escalas_notas (nombre, descripcion, tipo, es_numerica, cantidad_decimales, separador_decimal, nota_inicial, nota_final, estado)
		SELECT 
			left(nombre || ' - copia', 50),
			descripcion,
			tipo,
			es_numerica,
			cantidad_decimales,
			separador_decimal,
			nota_inicial,
			nota_final,
			'A'
		FROM 
			sga_escalas_notas
		WHERE 
			escala_nota = pEscalaOrigen;
      
  -- Se recupera el serial de la nueva escala
  _escala_nueva := (SELECT currval('sga_escalas_notas_seq'));
  
  -- Se copian los detalles de la escala
	INSERT INTO sga_escalas_notas_det(escala_nota, nota, descripcion, concepto, resultado, valor_numerico, orden) 
		SELECT 
			_escala_nueva,
			nota,
			descripcion,
			concepto,
			resultado,
			valor_numerico,
			orden
		FROM 
			sga_escalas_notas_det
		WHERE
			escala_nota = pEscalaOrigen;
	
	-- sga_escalas_notas_rangos_resultados
	INSERT INTO sga_escalas_notas_rangos_resultados(escala_nota, resultado, nota_inicial, nota_final) 
		SELECT 
			_escala_nueva,
			resultado,
			nota_inicial,
			nota_final
		FROM 
			sga_escalas_notas_rangos_resultados
		WHERE
			escala_nota = pEscalaOrigen;
	
	-- sga_escalas_notas_rangos_conceptos
	INSERT INTO sga_escalas_notas_rangos_conceptos(escala_nota, concepto, nota_inicial, nota_final) 
		SELECT 
			_escala_nueva,
			concepto,
			nota_inicial,
			nota_final
		FROM 
			sga_escalas_notas_rangos_conceptos
		WHERE
			escala_nota = pEscalaOrigen;
	
	-- Se retorna el ID de la nueva escala
	return _escala_nueva;
 
END;
$$;
