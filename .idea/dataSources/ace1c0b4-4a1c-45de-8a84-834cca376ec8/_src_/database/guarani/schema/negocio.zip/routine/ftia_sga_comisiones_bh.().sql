create function negocio.ftia_sga_comisiones_bh() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _dia_semana varchar(10);
  _periodicidad  varchar(10);
  _fecha_desde date;
  _fecha_hasta date;
  _cant_clases integer;
  _cantidad_horas numeric(5,2);
BEGIN
   -- Crea las clases en sga_clases segun asignación y comision.
   SELECT fecha_desde, fecha_hasta, periodicidad, dia_semana, cantidad_horas 
     INTO _fecha_desde, _fecha_hasta, _periodicidad, _dia_semana, _cantidad_horas
     FROM sga_asignaciones
     WHERE asignacion = NEW.asignacion; 
     
   _cant_clases := f_crear_clases_banda_horaria(NEW.banda_horaria, _fecha_desde, _fecha_hasta, _periodicidad, _dia_semana, _cantidad_horas);
   
   RETURN NEW;
END;
$$;
