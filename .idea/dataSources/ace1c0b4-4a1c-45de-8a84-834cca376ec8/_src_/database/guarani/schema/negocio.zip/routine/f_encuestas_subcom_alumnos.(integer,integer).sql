create function negocio.f_encuestas_subcom_alumnos(palumno integer, pcomision integer) returns integer[]
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  k integer;
  _subcomisiones Integer[];
  cur1 record;

  BEGIN
   cnt := 0;
   _subcomisiones := NULL;

  -- Recupero el nombre de los docentes
  FOR cur1 IN SELECT i.subcomision
                FROM sga_insc_cursada as c,
                     sga_insc_subcomision as i,
                     sga_subcomisiones as subco
               WHERE c.comision = pComision 
                 AND c.alumno = pAlumno
                 AND i.inscripcion = c.inscripcion
                 AND subco.subcomision = i.subcomision
            ORDER BY subco.tipo_clase 
  LOOP
      cnt := cnt + 1;
      _subcomisiones[cnt] := cur1.subcomision;
  END LOOP;

  RETURN _subcomisiones;

END;
$$;
