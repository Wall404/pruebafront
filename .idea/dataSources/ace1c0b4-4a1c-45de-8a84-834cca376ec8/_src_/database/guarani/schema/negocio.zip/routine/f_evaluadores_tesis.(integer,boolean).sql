create function negocio.f_evaluadores_tesis(_tesis integer, pmostrarrol boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _evaluadores text;
  cur1 record;
        
  BEGIN
  
   _evaluadores := '';
        
  -- Recupero el nombre de los evaluadores
  FOR cur1 IN SELECT vw_personas.apellido_nombres,
  					 sga_tesis_roles_evaluador.nombre as nombre_rol
                      FROM sga_tesis_evaluadores, sga_tesis_roles_evaluador, vw_personas
                      WHERE sga_tesis_evaluadores.tesis = _tesis
                      AND sga_tesis_evaluadores.persona = vw_personas.persona
                      AND sga_tesis_evaluadores.rol_evaluador = sga_tesis_roles_evaluador.rol_evaluador
			ORDER BY vw_personas.apellido_nombres
  LOOP
         
        IF pMostrarRol THEN
     		_evaluadores :=  _evaluadores || ' - ' || cur1.apellido_nombres || ' (' || cur1.nombre_rol || ')';
   		ELSE
     		_evaluadores :=  _evaluadores || ' - ' || cur1.apellido_nombres;
   		END IF;  
   		
  END LOOP;
  
  _evaluadores := trim(leading ' - ' from _evaluadores);

  RETURN _evaluadores;
    
END;
$$;
