create function negocio.get_ultimo_dato_censal(ppersona integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE iDatoCensal Integer;
BEGIN
   iDatoCensal := NULL;
   
   SELECT dato_censal INTO iDatoCensal
   	FROM mdp_datos_censales
	WHERE persona = pPersona;

  -- Retorno el id del Dato Censal de la persona
  Return iDatoCensal;
	
END;
$$;
