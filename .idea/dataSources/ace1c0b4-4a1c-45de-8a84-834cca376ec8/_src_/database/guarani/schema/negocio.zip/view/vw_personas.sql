CREATE VIEW vw_personas AS SELECT mdp_personas.persona,
    mdp_personas.apellido,
    mdp_personas.nombres,
    (((mdp_personas.apellido)::text || ' '::text) || (mdp_personas.nombres)::text) AS apellido_nombres,
    COALESCE(mdp_personas.apellido_elegido, mdp_personas.apellido) AS apellido_elegido,
    COALESCE(mdp_personas.nombres_elegido, mdp_personas.nombres) AS nombres_elegido,
    (((COALESCE(mdp_personas.apellido_elegido, mdp_personas.apellido))::text || ' '::text) || (COALESCE(mdp_personas.nombres_elegido, mdp_personas.nombres))::text) AS apellido_nombres_elegido,
    mdp_personas.sexo,
    mdp_personas.nacionalidad,
    mdp_personas.usuario,
    mdp_personas_documentos.documento,
    mdp_personas_documentos.nro_documento,
    mdp_personas_documentos.tipo_documento,
    mdp_tipo_documento.desc_abreviada AS desc_tipo_documento,
    (((mdp_tipo_documento.desc_abreviada)::text || ' '::text) || (mdp_personas_documentos.nro_documento)::text) AS tipo_nro_documento,
    mdp_personas.id_imagen
   FROM ((negocio.mdp_personas
     LEFT JOIN negocio.mdp_personas_documentos ON ((mdp_personas_documentos.documento = mdp_personas.documento_principal)))
     LEFT JOIN negocio.mdp_tipo_documento ON ((mdp_tipo_documento.tipo_documento = mdp_personas_documentos.tipo_documento)));
