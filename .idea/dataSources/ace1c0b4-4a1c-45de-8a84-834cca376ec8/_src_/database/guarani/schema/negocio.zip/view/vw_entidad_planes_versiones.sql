CREATE VIEW vw_entidad_planes_versiones AS SELECT DISTINCT sga_instituciones.entidad,
    sga_planes_versiones.plan_version
   FROM negocio.sga_planes_versiones,
    negocio.sga_planes,
    negocio.sga_propuestas_ra,
    negocio.sga_responsables_academicas,
    negocio.sga_instituciones
  WHERE (((((sga_planes_versiones.plan = sga_planes.plan) AND (sga_planes_versiones.estado = ANY (ARRAY['V'::bpchar, 'A'::bpchar]))) AND (sga_planes.propuesta = sga_propuestas_ra.propuesta)) AND (sga_propuestas_ra.responsable_academica = sga_responsables_academicas.responsable_academica)) AND (sga_responsables_academicas.institucion = sga_instituciones.institucion))
UNION
 SELECT DISTINCT sga_responsables_academicas.entidad,
    sga_planes_versiones.plan_version
   FROM negocio.sga_planes_versiones,
    negocio.sga_planes,
    negocio.sga_propuestas_ra,
    negocio.sga_responsables_academicas
  WHERE ((((sga_planes_versiones.plan = sga_planes.plan) AND (sga_planes_versiones.estado = ANY (ARRAY['V'::bpchar, 'A'::bpchar]))) AND (sga_planes.propuesta = sga_propuestas_ra.propuesta)) AND (sga_propuestas_ra.responsable_academica = sga_responsables_academicas.responsable_academica))
UNION
 SELECT DISTINCT sga_propuestas.entidad,
    sga_planes_versiones.plan_version
   FROM negocio.sga_planes_versiones,
    negocio.sga_planes,
    negocio.sga_propuestas
  WHERE (((sga_planes_versiones.plan = sga_planes.plan) AND (sga_planes_versiones.estado = ANY (ARRAY['V'::bpchar, 'A'::bpchar]))) AND (sga_planes.propuesta = sga_propuestas.propuesta))
UNION
 SELECT DISTINCT sga_planes.entidad,
    sga_planes_versiones.plan_version
   FROM negocio.sga_planes_versiones,
    negocio.sga_planes
  WHERE ((sga_planes_versiones.plan = sga_planes.plan) AND (sga_planes_versiones.estado = ANY (ARRAY['V'::bpchar, 'A'::bpchar])))
UNION
 SELECT sga_planes_versiones.entidad,
    sga_planes_versiones.plan_version
   FROM negocio.sga_planes_versiones
  WHERE (sga_planes_versiones.estado = ANY (ARRAY['V'::bpchar, 'A'::bpchar]));
