create function negocio.get_pais_localidad(plocalidad integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
	_pais integer;
BEGIN
	SELECT	mug_provincias.pais INTO _pais
	FROM	mug_localidades,
			mug_dptos_partidos,
			mug_provincias
	WHERE	mug_localidades.dpto_partido = mug_dptos_partidos.dpto_partido AND
			mug_dptos_partidos.provincia = mug_provincias.provincia AND
			mug_localidades.localidad = pLocalidad;

	RETURN _pais;
END;
$$;
