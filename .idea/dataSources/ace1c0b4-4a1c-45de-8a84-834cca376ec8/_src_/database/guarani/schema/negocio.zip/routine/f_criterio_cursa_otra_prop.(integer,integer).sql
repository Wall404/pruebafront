create function negocio.f_criterio_cursa_otra_prop(_persona integer, _propuesta integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _cnt integer;

BEGIN
  _cnt := 1; -- no cursa otra propuesta
  SELECT COUNT(*) INTO _cnt
    FROM sga_alumnos
    WHERE persona = _persona
      AND propuesta <> _propuesta
      AND calidad = 'A';
  
  IF _cnt > 0 THEN
    -- Cursa al menos otra propuesta (Alumno Activo)
    RETURN 0;
  ELSE  
    -- No cursa otra propuesta
    RETURN 1;
  END IF;  

END;
$$;
