create function negocio.get_nombres_modulos(pelemento integer, pplanversion integer, pcontador integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
  rec record;
  rtn TEXT;
  _nombre_elemento text;
  _nombre_modulo text;
  _elemento_nombre text;
  _elemento integer;
BEGIN
  IF pContador = 10 THEN
      -- Salgo para que no se haga infinito..
      RAISE EXCEPTION 'Loop !!!';
  END IF;

  -- Recupero el nombre del elemento  
  SELECT nombre INTO _elemento_nombre FROM vw_elementos_plan WHERE elemento = pElemento AND plan_version = pPlanVersion;
  
  -- Recupero el nombre del modulo donde esta padre
  _elemento := NULL;
  SELECT padre.elemento, padre.nombre 
    INTO _elemento, _nombre_modulo
    FROM vw_elementos_plan as ep,
         sga_elementos_comp as modulo,
         vw_elementos as padre,
         sga_planes_versiones as pv
   WHERE ep.elemento = pElemento
     AND ep.plan_version = pPlanVersion
     AND modulo.elemento_hijo = ep.elemento_revision
     AND modulo.elemento_padre = padre.elemento_revision
     AND pv.plan_version = pPlanVersion
     AND pv.elemento_revision <> padre.elemento_revision -- Que el modulo padre no sea el modulo raiz.
  LIMIT 1; -- Por si el elemento esta en mas de un modulo, solo recupero el primero que encuentra.

  IF _elemento IS NOT NULL AND FOUND THEN
    IF pContador = 1 THEN
      -- No devuelvo el nombre de la actividad 
      RETURN get_nombres_modulos( _elemento, pPlanVersion, pContador + 1) ;
    ELSE
      RETURN _elemento_nombre || '/' || get_nombres_modulos( _elemento, pPlanVersion, pContador + 1) ;
    END IF;

  ELSE
    -- llegue a donde el padre es el elemento raiz. Devuelvo el nombre del elemento.
    RETURN _elemento_nombre;
  END IF;

END;
$$;
