create function negocio.f_instancias_comision_escala_notas(pcomision integer, pmostrarescalanotas boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _retorno := NULL;
		
  -- Recupero el nombre de las modalidades de cursada
  FOR cur1 IN SELECT sga_instancias.nombre as instancia_nombre,
                     sga_escalas_notas.nombre as escala_nota_nombre
                FROM sga_comisiones_instancias, 
                     sga_instancias,
                     sga_escalas_notas
               WHERE sga_comisiones_instancias.comision = pComision
                 AND sga_comisiones_instancias.instancia = sga_instancias.instancia
                 AND sga_escalas_notas.escala_nota = sga_comisiones_instancias.escala_nota
  LOOP
      IF cnt = 0 THEN		
         _retorno :=  cur1.instancia_nombre;
      ELSE
         _retorno :=  _retorno || ' / ' || cur1.instancia_nombre;
      END IF;   
      IF pMostrarEscalaNotas THEN
         _retorno :=  _retorno || ' (' || cur1.escala_nota_nombre || ')';
      END IF;
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
