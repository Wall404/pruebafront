create function negocio.ftia_sga_docentes_comision() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

  -- Pego los derechos del rol del docente.    
  INSERT INTO gdu_derechos_personas (entidad, derecho, persona)
       SELECT sga_comisiones.entidad, 
              gdu_comision.derecho, 
              sga_docentes.persona
         FROM sga_comisiones,
              gdu_comision,
              sga_docentes
        WHERE sga_comisiones.comision = NEW.comision
          AND gdu_comision.responsabilidad = NEW.responsabilidad
          AND sga_docentes.docente = NEW.docente;

  RETURN NEW;
END;
$$;
