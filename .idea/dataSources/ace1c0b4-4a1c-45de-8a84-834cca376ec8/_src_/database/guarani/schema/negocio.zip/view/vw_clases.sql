CREATE VIEW vw_clases AS SELECT sga_comisiones.comision,
    sga_comisiones.nombre AS comision_nombre,
    sga_clases.clase,
    sga_clases.fecha,
    sga_comisiones_bh.tipo_clase,
    sga_clases_tipos.nombre AS tipo_clase_nombre,
    sga_clases.id_tramo,
    sga_periodos_lectivos_tramos.nro_tramo,
    sga_periodos_lectivos_tramos.fecha_inicio AS fecha_inicio_tramo,
    sga_periodos_lectivos_tramos.fecha_fin AS fecha_fin_tramo,
    sga_clases.cantidad_horas_dictadas,
    sga_clases.valido,
    sga_comisiones_bh.banda_horaria,
    sga_comisiones_bh.asignacion,
    sga_asignaciones.dia_semana,
    sga_asignaciones.hora_inicio,
    sga_asignaciones.hora_finalizacion
   FROM (negocio.sga_clases
     LEFT JOIN negocio.sga_periodos_lectivos_tramos ON ((sga_periodos_lectivos_tramos.id_tramo = sga_clases.id_tramo))),
    negocio.sga_comisiones_bh,
    negocio.sga_comisiones,
    negocio.sga_asignaciones,
    negocio.sga_clases_tipos
  WHERE ((((sga_comisiones_bh.banda_horaria = sga_clases.banda_horaria) AND (sga_comisiones.comision = sga_comisiones_bh.comision)) AND (sga_asignaciones.asignacion = sga_comisiones_bh.asignacion)) AND (sga_clases_tipos.tipo_clase = sga_comisiones_bh.tipo_clase));
