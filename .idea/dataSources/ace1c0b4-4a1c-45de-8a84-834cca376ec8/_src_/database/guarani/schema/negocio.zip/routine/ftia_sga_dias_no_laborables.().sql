create function negocio.ftia_sga_dias_no_laborables() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    -- Setea como clases invalidas las que se correspondan con el dia no laborable
    UPDATE sga_clases 
      SET valido = 0,
          motivo_invalidacion = 1
     WHERE fecha = NEW.fecha;
    
    RETURN NEW;
  END;
$$;
