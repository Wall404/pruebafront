create function negocio.ftua_sga_evaluaciones() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _cnt smallint;
  
  BEGIN
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Evaluaciones de las Comisiones - Cambio de escala de notas
   -- Si cambia la escala de notas, se la cambio a todos los alumnos de la evaluacion
   -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   IF (NEW.escala_nota <> OLD.escala_nota) THEN
      SELECT COUNT(*) INTO _cnt
        FROM sga_evaluaciones_tipos
        WHERE evaluacion_tipo = NEW.evaluacion_tipo
          AND aplica_a   = 'C' -- Comisiones
          AND automatica = 'N'; -- No automática
      
      IF _cnt > 0 THEN
        -- Actualizo escala de notas a todos los alumnos de la evaluacion
        UPDATE sga_eval_detalle
          SET escala_nota = NEW.escala_nota
          WHERE evaluacion = NEW.evaluacion;
      END IF;  
   END IF;     
   RETURN NEW;
  END;
$$;
