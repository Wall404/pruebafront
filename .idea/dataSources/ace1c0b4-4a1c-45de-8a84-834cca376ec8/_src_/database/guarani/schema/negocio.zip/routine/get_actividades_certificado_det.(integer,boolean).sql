create function negocio.get_actividades_certificado_det(pelementorevision integer, pdevolvermodulos boolean DEFAULT false) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE 
	hijos record;
	cur_actividades record;
BEGIN
	-- Elementos que contiene el módulo.
	FOR hijos IN 
		SELECT	sga_elementos.elemento,
				sga_g3entidades_subtipos.entidad_tipo,
				sga_elementos_revision.elemento_revision
		FROM	sga_elementos_comp,
				sga_elementos_revision,
				sga_elementos,
				sga_g3entidades_subtipos
		WHERE	sga_elementos_comp.elemento_hijo = sga_elementos_revision.elemento_revision AND
				sga_elementos_revision.elemento = sga_elementos.elemento AND
				sga_elementos.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo AND
				sga_elementos_comp.elemento_padre = pElementoRevision
	LOOP
		IF pDevolverModulos AND hijos.entidad_tipo = 1 THEN
			-- Devuelvo el id del modulo
			RETURN NEXT hijos.elemento;
		END IF;	
		IF hijos.entidad_tipo = 2 THEN
			-- Devuelvo el id de la actividad
			RETURN NEXT hijos.elemento;
		ELSE
			-- Llamo de nuevo a la funcion para ver si alguno de los hijos del modulo es una orientacion.
			FOR cur_actividades IN
				SELECT	cast(get_actividades_certificado_det as integer) as elemento
				FROM	get_actividades_certificado_det(hijos.elemento_revision)
			LOOP
				RETURN NEXT cur_actividades.elemento;
			END LOOP; -- Actividades.
		END IF;
	END LOOP; -- Componentes del módulo.
END;
$$;
