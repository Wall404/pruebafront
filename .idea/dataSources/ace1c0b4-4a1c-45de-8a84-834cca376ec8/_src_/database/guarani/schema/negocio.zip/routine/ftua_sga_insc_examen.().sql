create function negocio.ftua_sga_insc_examen() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion integer;
  DECLARE _escala_nota integer;
  DECLARE _fecha_examen date; 
  DECLARE cnt smallint;
  
  BEGIN
    -- Si acepto la inscripcion
    IF (NEW.estado = 'A' AND OLD.estado = 'P') THEN
      -- Recupero la evaluacion automática de la mesa y llamado
      SELECT sga_evaluaciones.evaluacion, sga_mesas_examen_instancias.escala_nota, sga_llamados_mesa.fecha
          INTO _evaluacion, _escala_nota, _fecha_examen 
          FROM sga_llamados_mesa, 
               sga_evaluaciones, 
               sga_evaluaciones_tipos, 
               sga_mesas_examen, 
               sga_mesas_examen_instancias 
          WHERE sga_llamados_mesa.llamado_mesa = NEW.llamado_mesa
            AND sga_evaluaciones.entidad       = sga_llamados_mesa.entidad
            AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
            AND sga_evaluaciones_tipos.automatica = 'S' -- Generación Automática
            AND sga_mesas_examen.mesa_examen   = sga_llamados_mesa.mesa_examen  
            AND sga_mesas_examen_instancias.mesa_examen = sga_mesas_examen.mesa_examen
            AND sga_mesas_examen_instancias.instancia   = NEW.instancia;
          
      IF _evaluacion IS NOT NULL THEN
         -- Si se acepta  una inscripción que estaba en estado "Pendiente"
         IF (NEW.estado = 'A' AND OLD.estado = 'P') THEN
            SELECT COUNT(*) INTO cnt
             FROM sga_eval_detalle_examenes 
             WHERE evaluacion = _evaluacion
               AND alumno = NEW.alumno;
            
            IF cnt = 0 THEN
               -- Inserto la inscripción en el detalle de la evaluacion automática.    
               INSERT INTO sga_eval_detalle_examenes (evaluacion, alumno, instancia, escala_nota, fecha, inscripto, plan_version)
                    VALUES ( _evaluacion, NEW.alumno, NEW.instancia, _escala_nota, _fecha_examen, 'S', NEW.plan_version); 
            END IF;
         END IF; -- cambio de estado
       END IF; -- evaluacion
       
        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        -- Inserto un registro por cada evaluacion (de generacion manual) en el detalle
        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       INSERT INTO sga_eval_detalle (evaluacion, alumno, escala_nota, fecha)
        	 SELECT  sga_evaluaciones.evaluacion, NEW.alumno, sga_evaluaciones.escala_nota, _fecha_examen
             FROM sga_llamados_mesa, sga_evaluaciones, sga_evaluaciones_tipos
              WHERE sga_llamados_mesa.llamado_mesa = NEW.llamado_mesa
                AND sga_evaluaciones.entidad       = sga_llamados_mesa.entidad
                AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
                AND sga_evaluaciones_tipos.automatica = 'N'; -- Generación Manual

    END IF;	-- cambio de estado de la inscripcion     
     
    RETURN NEW;
  END;
$$;
