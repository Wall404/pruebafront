CREATE VIEW vw_formularios_items AS SELECT h.habilitacion,
    h.kolla_id_habilitacion,
    f.formulario,
    f.titulo AS formulario_titulo,
    f.comision AS formulario_comision,
    f.subcomisiones,
    i.item,
    i.titulo AS item_titulo,
    i.encuesta,
    e.elemento AS actividad,
    e.nombre AS actividad_nombre,
    e.codigo AS actividad_codigo,
    i.comision,
    c.nombre AS comision_nombre,
    i.subcomision,
    sc.nombre AS subcomision_nombre,
    tc.descripcion AS tipo_clase,
    i.docente,
    d.legajo AS docente_legajo,
    p.apellido AS docente_apellido,
    p.nombres AS docente_nombres,
    r.descripcion AS docente_responsabilidad,
    f.estado AS formulario_estado,
    i.estado AS item_estado
   FROM negocio.gde_formularios f,
    negocio.gde_formulario_items fi,
    ((((((((negocio.gde_items i
     LEFT JOIN negocio.sga_docentes d ON ((d.docente = i.docente)))
     LEFT JOIN negocio.mdp_personas p ON ((p.persona = d.persona)))
     LEFT JOIN negocio.sga_comisiones c ON ((c.comision = i.comision)))
     LEFT JOIN negocio.sga_elementos e ON ((e.elemento = c.elemento)))
     LEFT JOIN negocio.sga_subcomisiones sc ON ((sc.subcomision = i.subcomision)))
     LEFT JOIN negocio.sga_clases_tipos tc ON ((tc.tipo_clase = sc.tipo_clase)))
     LEFT JOIN negocio.sga_docentes_comision dc ON (((dc.comision = i.comision) AND (dc.docente = i.docente))))
     LEFT JOIN negocio.sga_docentes_responsabilidades r ON ((r.responsabilidad = dc.responsabilidad))),
    negocio.gde_habilitaciones h
  WHERE (((fi.formulario = f.formulario) AND (i.item = fi.item)) AND (h.habilitacion = i.habilitacion));
