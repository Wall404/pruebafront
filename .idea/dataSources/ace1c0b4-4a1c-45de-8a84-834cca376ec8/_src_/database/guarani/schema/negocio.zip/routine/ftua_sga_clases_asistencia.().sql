create function negocio.ftua_sga_clases_asistencia() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   
  -- Actualizo registro acumulado de inasistencias o inasist justificadas si fue modificado.
  PERFORM f_asistencia_actualizar_acumulado('U', NEW.alumno, NEW.clase, OLD.cant_inasistencias, OLD.cant_justificadas, NEW.cant_inasistencias, NEW.cant_justificadas); 
  
  RETURN NEW;
END;
$$;
