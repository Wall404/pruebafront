create function negocio.ftub_sga_actas() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
   -- No se permite modificar datos de la cabecera del acta si la misma esta Cerrada y/o Anulada
   IF (OLD.estado = 'C' OR OLD.estado = 'B') AND OLD.estado = NEW.estado THEN  
      IF (OLD.origen <> NEW.origen OR
          OLD.tipo_acta <> NEW.tipo_acta OR
          OLD.evaluacion <> NEW.evaluacion OR
          OLD.comision <> NEW.comision OR
          OLD.llamado_mesa <> NEW.llamado_mesa OR
          OLD.renglones_folio <> NEW.renglones_folio OR
          OLD.acta_referencia <> NEW.acta_referencia OR
          OLD.fecha_generacion <> NEW.fecha_generacion OR
          OLD.fecha_cierre <> NEW.fecha_cierre OR
          OLD.fecha_anulacion <> NEW.fecha_anulacion OR
          OLD.nua <> NEW.nua OR
          OLD.documento <> NEW.documento
          ) THEN
          -- Los campos: nro_acta, version, version_impresa y nro_ultima_copia se permiten modificar en actas
          -- cerradas o anuladas porque podrian cambiarse datos de la mesa (el nombre, ubicacion, fecha, docentes)		  
		  -- el cual implica reimprimir el acta. El nro de acta podria cambiarse si el ingreso es manual.
          IF OLD.estado = 'C' THEN
             raise exception 'No se puede modificar datos del acta porque esta Cerrada';
          ELSEIF OLD.estado = 'B' THEN
             raise exception 'No se puede modificar datos del acta porque esta Anulada';
          END IF ;
      END IF;
   END IF;
   
   RETURN NEW;
END;
$$;
