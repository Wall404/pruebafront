create function negocio.f_acta_examen_alta(pnroacta character varying, pevaluacion integer, pllamado_mesa integer, pfecha character varying, pinstancias text[], prenglonesfolio integer, pobservacionesacta character varying) returns negocio.type_retorno_creacion_acta_examen
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno  type_retorno_creacion_acta_examen;
  _id_acta Integer;
  vFecha Date;


  i Integer;
  _cant_instancias Integer;

BEGIN


  -- Variables de retorno
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800EXA_acta_examen_alta_ok';
  cur_retorno.mensaje_param  := NULL;
 
    
  -- Recupero valores de los arreglos
  _cant_instancias := 0;
  IF pInstancias IS NOT NULL THEN
    -- _cant_instancias := array_lenght(pInstancias[]); -- Para version 9.0 en adelante
    _cant_instancias := (select array_upper(pInstancias , 1) - array_lower(pInstancias ,1) + 1);
  END IF;
  IF _cant_instancias = 0 THEN 
    -- Error
  END IF;
  
    
  -- Seteo Variables
  vFecha := to_date(pFecha, 'DD/MM/YYYY');

-- Comienzo transacción.
BEGIN

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Genero el Acta de Examen
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 INSERT INTO sga_actas (nro_acta, evaluacion, llamado_mesa, origen, tipo_acta, fecha_generacion, observaciones, estado, renglones_folio)
  VALUES (pNroActa, pEvaluacion, pLlamado_mesa, 'E', 'N', vFecha, pObservacionesActa, 'A', pRenglonesFolio);

  _id_acta = (SELECT currval('sga_actas_seq'));
  
  -- Instancias del Acta
  FOR i IN 1 .. _cant_instancias 
  LOOP
	INSERT INTO sga_actas_instancias (id_acta, instancia, escala_nota) VALUES (_id_acta, pInstancias[i][1]::smallint, pInstancias[i][2]::integer);
  END LOOP;


  -- Error.
  EXCEPTION WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800EXA_acta_examen_alta_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800EXA_acta_examen_alta_ok';
  cur_retorno.id_acta = cast(_id_acta as text);
  
  
  RETURN cur_retorno;

END;
$$;
