create function negocio.ftdb_mdp_personas_documentos() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;   
  _documento integer;

BEGIN

   -- Cambio el documento principal de la persona
   SELECT COUNT(*) INTO cnt
     FROM mdp_personas
     WHERE persona = OLD.persona
       AND documento_principal = OLD.documento;
   
   IF cnt > 0 THEN
     _documento := NULL;
     -- Recupero el documento que queda como principal.
     SELECT documento INTO _documento
       FROM mdp_personas_documentos, 
            mdp_tipo_documento
       WHERE persona = OLD.persona
         AND documento <> OLD.documento
         AND mdp_personas_documentos.tipo_documento = mdp_tipo_documento.tipo_documento
       ORDER BY mdp_tipo_documento.orden_principal ASC
       LIMIT 1;
         
      -- Actualizo el documento principal de la persona.
      UPDATE mdp_personas 
         SET documento_principal = _documento
       WHERE persona = OLD.persona;
       
   END IF;

   RETURN OLD;
END;
$$;
