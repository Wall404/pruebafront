create function negocio.f_evaluacion_alta(pcomision integer, pnombre character varying, pdescripcion character varying, pevaluaciontipo integer, pfecha character varying, phorainicio character varying, phorafin character varying, pescalanota integer, pvisiblealalumno character, ppromediable character, pinstancias integer[], pevaluacionesrel integer[]) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno	type_retorno_funcion;
  _evaluacion	Integer;
  _entidad	Integer;
  i Integer;
  _cant_instancias Integer;
  _cant_relacion Integer;
  vFecha Date;
  vHI Time;
  vHF Time;

BEGIN
/* Formato de los datos:
   pFecha      = DD/MM/YYY
   pHoraInicio = HH:MM
   pHoraFin    = HH:MM
*/  

  -- Variables de retorno
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800CUR_evaluacion_alta_ok';
  cur_retorno.mensaje_param  := NULL;
  
  SELECT entidad INTO _entidad FROM sga_comisiones WHERE comision = pComision;
  
  _cant_instancias := 0;
  IF pInstancias IS NOT NULL THEN
    -- _cant_instancias := array_lenght(pInstancias[]); -- Para version 9.0 en adelante
    _cant_instancias := (select array_upper( pInstancias , 1) - array_lower( pInstancias ,1) + 1);
  END IF;

  _cant_relacion := 0;
  IF pEvaluacionesRel IS NOT NULL THEN
    -- _cant_relacion := array_lenght(pEvaluacionesRel[]); -- Para version 9.0 en adelante
    _cant_relacion := (select array_upper( pEvaluacionesRel , 1) - array_lower( pEvaluacionesRel ,1) + 1);
  END IF;
  
-- Comienzo transacción.
BEGIN


  -- Alta de la evaluacion
  vFecha := to_date(pFecha, 'DD/MM/YYYY');
  vHI := pHoraInicio::time;
  vHF := pHoraFin::time;
  INSERT INTO sga_evaluaciones (entidad, nombre, descripcion, evaluacion_tipo, visible_al_alumno, promediable, fecha, hora_inicio, hora_fin, escala_nota, estado)
     VALUES (_entidad, pNombre, pDescripcion, pEvaluacionTipo, pVisibleAlAlumno, pPromediable, vFecha, vHI, vHF, pEscalaNota, 'A');

  -- Recupero el Serial de la inscripcion
  _evaluacion := (SELECT currval('sga_evaluaciones_seq'));

  -- Inserto las instancias de la evaluacion
  FOR i IN 1 .. _cant_instancias 
  LOOP
    INSERT INTO  sga_evaluaciones_instancias (evaluacion, instancia) VALUES (_evaluacion, pInstancias[i]);
  END LOOP;

  -- Inserto las evluaciones relacionadas
  FOR i IN 1 .. _cant_relacion
  LOOP
    INSERT INTO  sga_evaluaciones_relacion (evaluacion_hijo, evaluacion_padre) VALUES (_evaluacion, pEvaluacionesRel[i]);
  END LOOP;


  -- Error.
  EXCEPTION WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800CUR_evaluacion_alta_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800CUR_evaluacion_alta_ok';
  
  RETURN cur_retorno;

END;
$$;
