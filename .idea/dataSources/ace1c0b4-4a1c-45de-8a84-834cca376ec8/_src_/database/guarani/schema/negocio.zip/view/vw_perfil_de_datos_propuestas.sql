CREATE VIEW vw_perfil_de_datos_propuestas AS SELECT sga_propuestas.propuesta,
    sga_propuestas.nombre,
    sga_propuestas.nombre_abreviado,
    sga_propuestas.codigo,
    sga_propuestas.propuesta_tipo,
    sga_propuestas.estado,
    ((('('::text || (sga_propuestas.codigo)::text) || ') '::text) || (sga_propuestas.nombre_abreviado)::text) AS propuesta_descripcion
   FROM negocio.sga_propuestas;
