create function negocio.get_forma_ingreso_araucano_nominal(palumno integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
	_anio_academico_ingreso numeric;
	_fecha_fin_anio_academico_ingreso date;
	_fecha_inscripcion date;
	_cant_equivalencias integer;
	_cant_reconocimientos integer;
	_codigo_forma_ingreso integer;
BEGIN
	_codigo_forma_ingreso := 1;
	
	-- Recupero año de ingreso en la propuesta.
	SELECT	sga_propuestas_aspira.anio_academico, sga_propuestas_aspira.fecha_inscripcion 
	  INTO _anio_academico_ingreso, _fecha_inscripcion
	FROM	sga_alumnos,
			sga_propuestas_aspira,
			sga_situacion_aspirante
	WHERE	sga_alumnos.persona = sga_propuestas_aspira.persona AND
			sga_alumnos.propuesta = sga_propuestas_aspira.propuesta AND
			sga_propuestas_aspira.situacion_asp = sga_situacion_aspirante.situacion_asp AND
			sga_situacion_aspirante.resultado_asp IN ('A', 'P') AND
			sga_alumnos.alumno = pAlumno;
	_fecha_fin_anio_academico_ingreso := _anio_academico_ingreso + 1 || '-03-31';

	
	-- Equivalencia Total/Parcial/Regularidad...o Aprobaciones por resolucion.
	_cant_equivalencias := 0;
	SELECT COUNT(*) INTO _cant_equivalencias
	  FROM int_arau_nominal_ha
	 WHERE alumno = pAlumno 
	   AND origen IN ('Equivalencia', 'Aprob. por Resolución') 
	   AND fecha BETWEEN _fecha_inscripcion AND _fecha_fin_anio_academico_ingreso;

	IF _cant_equivalencias > 0 THEN
		_codigo_forma_ingreso := 2;
	ELSE
		_codigo_forma_ingreso := 1;
	END IF;
	  
	
	RETURN _codigo_forma_ingreso;
END;
$$;
