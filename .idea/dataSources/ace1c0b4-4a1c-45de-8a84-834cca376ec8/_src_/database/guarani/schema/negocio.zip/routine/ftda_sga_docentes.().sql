create function negocio.ftda_sga_docentes() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _cnt smallint;
BEGIN

  -- Borro el tipo de usuario Docente al docente que se esta borrando.
  DELETE FROM mdp_personas_tipo_usuario WHERE persona = OLD.persona AND tipo_usuario = 'Docente';

  RETURN OLD;
END;
$$;
