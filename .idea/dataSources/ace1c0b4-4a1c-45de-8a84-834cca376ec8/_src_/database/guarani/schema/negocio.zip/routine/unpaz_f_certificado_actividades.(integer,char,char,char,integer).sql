create function negocio.unpaz_f_certificado_actividades(palumno integer, presultado character, porigen character, pplanversionactual character, pcertificado integer) returns TABLE(actividad_codigo character varying, elemento integer, actividad_nombre character varying, fecha character, nota character varying, nota_descripcion character varying, tipo character varying, actividad_documento character varying, folio_fisico integer, creditos numeric, plan_codigo character varying, plan_nombre character varying, origen character, nro_acta character varying, resultado_descripcion character varying)
LANGUAGE plpgsql
AS $$
DECLARE 
  _PropuestaAlumno Integer;
  _PlanVersionAlumno Integer;
  _PlanAlumno Integer;
  _Persona Integer;

BEGIN


CREATE TABLE _temp_prop_alumno (alumno integer, propuesta integer, plan integer, orden integer);
CREATE TABLE _temp_relacion (relacion integer);

 -- +++++++++++++++++++++++++++++++++++++++++++++++++
 -- Actividades de propuestas vinculadas a la propuesta del alumno
 -- +++++++++++++++++++++++++++++++++++++++++++++++++
 SELECT a.persona, a.propuesta, a.plan_version, v.plan  
   INTO _Persona, _PropuestaAlumno, _PlanVersionAlumno, _PlanAlumno
   FROM sga_alumnos as a, 
        sga_planes_versiones as v
  WHERE a.plan_version = v.plan_version
    AND a.alumno = pAlumno;


 -- Propuesta del alumno  y plan actual
 INSERT INTO _temp_prop_alumno (alumno, propuesta, plan, orden) VALUES (pAlumno, _PropuestaAlumno, _PlanAlumno, 1);
 
 
 -- Propuestas Vinculadas
 INSERT INTO _temp_relacion (relacion) SELECT * FROM get_relacion_propuesta(pAlumno);
 
 -- Recupera todos los planes de estudio de propuestas vinculadas de cada grupo
 -- Saca el distinct porque puede estar el mismo plan de estudios en diferentes grupos
 INSERT INTO _temp_prop_alumno (alumno, propuesta, plan, orden)
       SELECT DISTINCT sga_alumnos.alumno, sga_planes.propuesta, sga_planes.plan, 1
         FROM _temp_relacion as t,
              sga_propuestas_relacion_grupo,
              sga_propuestas_relacion_plan,
              sga_planes, 
              sga_alumnos  
        WHERE sga_propuestas_relacion_grupo.relacion = t.relacion
          AND sga_propuestas_relacion_grupo.incluir_en_analitico = 'S'
          AND sga_propuestas_relacion_plan.relacion_grupo = sga_propuestas_relacion_grupo.relacion_grupo
          AND sga_planes.plan = sga_propuestas_relacion_plan.plan
          AND sga_alumnos.persona = _Persona
          AND sga_alumnos.propuesta = sga_planes.propuesta;
 
 -- +++++++++++++++++++++++++++++++++++++++++++++++++
 -- Actividades del Plan Actual del Alumno. 
 -- Actividades realizadas en la misma propuesta o en otra propuesta (actividades comunes)
 --  Actividades de la version actual del alumno en cada plan de estudios de cada propuesta
 -- +++++++++++++++++++++++++++++++++++++++++++++++++
RETURN QUERY SELECT 
        vw_hist_academica.actividad_codigo as actividad_codigo,
        vw_hist_academica.elemento,
        vw_hist_academica.actividad_nombre as actividad_nombre,
	CASE
	   WHEN sga_planes.plan = 4 THEN coalesce(cast(to_char(equiv_internas.fecha, 'DD/MM/YYYY') as char(10)) , cast(to_char(vw_hist_academica.fecha, 'DD/MM/YYYY') as char(10))) 
	   ELSE cast(to_char(vw_hist_academica.fecha, 'DD/MM/YYYY') as char(10)) 
	END as fecha,
        vw_hist_academica.nota as nota,
        vw_hist_academica.nota_descripcion as nota_descripcion,
        CASE 
          WHEN vw_hist_academica.origen = 'A' THEN 'Resolución'
          ELSE vw_hist_academica.tipo
        END as tipo,
        CASE vw_hist_academica.origen
          WHEN 'P' THEN vw_hist_academica.nro_acta
          WHEN 'E' THEN vw_hist_academica.nro_acta
          WHEN 'A' THEN vw_hist_academica.nro_resolucion_descripcion
          WHEN 'B' THEN vw_hist_academica.nro_resolucion_descripcion
        END as actividad_documento,
        sga_actas_folios.folio_fisico as folio_fisico,
        vw_hist_academica.creditos as creditos,
        sga_planes.codigo as plan_codigo,
        sga_planes.nombre as plan_nombre,
        vw_hist_academica.origen as origen,
        vw_hist_academica.nro_acta,
        vw_hist_academica.resultado_descripcion
     FROM 
         _temp_prop_alumno as t,
         vw_hist_academica
           LEFT JOIN sga_actas_folios ON sga_actas_folios.id_acta = vw_hist_academica.id_acta
                                     AND sga_actas_folios.folio  = vw_hist_academica.folio
           LEFT JOIN (SELECT max(sga_equiv_internas.fecha) as fecha, equivalencia FROM negocio.sga_equiv_internas GROUP BY equivalencia) as equiv_internas ON equiv_internas.equivalencia = vw_hist_academica.equivalencia,
         sga_alumnos,
         sga_planes_versiones as plan_version_alumno,
         sga_planes_versiones,
         sga_planes
    WHERE vw_hist_academica.alumno = t.alumno
      AND sga_alumnos.alumno = t.alumno
      AND plan_version_alumno.plan_version = sga_alumnos.plan_version
      AND plan_version_alumno.plan = t.plan   -- mismo plan de la vinculación
      AND sga_planes_versiones.plan_version = vw_hist_academica.plan_version
      AND sga_planes.plan = sga_planes_versiones.plan
      AND ((pResultado = 'T' AND vw_hist_academica.resultado IN ('A','R')) OR
	       (pResultado <> 'T' AND vw_hist_academica.resultado = pResultado)
		   )
      AND (pOrigen = 'T' OR vw_hist_academica.origen = pOrigen)
      --Agrego una excepcion para que no traiga actividades no promocionadas
      AND ((vw_hist_academica.origen = 'P' AND vw_hist_academica.resultado = 'A') OR (vw_hist_academica.origen <> 'P'))
      AND (pPlanVersionActual = 'T' OR 
           (pPlanVersionActual = 'A' AND -- Solo actividades de la version actual del plan del alumno
            (vw_hist_academica.elemento IN (SELECT ep.elemento FROM vw_elementos_plan as ep  WHERE ep.plan_version = sga_alumnos.plan_version))
           )
          )
	  --solo actividades que pertenezcan al certificado (01/18)	  
      AND vw_hist_academica.elemento IN (SELECT * FROM get_actividades_certificado(pcertificado, sga_alumnos.plan_version))  
    ORDER BY actividad_codigo,vw_hist_academica.fecha; --t.orden, vw_hist_academica.fecha, actividad_nombre;

 -- Borro la tabla temporal
 DROP TABLE _temp_prop_alumno;
 DROP TABLE _temp_relacion;
              
END;
$$;
