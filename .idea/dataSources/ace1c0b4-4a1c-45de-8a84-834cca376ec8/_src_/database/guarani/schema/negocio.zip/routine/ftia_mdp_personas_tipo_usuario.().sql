create function negocio.ftia_mdp_personas_tipo_usuario() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

   -- Si es alumno o docente inserto los grupos de acceso asociados al tipo de usuario
   IF NEW.tipo_usuario = 'Alumno' OR NEW.tipo_usuario = 'Docente' OR NEW.tipo_usuario = 'Cursos' THEN
     INSERT INTO mdp_personas_grupo_acc (persona, tipo_usuario, usuario_grupo_acc, grupo_acceso_default)
          SELECT NEW.persona, g.tipo_usuario, g.usuario_grupo_acc, g.grupo_acc_default
            FROM acc_grupo_acc_x_tipo_usuario as g
           WHERE g.tipo_usuario = NEW.tipo_usuario;
   END IF;        

   RETURN NEW;
END;
$$;
