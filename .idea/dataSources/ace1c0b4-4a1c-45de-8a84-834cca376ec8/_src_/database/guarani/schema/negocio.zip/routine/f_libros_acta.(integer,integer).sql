create function negocio.f_libros_acta(pidacta integer, pmostrar integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
BEGIN
  cnt := 0;
  _retorno := '';

  -- Recupero el nombre de las propuestas.
  FOR cur1 IN  SELECT DISTINCT 
                    sga_libros_actas.nro_libro as nro_libro,
                    sga_libros_actas.nombre as nombre
               FROM sga_actas_folios,
                    sga_libros_tomos,
                    sga_libros_actas
               WHERE sga_actas_folios.id_acta = pIdActa
                 AND sga_libros_tomos.libro_tomo = sga_actas_folios.libro_tomo
                 AND sga_libros_actas.libro = sga_libros_tomos.libro
  LOOP
    IF cnt > 0 THEN
       _retorno :=  _retorno || ' / ';
    END IF;
    
    IF pMostrar = 1 THEN
       _retorno := _retorno || cur1.nro_libro;
    ELSEIF pMostrar = 2 THEN
       _retorno := _retorno || cur1.nombre;
    ELSE 
       _retorno := _retorno || '(' || cur1.nro_libro || ') ' || cur1.nombre;
    END IF;
    cnt := cnt + 1;
  END LOOP;

  RETURN _retorno;

END;
$$;
