create function negocio.ftia_sga_insc_examen() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion integer;
  DECLARE _escala_nota integer;
  DECLARE _fecha_examen date; 
  BEGIN
   	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Inserta el registro en el detalle de la evaluación automática de la mesa de examen
    -- Solo si el estado de la inscripción es "Aceptado"
   	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	  
    IF NEW.estado = 'A' THEN
       SELECT sga_evaluaciones.evaluacion, sga_mesas_examen_instancias.escala_nota, sga_llamados_mesa.fecha
          INTO _evaluacion, _escala_nota, _fecha_examen 
          FROM sga_llamados_mesa, 
               sga_evaluaciones, 
               sga_evaluaciones_tipos, 
               sga_mesas_examen, 
               sga_mesas_examen_instancias 
          WHERE sga_llamados_mesa.llamado_mesa = NEW.llamado_mesa
            AND sga_evaluaciones.entidad       = sga_llamados_mesa.entidad
            AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
            AND sga_evaluaciones_tipos.automatica = 'S' -- Generación Automática
            AND sga_mesas_examen.mesa_examen   = sga_llamados_mesa.mesa_examen  
            AND sga_mesas_examen_instancias.mesa_examen = sga_mesas_examen.mesa_examen
            AND sga_mesas_examen_instancias.instancia   = NEW.instancia;

        IF _evaluacion IS NOT NULL THEN
          -- Inserto la inscripción en el detalle de la evaluacion automática.    
          INSERT INTO sga_eval_detalle_examenes (evaluacion, alumno, instancia, escala_nota, fecha, inscripto, plan_version )
       		     VALUES ( _evaluacion, NEW.alumno, NEW.instancia, _escala_nota, _fecha_examen, 'S', NEW.plan_version); 
       	END IF;	     
       	
       	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       	-- Inserto un registro por cada evaluacion (de generacion manual) en el detalle
       	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        INSERT INTO sga_eval_detalle (evaluacion, alumno, escala_nota, fecha)
        	 SELECT  sga_evaluaciones.evaluacion, NEW.alumno, sga_evaluaciones.escala_nota, _fecha_examen
             FROM sga_llamados_mesa, sga_evaluaciones, sga_evaluaciones_tipos
              WHERE sga_llamados_mesa.llamado_mesa = NEW.llamado_mesa
                AND sga_evaluaciones.entidad       = sga_llamados_mesa.entidad
                AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
                AND sga_evaluaciones_tipos.automatica = 'N'; -- Generación Manual
    END IF;  
     
    RETURN NEW;
  END;
$$;
