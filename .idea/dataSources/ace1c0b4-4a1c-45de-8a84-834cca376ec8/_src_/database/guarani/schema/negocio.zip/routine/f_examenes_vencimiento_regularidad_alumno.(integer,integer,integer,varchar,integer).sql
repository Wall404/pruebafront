create function negocio.f_examenes_vencimiento_regularidad_alumno(pactaexamen integer, pactividad integer, palumno integer, pfechadetalle character varying, pcantvecesrendirexamenregular integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE
	_observaciones varchar(200);
	_pFechaDetalle date;
	_fecha_regular date;
	_fecha_vigencia date;
	_origen char(1);
	_id_acta integer;
	_equivalencia integer;
	_cant_examenes_desaprobados smallint;
	_dato_alumno record;
	
BEGIN
	_pFechaDetalle := to_date(pFechaDetalle, 'YYYY-MM-DD');
	_observaciones := 'Cambio de fin de vigencia por llegar a la cantidad máxima permitida de exámenes desaprobados en condición de regular';

	-- Se obtienen los datos de la última regularidad aprobada y vigente de la persona para la actividad.
	SELECT		vw_regularidades_basica.fecha,
				vw_regularidades_basica.fecha_vigencia,
				vw_regularidades_basica.origen,
				vw_regularidades_basica.id_acta,
				vw_regularidades_basica.equivalencia 
	INTO 		_fecha_regular, _fecha_vigencia, _origen, _id_acta, _equivalencia
	FROM		vw_regularidades_basica
	WHERE		vw_regularidades_basica.alumno = pAlumno AND
				vw_regularidades_basica.elemento = pActividad AND
				vw_regularidades_basica.es_vigente = 1 AND
				vw_regularidades_basica.resultado = 'A'
	ORDER BY	vw_regularidades_basica.fecha DESC
	LIMIT		1;

	-- Si no se encuentra una regularidad vigente, finalizar la ejecución.
	IF _fecha_regular IS NOT NULL THEN

		-- Se obtiene la cantidad de exámenes regulares desaprobados por la persona desde la fecha de última regularidad vigente.
		SELECT	COUNT(1) 
		INTO 	_cant_examenes_desaprobados
		FROM	vw_hist_academica_basica
		WHERE	vw_hist_academica_basica.elemento = pActividad AND
				vw_hist_academica_basica.resultado = 'R' AND
				vw_hist_academica_basica.origen = 'E' AND
				vw_hist_academica_basica.instancia = 3 AND
				vw_hist_academica_basica.alumno = pAlumno AND
				vw_hist_academica_basica.fecha >= _fecha_regular;

		IF _cant_examenes_desaprobados >= pCantVecesRendirExamenRegular THEN
			-- Se vence la regularidad con la fecha del examen.
			IF _origen = 'R' OR _origen = 'P' THEN
				UPDATE	sga_actas_detalle
				SET		fecha_vigencia = _pFechaDetalle
				WHERE	id_acta = _id_acta AND
						alumno = pAlumno;
						
				-- Si hubo actualización, se inserta el cambio de fecha fin de vigencia.
				IF FOUND THEN
					INSERT INTO sga_regularidades_venc (id_acta, alumno, fecha_vigencia_anterior, fecha_vigencia_nuevo, observaciones)
					VALUES (_id_acta, pAlumno, _fecha_vigencia, _pFechaDetalle, _observaciones);
				END IF;
			ELSE -- Origen = 'C'.
				UPDATE	sga_equiv_otorgada
				SET		fecha_vigencia = _pFechaDetalle
				FROM	sga_equiv_tramite
				WHERE	sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite AND
						sga_equiv_otorgada.equivalencia = _equivalencia AND
						sga_equiv_tramite.alumno = pAlumno;
				-- Si hubo actualización, se inserta el cambio de fecha fin de vigencia.
				IF FOUND THEN
					INSERT INTO sga_regularidades_venc (equivalencia, alumno, fecha_vigencia_anterior, fecha_vigencia_nuevo, observaciones)
					VALUES (_equivalencia, pAlumno, _fecha_vigencia, _pFechaDetalle, _observaciones);
				END IF;
			END IF;
		END IF;
	
	END IF;		
		

	RETURN;
END;
$$;
