CREATE VIEW vw_ug_propuestas_sin_gestionar_actividades AS SELECT sga_unidades_gestion.unidad_gestion,
    sga_propuestas.propuesta,
    sga_propuestas_oferta.ubicacion
   FROM negocio.sga_unidades_gestion,
    (negocio.sga_propuestas
     LEFT JOIN negocio.sga_propuestas_oferta ON ((sga_propuestas.propuesta = sga_propuestas_oferta.propuesta)))
  WHERE (sga_unidades_gestion.dominio = 1)
UNION
 SELECT sga_ug_tipos_propuestas.unidad_gestion,
    sga_propuestas.propuesta,
    sga_propuestas_oferta.ubicacion
   FROM negocio.sga_ug_tipos_propuestas,
    (negocio.sga_propuestas
     LEFT JOIN negocio.sga_propuestas_oferta ON ((sga_propuestas.propuesta = sga_propuestas_oferta.propuesta)))
  WHERE (sga_ug_tipos_propuestas.propuesta_tipo = sga_propuestas.propuesta_tipo)
UNION
 SELECT sga_ug_responsables_academicas.unidad_gestion,
    sga_propuestas_ra.propuesta,
    sga_propuestas_oferta.ubicacion
   FROM negocio.sga_ug_responsables_academicas,
    (negocio.sga_propuestas_ra
     LEFT JOIN negocio.sga_propuestas_oferta ON ((sga_propuestas_ra.propuesta = sga_propuestas_oferta.propuesta)))
  WHERE (sga_ug_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica)
UNION
 SELECT sga_ug_propuestas.unidad_gestion,
    sga_ug_propuestas.propuesta,
    sga_ug_propuestas.ubicacion
   FROM negocio.sga_ug_propuestas;
