create function negocio.f_get_max_nro_tomo(plibro integer) returns integer
LANGUAGE plpgsql
AS $$
BEGIN
  RETURN (SELECT MAX(nro_tomo) FROM sga_libros_tomos WHERE libro = pLibro);
END;
$$;
