create function negocio.f_subcomisiones_comision(pcomision integer, ptipoclase boolean, phorario boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
  _horario text;
        
BEGIN
   cnt := 0;	
   _retorno := NULL;

  -- Recupero el nombre de las modalidades de cursada
  FOR cur1 IN SELECT sc.subcomision as subcomision,
                     sc.nombre as nombre,
                     t.tipo_clase as tipo_clase,
                     t.nombre as tipo_clase_nombre
                FROM sga_subcomisiones as sc,
                     sga_clases_tipos as t
               WHERE sc.comision = pComision
                 AND t.tipo_clase = sc.tipo_clase 
               ORDER BY 3, 2
  LOOP
      IF cnt = 0 THEN		
         _retorno :=  cur1.nombre;
      ELSE
         _retorno :=  _retorno || ' / ' || cur1.nombre;
      END IF;   

      IF pTipoClase THEN
        _retorno :=   _retorno || ' - ' || cur1.tipo_clase_nombre;
      END IF;
      IF pHorario THEN
        _horario := f_horario_subcomision(cur1.subcomision);
        IF _horario IS NOT NULL THEN
          _retorno :=   _retorno || ' - ' || _horario;
        END IF;
      END IF;

      cnt := cnt + 1;
  END LOOP;

  RETURN _retorno;
END;
$$;
