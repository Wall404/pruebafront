create function negocio.get_nombre_planes_relacion_grupo(_relacion_grupo integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	cant SMALLINT;
	retorno TEXT;
	cur RECORD;
BEGIN
	cant := 0;
	retorno := NULL;

	-- Recupero el nombre de los planes.
	FOR cur IN	SELECT	sga_planes.nombre
				FROM	sga_propuestas_relacion_plan,
						sga_planes
				WHERE	sga_propuestas_relacion_plan.plan = sga_planes.plan AND
						sga_propuestas_relacion_plan.relacion_grupo = _relacion_grupo
	LOOP
		IF cant = 0 THEN		
			retorno := cur.nombre;
		ELSE
			retorno := retorno || ' y ' || cur.nombre;
		END IF;   
		cant := cant + 1;
	END LOOP;

	RETURN retorno;
END;
$$;
