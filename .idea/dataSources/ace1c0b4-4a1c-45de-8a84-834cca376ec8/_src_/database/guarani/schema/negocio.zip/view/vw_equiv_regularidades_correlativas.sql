CREATE VIEW vw_equiv_regularidades_correlativas AS SELECT sga_equiv_otorgada.elemento,
    sga_equiv_tramite.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_tramite.tipo_tramite,
    sga_equiv_otorgada.equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_equiv_tramite.alumno AS alumno2,
    sga_equiv_tramite.plan_version,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.fecha_vigencia,
        CASE
            WHEN ((sga_equiv_otorgada.fecha_vigencia IS NULL) OR (sga_equiv_otorgada.fecha_vigencia >= ('now'::text)::date)) THEN 1
            ELSE 0
        END AS es_vigente,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta
   FROM (((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_equiv_tramite ON ((sga_equiv_tramite.alumno = sga_alumnos.alumno)))
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_equiv_otorgada.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_equiv_tramite.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
  WHERE ((((((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.instancia = 14)) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar)) AND (sga_equiv_otorgada.estado = 'A'::bpchar)) AND (sga_equiv_otorgada.resultado = ANY (ARRAY['A'::bpchar, 'R'::bpchar]))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))));
