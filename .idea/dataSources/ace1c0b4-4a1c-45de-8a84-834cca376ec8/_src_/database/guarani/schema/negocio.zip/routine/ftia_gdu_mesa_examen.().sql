create function negocio.ftia_gdu_mesa_examen() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   
   -- Asigno el derecho a los docentes de las mesas de examen futuras
   -- que pertenezcan al rol seleccionado
   INSERT INTO gdu_derechos_personas (entidad, derecho, persona)
      SELECT sga_llamados_mesa.entidad, 
             NEW.derecho, 
             sga_docentes.persona
        FROM sga_llamados_mesa,
             sga_docentes_mesa_llamado,
             sga_docentes
       WHERE sga_llamados_mesa.fecha >= CURRENT_DATE
         AND sga_docentes_mesa_llamado.llamado_mesa = sga_llamados_mesa.llamado_mesa
         AND sga_docentes_mesa_llamado.rol = NEW.rol
         AND sga_docentes.docente = sga_docentes_mesa_llamado.docente
         AND NOT EXISTS (SELECT 1 FROM gdu_derechos_personas 
                          WHERE derecho = NEW.derecho 
                            AND entidad = sga_llamados_mesa.entidad
                            AND persona = sga_docentes.persona);
   
   RETURN NEW;
END;
$$;
