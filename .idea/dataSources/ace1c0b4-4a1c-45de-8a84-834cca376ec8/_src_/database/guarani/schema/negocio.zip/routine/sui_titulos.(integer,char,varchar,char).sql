create function negocio.sui_titulos(ptitulo integer, ptipotitulo character, pnombre character varying, pcategoriaconeau character) returns void
LANGUAGE plpgsql
AS $$
BEGIN
  -- Inserta el pais
  INSERT INTO mdp_titulos (titulo, nombre, titulo_tipo, categoria_coneau) VALUES (pTitulo, pNombre, pTipoTitulo , pCategoriaConeau);

  -- Existe el titulo, entonces lo actualizo
  EXCEPTION 
     WHEN unique_violation THEN
       UPDATE mdp_titulos SET (nombre, titulo_tipo, categoria_coneau) = (pNombre, pTipoTitulo , pCategoriaConeau) 
        WHERE titulo = pTitulo;
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Título: %. Error Nro: %. %',pTitulo || ' - ' || pNombre, SQLSTATE, SQLERRM;   
END;
$$;
