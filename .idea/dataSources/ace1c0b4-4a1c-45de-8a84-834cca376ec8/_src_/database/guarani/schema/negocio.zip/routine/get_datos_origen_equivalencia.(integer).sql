create function negocio.get_datos_origen_equivalencia(pequivalencia integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE cur_origen record;
DECLARE i integer;
DECLARE datos_origen text;
DECLARE _persona integer;
DECLARE _tipo_equivalencia varchar(10);
DECLARE _folio varchar(20);
DECLARE _nombre_actividad varchar(255);
DECLARE _origen char(1);
DECLARE _nro_acta_resolucion varchar(50);
DECLARE _folio_fisico integer;
DECLARE _id_acta integer;

BEGIN
   datos_origen := '';
   i := 0;
   _folio_fisico := NULL;
   _folio := '';
   
  
   -- Verifico si es una equivalencia interna	
   SELECT o.tipo, a.persona INTO _tipo_equivalencia, _persona
     FROM sga_equiv_otorgada as eo
	 JOIN sga_equiv_tramite as et ON et.equivalencia_tramite = eo.equivalencia_tramite
	 JOIN sga_equiv_tramite_origen as o ON o.origen = et.origen
	 JOIN sga_alumnos as a ON a.alumno = et.alumno
   WHERE eo.equivalencia = pEquivalencia;
   
   IF _tipo_equivalencia <> 'Interna' THEN
      -- Es una equivalencia Externa, no se informa datos del origen de la equivalencia.
	  datos_origen := NULL;
      RETURN datos_origen;
   END IF;
   -- Recorro las actividades que dieron origen a la equivalencia
   FOR cur_origen IN (SELECT i.propuesta, i.elemento, i.fecha, i.nota, i.origen, i.resultado, a.alumno
                        FROM sga_equiv_internas as i
                        JOIN sga_alumnos as a ON (a.propuesta = i.propuesta AND a.persona = _persona)
                       WHERE i.equivalencia = pEquivalencia
					  ) 
   
   LOOP 
     i := i + 1;
	 SELECT cast(actividad_nombre as varchar(255)),
	        cast(origen as char(1)),
			cast(id_acta as integer),
	        Cast(CASE 
			  WHEN origen = 'E' THEN ' Acta de Examen ' || nro_acta
			  WHEN origen = 'P' THEN ' Acta de Promoción ' || nro_acta
			  WHEN origen IN ('B','A') THEN ' Res. ' || nro_resolucion_descripcion
 			  ELSE ''
			END  as varchar(50))
			INTO _nombre_actividad, _origen, _id_acta, _nro_acta_resolucion
	   FROM vw_hist_academica
	  WHERE alumno = cur_origen.alumno
	    AND elemento = cur_origen.elemento
		AND fecha = cur_origen.fecha
	    AND (nota = cur_origen.nota OR cur_origen.nota IS NULL)
	 LIMIT 1;
	 
	IF FOUND THEN   
	    _folio := '';
	    IF _origen IN ('E','P') THEN
		   -- Recupero el folio fisico del acta
		   SELECT f.folio_fisico INTO _folio_fisico
		     FROM sga_actas_detalle as d
			 JOIN sga_actas_folios as f ON (f.id_acta = d.id_acta AND f.folio = d.folio)
		    WHERE d.id_acta = _id_acta 
              AND d.alumno = cur_origen.alumno;
           IF _folio_fisico IS NOT NULL THEN
              _folio := ' - Folio ' || cast(_folio_fisico as varchar);
		   END IF;  	  
		END IF;

		IF i > 1 THEN
			datos_origen := datos_origen || ' | '; 
		END IF;	
		
		datos_origen := datos_origen || _nombre_actividad || ' - ' || _nro_acta_resolucion || ' - ' || to_char(cur_origen.fecha,'DD/MM/YYYY') || _folio;
	END IF;	
   END LOOP;


  RETURN datos_origen;
	
END;
$$;
