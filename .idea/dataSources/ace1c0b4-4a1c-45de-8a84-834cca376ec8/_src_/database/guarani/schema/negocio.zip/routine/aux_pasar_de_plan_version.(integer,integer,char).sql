create function negocio.aux_pasar_de_plan_version(ppvorigen integer, ppvdestino integer, palumnos character) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE
 _cant integer;
 _alumno integer;
 cur1 record;
 cur_retorno type_retorno_funcion;
 _po integer;
 _pd integer;
       
BEGIN
 
 IF pAlumnos <> 'T' and pAlumnos <> 'A' AND pAlumnos <> 'P' THEN
   cur_retorno.resultado := -1;
   cur_retorno.sqlerrm := 'Debe ingresar a que alumnos se cambiará de version de plan de estudios. Valores: T / A / P' ;
   RETURN cur_retorno;
 END IF;
 SELECT COUNT(*) INTO _cant FROM sga_planes_versiones WHERE plan_version = pPVOrigen;
 IF _cant = 0 THEN
   cur_retorno.resultado := -1;
   cur_retorno.sqlerrm := 'La version del plan ' || cast(pPVorigen as text) || ' no existe' ;
   RETURN cur_retorno;
 END IF;

 SELECT COUNT(*) INTO _cant FROM sga_planes_versiones WHERE plan_version = pPVOrigen AND estado in ('V','A');
 IF _cant = 0 THEN
   cur_retorno.resultado := -1;
   cur_retorno.sqlerrm := 'La version del plan ' || cast(pPVorigen as text) || ' no esta activa' ;
   RETURN cur_retorno;
 END IF;

 SELECT COUNT(*) INTO _cant FROM sga_planes_versiones WHERE plan_version = pPVDestino;
 IF _cant = 0 THEN
   cur_retorno.resultado := -1;
   cur_retorno.sqlerrm := 'La version del plan ' || cast(pPVDestino as text) || ' no existe' ;
   RETURN cur_retorno;
 END IF;

 SELECT COUNT(*) INTO _cant FROM sga_planes_versiones WHERE plan_version = pPVDestino AND estado in ('V','A');
 IF _cant = 0 THEN
   cur_retorno.resultado := -1;
   cur_retorno.sqlerrm := 'La version del plan ' || cast(pPVDestino as text) || ' no esta activa' ;
   RETURN cur_retorno;
 END IF;
   
 SELECT plan INTO _po FROM sga_planes_versiones WHERE plan_version = pPVOrigen;
 SELECT plan INTO _pd FROM sga_planes_versiones WHERE plan_version = pPVDestino;
 IF _po <> _pd THEN
   cur_retorno.resultado := -1;
   cur_retorno.sqlerrm := 'La version del plan origen no corresponde al mismo plan de estudios de la version de plan destino' ;
   RETURN cur_retorno;
 END IF;


_cant := 0;

-- Comienza la transaccion
BEGIN  
 -- Recupero el nombre de los tutores
 FOR cur1 IN SELECT alumno
                 FROM sga_alumnos
                WHERE plan_version = pPVOrigen
                  AND (pAlumnos = 'T' OR calidad = pAlumnos)
 LOOP
 
   -- Actualizo el plan y la version de los alumno
   UPDATE sga_alumnos SET plan_version = pPVDestino WHERE alumno = cur1.alumno;
 
   -- motivo_plan = 3 - Cambio de version de plan de estudios.
   -- tipo = 5 - Cambio de Version de Plan de Estudios Forzado.
   INSERT INTO sga_alumnos_hist_planes(alumno, plan_version, motivo_plan, fecha, tipo, documento, observaciones)
        VALUES (cur1.alumno, pPVDestino, 3, CURRENT_DATE, 5, NULL, NULL);

   _cant := _cant + 1;
 END LOOP;

 -- Error.
 EXCEPTION
    WHEN OTHERS THEN
       cur_retorno.resultado := -1;
       cur_retorno.sqlerrm  := SQLERRM;
       cur_retorno.sqlstate := SQLSTATE;
       RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

-- OK    
cur_retorno.resultado := 1;
cur_retorno.sqlerrm := 'Se cambio de version de plan de estudios a ' || cast(_cant as text) || ' alumnos' ;
RETURN cur_retorno;
   
END;
$$;
