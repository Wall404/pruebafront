create function negocio.ftia_gdu_comision() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   
   -- Asigno el derecho a los docentes de las comisiones vigentes que 
   -- pertenezcan a la responsabilidad seleccionada
   INSERT INTO gdu_derechos_personas (entidad, derecho, persona)
      SELECT sga_comisiones.entidad, 
             NEW.derecho, 
             sga_docentes.persona
        FROM sga_comisiones,
             sga_periodos_lectivos,
             sga_periodos,
             sga_docentes_comision,
             sga_docentes
       WHERE sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo
         AND sga_periodos.periodo = sga_periodos_lectivos.periodo
         AND sga_periodos.fecha_fin >= CURRENT_DATE
         AND sga_docentes_comision.comision = sga_comisiones.comision
         AND sga_docentes_comision.responsabilidad = NEW.responsabilidad
         AND sga_docentes.docente = sga_docentes_comision.docente
         AND NOT EXISTS (SELECT 1 FROM gdu_derechos_personas 
                          WHERE derecho = NEW.derecho 
                            AND entidad = sga_comisiones.entidad
                            AND persona = sga_docentes.persona);
   
   RETURN NEW;
END;
$$;
