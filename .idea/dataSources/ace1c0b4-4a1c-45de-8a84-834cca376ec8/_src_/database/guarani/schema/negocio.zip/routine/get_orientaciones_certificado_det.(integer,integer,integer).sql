create function negocio.get_orientaciones_certificado_det(_elemento integer, _elemento_revision integer, _subtipo integer) returns SETOF negocio.type_orientacion
LANGUAGE plpgsql
AS $$
DECLARE 
  hijos record;
  cur_orientaciones record;
  orientaciones type_orientacion;
BEGIN

  -- elementos que contiene el modulo. 
  FOR hijos IN 
    SELECT e.elemento, er.elemento_revision, e.entidad_subtipo
      FROM sga_elementos_comp as ec,
           sga_elementos_revision as er,
           sga_elementos as e,
           sga_g3entidades_subtipos as est
     WHERE ec.elemento_padre = _elemento_revision 
       AND er.elemento_revision = ec.elemento_hijo
       AND e.elemento = er.elemento
       AND est.entidad_subtipo = e.entidad_subtipo
       AND est.entidad_tipo = 1 -- Modulo
  
   LOOP
     IF hijos.entidad_subtipo = 3 THEN
       orientaciones.elemento := hijos.elemento;
       orientaciones.elemento_revision := hijos.elemento_revision;
       orientaciones.entidad_subtipo   := hijos.entidad_subtipo;
       RETURN NEXT orientaciones;
     ELSE
       -- Llamo de nuevo a la funcion para ver si alguno de los hijos del modulo es una orientacion.
       FOR cur_orientaciones IN SELECT * FROM get_orientaciones_certificado_det(hijos.elemento, hijos.elemento_revision, hijos.entidad_subtipo)
       LOOP 
          RETURN NEXT cur_orientaciones;
       END LOOP; --
     END IF;
   END LOOP; -- Componentes del módulo

END
$$;
