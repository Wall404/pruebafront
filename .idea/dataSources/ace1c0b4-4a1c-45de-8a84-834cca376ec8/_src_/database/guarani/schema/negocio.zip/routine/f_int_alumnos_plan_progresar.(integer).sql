create function negocio.f_int_alumnos_plan_progresar(panio integer) returns SETOF text
LANGUAGE plpgsql
AS $$
DECLARE 
  _datos text;
  _alu  record;
  _ci record;
  _planes record;
  _arch1 record;
  _arch2 record;
  _cant_aprobadas integer;
  _cant_aprobadas_anio_a_evaluar integer;
  _fecha_curso_ingreso varchar(10);
  _inst_codigo integer;
  _inst_nombre varchar(100);
  _TipoCursoIngreso integer;
  _AlumnoCI integer;
  _PropuestaCI integer;
  _PlanCI integer;
  _PlanVersionCI integer;        
  _cant_no_aprobadas_ci integer;
  _dfecha_ci date;
  _aux_plan varchar(10);
  _aux_titulo integer;
  
BEGIN
  _TipoCursoIngreso = 204; -- Curso de Ingreso
  
  /*
  -- Nombre de la institucion
  SELECT a.institucion_araucano, a.nombre 
    INTO _inst_codigo, _inst_nombre
    FROM par_configuraciones as p,
         sga_instituciones as i,
         int_arau_instituciones a
   WHERE p.nombre = 'institucion_instalacion'
     AND i.institucion = cast(p.valor as integer)
     AND i.institucion_araucano = a.institucion_araucano;
  */
  
  
  CREATE TEMP TABLE _Tplanes (
     plan integer, 
     cnt_materias integer, 
     titulo_araucano integer,
     institucion_araucano integer
    );
  
 -- Limpio datos por si viene el string vacio
 UPDATE int_progresar SET codigo_titulo_araucano = NULL WHERE trim(codigo_titulo_araucano) = '';
 UPDATE int_progresar SET codigo_facultad  = NULL WHERE trim(codigo_facultad) = '';
 UPDATE int_progresar SET codigo_institucion  = NULL  WHERE trim(codigo_institucion) = '';
 
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- Devuelvo el archivo de alumnos
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 _datos := '**************** Inicio archivo alumnos.txt *****************';  
 RETURN NEXT _datos;

 -- Recupero una vez cada persona (por si esta informado mas de una vez en el archivo)  
 -- Lo informo por cada titulo araucano que viene en el archivo a informar.
 FOR _alu IN 
     SELECT DISTINCT
           CASE tipo_documento
             WHEN 'DNI' THEN 0
             WHEN 'DNT' THEN 1
             WHEN 'CI'  THEN 2
             WHEN 'LE'  THEN 18
             WHEN 'LC'  THEN 19             
             WHEN 'PAS' THEN 90             
          END as tipo_documento, 
          numero_documento,
          cast(trim(codigo_titulo_araucano) as integer) as codigo_titulo_araucano,
          cast(trim(codigo_facultad) as integer) as codigo_facultad		  
      FROM int_progresar
	  ORDER BY numero_documento
  
  LOOP
   
   -- Datos del alumno a informar
   FOR _arch2 IN
   -- Titulos Araucano por los que va a informar...
   -- Por el que viene informado desde el ministerio y si no viene titulo se informa por todos 
   -- en los que se encuentre el alumno.
   SELECT 
           CASE d.tipo_documento
             WHEN 0 THEN 'DNI'
             WHEN 1 THEN 'DNT' 
             WHEN 2 THEN 'CI'  
             WHEN 18 THEN 'LE' 
             WHEN 19 THEN 'LC'              
             WHEN 90 THEN 'PAS'             
          END as tipo_documento_progresar, 
          alu.persona as persona, 
          alu.alumno as alumno,    
		  alu.propuesta as propuesta,
          d.tipo_documento,
          d.nro_documento,
          p.apellido,
          p.nombres,
          CASE p.sexo
            WHEN 'M' THEN '1'
            WHEN 'F' THEN '2'
          END as genero,
          to_char(p.fecha_nacimiento, 'YYYYMMDD') as fecha_nacimiento,
          c.titulo_araucano as titulo_araucano,
          pa.anio_academico as anio_ingreso,
          pv.plan as plan,
          sga_planes.codigo as plan_codigo,
          pv.cnt_materias as cnt_materias,
          prop.nombre as propuesta_nombre

     FROM mdp_personas_documentos as d,
          mdp_personas as p,
          sga_alumnos as alu,
          sga_planes_versiones as pv,
          sga_planes,
          sga_planes_certificados as pc,
          sga_certificados as c,
          sga_propuestas_aspira as pa,
          sga_propuestas as prop,
          sga_situacion_aspirante as sa
          
      WHERE d.tipo_documento = _alu.tipo_documento
        AND d.nro_documento  = _alu.numero_documento
        AND p.documento_principal = d.documento
        AND alu.persona = p.persona
        -- AND alu.calidad = 'A'
        AND prop.propuesta = alu.propuesta
        AND pv.plan_version = alu.plan_version
        AND pc.plan_version = alu.plan_version
        AND sga_planes.plan = pv.plan
        
        AND c.certificado     = pc.certificado
        AND c.titulo_nivel    = 'FINAL'
        AND c.titulo_araucano IS NOT NULL
        AND ((_alu.codigo_titulo_araucano IS NOT NULL AND c.titulo_araucano = _alu.codigo_titulo_araucano) OR
		     (_alu.codigo_titulo_araucano IS NULL AND 
			  _alu.codigo_facultad IN (SELECT sra.institucion_araucano
		  	                             FROM sga_propuestas_ra as pra, sga_responsables_academicas as sra 
		  	                            WHERE pra.propuesta = alu.propuesta
		  	                              AND sra.responsable_academica = pra.responsable_academica
		  	                              AND sra.institucion_araucano IS NOT NULL
					                   )
		      )
		    )
        AND pa.propuesta = alu.propuesta
        AND pa.persona   = alu.persona
        AND sa.situacion_asp = pa.situacion_asp
        AND sa.resultado_asp IN ('P','A')
      ORDER BY p.apellido, p.nombres, prop.nombre
  LOOP
  
  
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Recupero codigo de institucion araucano y nombre en base a la responsable academica
	-- Tomo la primera que encuentre si existe mas de una RA para la propuesta
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	_inst_codigo := null;
	_inst_nombre := null;
	SELECT ra.institucion_araucano, ra.nombre
	  INTO _inst_codigo, _inst_nombre
	  FROM sga_propuestas_ra as pra,
	       sga_responsables_academicas as ra
     WHERE pra.propuesta = _arch2.propuesta
	   AND pra.responsable_academica = ra.responsable_academica
	   AND ra.institucion_araucano IS NOT NULL
	 ORDER BY ra.nombre
	 LIMIT 1;

     -- Inserto los planes
     INSERT INTO _Tplanes (plan, cnt_materias, titulo_araucano, institucion_araucano) 
	      VALUES (_arch2.plan, _arch2.cnt_materias, _arch2.titulo_araucano, _inst_codigo);

	 
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Cuento materias aprobadas
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    _cant_aprobadas := 0;
    _cant_aprobadas_anio_a_evaluar := 0;
    SELECT COUNT(*), SUM(CASE WHEN EXTRACT(YEAR FROM fecha) = pAnio THEN 1 ELSE 0 END)
      INTO _cant_aprobadas, _cant_aprobadas_anio_a_evaluar          
      FROM vw_hist_academica_basica
     WHERE alumno = _arch2.alumno
       AND resultado = 'A';
       
       
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Fecha cumplimiento Curso de Ingreso
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    _fecha_curso_ingreso := '';
    _AlumnoCI    := NULL;
    _PropuestaCI := NULL;
    _PlanCI      := NULL;
    _PlanVersionCI := NULL;
    _dfecha_ci     := NULL;
    
    -- Verifico si la propuesta tiene un curso de ingreso vinculado y la persona esta como alumno en esa propuesta
    SELECT sga_alumnos.alumno, sga_planes.propuesta, sga_planes.plan, sga_alumnos.plan_version
         INTO _AlumnoCI, _PropuestaCI, _PlanCI, _PlanVersionCI 
         FROM sga_propuestas_relacion_grupo,
              sga_propuestas_relacion_plan,
              sga_propuestas,
              sga_planes, 
              sga_alumnos  
        WHERE sga_propuestas_relacion_grupo.relacion IN (SELECT relacion FROM get_relacion_propuesta(_arch2.alumno))
          AND sga_propuestas_relacion_plan.relacion_grupo = sga_propuestas_relacion_grupo.relacion_grupo
          AND sga_planes.plan          = sga_propuestas_relacion_plan.plan
          AND sga_propuestas.propuesta = sga_planes.propuesta
          AND sga_propuestas.propuesta_tipo = _TipoCursoIngreso
          AND sga_alumnos.persona   = _arch2.persona
          AND sga_alumnos.propuesta = sga_planes.propuesta
          LIMIT 1;
    
    IF FOUND THEN
       -- Existe Curso de ingreso. 
       -- Verifico si cumplio todas las actividades y si es asi recupero la fecha maxima de aprobación.
       
       _cant_no_aprobadas_ci := 0;
       
       SELECT COUNT(*) INTO _cant_no_aprobadas_ci
         FROM vw_actividades_plan
         WHERE plan_version = _PlanVersionCI
           AND elemento NOT IN (SELECT elemento FROM vw_hist_academica_basica
                                 WHERE alumno = _AlumnoCI
                                   AND resultado = 'A'
                                );
       
       IF _cant_no_aprobadas_ci = 0 THEN
          -- Recupero fecha maxima de aprobacion de las materias del curso de ingreso.  
          SELECT MAX(fecha) INTO _dfecha_ci
            FROM vw_hist_academica_basica
           WHERE alumno    = _AlumnoCI
             AND resultado = 'A'
             AND elemento IN (SELECT elemento FROM vw_actividades_plan WHERE plan_version = _PlanVersionCI);
          
          _fecha_curso_ingreso := to_char(_dfecha_ci, 'DD-MM-YYYY');
       END IF;
     
    END IF; -- Existe Curso de Ingreso


    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Devuelvo los datos
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    _datos := _arch2.tipo_documento_progresar;
    _datos := _datos || '|' || _arch2.nro_documento;
    _datos := _datos || '|' || LEFT(_arch2.apellido,30);
    _datos := _datos || '|' || LEFT(_arch2.nombres,30);
    _datos := _datos || '|' || COALESCE(_inst_codigo::text,'');
    _datos := _datos || '|' || COALESCE(LEFT(_inst_nombre,60),'');
    _datos := _datos || '|' || _arch2.titulo_araucano; 
    _datos := _datos || '|' || _arch2.propuesta_nombre;
    _datos := _datos || '|' || _arch2.plan_codigo;
    _datos := _datos || '|' || _arch2.anio_ingreso::text;
    _datos := _datos || '|' || COALESCE(_fecha_curso_ingreso,'');
    _datos := _datos || '|' || COALESCE(_cant_aprobadas::text, '0');
    _datos := _datos || '|' || COALESCE(_cant_aprobadas_anio_a_evaluar::text, '0');
    
    RETURN NEXT _datos;
  
  END LOOP; -- Datos de cada alumno
      
END LOOP; -- Archivo de alumnos

 _datos := '**************** Fin archivo alumnos.txt *****************';  
 RETURN NEXT _datos;
_datos := '**************** Inicio archivo planes_estudio.txt *****************';  
 RETURN NEXT _datos;
 
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- Devuelvo el archivo de planes de estudios.
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 _aux_plan   := '';
 _aux_titulo := 0;
 FOR _arch1 IN SELECT DISTINCT t.institucion_araucano, p.codigo, t.cnt_materias, t.titulo_araucano, p.duracion_en_anios
                 FROM _Tplanes as t, sga_planes as p
                WHERE t.plan = p.plan
			 ORDER BY t.institucion_araucano, p.codigo, t.cnt_materias DESC
 LOOP
    -- Puede haber versiones de plan para informar el mismo titulo con cantidad de materias diferentes.
	-- Informo por la version del plan que mas materias tiene.
    IF _aux_titulo = _arch1.titulo_araucano AND _aux_plan = _arch1.codigo THEN 
	   CONTINUE;
	END IF;   
	
    _datos := COALESCE(_arch1.institucion_araucano::text,''); 
    _datos := _datos || '|' || COALESCE(_arch1.titulo_araucano::text, '') ;
    _datos := _datos || '|' || COALESCE(_arch1.codigo, ''); 
    _datos := _datos || '|' || COALESCE(_arch1.cnt_materias::text, '0');  
    _datos := _datos || '|' || COALESCE(_arch1.duracion_en_anios::text, '0') ;
    RETURN NEXT _datos;
	
	_aux_titulo := _arch1.titulo_araucano;
	_aux_plan   := _arch1.codigo;
 END LOOP;

 _datos := '**************** Fin archivo planes_estudio.txt ************';  
 RETURN NEXT _datos;


 -- Borro la tabla temporal   
 DROP TABLE _Tplanes;
    
END;
$$;
