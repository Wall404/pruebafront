create function negocio.f_subcomisiones_insc_cursada_log(pinscripcion integer, ptipoclase boolean, phorario boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
  _horario text;
        
BEGIN
   cnt := 0;	
   _retorno := NULL;

  -- Recupero el nombre de las modalidades de cursada
  FOR cur1 IN SELECT v.subcomision as subcomision,
                     sc.nombre as nombre,
                     t.nombre as tipo_clase
                FROM vw_insc_subcomision_log as v, 
                     sga_subcomisiones as sc,
                     sga_clases_tipos as t
               WHERE v.inscripcion = pInscripcion
                 AND sc.subcomision = v.subcomision
                 AND t.tipo_clase = sc.tipo_clase 
  LOOP
      IF cnt = 0 THEN		
         _retorno :=  cur1.nombre;
      ELSE
         _retorno :=  _retorno || ' / ' || cur1.nombre;
      END IF;   

      IF pTipoClase THEN
        _retorno :=   _retorno || ' - ' || cur1.tipo_clase;
      END IF;
      IF pHorario THEN
        _horario := f_horario_subcomision(cur1.subcomision);
        IF _horario IS NOT NULL THEN
          _retorno :=   _retorno || ' - ' || _horario;
        END IF;
      END IF;

      cnt := cnt + 1;
  END LOOP;

  RETURN _retorno;
END;
$$;
