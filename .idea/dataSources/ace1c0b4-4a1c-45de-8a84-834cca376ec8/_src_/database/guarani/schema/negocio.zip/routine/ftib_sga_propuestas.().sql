create function negocio.ftib_sga_propuestas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
       -- Genera un registro en la tabla de entidades..
       NEW.entidad := f_generar_entidad(NEW.propuesta_tipo);
       RETURN NEW;
  END;
$$;
