create function negocio.get_dato_censal_actividad(ppersona integer, pfecha date) returns integer
LANGUAGE plpgsql
AS $$
DECLARE iDatoCensal Integer;
DECLARE vFecha DATE;
BEGIN
   iDatoCensal := NULL;
   vFecha := COALESCE(pFecha, CURRENT_DATE);
   
   SELECT dato_censal_act INTO iDatoCensal
   	 FROM his_datos_censales, his_datos_actividades
	WHERE his_datos_censales.persona = pPersona
	  AND his_datos_actividades.dato_censal = his_datos_censales.dato_censal
      AND DATE(his_datos_actividades.fecha_alta) <= vFecha
	ORDER BY his_datos_actividades.fecha_alta DESC
   LIMIT 1;
   
   IF iDatoCensal IS NULL THEN
     -- Busco el dato censal mas proximo siguiente a la fecha.
     SELECT dato_censal_act INTO iDatoCensal
   	   FROM his_datos_censales, his_datos_actividades
	  WHERE his_datos_censales.persona = pPersona
	    AND his_datos_actividades.dato_censal = his_datos_censales.dato_censal
        AND DATE(his_datos_actividades.fecha_alta) > vFecha
	  ORDER BY his_datos_actividades.fecha_alta DESC  
     LIMIT 1;
   END IF;

  -- Retorno el id del Dato Censal de Actividades
  Return iDatoCensal;
	
END;
$$;
