create function negocio.f_responsables_academicas_mesa_examen(_pmesallamado integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _ra text;
  cur1 record;

BEGIN
  cnt := 0;
  _ra := NULL;

  -- Recupero el nombre de las RAs
  FOR cur1 IN 
SELECT DISTINCT sga_responsables_academicas.responsable_academica, sga_responsables_academicas.nombre as nombre
FROM sga_responsables_academicas 
JOIN sga_propuestas_ra ON (sga_propuestas_ra.responsable_academica = sga_responsables_academicas.responsable_academica)
JOIN sga_mesas_examen_propuestas  	ON (sga_mesas_examen_propuestas.propuesta = sga_propuestas_ra.propuesta)
JOIN sga_llamados_mesa ON (sga_llamados_mesa.mesa_examen = sga_mesas_examen_propuestas.mesa_examen)
WHERE sga_llamados_mesa.llamado_mesa =  _pMesaLlamado
					
 

  LOOP
      IF cnt = 0 THEN
         _ra :=  cur1.nombre;
      ELSE
         _ra :=  _ra || ', ' || cur1.nombre;
      END IF;   
      cnt := cnt + 1;
  END LOOP;

  RETURN _ra;

END;
$$;
