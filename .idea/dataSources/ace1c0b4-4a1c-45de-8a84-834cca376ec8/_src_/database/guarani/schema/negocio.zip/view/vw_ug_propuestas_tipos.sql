CREATE VIEW vw_ug_propuestas_tipos AS SELECT sga_unidades_gestion.unidad_gestion,
    sga_propuestas_tipos.propuesta_tipo
   FROM negocio.sga_unidades_gestion,
    negocio.sga_propuestas_tipos
  WHERE (sga_unidades_gestion.dominio = 1)
UNION
 SELECT sga_ug_tipos_propuestas.unidad_gestion,
    sga_ug_tipos_propuestas.propuesta_tipo
   FROM negocio.sga_ug_tipos_propuestas
UNION
 SELECT sga_ug_responsables_academicas.unidad_gestion,
    sga_propuestas.propuesta_tipo
   FROM negocio.sga_ug_responsables_academicas,
    negocio.sga_propuestas_ra,
    negocio.sga_propuestas
  WHERE ((sga_ug_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica) AND (sga_propuestas_ra.propuesta = sga_propuestas.propuesta))
UNION
 SELECT sga_ug_propuestas.unidad_gestion,
    sga_propuestas.propuesta_tipo
   FROM negocio.sga_ug_propuestas,
    negocio.sga_propuestas
  WHERE (sga_ug_propuestas.propuesta = sga_propuestas.propuesta);
