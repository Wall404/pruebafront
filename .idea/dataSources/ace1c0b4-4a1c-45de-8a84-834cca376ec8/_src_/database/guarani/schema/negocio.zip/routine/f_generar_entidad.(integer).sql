create function negocio.f_generar_entidad(_subtipo integer) returns integer
LANGUAGE plpgsql
AS $$
BEGIN
    -- Inserto registro en tabla de entidades
    INSERT INTO sga_g3entidades (entidad_subtipo) VALUES (_subtipo);
    -- Recupero el Serial (entidad).
    RETURN (SELECT currval('sga_g3entidades_seq'));
  END;
$$;
