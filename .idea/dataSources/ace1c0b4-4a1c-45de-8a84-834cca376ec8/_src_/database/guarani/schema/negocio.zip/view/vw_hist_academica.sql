CREATE VIEW vw_hist_academica AS SELECT sga_comisiones.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    sga_periodos_perlect.anio_academico,
    sga_periodos_lectivos.periodo_lectivo,
    sga_periodos_perlect.nombre AS periodo_lectivo_nombre,
    NULL::integer AS llamado,
    NULL::character varying(100) AS llamado_nombre,
    NULL::integer AS mesa_examen,
    NULL::character varying(100) AS mesa_examen_nombre,
    NULL::integer AS turno_examen,
    NULL::character varying(100) AS turno_examen_nombre,
    sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.nro_acta,
    sga_actas.tipo_acta,
    sga_actas.origen,
    'Promoción'::character varying(30) AS tipo,
    sga_actas.evaluacion,
    sga_actas.comision,
    sga_actas.llamado_mesa,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS nro_resolucion,
    NULL::character varying(30) AS nro_resolucion_descripcion,
    NULL::integer AS equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_actas_detalle.alumno AS alumno2,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
    sga_actas_detalle.folio,
    sga_actas_detalle.renglon,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_actas_detalle.cond_regularidad,
    sga_actas_detalle.estado,
    sga_actas_detalle.pct_asistencia,
    sga_actas_detalle.observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    sga_instancias_resultado.descripcion AS resultado_descripcion,
    sga_elementos_plan.creditos,
    sga_actas.nua,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    'N'::text AS homologada
   FROM ((((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.alumno = sga_alumnos.alumno)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_actas_detalle.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_actas_detalle.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto)))
     JOIN negocio.sga_actas ON ((sga_actas.id_acta = sga_actas_detalle.id_acta)))
     JOIN negocio.sga_comisiones ON ((sga_comisiones.comision = sga_actas.comision)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_comisiones.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_actas_detalle.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_periodos_lectivos ON ((sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo)))
     JOIN negocio.sga_periodos sga_periodos_perlect ON ((sga_periodos_perlect.periodo = sga_periodos_lectivos.periodo)))
     JOIN negocio.sga_instancias_resultado ON (((sga_instancias_resultado.instancia = sga_actas_detalle.instancia) AND (sga_instancias_resultado.resultado = sga_actas_detalle.resultado))))
  WHERE (((((sga_actas.estado = 'C'::bpchar) AND (sga_actas.origen = 'P'::bpchar)) AND (sga_actas_detalle.estado = 'A'::bpchar)) AND (sga_actas_detalle.rectificado = 'N'::bpchar)) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_mesas_examen.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
        CASE sga_mesas_examen.mesa_en_turno_examen
            WHEN 'S'::bpchar THEN sga_periodos_llamado.anio_academico
            WHEN 'N'::bpchar THEN (sga_mesas_examen.anio_academico)::numeric
            ELSE NULL::numeric
        END AS anio_academico,
    NULL::integer AS periodo_lectivo,
    NULL::character varying(100) AS periodo_lectivo_nombre,
    sga_llamados_turno.llamado,
    sga_periodos_llamado.nombre AS llamado_nombre,
    sga_mesas_examen.mesa_examen,
    (sga_mesas_examen.nombre)::character varying(100) AS mesa_examen_nombre,
    sga_turnos_examen.turno_examen,
    sga_periodos_turno.nombre AS turno_examen_nombre,
    sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.nro_acta,
    sga_actas.tipo_acta,
    sga_actas.origen,
    'Examen'::character varying(30) AS tipo,
    sga_actas.evaluacion,
    sga_actas.comision,
    sga_actas.llamado_mesa,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS nro_resolucion,
    NULL::character varying(30) AS nro_resolucion_descripcion,
    NULL::integer AS equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_actas_detalle.alumno AS alumno2,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
    sga_actas_detalle.folio,
    sga_actas_detalle.renglon,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_actas_detalle.cond_regularidad,
    sga_actas_detalle.estado,
    sga_actas_detalle.pct_asistencia,
    sga_actas_detalle.observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    sga_instancias_resultado.descripcion AS resultado_descripcion,
    sga_elementos_plan.creditos,
    sga_actas.nua,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    'N'::text AS homologada
   FROM (((((((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.alumno = sga_alumnos.alumno)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_actas_detalle.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_actas_detalle.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto)))
     JOIN negocio.sga_actas ON ((sga_actas.id_acta = sga_actas_detalle.id_acta)))
     JOIN negocio.sga_llamados_mesa ON ((sga_llamados_mesa.llamado_mesa = sga_actas.llamado_mesa)))
     JOIN negocio.sga_mesas_examen ON ((sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen)))
     LEFT JOIN negocio.sga_llamados_turno ON ((sga_llamados_turno.llamado = sga_llamados_mesa.llamado)))
     LEFT JOIN negocio.sga_periodos sga_periodos_llamado ON ((sga_periodos_llamado.periodo = sga_llamados_turno.periodo)))
     LEFT JOIN negocio.sga_turnos_examen ON ((sga_turnos_examen.turno_examen = sga_llamados_turno.turno_examen)))
     LEFT JOIN negocio.sga_periodos sga_periodos_turno ON ((sga_periodos_turno.periodo = sga_turnos_examen.periodo)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_mesas_examen.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_actas_detalle.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_instancias_resultado ON (((sga_instancias_resultado.instancia = sga_actas_detalle.instancia) AND (sga_instancias_resultado.resultado = sga_actas_detalle.resultado))))
  WHERE ((((((sga_actas.estado = 'C'::bpchar) AND (sga_actas.origen = 'E'::bpchar)) AND (sga_actas_detalle.estado = 'A'::bpchar)) AND (sga_actas_detalle.rectificado = 'N'::bpchar)) AND (sga_actas_detalle.instancia = ANY (ARRAY[3, 4, 7]))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_equiv_otorgada.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    NULL::integer AS anio_academico,
    NULL::integer AS periodo_lectivo,
    NULL::character varying(100) AS periodo_lectivo_nombre,
    NULL::integer AS llamado,
    NULL::character varying(100) AS llamado_nombre,
    NULL::integer AS mesa_examen,
    NULL::character varying(100) AS mesa_examen_nombre,
    NULL::integer AS turno_examen,
    NULL::character varying(100) AS turno_examen_nombre,
    NULL::integer AS id_acta,
    NULL::integer AS id_acta_original,
    NULL::character varying(30) AS nro_acta,
    NULL::character(1) AS tipo_acta,
    'B'::bpchar AS origen,
    'Equivalencia'::character varying(30) AS tipo,
    NULL::integer AS evaluacion,
    NULL::integer AS comision,
    NULL::integer AS llamado_mesa,
    sga_equiv_tramite.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_tramite.tipo_tramite,
    sga_equiv_tramite.documento AS nro_resolucion,
    sga_documentos.documento_numero AS nro_resolucion_descripcion,
    sga_equiv_otorgada.equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_equiv_tramite.alumno AS alumno2,
    sga_equiv_tramite.plan_version,
    sga_equiv_otorgada.instancia,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.fecha_vigencia,
    NULL::smallint AS folio,
    NULL::smallint AS renglon,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado,
    NULL::integer AS cond_regularidad,
    sga_equiv_otorgada.estado,
    NULL::numeric(5,2) AS pct_asistencia,
    sga_equiv_otorgada.temas_a_rendir AS observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    sga_escalas_notas_resultado.descripcion AS resultado_descripcion,
    sga_elementos_plan.creditos,
    sga_equiv_tramite.nua,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    'N'::text AS homologada
   FROM ((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_equiv_tramite ON ((sga_equiv_tramite.alumno = sga_alumnos.alumno)))
     LEFT JOIN negocio.sga_documentos ON ((sga_documentos.documento = sga_equiv_tramite.documento)))
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_equiv_otorgada.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_equiv_otorgada.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_equiv_otorgada.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_equiv_tramite.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_escalas_notas_resultado ON ((sga_escalas_notas_resultado.resultado = sga_equiv_otorgada.resultado)))
  WHERE ((((((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.instancia = 10)) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar)) AND (sga_equiv_otorgada.estado = 'A'::bpchar)) AND (sga_equiv_otorgada.resultado = ANY (ARRAY['A'::bpchar, 'R'::bpchar]))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_reconocimiento_act.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    NULL::integer AS anio_academico,
    NULL::integer AS periodo_lectivo,
    NULL::character varying(100) AS periodo_lectivo_nombre,
    NULL::integer AS llamado,
    NULL::character varying(100) AS llamado_nombre,
    NULL::integer AS mesa_examen,
    NULL::character varying(100) AS mesa_examen_nombre,
    NULL::integer AS turno_examen,
    NULL::character varying(100) AS turno_examen_nombre,
    NULL::integer AS id_acta,
    NULL::integer AS id_acta_original,
    NULL::character varying(30) AS nro_acta,
    NULL::character(1) AS tipo_acta,
    'A'::bpchar AS origen,
    'Aprob. por Resolución'::character varying(30) AS tipo,
    NULL::integer AS evaluacion,
    NULL::integer AS comision,
    NULL::integer AS llamado_mesa,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    sga_reconocimiento.documento AS nro_resolucion,
    sga_documentos.documento_numero AS nro_resolucion_descripcion,
    NULL::integer AS equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_reconocimiento.alumno AS alumno2,
    sga_reconocimiento.plan_version,
    NULL::integer AS instancia,
    sga_reconocimiento.fecha,
    NULL::date AS fecha_vigencia,
    NULL::smallint AS folio,
    NULL::smallint AS renglon,
    sga_reconocimiento_act.escala_nota,
    sga_reconocimiento_act.nota,
    'A'::bpchar AS resultado,
    NULL::integer AS cond_regularidad,
    'A'::bpchar AS estado,
    NULL::numeric(5,2) AS pct_asistencia,
    NULL::text AS observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    'Aprobado'::character varying AS resultado_descripcion,
    COALESCE(sga_reconocimiento_act.creditos, sga_elementos_plan.creditos) AS creditos,
    sga_reconocimiento.nua,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    sga_reconocimiento_act.homologada
   FROM ((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_reconocimiento ON ((sga_reconocimiento.alumno = sga_alumnos.alumno)))
     JOIN negocio.sga_reconocimiento_act ON ((sga_reconocimiento_act.nro_tramite = sga_reconocimiento.nro_tramite)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_reconocimiento_act.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_reconocimiento_act.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_det.concepto = sga_escalas_notas_concepto.concepto)))
     JOIN negocio.sga_documentos ON ((sga_documentos.documento = sga_reconocimiento.documento)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_reconocimiento_act.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_reconocimiento.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_g3entidades_subtipos ON ((sga_g3entidades_subtipos.entidad_subtipo = sga_elementos.entidad_subtipo)))
  WHERE ((((sga_reconocimiento.estado = 'C'::bpchar) AND (sga_reconocimiento_act.reconocimiento_total = 'S'::bpchar)) AND (sga_g3entidades_subtipos.entidad_tipo = 2)) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))));
