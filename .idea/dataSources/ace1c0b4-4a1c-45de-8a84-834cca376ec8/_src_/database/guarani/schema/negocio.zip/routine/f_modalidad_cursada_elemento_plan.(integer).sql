create function negocio.f_modalidad_cursada_elemento_plan(_elemento_plan integer) returns text
LANGUAGE plpgsql
AS $$
declare
	retorno text;
	rec record;
begin
	retorno := '';
	for rec in
		select 	sga_modalidad_cursada.nombre 
		from	sga_elementos_plan_modalidad
		inner join
			sga_modalidad_cursada
		on	sga_elementos_plan_modalidad.modalidad = sga_modalidad_cursada.modalidad
		where 	sga_elementos_plan_modalidad.elemento_plan = _elemento_plan
		order by 1
	loop
		retorno := retorno||' / '||rec.nombre;
	end loop;
	return substring(retorno from 4 for char_length(retorno));
end;
$$;
