create function negocio.ftia_sga_comisiones() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _evaluacion_tipo integer;
   _evaluacion integer;
   _cupo smallint;   
BEGIN
   -- Inserto el dato del cupo de la comision. Si es null entonces inserto 0. 
   _cupo := COALESCE(NEW.cupo, 0);
   INSERT INTO sga_comisiones_cupo (comision, cupo) VALUES (NEW.comision, _cupo);
      
   -- Recupero el tipo de evaluacion automática para las comisiones
   SELECT evaluacion_tipo INTO _evaluacion_tipo
      FROM sga_evaluaciones_tipos
      WHERE sga_evaluaciones_tipos.automatica = 'S'
      AND sga_evaluaciones_tipos.aplica_a = 'C';

   -- Si no encontro ningun registro entonces salgo con error.
   IF _evaluacion_tipo IS NULL THEN
      RAISE EXCEPTION 'No esta definido el tipo de evaluación automática para las comisiones.';
   END IF;
				
   -- Inserto una evaluacion automática. 
   -- Estado "Abierta", Generación "Automática", Fecha Actual, Visible al Alumno = NO.
   INSERT INTO sga_evaluaciones (nombre, descripcion, entidad, evaluacion_tipo, visible_al_alumno, fecha, estado)
      VALUES (NEW.nombre, 'Evaluación automática para generación de acta de regulares y promoción', 
              NEW.entidad, _evaluacion_tipo, 'N', CURRENT_DATE,'A');
   
   RETURN NEW;
END;
$$;
