create function negocio.ws_datos_analitico(ppersona integer, ptituloaraucano integer, pdevolverrtf boolean) returns TABLE(titulo_araucano integer, titulo_nombre character varying, responsable_academica integer, propuesta integer, propuesta_nombre character varying, plan_codigo character varying, plan_nombre character varying, titulo_esta_cumplido character varying, nro_resolucion_ministerial character varying, nro_resolucion_coneau character varying, nro_resolucion_institucion character varying, fecha_ingreso character varying, fecha_egreso character varying, tiene_sanciones character, titulo_anterior_nivel character varying, titulo_anterior_origen integer, titulo_anterior_nacionalidad character varying, titulo_anterior_institucion character varying, titulo_anterior_denominacion character varying, titulo_anterior_revalidado character varying, titulo_anterior_nro_resolucion character varying, titulo_apto_ejercicio character varying, plan_vigente character varying, tipo character, actividad_nombre character varying, actividad_codigo character varying, creditos numeric, fecha character varying, nota character varying, resultado character varying, folio_fisico integer, acta_resolucion character varying, promedio numeric, promedio_sin_aplazos numeric, forma_aprobacion character)
LANGUAGE plpgsql
AS $$
DECLARE
	cnt smallint;
	_institucion_araucano integer;
	_plan_vigente char(2);
	_retorno text;
	_k integer;
	cur_tit record;
	cur_act record;
	cur_rtf record;
	_plan_version integer;
	_nro_resolucion_ministerial varchar(100);
	_nro_resolucion_coneau varchar(100);
	_nro_resolucion_institucion varchar(100);
	_titulo_apto_ejercicio varchar(2);
	_titulo_anterior_revalidado varchar(30);
	_titulo_anterior_resolucion_convalidacion varchar(30);
    _titulo_anterior_nacionalidad varchar(10);
	_titulo_anterior_origen integer;
	_tipo_actividad char(1);
	_tipo_trayecto char(1);
	_alumno_ant integer;
	_SUBTIPO_MODULO_RTF integer;
    _modulo_rtf_cumplido boolean;
	_modulo_reconocido_total integer;
	_fecha varchar(10);
	_acta_resolucion varchar(30);
	_codigo_ant varchar(20);
	_forma_aprobacion char(1);
	

BEGIN
 /* 
   forma_aprobacion = Valores posibles:  E = Examen / P = Promoción / Q = Equivalencia / R = Resolución
 */
  cnt := 0;
  _k := 0;
  _retorno := NULL;
  _nro_resolucion_coneau := '';
  _SUBTIPO_MODULO_RTF := 11;
  _tipo_actividad = 'A';
  _tipo_trayecto  = 'T';
  _alumno_ant := NULL;
  _institucion_araucano := NULL;

 -- Si no viene los datos de la identificacion del alumno sale sin devolver datos. 
 IF pPersona IS NULL THEN
   RETURN;
 END IF;   

 -- Tabla temporal para registrar las actividades aprobadas por el alumno. 
 CREATE TEMP TABLE _Taprobadas (elemento integer);

 -- Devuelve las certificaciones obtenidas por la persona. 
 FOR cur_tit IN	(
     SELECT 
	       a.alumno, a.plan_version as plan_version_actual, 
		   a.propuesta, prop.nombre as propuesta_nombre, 
		   prop.propuesta_tipo, 
		   pa.tipo_ingreso,
		   --sga_planes.codigo 
		   nro_resolucion_institucion as plan_codigo,
		   sga_planes.nombre as plan_nombre,
           c.titulo_araucano, c.certificado,
		   CASE p.sexo WHEN 'F' THEN c.nombre_femenino WHEN 'M' THEN c.nombre ELSE c.nombre END as titulo_nombre,
		   (CASE WHEN co.certificado IS NOT NULL THEN 'SI' ELSE 'NO' END) as titulo_esta_cumplido,
		   d.documento_numero as nro_resolucion_institucion,
		   pc.nro_resolucion_ministerial as nro_resolucion_ministerial,
           co.fecha_egreso as dfecha_egreso,
           CASE 
		      WHEN co.fecha_egreso IS NOT NULL THEN to_char(co.fecha_egreso, 'DD/MM/YYYY') 
			  ELSE ''
		   END as fecha_egreso,
           to_char(get_fecha_ingreso_alumno(a.alumno), 'DD/MM/YYYY') as fecha_ingreso,
           COALESCE(get_titulo_institucion_habilitante(a.alumno, c.certificado, 1), '') AS titulo_anterior_denominacion,
           COALESCE(get_titulo_institucion_habilitante(a.alumno, c.certificado, 2), '') AS titulo_anterior_institucion,
           COALESCE(get_titulo_institucion_habilitante(a.alumno, c.certificado, 3),'') AS  titulo_anterior_institucion_nacionalidad,
           COALESCE(get_titulo_institucion_habilitante(a.alumno, c.certificado, 4), '') AS titulo_anterior_nivel,
           co.promedio as promedio,  -- promedio con aplazos
           co.promedio_sin_aplazos as promedio_sin_aplazos,
          (SELECT (CASE WHEN count(*) > 0 THEN 'S' ELSE 'N' END)
		     FROM sga_sanciones as s
           WHERE s.persona = p.persona
             AND (s.fecha_desde IS NULL OR s.fecha_desde <= COALESCE(co.fecha_egreso, CURRENT_DATE))
             AND (s.fecha_hasta IS NULL OR s.fecha_hasta >= COALESCE(co.fecha_egreso, CURRENT_DATE))
             AND (s.fecha_cancelacion IS NULL OR (s.fecha_cancelacion IS NOT NULL AND s.fecha_cancelacion > COALESCE(co.fecha_egreso, CURRENT_DATE)))
			 AND (s.propuesta IS NULL OR s.propuesta = a.propuesta)
         ) as tiene_sanciones		
		 
    FROM mdp_personas as p
		 JOIN sga_alumnos as a ON a.persona = p.persona
		 JOIN sga_planes_versiones as pv ON pv.plan_version = a.plan_version
		 JOIN sga_planes ON sga_planes.plan = pv.plan
		 JOIN sga_propuestas as prop ON prop.propuesta = a.propuesta
		 JOIN sga_propuestas_aspira as pa ON (pa.propuesta = a.propuesta AND pa.persona = a.persona)
		 JOIN sga_situacion_aspirante as sa ON (sa.situacion_asp = pa.situacion_asp AND sa.resultado_asp IN ('A','P'))
		 JOIN sga_planes_certificados as pc ON pc.plan_version = a.plan_version
    	 JOIN sga_certificados as c ON c.certificado = pc.certificado
		 LEFT JOIN sga_documentos as d ON d.documento = c.nro_resolucion
         LEFT JOIN sga_certificados_otorg as co ON (co.alumno = a.alumno AND co.certificado = c.certificado AND co.anulado = 0)
		 
    WHERE p.persona = pPersona
      AND (pTituloAraucano IS NULL OR c.titulo_araucano = pTituloAraucano)
    ORDER BY a.alumno, c.nombre	  
	)  
 LOOP
    
    -- Si no se informa por titulo, entonces solo informo una vez por cada alumno y propuesta.
	/*IF pTituloAraucano IS NULL AND _alumno_ant = cur_tit.alumno THEN 
	  -- Continuo con el proximo registro.
	  _alumno_ant := cur_tit.alumno;	
      CONTINUE;
	END IF;*/
    _alumno_ant := cur_tit.alumno;	

    -- Obtengo el codigo de institucion araucano de la responsable academica de la propuesta
	SELECT ra.institucion_araucano
	  INTO _institucion_araucano
	  FROM sga_propuestas_ra as pra
	       JOIN sga_responsables_academicas as ra ON pra.responsable_academica = ra.responsable_academica
	 WHERE pra.propuesta = cur_tit.propuesta
	 ORDER BY pra.responsable_academica
	 LIMIT 1;
	 
    -- Registro las actividades aprobadas del alumno en una tabla temporal si cambio de propuesta.
	IF _alumno_ant <> cur_tit.alumno THEN 
      DELETE FROM _Taprobadas;
	  INSERT INTO _Taprobadas (elemento)
	       SELECT ha.elemento FROM vw_hist_academica_basica as ha
	        WHERE ha.alumno = cur_tit.alumno 
              AND ha.resultado = 'A';
	END IF;
    _alumno_ant := cur_tit.alumno;	
	
	

    -- Recupero version del plan de estudios en la que se encontraba el alumno al momento del egreso
	IF pTituloAraucano IS NULL OR cur_tit.dfecha_egreso IS NULL THEN 
	   _plan_version := cur_tit.plan_version_actual;
	ELSE
	   -- Obtengo la version del plan de estudios a la fecha de egreso.
	   _plan_version := get_plan_version_alumno(cur_tit.alumno, to_char(cur_tit.dfecha_egreso, 'YYYY-MM-DD'));
    END IF;	

	-- Verifica si el plan de estudios es activo vigente
	_plan_vigente := 'SI';
	SELECT (CASE sga_planes.estado WHEN 'V' THEN 'SI' ELSE 'NO' END) INTO _plan_vigente
	  FROM sga_planes_versiones 
	       JOIN sga_planes ON sga_planes.plan = sga_planes_versiones.plan
     WHERE sga_planes_versiones.plan_version = _plan_version;
	
		
	-- Verifica el estado de convalidacion/revalidacion del titulo anterior habilitante cuando es de un pais extranjero
    _titulo_anterior_revalidado := '';
	_titulo_anterior_resolucion_convalidacion := '';
	_titulo_anterior_nacionalidad := '';
	
	IF cur_tit.titulo_anterior_institucion_nacionalidad = 'E' THEN
	  _titulo_anterior_revalidado := COALESCE(get_titulo_institucion_habilitante(cur_tit.alumno, cur_tit.certificado, 5), '');
	  _titulo_anterior_resolucion_convalidacion := COALESCE(get_titulo_institucion_habilitante(cur_tit.alumno, cur_tit.certificado, 6), '');
  	 -- _titulo_anterior_nacionalidad := 'Extranjero';
    ELSEIF cur_tit.titulo_anterior_institucion_nacionalidad = 'N' THEN 
	 -- _titulo_anterior_nacionalidad := 'Argentino';
	END IF;
	
	
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Origen titulo anterior
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	/*
	1 = Institución Argentina
    2 = Institución Extranjera
    3 = para títulos de grado: Ley de Educ. Sup. Mayores de 25 años - Art. Nº 7 - Ley 24521
    4 = para posgrados y ciclos: Ley de Educ. Sup Ley 24521 Art. 39 bis
    5 = No corresponde (solamente para primario o inicial)
	
	3 y 4 es para cuando el ingreso es por ser mayor de 25 años (ingresan sin titulo anterior habiliante)
	*/
	_titulo_anterior_origen := NULL;

	IF cur_tit.tipo_ingreso = 3 THEN -- Mayor de 25 años
	   IF cur_tit.propuesta_tipo IN (202,205) THEN 
	      -- Propuestas de Posgrado... (202 = Posgrado, 205 = Postitulo). 
	      _titulo_anterior_origen := 4;
	      _titulo_anterior_nacionalidad := 4;
	   ELSE
	      -- Propuestas de Grado/Pre-Grado 
	      _titulo_anterior_origen := 3;
	      _titulo_anterior_nacionalidad := 3;
	   END IF;
	ELSE 
	   -- Ingresa con titulo anterior habilitante 
	   -- Verifico el origen de la institucion del titulo anterior habilitante..
       IF cur_tit.titulo_anterior_institucion_nacionalidad = 'N' THEN      -- Pais Argentina
	      _titulo_anterior_origen := 1;
	      _titulo_anterior_nacionalidad := 1;
	   ELSEIF cur_tit.titulo_anterior_institucion_nacionalidad = 'E' THEN  -- Pais Extranjero.
	      _titulo_anterior_origen := 2;
	      _titulo_anterior_nacionalidad := 2;
	   END IF;
	END IF;
	
	
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Verifica si es apto profesional el titulo
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	_titulo_apto_ejercicio := 'SI';
	IF cur_tit.titulo_anterior_institucion_nacionalidad = 'E' AND cur_tit.propuesta_tipo IN (202, 205) THEN
	  -- El titulo es de Posgrado/Postitulo y la institucion del titulo anterior habilitante es de un pais extranjero.
	  -- El titulo NO es apto para su ejercicio en el pais.
	  _titulo_apto_ejercicio := 'NO';
	END IF;

	
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Retorno los datos del titulo y actividades aprobadas/desaprobadas relacionadas con el titulo a informar.
    -- Se devuelven actividades realizadas hasta la fecha de egreso. por si siguio realizando actividades luego de obtener este titulo.
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	RETURN QUERY 
	SELECT 
	       -- Datos del titulo
	       cur_tit.titulo_araucano,
		   cur_tit.titulo_nombre,
		   _institucion_araucano,
		   cur_tit.propuesta,
		   cur_tit.propuesta_nombre,
		   cur_tit.plan_codigo,
		   cur_tit.plan_nombre,
		   cast(cur_tit.titulo_esta_cumplido as varchar(2)),
		   cur_tit.nro_resolucion_ministerial,
		   _nro_resolucion_coneau,
		   cur_tit.nro_resolucion_institucion,
           cast(cur_tit.fecha_ingreso as varchar(10)),
           cast(cur_tit.fecha_egreso as varchar(10)),
		  cast(cur_tit.tiene_sanciones as char(1)),
		   cast(cur_tit.titulo_anterior_nivel as varchar(100)),
  	       _titulo_anterior_origen,
  	       _titulo_anterior_nacionalidad,
		   cast(cur_tit.titulo_anterior_institucion as varchar(255)),
		   cast(cur_tit.titulo_anterior_denominacion as varchar(255)),
	       _titulo_anterior_revalidado,
	       _titulo_anterior_resolucion_convalidacion,
		   _titulo_apto_ejercicio,
           cast(_plan_vigente as varchar(2)),
   
		   -- Datos de las actividades
		   _tipo_actividad,
	       ha.actividad_nombre,
	       ha.actividad_codigo,
		   ha.creditos,
		   cast(COALESCE(to_char(cast(p.fecha as timestamp), 'DD/MM/YYYY'), to_char(ha.fecha, 'DD/MM/YYYY')) as varchar(10)) as fecha,
	       CASE 
		     WHEN ha.nota ~ '[a-zA-Z]+' THEN cast(NULL as varchar(10)) 
			 ELSE ha.nota 
		   END as nota,
	       cast(case when ha.resultado_descripcion = 'Promocionado' then 'Aprobado' else ha.resultado_descripcion end as varchar(20)) as resultado,
	       CASE 
		     WHEN ha.origen IN ('P','E') THEN (SELECT af.folio_fisico::integer 
                                                  FROM sga_actas_folios as af 
			                                    WHERE af.id_acta = ha.id_acta AND af.folio = ha.folio LIMIT 1)
		     ELSE CAST(NULL as integer)
		   END as folio_fisico,
	       cast(CASE ha.origen
		          WHEN 'P' THEN ha.nro_acta
		          WHEN 'E' THEN ha.nro_acta
		          WHEN 'A' THEN ha.nro_resolucion_descripcion  -- Aprobacion x Resolucion
		          WHEN 'B' THEN ha.nro_resolucion_descripcion  -- Equivalencia.
		         END as varchar(30)
               ) as acta_resolucion,
		   cur_tit.promedio,
		   cur_tit.promedio_sin_aplazos,
		   CASE ha.origen
		     WHEN 'A' THEN 'R' -- Resolucion
		     WHEN 'B' THEN 'Q' -- Equiv Total
			 ELSE ha.origen
		   END as forma_aprobacion 
	  FROM vw_hist_academica as ha
	  LEFT JOIN unpaz_f_certificado_actividades(cur_tit.alumno,'T','T','A',cur_tit.certificado) as p ON (ha.elemento = p.elemento and ha.resultado_descripcion = p.resultado_descripcion )--and ha.nro_acta = p.nro_acta)
	WHERE ha.alumno    = cur_tit.alumno
	  AND ha.resultado IN ('A','R')
	  AND NOT (ha.resultado = 'R' AND ha.origen = 'P')
	  AND /*(
		  (
			pTituloAraucano IS NULL
			AND COALESCE(cast(p.fecha as timestamp), ha.fecha)  <= COALESCE(cur_tit.dfecha_egreso, CURRENT_DATE)
		  ) 
		  OR (
			pTituloAraucano IS NOT NULL
			AND */ COALESCE(cast(p.fecha as timestamp), ha.fecha) <= COALESCE(cur_tit.dfecha_egreso, CURRENT_DATE)
			AND ha.elemento IN (SELECT * FROM get_actividades_certificado(cur_tit.certificado, _plan_version, false)) 
		  /*)
	  ) */
		  AND EXISTS (Select 1 from
			negocio.sga_planes_versiones as planes_versiones1
			LEFT JOIN negocio.sga_planes on (planes_versiones1.plan = sga_planes.plan)
			LEFT JOIN negocio.sga_planes_versiones as planes_versiones2 on (planes_versiones2.plan = sga_planes.plan)
			LEFT JOIN negocio.sga_alumnos on (sga_alumnos.plan_version = planes_versiones2.plan_version)
			where sga_alumnos.alumno = ha.alumno AND planes_versiones1.plan_version = ha.plan_version)
	  ORDER BY fecha, ha.actividad_nombre;
	  
	  
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Recorro los modulos RTF que se encuentran en el titulo y que esten cumplidos (todas sus actividades aprobadas)  
	-- Modulos RTF de la version actual del alumno o la version a la fecha de egreso.
	-- O modulos RTF que formen parte de algun plan de la propuesta del alumno y que este cumplido por el alumno
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	IF pDevolverRTF THEN 
	  _modulo_rtf_cumplido := false;
	  _codigo_ant := '';
	  
	  FOR cur_rtf IN SELECT DISTINCT mp.elemento, mp.elemento_revision, mrtf.nombre, mrtf.codigo, mrtf.creditos
	                  FROM vw_modulos_plan as mp
                      JOIN sga_modulos_rtf as mrtf ON mrtf.codigo = mp.codigo					  
					 WHERE mp.entidad_subtipo = _SUBTIPO_MODULO_RTF
					   AND mp.plan_version = _plan_version
					   AND (pTituloAraucano IS NULL OR 
	                        (pTituloAraucano IS NOT NULL AND 
                             mp.elemento IN (SELECT * FROM get_actividades_certificado(cur_tit.certificado, _plan_version, true))
							)
                           ) 							
					ORDER BY mrtf.codigo 
	  LOOP
	     IF _codigo_ant = cur_rtf.codigo AND _modulo_rtf_cumplido THEN
		    -- Si ya informe este modulo porque estaba cumplido entonces continuo con el proximo. 
			-- Esto puede darse si es que se consultan diferentes planes de una propuesta. Cada modulo tiene una revision diferente en cada version de plan de estudios
		    CONTINUE;		
		 END IF;

		 
		 _modulo_rtf_cumplido := false;
		 _fecha := NULL;
		 _acta_resolucion := NULL;
		 
		 -- Verifico si el modulo esta reconocido por resolucion.
		 SELECT to_char(r.fecha, 'DD/MM/YYYY'), d.documento_numero 
		   INTO _fecha, _acta_resolucion
		   FROM sga_reconocimiento as r
		        JOIN sga_reconocimiento_act as ra ON ra.nro_tramite = r.nro_tramite
		        LEFT JOIN sga_documentos as d ON d.documento = r.documento
		  WHERE r.alumno = cur_tit.alumno
		    AND r.estado = 'C'
			AND ra.elemento = cur_rtf.elemento
			AND ra.reconocimiento_total = 'S'
			LIMIT 1;
		
		IF FOUND THEN
		    _modulo_rtf_cumplido := true;
		END IF;
			
		IF NOT _modulo_rtf_cumplido THEN 
		   -- Verifico si todas las actividades del modulo RTF estan cumplidas
	       FOR cur_act IN (
		     SELECT e_actividad.elemento
              FROM sga_elementos_comp
              JOIN sga_elementos_revision as er_actividad ON er_actividad.elemento_revision = sga_elementos_comp.elemento_hijo
              JOIN sga_elementos as e_actividad ON e_actividad.elemento = er_actividad.elemento
			  JOIN sga_g3entidades_subtipos as s ON s.entidad_subtipo = e_actividad.entidad_subtipo
             WHERE sga_elementos_comp.elemento_padre = cur_rtf.elemento_revision
			   AND s.entidad_tipo    = 2 -- Actividades
			   )
		   LOOP
			  _modulo_rtf_cumplido := true;
			  
		      SELECT COUNT(*) INTO cnt FROM _Taprobadas WHERE elemento = cur_act.elemento;
			  IF cnt = 0 THEN
			    -- No aprobo la actividad del modulo. Salgo y no informo el modulo.
			    _modulo_rtf_cumplido := false;
			    EXIT;
			  END IF;
		   END LOOP; -- Fin actividades del modulo RTF
		 END IF; 
		 
		 IF _modulo_rtf_cumplido THEN
		   -- Devuelvo el modulo RTF que esta cumplido. 
	       RETURN QUERY 
		   SELECT 
	           -- Datos del titulo
	           cur_tit.titulo_araucano,
		       cur_tit.titulo_nombre,
		       _institucion_araucano,
		       cur_tit.propuesta,
		       cur_tit.propuesta_nombre,
			   cur_tit.plan_codigo,
			   cur_tit.plan_nombre,
		       cast(cur_tit.titulo_esta_cumplido as varchar(2)),
		       cur_tit.nro_resolucion_ministerial,
		       _nro_resolucion_coneau,
		       cur_tit.nro_resolucion_institucion,
               cast(cur_tit.fecha_ingreso as varchar(10)),
               cast(cur_tit.fecha_egreso as varchar(10)),
               cast(cur_tit.tiene_sanciones as char(1)),
		       cast(cur_tit.titulo_anterior_nivel as varchar(100)),
		       _titulo_anterior_origen,
  	           _titulo_anterior_nacionalidad,
		       cast(cur_tit.titulo_anterior_institucion as varchar(255)),
		       cast(cur_tit.titulo_anterior_denominacion as varchar(255)),
	           _titulo_anterior_revalidado,
	           _titulo_anterior_resolucion_convalidacion,
		       _titulo_apto_ejercicio,
		       cast(_plan_vigente as varchar(2)),

		       -- Datos modulo RTF
			   _tipo_trayecto,
		       cur_rtf.nombre,
		       cur_rtf.codigo,
			   cur_rtf.creditos,
		       _fecha as fecha,
		       cast(NULL as varchar(10)) as nota,
		       cast('Aprobado' as varchar(20)) as resultado,
		       cast(null as integer) as folio_fisico,
		       _acta_resolucion as acta_resolucion,
		       cast(null as decimal(5,2)) as promedio,
		       cast(null as decimal(5,2)) as promedio_sin_aplazos,
		       cast(null as char(1)) as forma_aprobacion
		     ;		 
		   
		 END IF; -- Modulo RTF cumplido.
	  END LOOP; -- Modulos RTF
	END IF; -- Devolver modulos RTF cumplidos.
	-- +++++++++++++++++++++++++++++++++ Fin modulos RTF ++++++++++++++++++++++++++++++++++++++++++++++++
	
 END LOOP; -- FIN titulos a consultar
 
 -- Borro tabla temporal.
 DROP TABLE IF EXISTS _Taprobadas;

 
END;
$$;
