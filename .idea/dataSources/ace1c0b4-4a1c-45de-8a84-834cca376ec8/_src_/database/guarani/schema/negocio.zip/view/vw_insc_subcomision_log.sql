CREATE VIEW vw_insc_subcomision_log AS SELECT sga_insc_subcomision_log.inscripcion,
    sga_insc_subcomision_log.subcomision
   FROM negocio.sga_insc_subcomision_log
UNION ALL
 SELECT his_insc_subcomision_log.inscripcion,
    his_insc_subcomision_log.subcomision
   FROM negocio.his_insc_subcomision_log;
