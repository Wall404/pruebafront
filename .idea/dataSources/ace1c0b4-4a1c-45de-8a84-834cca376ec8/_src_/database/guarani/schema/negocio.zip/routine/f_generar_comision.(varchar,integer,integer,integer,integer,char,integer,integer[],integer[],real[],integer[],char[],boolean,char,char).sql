create function negocio.f_generar_comision(_nombre character varying, _per_lectivo_destino integer, _elemento integer, _turno integer, _catedra integer, _inscripcion_habilitada character, _ubicacion integer, _instancia integer[], _escala integer[], _porc_asistencia real[], _plan integer[], _modalidad character[], _utilizar_docentes boolean, pasistenciaporhoras character, pasistenciacantidadinasist character) returns SETOF negocio.type_comision_copiado_generacion
LANGUAGE plpgsql
AS $$
DECLARE
  comision_nueva integer;  	
  docentes record;
  _fecha_desde date;
  _fecha_hasta date;
  _division integer;
  i smallint;
  n integer;
  cur_retorno type_comision_copiado_generacion; -- para retornar datos de la comision creada

BEGIN

_division := NULL;

-- Creo el registro en la tabla de Comisiones
INSERT INTO sga_comisiones (nombre, periodo_lectivo, elemento, turno, catedra, ubicacion, letra_desde, letra_hasta, cupo_minimo, cupo, inscripcion_habilitada, division, asistencia_por_horas, asistencia_cantidad_inasist, cobrable, estado)
  VALUES (_nombre, _per_lectivo_destino, _elemento, _turno, _catedra, _ubicacion, null, null, null, null, _inscripcion_habilitada, _division, pAsistenciaPorHoras, pAsistenciaCantidadInasist, 'N', 'A');

-- Recupero el Serial de la comisión
comision_nueva := (SELECT currval('sga_comisiones_seq'));

cur_retorno.codigo_retorno := 0; -- OK. (comision generada)
cur_retorno.comision := comision_nueva;
cur_retorno.nombre_comision := _nombre;
  
-- Creo el registro en la tabla de Instancias de la Comisión
-- Cuando se pase a 8.4 o superior usar la funcion array_lenght(array[]) para sacar el valor n.
n := (select array_upper( _instancia, 1) - array_lower( _instancia ,1) + 1);
FOR i IN 1 .. n 
LOOP
  INSERT INTO sga_comisiones_instancias (comision, instancia, escala_nota, porc_asistencia)
      VALUES (comision_nueva, _instancia[i], _escala[i], _porc_asistencia[i]);
END LOOP;
   
-- Creo el registro en la tabla de Propuestas de la Comisión
INSERT INTO sga_comisiones_propuestas (comision, propuesta, plan)
  SELECT DISTINCT comision_nueva, propuesta, plan
    FROM vw_actividades_plan
   WHERE elemento = _elemento
     AND plan = ANY (_plan);

-- Modalidad de Cursada.   (Analizar si solo se registran las modalidades de los planes asociados a la comision)
INSERT INTO sga_comisiones_modalidad (comision, modalidad) 
   SELECT DISTINCT comision_nueva, sga_elementos_plan_modalidad.modalidad 
     FROM vw_actividades_plan, sga_elementos_plan_modalidad 
     WHERE vw_actividades_plan.elemento = _elemento 
       AND vw_actividades_plan.plan = ANY (_plan) 
       AND vw_actividades_plan.elemento_plan = sga_elementos_plan_modalidad.elemento_plan 
       AND sga_elementos_plan_modalidad.modalidad = ANY (_modalidad); 	


IF _utilizar_docentes THEN
  -- Recupero los docentes de la cátedra
  FOR docentes IN SELECT	docente, responsabilidad
                    FROM	sga_catedras_docentes
                   WHERE	sga_catedras_docentes.catedra	= _catedra
                     AND sga_catedras_docentes.estado	= 'A'
  LOOP
    -- Recupero las Fechas de Inicio y Fin dictado del período lectivo
    SELECT sga_periodos_lectivos.fecha_inicio_dictado, sga_periodos_lectivos.fecha_fin_dictado
      INTO _fecha_desde,_fecha_hasta
      FROM sga_periodos_lectivos
     WHERE sga_periodos_lectivos.periodo_lectivo = _per_lectivo_destino;
    
     -- Inserto el Docente
     INSERT INTO sga_docentes_comision (comision, docente, responsabilidad, fecha_desde, fecha_hasta)
          VALUES (comision_nueva, docentes.docente, docentes.responsabilidad, _fecha_desde, _fecha_hasta);
  END LOOP;
END IF;

-- Retorno la comision
RETURN NEXT cur_retorno;

END;
$$;
