create function negocio.ftda_sga_responsables_academicas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
       -- Borro el registro en la tabla de entidades..
       DELETE FROM sga_g3entidades WHERE entidad = OLD.entidad;
       RETURN OLD;
  END;
$$;
