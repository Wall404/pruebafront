create function negocio.get_plan_contenido(integer, boolean, boolean) returns SETOF negocio.type_plan_contenido
LANGUAGE plpgsql
AS $$
DECLARE 

id_plan_version ALIAS for $1;
mostrar_hijos ALIAS for $2;
mostrar_hijos_mg ALIAS for $3;
modulo_raiz record;
hijos record;
cant integer;
BEGIN

SELECT COUNT (relname) INTO cant FROM pg_class WHERE relname = 'temp_seq';
IF (cant = 0) THEN 
	CREATE TEMP sequence temp_seq;
END IF;	
	-- Recupera los datos del Módulo Raiz de la Versiòn del Plan.
	SELECT 	nextval('temp_seq') 	as 	orden_arbol,
			ep.elemento_revision 	as	elemento_revision,
			e.elemento 				as	elemento,
			e.codigo 				as	codigo,
			ep.nombre				as	nombre,
			est.entidad_tipo 		as	entidad_tipo,
			est.entidad_subtipo 	as	entidad_subtipo,
			est.php_clase_gui 		as	entidad_clase_gui,
			CAST(NULL as integer) 	as	elemento_comp,
			CAST(NULL as integer) 	as	elemento_revision_padre,
			CAST(NULL as integer) 	as	elemento_padre,
			CAST(NULL as smallint) 	as	orden
	INTO	modulo_raiz
	FROM sga_planes_versiones as pv,
		sga_elementos_plan as ep,
		sga_elementos_revision as m,
		sga_elementos as e,
		sga_g3entidades_subtipos as est
	WHERE pv.plan_version = id_plan_version 
	AND   ep.plan_version = id_plan_version 
	AND   ep.elemento_revision = pv.elemento_revision
	AND   m.elemento_revision = ep.elemento_revision
	AND   e.elemento = m.elemento
	AND   est.entidad_subtipo = e.entidad_subtipo;

	RETURN NEXT modulo_raiz;

	-- elementos contenidos
	FOR hijos IN (	
			SELECT 	orden_arbol,	
				elemento_revision,
				elemento,
				codigo,
				nombre,
				entidad_tipo,
				entidad_subtipo,
				entidad_clase_gui,
				elemento_comp,
				elemento_revision_padre,
				elemento_padre,
				orden
			FROM get_elemento_contenido( modulo_raiz.elemento_revision, id_plan_version, false, mostrar_hijos, mostrar_hijos_mg)

	) LOOP
		RETURN NEXT hijos;
	END LOOP;


IF (cant = 0) THEN 
	DROP sequence temp_seq;	
END IF;	

END
$$;
