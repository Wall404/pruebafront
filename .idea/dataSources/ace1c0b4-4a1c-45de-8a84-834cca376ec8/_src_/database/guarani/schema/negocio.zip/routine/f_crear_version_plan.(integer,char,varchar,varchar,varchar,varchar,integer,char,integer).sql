create function negocio.f_crear_version_plan(pplan_version_origen integer, ptipo character, pversion character varying, pversion_nombre character varying, pplan_nombre character varying, pplan_tipo character varying, ppropuesta integer, pmodalidad character, pconvenio integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _revision_modulo_raiz_old  INTEGER;
  _revision_modulo_raiz_new  INTEGER;
  cnt  SMALLINT;
  _codigo_plan  varchar(10);
  _prefijo_codigo_plan varchar(10);
  _plan  INTEGER;
  _plan_new  INTEGER;
  _plan_version_new  INTEGER;
  _elemento_revision_old  INTEGER;
  _elemento_revision_new  INTEGER;
  _elemento_new INTEGER;
  _entidad_subtipo  INTEGER;
  _entidad_tipo  INTEGER;
  _compartible char(1);
  _rtn_mensaje  text;
  _cnt_matrices integer;
  _condicion_new  INTEGER;
  _grupo_new INTEGER;
  cursor1 record;
  cursor2 record;
  cursor3 record;
  cursor4 record;
  
  BEGIN
	_rtn_mensaje := '1,OK';
	_prefijo_codigo_plan := 'PP-';

	IF pTipo <> 'P' AND pTipo <> 'V' THEN
		_rtn_mensaje := '-1,Debe indicar correctamente si va a duplicar un plan de estudios o generar una version nueva del plan de estudios';
		RETURN _rtn_mensaje;
	END IF;

        -- Valido que no exista otra version del mismo plan de estudios con el mismo nombre o codigo de versión		
	IF pTipo = 'V' THEN
 	  SELECT COUNT(*) INTO cnt
 	    FROM sga_planes_versiones as a,
 	         sga_planes_versiones as b
  	   WHERE a.plan_version = pPlan_version_origen
  	     AND b.plan = a.plan
  	     AND (b.version = pVersion OR b.nombre = pVersion_nombre);
  	   
	  IF cnt > 0 THEN	
	    _rtn_mensaje := '-1, Ya existe una version del plan de estudios con el mismo nombre o código de versión.';
	    RETURN _rtn_mensaje;
	  END IF;
        END IF;


	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  	-- Recupero la revision del modulo raiz de la version del plan
  	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  	SELECT elemento_revision, plan 
  	    INTO _revision_modulo_raiz_old, _plan
  	    FROM sga_planes_versiones
  	    WHERE plan_version = pPlan_version_origen;
  	    
	IF _revision_modulo_raiz_old IS NULL OR NOT FOUND THEN	
		_rtn_mensaje := '-1,No existe la versión actual del Plan de Estudios. ID Versión: ' || pPlan_version_origen::varchar;
		RETURN _rtn_mensaje;
	END IF;
	
	-- Si hay otra version nueva del Plan de Estudios, no la dejo crear.
	IF pTipo = 'V' THEN
	  SELECT count(*) INTO cnt FROM sga_planes_versiones WHERE plan = _plan AND estado = 'N';
	  IF cnt > 0 THEN	
	  	_rtn_mensaje := '-1, Ya existe una versión del Plan de Estudios en estado "Nuevo". No se permite crear otra version del plan de estudios.';
	  	RETURN _rtn_mensaje;
	  END IF;
	END IF;
	

  	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  	-- Recorro los elementos del plan. 
  	-- Genero revisiones nuevas de los modulos no compartibles.
  	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  	DROP TABLE IF EXISTS tmp_elementos;
  	CREATE TEMP TABLE tmp_elementos (elemento_revision_old  integer, elemento_revision_new integer);
  	
	INSERT INTO tmp_elementos (elemento_revision_old, elemento_revision_new)
	  SELECT elemento_revision, elemento_revision  FROM sga_elementos_plan  WHERE plan_version = pPlan_version_origen;
  	  
  	-- Recupero los elementos del Plan (modulos y actividades)
  	FOR cursor1 IN SELECT e.elemento, ep.elemento_revision, e.compartible, e.entidad_subtipo, e.entidad_tipo 
  	    FROM sga_elementos_plan as ep,
  	         vw_elementos as e
  	    WHERE ep.plan_version   = pPlan_version_origen
  	    AND e.elemento_revision = ep.elemento_revision
        LOOP		
  	
  	    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	    -- Si es un módulo verifico si debo generar una nueva revision al mismo.
	    -- Para nuevo plan se genera un nuevo modulo.
	    -- Para una version de plan se genera una nueva revision al modulo existente de la version origen del plan.
  	    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 	    IF cursor1.entidad_tipo = 1 THEN
 			-- MODULOS: 
 			--    a. Que no sea compartible 
 			--    b. Que no sea una materia Genérica
 			IF cursor1.compartible = 'N' AND cursor1.entidad_subtipo <> 2 THEN
 			
 			   _elemento_new := cursor1.elemento;
 			   
 			   IF pTipo = 'P' THEN
 			      -- Para el caso de Nuevo Plan, creo nuevos modulos que sean copia de los modulos de la version de plan origen
 			      -- En caso de nuevas versinoes, se genera una nueva revision de cada modulo
                  -- Estos modulos no llevan registro en sga_elementos_atrib ni en sga_elementos_ra		
 			      
 			      INSERT INTO sga_elementos (nombre, nombre_abreviado, codigo, entidad_subtipo,	compartible, estado, disponible_para)
 			         SELECT nombre, nombre_abreviado, codigo, entidad_subtipo,	compartible, estado, disponible_para
 			           FROM sga_elementos WHERE elemento = cursor1.elemento; 

				  -- Recupero el id del elemento
				  _elemento_new := (SELECT currval('sga_elementos_seq'));
				 
 			   END IF;
 			
 			
				-- Genero una nueva revision de los modulos que no son compartibles. Copia de la revision original
				INSERT INTO sga_elementos_revision (elemento, regla, parametros, origen_creditos)
					SELECT _elemento_new, regla, parametros, origen_creditos  
					  FROM sga_elementos_revision
					 WHERE elemento_revision = cursor1.elemento_revision;

				-- Recupero el Serial (entidad).
				_elemento_revision_new := (SELECT currval('sga_elementos_revision_seq'));

				-- Actualizo la tabla temporal con el nuevo nro de revision. No importa si es actividad.
				UPDATE tmp_elementos 
					SET elemento_revision_new = _elemento_revision_new 
					WHERE elemento_revision_old = cursor1.elemento_revision; 
				
			ELSE
			   -- Modulos Compartibles
			END IF;
		ELSE
		   -- ACTIVIDADES
 		END IF;
 		
	END LOOP;
	
  	    
  	-- Cursor de la tabla temporal con los elementos del plan. Solo los módulos con revisiones nuevas.
  	-- Creo las componentes de las nuevas revisiones de módulos generados.
  	FOR cursor2 IN SELECT elemento_revision_old, elemento_revision_new 
  	    FROM tmp_elementos
  	    WHERE elemento_revision_old <> elemento_revision_new
  	LOOP
		-- Genero las componentes de la nueva revisión del módulo.	
		INSERT INTO sga_elementos_comp (elemento_padre, elemento_hijo, puntaje, orden)
			SELECT 
				cursor2.elemento_revision_new,
				(select elemento_revision_new FROM tmp_elementos WHERE elemento_revision_old = sga_elementos_comp.elemento_hijo),
				puntaje,
				orden
			FROM sga_elementos_comp
			WHERE elemento_padre = cursor2.elemento_revision_old;
	END LOOP;
    
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Creo version del plan
    -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Recupeo la nueva revision del elemento raiz (puede ser del mismo módulo o de un módulo nuevo)
    SELECT elemento_revision_new INTO _revision_modulo_raiz_new
		FROM tmp_elementos 
		WHERE elemento_revision_old = _revision_modulo_raiz_old;
	
	_plan_new := _plan;
	
	IF pTipo = 'P' THEN
	  -- Asigno un codigo correlativo sacado de una secuencia para estos casos
	  _codigo_plan := _prefijo_codigo_plan || cast((SELECT nextval('codigo_planes_personalizados_seq')) as varchar);
	  
	  -- Creo un nuevo plan de estudios con los datos del original más los dados por parámetro.
  	  -- En caso de que el Plan sea de Tipo Convenio
      INSERT INTO sga_planes (propuesta, nombre, codigo, tipo_plan, duracion_teorica, duracion_en_anios, duracion_en_meses, vigencia_minima, 
                              tope_creditos_cursado, tope_creditos_reg_vigentes, documento_alta, inscripcion_habilitada, estado, convenio)
        SELECT pPropuesta, pPlan_nombre, _codigo_plan, pPlan_tipo, duracion_teorica, duracion_en_anios, duracion_en_meses, vigencia_minima, 
               tope_creditos_cursado, tope_creditos_reg_vigentes, documento_alta, inscripcion_habilitada, 'N', pConvenio
          FROM sga_planes
         WHERE plan = _plan;
      
      -- Recupero el id del nuevo plan.   
      _plan_new := (SELECT currval('sga_planes_seq'));
	  
	  -- Insertar la Modalidad correspondiente al Plan creado (modalidad única para planes personalizados).
	  INSERT INTO sga_planes_modalidad(plan, modalidad)
		VALUES (_plan_new, pModalidad);
	END IF;

	-- Nueva version de plan de estudios
    INSERT INTO sga_planes_versiones (version, nombre, plan, elemento_revision, cnt_materias, cnt_optativas, cnt_idiomas, estado)
      SELECT pVersion, pVersion_nombre, _plan_new, _revision_modulo_raiz_new, cnt_materias, cnt_optativas, cnt_idiomas, 'N'
        FROM sga_planes_versiones
       WHERE plan_version = pPlan_version_origen;
       
    -- Recupero el id de la nueva version del plan.   
    _plan_version_new := (SELECT currval('sga_planes_versiones_seq'));

    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Inserto los elementos del Plan en la nueva version.
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    INSERT INTO sga_elementos_plan (
        plan_version,
        elemento_revision,
        nombre,
        nombre_abreviado,
        anio_de_cursada,
        periodo_de_cursada ,
        escala_nota_cursada_regular ,
        escala_nota_cursada_promocion ,
        escala_nota_examen ,
        escala_nota_equivalencia ,
        creditos,
        creditos_min,
        creditos_max,
        coeficiente,
        horas_semanales,
        horas_totales,
        requiere_cursada,
        requiere_examen,
        permite_promocion,
        permite_rendir_libre,
        aprobacion_x_resolucion,
        vigencia,
        plazo,
        promediable,
        sale_listado,
        cantidad_de_aplazos,
		cobrable
        )
      SELECT 
        _plan_version_new, 
        t.elemento_revision_new,
        ep.nombre,
        ep.nombre_abreviado,
        ep.anio_de_cursada,
        ep.periodo_de_cursada ,
        ep.escala_nota_cursada_regular ,
        ep.escala_nota_cursada_promocion ,
        ep.escala_nota_examen ,
        ep.escala_nota_equivalencia ,
        ep.creditos,
        ep.creditos_min,
        ep.creditos_max,
        ep.coeficiente,
        ep.horas_semanales,
        ep.horas_totales,
        ep.requiere_cursada,
        ep.requiere_examen,
        ep.permite_promocion,
        ep.permite_rendir_libre,
        ep.aprobacion_x_resolucion,
        ep.vigencia,
        ep.plazo,
        ep.promediable,
        ep.sale_listado,
        ep.cantidad_de_aplazos,
		ep.cobrable

      FROM sga_elementos_plan as ep,
           tmp_elementos as t
      WHERE ep.plan_version = pPlan_version_origen
      AND t.elemento_revision_old = ep.elemento_revision;

     
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Modalidad de los Elementos del Plan
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	IF pTipo = 'P' THEN
	  -- En el caso de Plan Personalizado la modalidad viene por parámetro y se la asigna a todas las actividades.
	  INSERT INTO sga_elementos_plan_modalidad (elemento_plan, modalidad)
	      SELECT elemento_plan, pModalidad
	        FROM sga_elementos_plan as ep,
	             sga_elementos_revision as er,
	             sga_elementos as e,
	             sga_g3entidades_subtipos as s
    	   WHERE ep.plan_version      = _plan_version_new
    	     AND er.elemento_revision = ep.elemento_revision
    	     AND e.elemento = er.elemento
    	     AND s.entidad_subtipo = e.entidad_subtipo
    	     AND s.entidad_tipo = 2;
    	     
	ELSE
	    -- En la creación de Versión en base a una version del mismo plan, se copia de la versión anterior del plan.
    	INSERT INTO sga_elementos_plan_modalidad (elemento_plan, modalidad)
	      SELECT ep2.elemento_plan, m.modalidad
	      FROM sga_elementos_plan as ep1,
    	       sga_elementos_plan_modalidad as m,
    	       tmp_elementos as t,
	           sga_elementos_plan as ep2
    	  WHERE ep1.plan_version      = pPlan_version_origen
	      AND m.elemento_plan         = ep1.elemento_plan       
    	  AND t.elemento_revision_old = ep1.elemento_revision
	      AND ep2.plan_version        = _plan_version_new
	      AND ep2.elemento_revision   = t.elemento_revision_new;
	END IF;
      
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Matrices de Equivalencias que tenga definida la version de plan de estudios origen con otros planes
    -- de la misma propuesta o con otras propuestas o general.
    -- No se copian las matrices que el Plan-version tenga definida con otra version del mismo plan de estudios.
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    _cnt_matrices := f_copiar_matrices_equivalencia(pPlan_version_origen, _plan_version_new, NULL::integer);
   
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Correlativas y Certificados
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Certificados
    INSERT INTO sga_planes_certificados (plan_version, certificado)
      SELECT _plan_version_new, certificado
      FROM sga_planes_certificados
      WHERE plan_version = pPlan_version_origen;


    -- 1. Recorro la cabecera de las condiciones (correlativas y cumplimiento de certificados)
    FOR cursor3 IN SELECT condicion  FROM sga_condiciones WHERE plan_version = pPlan_version_origen
    LOOP
      -- Inserto registro en la cabecera
      INSERT INTO sga_condiciones (entidad, condicion_tipo, plan_version)
        SELECT 
               CASE 
                 WHEN c.condicion_tipo = '3' THEN c.entidad     -- Certificados
                 ELSE  
                     COALESCE( -- Recupero la entidad del elemento o nuevo elemento creado. Correlativas.
                       (SELECT nuevo.entidad
                         FROM sga_elementos as e,
                              sga_elementos_revision as er,
                              tmp_elementos as t,
                              sga_elementos_revision as er2,
                              sga_elementos as nuevo
                        WHERE e.entidad = c.entidad
                          AND er.elemento = e.elemento
                          AND t.elemento_revision_old = er.elemento_revision
                          AND er2.elemento_revision = t.elemento_revision_new
                          AND nuevo.elemento = er2.elemento
                      ), c.entidad)
               END,  
               c.condicion_tipo, 
               _plan_version_new
         FROM sga_condiciones as c
        WHERE c.condicion = cursor3.condicion;
        
      -- Recupero el serial.	
      _condicion_new := (SELECT currval('sga_condiciones_seq'));
  
      -- 2. Grupos de Condiciones
      FOR cursor4 IN SELECT sga_condiciones_grupos.condicion, sga_condiciones_grupos.grupo_condicion, sga_condiciones_grupos.orden
        FROM sga_condiciones, 
             sga_condiciones_grupos
       WHERE sga_condiciones.condicion  = sga_condiciones_grupos.condicion
         AND sga_condiciones.plan_version = pPlan_version_origen
         AND sga_condiciones_grupos.condicion = cursor3.condicion
        
       LOOP 
         -- Grupo de condiciones
         INSERT INTO sga_condiciones_grupos (condicion, orden) VALUES (_condicion_new, cursor4.orden);
         _grupo_new := (SELECT currval('sga_condiciones_grupos_seq'));
      
        -- Requisitos del Grupo.		
        INSERT INTO sga_condiciones_requisitos (grupo_condicion, orden, operador_not, tipo, requisito, origen, entidad, estado, regla,	parametros)
           SELECT _grupo_new, orden, operador_not, tipo, requisito, origen, 
                  CASE
                    WHEN entidad IS NULL THEN entidad
                    ELSE
                      COALESCE(( -- Recupero la entidad del elemento o nuevo elemento creado (por si se crea un nuevo modulo en vez de una nueva revision)
                                SELECT nuevo.entidad
                                  FROM sga_elementos as e,
                                       sga_elementos_revision as er,
                                       tmp_elementos as t,
                                       sga_elementos_revision as er2,
                                       sga_elementos as nuevo
                                 WHERE e.entidad = sga_condiciones_requisitos.entidad
                                   AND er.elemento = e.elemento
                                   AND t.elemento_revision_old = er.elemento_revision
                                   AND er2.elemento_revision = t.elemento_revision_new
                                   AND nuevo.elemento = er2.elemento
                               ), sga_condiciones_requisitos.entidad)
                  END, 
                  estado, regla, parametros
           FROM sga_condiciones_requisitos 
                
           WHERE grupo_condicion = cursor4.grupo_condicion;
       
      END LOOP; -- Grupos de Condiciones.
  END LOOP; -- Condiciones.

   -- Borro la tabla temporal
   DROP TABLE IF EXISTS tmp_elementos;

   -- Salgo.
    _rtn_mensaje := _plan_version_new::varchar || ',OK';
    RETURN _rtn_mensaje;
    
  END;
$$;
