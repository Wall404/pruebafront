create function negocio.ftia_sga_alumnos_optativas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    INSERT INTO sga_alumnos_optativas_mov (alumno, plan_version, generica, optativa, accion)
	   VALUES (NEW.alumno, NEW.plan_version, NEW.generica, NEW.optativa, 'I');

	RETURN NEW;
END;
$$;
