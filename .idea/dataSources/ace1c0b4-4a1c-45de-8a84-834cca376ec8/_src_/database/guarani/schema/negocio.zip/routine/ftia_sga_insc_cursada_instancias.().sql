create function negocio.ftia_sga_insc_cursada_instancias() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion integer;
  DECLARE _alumno integer;
  DECLARE _cursada smallint;
  DECLARE _promocion smallint;
  DECLARE _escala_nota integer;
  DECLARE _plan_version integer;

  BEGIN
  	-- Instancias: 1-Cursadas / 2-Promocion

    -- Recupero la evaluacion automatica de la comision.
    SELECT sga_insc_cursada.alumno, sga_evaluaciones.evaluacion, sga_comisiones_instancias.escala_nota, sga_insc_cursada.plan_version 
      INTO _alumno, _evaluacion, _escala_nota, _plan_version
    FROM sga_insc_cursada,
         sga_comisiones, 
         sga_comisiones_instancias, 
         sga_evaluaciones,
         sga_evaluaciones_tipos
    WHERE sga_insc_cursada.inscripcion = NEW.inscripcion
      AND sga_comisiones.comision      = sga_insc_cursada.comision
      AND sga_comisiones_instancias.comision  = sga_comisiones.comision
      AND sga_comisiones_instancias.instancia = NEW.instancia
      AND sga_evaluaciones.entidad     = sga_comisiones.entidad
      AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
      AND sga_evaluaciones_tipos.automatica = 'S'; -- Generación Automática

    IF _evaluacion IS NOT NULL THEN
       -- Verifico si tiene registro en el detalle de las evaluaciones y si esta inscripto a otra instancia
       SELECT instancia_cursada, instancia_promocion
         INTO _cursada, _promocion
         FROM sga_eval_detalle_cursadas
         WHERE sga_eval_detalle_cursadas.evaluacion = _evaluacion
           AND sga_eval_detalle_cursadas.alumno     = _alumno;
           
       
       IF FOUND THEN
         -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         -- Actualizo el dato de la instancia y escala de notas
         -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         -- Cursadas
         IF NEW.instancia = 1 and _cursada = 0 THEN
           UPDATE sga_eval_detalle_cursadas    
           SET instancia_cursada = 1,
               escala_nota_cursada = _escala_nota,
               inscripto = 'S'
           WHERE sga_eval_detalle_cursadas.evaluacion = _evaluacion
             AND sga_eval_detalle_cursadas.alumno     = _alumno;
         END IF;
         
         -- Promocion
         IF NEW.instancia = 2 and _promocion = 0 THEN
           UPDATE sga_eval_detalle_cursadas    
           SET instancia_promocion = 1, 
               escala_nota_promocion = _escala_nota,
               inscripto = 'S'
           WHERE sga_eval_detalle_cursadas.evaluacion = _evaluacion
             AND sga_eval_detalle_cursadas.alumno     = _alumno;
         END IF;
         
       ELSE
         -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         -- Inserto el registro en el detalle de las evaluaciones.
         -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
         -- Cursada
         IF NEW.instancia = 1  THEN
            INSERT INTO sga_eval_detalle_cursadas (evaluacion, alumno, instancia_cursada, escala_nota_cursada, inscripto, plan_version)
                 VALUES (_evaluacion, _alumno, 1, _escala_nota, 'S', _plan_version);
         END IF;
         
         -- Promociones 
         IF NEW.instancia = 2  THEN
            INSERT INTO sga_eval_detalle_cursadas (evaluacion, alumno, instancia_promocion, escala_nota_promocion, inscripto, plan_version)
                VALUES (_evaluacion, _alumno, 1, _escala_nota, 'S', _plan_version);
          END IF;
       END IF; -- Fin detalle de evaluaciones
   
    END IF;   -- evaluacion IS NOT NULL    
     
    RETURN NEW;
  END;
$$;
