CREATE VIEW vw_equivalencias AS SELECT sga_equiv_otorgada.equivalencia,
    sga_equiv_otorgada.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_otorgada.elemento,
    sga_equiv_otorgada.instancia,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado,
    sga_equiv_otorgada.fecha_vigencia,
    sga_equiv_otorgada.temas_a_rendir,
    sga_equiv_otorgada.grupo_equivalencia,
    sga_equiv_otorgada.rectificado,
    sga_equiv_otorgada.rectifica_a,
    sga_equiv_otorgada.estado,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_resultado.descripcion AS resultado_descripcion
   FROM (((negocio.sga_equiv_tramite
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_equiv_otorgada.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_equiv_otorgada.nota)::text))))
     JOIN negocio.sga_escalas_notas_resultado ON ((sga_escalas_notas_resultado.resultado = sga_equiv_otorgada.resultado)))
  WHERE ((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar));
