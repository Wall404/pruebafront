create function negocio.ftdb_sga_actas_detalle() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
   _estado char(1);
BEGIN
   -- No se permite borrar un registro si el acta esta cerrada. (y Anulada?)
   SELECT estado INTO _estado
      FROM sga_actas
      WHERE id_acta = OLD.id_acta;
   
   IF _estado = 'C' THEN
      raise exception 'No se puede sacar alumnos del acta porque esta Cerrada';
   ELSEIF _estado = 'B' THEN
      raise exception 'No se puede sacar alumnos del acta porque esta Anulada';
   END IF ;
   
   RETURN OLD;
END;
$$;
