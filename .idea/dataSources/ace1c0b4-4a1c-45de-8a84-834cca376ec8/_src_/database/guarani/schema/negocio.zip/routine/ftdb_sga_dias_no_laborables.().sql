create function negocio.ftdb_sga_dias_no_laborables() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    -- Vuelvo a activar las clases que fueron invalidadas por el alta de un dia no laborable
    -- motivo_invalidacion = 1 (dia no laborable)
    UPDATE sga_clases 
      SET valido = 1,
          motivo_invalidacion = NULL
     WHERE fecha = OLD.fecha 
       AND valido = 0 
       AND motivo_invalidacion = 1; 
    
    RETURN OLD;
  END;
$$;
