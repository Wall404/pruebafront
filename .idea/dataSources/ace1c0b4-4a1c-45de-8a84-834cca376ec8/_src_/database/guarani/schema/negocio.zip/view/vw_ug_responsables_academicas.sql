CREATE VIEW vw_ug_responsables_academicas AS SELECT sga_unidades_gestion.unidad_gestion,
    sga_responsables_academicas.responsable_academica
   FROM negocio.sga_unidades_gestion,
    negocio.sga_responsables_academicas
  WHERE (sga_unidades_gestion.dominio = 1)
UNION
 SELECT sga_ug_tipos_propuestas.unidad_gestion,
    sga_propuestas_ra.responsable_academica
   FROM ((negocio.sga_ug_tipos_propuestas
     JOIN negocio.sga_propuestas ON ((sga_propuestas.propuesta_tipo = sga_ug_tipos_propuestas.propuesta_tipo)))
     JOIN negocio.sga_propuestas_ra ON ((sga_propuestas_ra.propuesta = sga_propuestas.propuesta)))
UNION
 SELECT sga_ug_responsables_academicas.unidad_gestion,
    sga_ug_responsables_academicas.responsable_academica
   FROM negocio.sga_ug_responsables_academicas
UNION
 SELECT sga_ug_propuestas.unidad_gestion,
    sga_propuestas_ra.responsable_academica
   FROM (negocio.sga_ug_propuestas
     JOIN negocio.sga_propuestas_ra ON ((sga_propuestas_ra.propuesta = sga_ug_propuestas.propuesta)));
