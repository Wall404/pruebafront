create function negocio.ftib_sga_constancias_solicitud() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _vigencia integer;
BEGIN
       IF NEW.nro_transaccion IS NULL THEN
	     -- Genera un nro de Transaccion
         NEW.nro_transaccion := f_nro_transaccion();
       END IF; 
       
       -- Si fue solicitado por web y se valida online, defino la fecha de fin de vigencia
       IF NEW.estado = 'Online' THEN
          SELECT vigencia INTO _vigencia
            FROM sga_constancias
           WHERE constancia = NEW.constancia;
          IF _vigencia IS NOT NULL AND _vigencia > 0 THEN
            NEW.fecha_fin_vigencia = CURRENT_DATE + _vigencia;
          END IF;  
       END IF;
       
       RETURN NEW;
  END;
$$;
