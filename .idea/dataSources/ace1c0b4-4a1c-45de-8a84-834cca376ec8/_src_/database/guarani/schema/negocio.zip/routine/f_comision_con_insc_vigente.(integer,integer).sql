create function negocio.f_comision_con_insc_vigente(integer, integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE 

_id_plan_version ALIAS for $1;
_id_comision ALIAS for $2;
fecha RECORD;

BEGIN
    
  FOR fecha IN (SELECT	COALESCE(sga_comisiones_excep_perinsc.fecha_inicio, sga_periodos_inscripcion_fechas.fecha_inicio) as fecha_inicio,
						COALESCE(sga_comisiones_excep_perinsc.fecha_fin, sga_periodos_inscripcion_fechas.fecha_fin) as fecha_fin
			FROM 	sga_comisiones,
						sga_periodos_lectivos,
						sga_periodos,
						sga_periodos_inscripcion,
						sga_periodos_inscripcion_aplanado,
						sga_periodos_inscripcion_fechas
							LEFT JOIN sga_comisiones_excep_perinsc ON (sga_comisiones_excep_perinsc.comision = _id_comision 
														AND sga_comisiones_excep_perinsc.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc)
			WHERE sga_comisiones.comision = _id_comision
		    AND sga_comisiones.inscripcion_habilitada = 'S'				
		    AND sga_periodos_inscripcion_fechas.habilitado = 'S'
		    AND sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo
		    AND sga_periodos.periodo = sga_periodos_lectivos.periodo
		    AND sga_periodos_inscripcion.periodo = sga_periodos.periodo
		    AND sga_periodos_inscripcion_fechas.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion
		    AND sga_periodos_inscripcion_aplanado.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc
		    AND sga_periodos_inscripcion_aplanado.plan_version = _id_plan_version) 
  LOOP
			IF (CURRENT_TIMESTAMP BETWEEN fecha.fecha_inicio AND fecha.fecha_fin) THEN 
				RETURN TRUE;
			END IF;    
  END LOOP;

  RETURN FALSE;
END
$$;
