create function negocio.sau_mdp_personas() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
	schema_temp varchar;
	rtabla_usr RECORD;
	rusuario RECORD;
	vusuario VARCHAR(60);
BEGIN
	SELECT INTO schema_temp negocio.recuperar_schema_temp();
	SELECT INTO rtabla_usr * FROM pg_tables WHERE tablename = 'tt_usuario' AND schemaname = schema_temp;
	IF FOUND THEN
		SELECT INTO rusuario usuario, id_solicitud FROM tt_usuario;
		IF FOUND THEN
			vusuario := rusuario.usuario;
		ELSE
			vusuario := user;
		END IF;
	ELSE
		vusuario := user;
	END IF;
     IF (exists (Select * from negocio.mdp_personas_grupo_acc
     where mdp_personas_grupo_acc.tipo_usuario='Gestion' and mdp_personas_grupo_acc.tipo_usuario<>'Alumno' and
     mdp_personas_grupo_acc.usuario_grupo_acc<>'docente' and mdp_personas_grupo_acc.usuario_grupo_acc<>'alumno' and
     mdp_personas_grupo_acc.persona= OLD.persona) and not exists(SELECT *
		FROM negocio.mdp_personas
		join negocio.mdp_personas_grupo_acc on (mdp_personas.persona = mdp_personas_grupo_acc.persona)
		where usuario = vusuario and usuario_grupo_acc='admin') and not vusuario = 'siu') THEN
            RAISE EXCEPTION 'This settlement is locked';
	RETURN OLD;
     ELSE
	RETURN NEW;
     END IF;
END;
$$;
