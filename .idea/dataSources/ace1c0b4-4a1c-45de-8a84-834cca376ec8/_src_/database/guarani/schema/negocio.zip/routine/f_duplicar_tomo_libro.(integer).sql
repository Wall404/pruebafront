create function negocio.f_duplicar_tomo_libro(ptomo integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE new_tomo_libro integer;
 DECLARE _nro_tomo integer;
 DECLARE _libro integer;

BEGIN
	
  INSERT INTO sga_libros_tomos (nro_tomo, libro, cant_max_folios)
    SELECT (SELECT max(b.nro_tomo) + 1
              FROM sga_libros_tomos as a,
                   sga_libros_tomos as b
             WHERE a.libro_tomo = pTomo
               AND b.libro = a.libro
           ),
           libro, 
           cant_max_folios 
      FROM sga_libros_tomos
     WHERE libro_tomo = pTomo;
    
  -- Obtengo el ID del tomo
  new_tomo_libro := (SELECT currval('sga_libros_tomos_seq'));

  RETURN new_tomo_libro;

END;
$$;
