create function negocio.f_copiar_habilitacion_encuesta(phabilitacion integer) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE 
	_hab_nueva integer;
	cur_retorno type_retorno_funcion;
BEGIN
BEGIN -- Comienza la transacción.
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Se inerta la nueva habilitación.
	-- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	INSERT INTO gde_habilitaciones (
		titulo,	tipo, alcance, encuestado, descripcion, fecha_desde, fecha_hasta,
		activo, obligatoria, anonima, alumnos, alumnos_inscriptos, alumnos_reinscriptos, inscriptos_comision,
		cursada_aprobada, cursada_desaprobada, cursada_promocionada, anio_academico, periodo_lectivo,
		examen_aprobado, examen_desaprobado, docentes, egresados, fecha_egreso_desde, fecha_egreso_hasta,
		kolla_id_habilitacion, kolla_password, kolla_sincronizado, kolla_unidad_gestion, encuesta_por_propuesta)
	SELECT
		'Copia de ' || titulo, tipo, alcance, encuestado, descripcion, CURRENT_DATE + 1, CURRENT_DATE + 1,
		'S', obligatoria, anonima, alumnos, alumnos_inscriptos, alumnos_reinscriptos, inscriptos_comision,
		cursada_aprobada, cursada_desaprobada, cursada_promocionada, anio_academico, periodo_lectivo,
		examen_aprobado, examen_desaprobado, docentes, egresados, fecha_egreso_desde, fecha_egreso_hasta,
		NULL, kolla_password, 'N', kolla_unidad_gestion, encuesta_por_propuesta
	FROM gde_habilitaciones
	WHERE habilitacion = pHabilitacion;

	-- Se obtiene el identificador de la habilitación.
	_hab_nueva := (SELECT currval('gde_habilitaciones_seq'));

	-- Se copian los datos de encuestas, alcances, destinatarios y docentes.
	INSERT INTO gde_grupos (habilitacion, encuesta)
		SELECT _hab_nueva, encuesta FROM gde_grupos WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_responsables_academicas (habilitacion, responsable_academica)
		SELECT _hab_nueva, responsable_academica FROM gde_responsables_academicas WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_propuestas (habilitacion, propuesta)
		SELECT _hab_nueva, propuesta FROM gde_propuestas WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_propuestas_tipos (habilitacion, propuesta_tipo)
		SELECT _hab_nueva, propuesta_tipo FROM gde_propuestas_tipos WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_modalidades (habilitacion, modalidad)
		SELECT _hab_nueva, modalidad FROM gde_modalidades WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_ubicaciones (habilitacion, ubicacion)
		SELECT _hab_nueva, ubicacion FROM gde_ubicaciones WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_anios_academicos (habilitacion, anio_academico)
		SELECT _hab_nueva, anio_academico FROM gde_anios_academicos WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_actividades (habilitacion, elemento)
		SELECT _hab_nueva, elemento FROM gde_actividades WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_docentes_resp (habilitacion, responsabilidad)
		SELECT _hab_nueva, responsabilidad FROM gde_docentes_resp WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_certificados (habilitacion, certificado)
		SELECT _hab_nueva, certificado FROM gde_certificados WHERE habilitacion = pHabilitacion;

	INSERT INTO gde_tesis_estados (habilitacion, estado)
		SELECT _hab_nueva, estado FROM gde_tesis_estados WHERE habilitacion = pHabilitacion;

	-- Error.
	EXCEPTION WHEN OTHERS THEN
		cur_retorno.resultado := -1;
		cur_retorno.mensaje_indice := '800ENC_copiar_habilitacion_error';
	RETURN cur_retorno;
END; -- Termina la transacción.

	-- Retorno OK. Devuelvo el id de la nueva habilitacion.
	cur_retorno.resultado := _hab_nueva;
	cur_retorno.mensaje_indice := '800ENC_copiar_habilitacion_ok';

	RETURN cur_retorno;
END;
$$;
