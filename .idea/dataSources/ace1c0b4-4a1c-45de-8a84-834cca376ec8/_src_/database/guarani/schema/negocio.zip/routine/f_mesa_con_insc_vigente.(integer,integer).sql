create function negocio.f_mesa_con_insc_vigente(pplanversion integer, pmesaexamen integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE 

fecha RECORD;

BEGIN
    
  FOR fecha IN (
    SELECT COALESCE(sga_llamados_mesa_excep_perinsc.fecha_inicio, sga_periodos_inscripcion_fechas.fecha_inicio) as fecha_inicio,
	         COALESCE(sga_llamados_mesa_excep_perinsc.fecha_fin, 
	         COALESCE(sga_periodos_inscripcion_fechas.fecha_fin, cast(sga_llamados_mesa.fecha::text || ' ' || sga_llamados_mesa.hora_inicio::text as timestamp) - cast(cast(sga_periodos_inscripcion_fechas.hs_previas_fin as text) || ' hours' as interval))) as fecha_fin
	    FROM sga_mesas_examen,
	          sga_llamados_turno,
	          sga_periodos,
	          sga_periodos_inscripcion,
	          sga_llamados_mesa_excep_perinsc
	              RIGHT JOIN sga_llamados_mesa  ON sga_llamados_mesa_excep_perinsc.llamado_mesa = sga_llamados_mesa.llamado_mesa
	              RIGHT JOIN sga_periodos_inscripcion_fechas ON sga_llamados_mesa_excep_perinsc.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc,  
	          sga_periodos_inscripcion_aplanado,
	          sga_per_insc_ubicacion
	    WHERE sga_mesas_examen.mesa_examen = pMesaExamen
	      AND sga_llamados_mesa.mesa_examen = sga_mesas_examen.mesa_examen
	      AND sga_llamados_mesa.fecha >= CURRENT_DATE
	      AND sga_llamados_mesa.estado = 'A'
	      AND sga_llamados_turno.llamado = sga_llamados_mesa.llamado
	      AND sga_periodos.periodo = sga_llamados_turno.periodo
	      AND sga_periodos_inscripcion.periodo = sga_periodos.periodo
	      AND sga_periodos_inscripcion.periodo_inscripcion = sga_periodos_inscripcion_fechas.periodo_inscripcion
	      AND sga_periodos_inscripcion_fechas.periodo_insc = sga_periodos_inscripcion_aplanado.periodo_insc
	      AND sga_periodos_inscripcion_fechas.habilitado = 'S'
	      AND sga_periodos_inscripcion_aplanado.plan_version = pPlanVersion
	      AND sga_per_insc_ubicacion.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion
	      AND sga_per_insc_ubicacion.ubicacion = sga_mesas_examen.ubicacion
	      AND EXISTS (SELECT 1 FROM sga_per_insc_modalidad
	                   WHERE sga_per_insc_modalidad.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion
	                     AND sga_per_insc_modalidad.modalidad IN (SELECT modalidad FROM sga_mesas_examen_modalidad  WHERE sga_mesas_examen_modalidad.mesa_examen = pMesaExamen)
	                 )
	) LOOP
           
            IF (CURRENT_DATE >= fecha.fecha_inicio AND CURRENT_DATETIME <= fecha.fecha_fin) THEN 
                RETURN TRUE;
            END IF;    

  END LOOP;
         
  RETURN FALSE;
END
$$;
