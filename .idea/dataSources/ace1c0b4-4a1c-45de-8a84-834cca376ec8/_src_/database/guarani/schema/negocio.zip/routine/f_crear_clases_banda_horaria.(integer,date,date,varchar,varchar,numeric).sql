create function negocio.f_crear_clases_banda_horaria(pbandahoraria integer, pfechadesde date, pfechahasta date, pperiodicidad character varying, pdiasemana character varying, pcantidadhoras numeric) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt  integer;
  _fecha date;
  _valido smallint;
  _dia_semana_fecha smallint;
  _fecha_no_valida smallint;
  _cant_horas numeric(5,2);
  _periodo_lectivo integer;
  _id_tramo integer;
  
BEGIN
  cnt := 0;
  IF pCantidadHoras IS NULL OR pCantidadHoras <= 0 THEN
     _cant_horas := 1;
  ELSE
     _cant_horas := pCantidadHoras;   
  END IF;    
 
  -- Recupero el periodo lectivo
  SELECT sga_comisiones.periodo_lectivo INTO _periodo_lectivo
    FROM sga_comisiones_bh, 
         sga_comisiones 
   WHERE sga_comisiones_bh.comision = sga_comisiones.comision
     AND sga_comisiones_bh.banda_horaria = pBandaHoraria;

  -- Recorro todos los dias desde la fecha de inicio y fecha de finalizacion de la asignacion
  _fecha := pFechaDesde;
  cnt := 0;
  WHILE _fecha <= pFechaHasta LOOP
    
    -- 0 = Domingo.... 6 = Sabado
   _dia_semana_fecha := (SELECT EXTRACT(DOW FROM _fecha));
   IF (pDiaSemana = 'Domingo' and _dia_semana_fecha = 0) OR   
       (pDiaSemana = 'Lunes' and _dia_semana_fecha = 1) OR   
       (pDiaSemana = 'Martes' and _dia_semana_fecha = 2) OR   
       (pDiaSemana = 'Miercoles' and _dia_semana_fecha = 3) OR   
       (pDiaSemana = 'Jueves' and _dia_semana_fecha = 4) OR   
       (pDiaSemana = 'Viernes' and _dia_semana_fecha = 5) OR   
       (pDiaSemana = 'Sabado' and _dia_semana_fecha = 6) THEN
    
      -- Verifico si la clase cae en un dia no laborable.
      SELECT COUNT(*) INTO _fecha_no_valida 
        FROM sga_dias_no_laborables
       WHERE fecha = _fecha;
       
       IF _fecha_no_valida > 0 THEN
          _valido := 0;
       ELSE
          _valido := 1;
       END IF; 
     
      -- Recupero el tramo al que pertenece la clase
      _id_tramo := NULL;
      SELECT id_tramo INTO _id_tramo
        FROM sga_periodos_lectivos_tramos
       WHERE periodo_lectivo = _periodo_lectivo
         AND _fecha BETWEEN fecha_inicio AND fecha_fin
         LIMIT 1;

      IF FOUND THEN
         -- Genero la clase solo si cae dentro de un tramo.    
         INSERT INTO sga_clases (banda_horaria, fecha, valido, cantidad_horas_dictadas, id_tramo) 
            VALUES (pBandaHoraria, _fecha, _valido, _cant_horas, _id_tramo);
      END IF;
    
/*      
      IF NOT FOUND THEN
        -- La clase no cae en ningun tramo del periodo lectivo, busco el mas cercano..
        -- Recupero el 1er tramo que empieza despues de la fecha    
        SELECT id_tramo INTO _id_tramo
          FROM sga_periodos_lectivos_tramos
          WHERE periodo_lectivo = _periodo_lectivo
            AND fecha_inicio > _fecha
          ORDER BY fecha_inicio ASC
          LIMIT 1;
        IF NOT FOUND THEN
           -- Recupero el 1er tramo que finalizó cerca de la fecha de la clase
           SELECT id_tramo INTO _id_tramo
             FROM sga_periodos_lectivos_tramos
            WHERE periodo_lectivo = _periodo_lectivo
              AND fecha_fin < _fecha
            ORDER BY fecha_fin DESC
            LIMIT 1;
        END IF;
      END IF;
*/      

      cnt := cnt + 1;
      
      -- sumo dias segun la periodicidad
      IF pPeriodicidad = 'Semanal' THEN
        _fecha := _fecha + 7;
      ELSEIF pPeriodicidad = 'Quincenal' THEN
        _fecha := _fecha + 14;
      ELSEIF pPeriodicidad = 'Mensual' THEN
        _fecha := _fecha + 28;
      ELSE 
        _fecha := _fecha + 1;
      END IF;
    ELSE
      -- sumo un dia
      _fecha := _fecha + 1;
    END IF;
      
  END LOOP;
  
  -- Retorno cantidad de clases generadas
  RETURN cnt;
    
END;
$$;
