CREATE VIEW vw_ug_personas AS SELECT vw_ug_propuestas.unidad_gestion,
    sga_alumnos.persona
   FROM negocio.sga_alumnos,
    negocio.vw_ug_propuestas
  WHERE ((sga_alumnos.propuesta = vw_ug_propuestas.propuesta) AND (sga_alumnos.ubicacion = vw_ug_propuestas.ubicacion))
UNION
 SELECT sga_ug_responsables_academicas.unidad_gestion,
    sga_docentes.persona
   FROM negocio.sga_docentes,
    negocio.sga_docentes_ra,
    negocio.sga_ug_responsables_academicas
  WHERE ((sga_docentes.docente = sga_docentes_ra.docente) AND (sga_docentes_ra.responsable_academica = sga_ug_responsables_academicas.responsable_academica));
