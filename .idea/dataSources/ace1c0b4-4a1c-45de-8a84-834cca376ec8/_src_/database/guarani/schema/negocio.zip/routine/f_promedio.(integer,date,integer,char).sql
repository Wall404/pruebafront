create function negocio.f_promedio(palumno integer, pfecha date, pcertificado integer, pconaplazos character) returns numeric
LANGUAGE plpgsql
AS $$
DECLARE 
  _promedio numeric(8,3);
  _cantidad_actividades integer;      
  _cantidad_plan integer;      
  _total_notas decimal(10,3);
  _fecha_promedio date;
  _PropuestaAlumno Integer;
  _PlanVersionAlumno Integer;
  _PlanAlumno Integer;
  _Persona Integer;
  cur_prop record;
  cur_ele record;
  _elementos Integer[];

BEGIN
  
  _cantidad_actividades := 0;
  _promedio := 0;
  
  -- Si la fecha hasta la que se evaluan las actividades aprobadas es nula entonces se tomala fecha actual.
  _fecha_promedio := COALESCE(pFecha, CURRENT_DATE);

  -- Recupero datos del alumno a la fecha a evaluar
  _PlanVersionAlumno = (SELECT * FROM get_plan_version_alumno(pAlumno, to_char(_fecha_promedio, 'YYYY-MM-DD'))) ;
  
  SELECT persona, propuesta INTO _Persona, _PropuestaAlumno FROM sga_alumnos WHERE alumno = pAlumno;  
  SELECT plan INTO _PlanAlumno FROM sga_planes_versiones WHERE plan_version = _PlanVersionAlumno;


  -- Actividades realizadas por el alumno
  CREATE TEMP TABLE _Tactividades_aux (elemento integer,id_acta integer,origen char(1), equivalencia_tramite integer, equivalencia integer, fecha date, escala_nota integer, nota varchar(10), resultado char(1));
  CREATE TEMP TABLE _Tactividades (elemento integer,id_acta integer,origen char(1), equivalencia_tramite integer, equivalencia integer, fecha date, escala_nota integer, nota varchar(10), resultado char(1));

  
  -- Propuesta del alumno (Incluye propuestas vinculadas)
  CREATE TEMP TABLE _temp_prop_alumno (alumno integer, propuesta integer, plan integer, plan_version integer);
  CREATE TEMP TABLE _temp_relacion (relacion integer); -- Tabla de propuestas relacionadas

  -- Cargo la propuesta del alumno por la que se consulta el promedio
  INSERT INTO _temp_prop_alumno (alumno, propuesta, plan, plan_version) VALUES (pAlumno, _PropuestaAlumno, _PlanAlumno, _PlanVersionAlumno); 

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- PROPUESTAS VINCULADAS
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO _temp_relacion (relacion) SELECT * FROM get_relacion_propuesta(pAlumno);
     
     -- Recupera todos los planes de estudio de propuestas vinculadas de cada grupo
  -- Saca el distinct porque puede estar el mismo plan de estudios en diferentes grupos
  INSERT INTO _temp_prop_alumno (alumno, propuesta, plan, plan_version)
        SELECT DISTINCT sga_alumnos.alumno, sga_planes.propuesta, sga_planes.plan, sga_alumnos.plan_version
          FROM _temp_relacion as t,
               sga_propuestas_relacion_grupo,
               sga_propuestas_relacion_plan,
               sga_planes, 
               sga_alumnos  
         WHERE sga_propuestas_relacion_grupo.relacion = t.relacion
           AND sga_propuestas_relacion_grupo.incluir_en_analitico = 'S'
           AND sga_propuestas_relacion_plan.relacion_grupo = sga_propuestas_relacion_grupo.relacion_grupo
           AND sga_planes.plan = sga_propuestas_relacion_plan.plan
           AND sga_alumnos.persona = _Persona
           AND sga_alumnos.propuesta = sga_planes.propuesta;

             

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Actividades del Plan Actual del Alumno en cada propuesta. 
  -- Actividades realizadas en la misma propuesta o en otra propuesta (actividades comunes)
  -- Actividades de la version actual del alumno en cada plan de estudios de cada propuesta
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Recupero actividades:
  --  * Aprobadas/reprobadas de la version actual del alumno
  --  * Con fecha menor o igual a la fecha pasada por parametro.
  --  * Solo actividades que son promediables
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 FOR cur_prop IN SELECT alumno, propuesta, plan, plan_version FROM _temp_prop_alumno
 LOOP
 
    -- Recupero actividades que pertenecen a la version del plan de estudios en cada propuesta del alumno
    -- Las actividades pueden haber sido aprobadas en esa version/plan o en versiones/planes anteriores o en otra propuesta...
  
   INSERT INTO _Tactividades_aux (elemento, id_acta, origen, equivalencia_tramite,equivalencia, fecha, escala_nota, nota, resultado)
       SELECT elemento, id_acta, origen, equivalencia_tramite,equivalencia, fecha, escala_nota, nota, resultado
         FROM vw_hist_academica_basica
        WHERE alumno = cur_prop.alumno
          AND fecha <= _fecha_promedio
          AND resultado IN ('A','R')
          AND elemento IN (SELECT vw_elementos_plan.elemento 
                             FROM vw_elementos_plan,
                                  sga_elementos_plan
                             WHERE vw_elementos_plan.plan_version = cur_prop.plan_version
                               AND sga_elementos_plan.elemento_plan = vw_elementos_plan.elemento_plan
                               AND sga_elementos_plan.promediable = 'S');
  END LOOP; -- Propuestas del alumno

  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Saco las materias duplicadas (mismo origen)
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO _Tactividades (elemento, id_acta, origen, equivalencia_tramite, equivalencia, fecha, escala_nota, nota, resultado)
     SELECT DISTINCT elemento, id_acta, origen, equivalencia_tramite, equivalencia, fecha, escala_nota, nota, resultado
      FROM _Tactividades_aux;
   
  	   
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Promedio General en todas las actividades realizadas del plan de estudios (con/sin aplazos)
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF pCertificado IS NULL THEN
      
    -- Recupero el total de notas y la cantidad de examenes/promociones/equivalencias consideradas en el calculo.  
    SELECT SUM(e.valor_numerico), COUNT(*) 
      INTO _total_notas, _cantidad_actividades
      FROM _Tactividades as t,
           sga_escalas_notas_det as e
     WHERE (pConAplazos = 'S' OR (pConAplazos = 'N' AND t.resultado = 'A'))
       AND t.nota IS NOT NULL
       AND e.escala_nota = t.escala_nota
       AND e.nota = t.nota
       AND e.valor_numerico IS NOT NULL;
          
    -- Promedio
    _promedio := _total_notas / _cantidad_actividades;
          
   END IF;  -- Calculo con todas las actividades de la propuesta (no por una certificacion)
      
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Cálculo de promedio de actividades relacionadas con el certificado
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF pCertificado IS NOT NULL THEN
  
	-- Saco las actividades excluidas de la historia académica
	DELETE
	FROM 	_Tactividades
	WHERE	elemento IN (	
				SELECT 	sga_certificados_ha_no_elementos.elemento
				FROM 	sga_certificados_ha_no_elementos, 
						sga_certificados_configurar_ha,
						sga_certificados_otorg
				WHERE 	sga_certificados_ha_no_elementos.certificado_ha = sga_certificados_configurar_ha.certificado_ha
						AND sga_certificados_otorg.nro_solicitud = sga_certificados_configurar_ha.nro_solicitud
						AND sga_certificados_otorg.certificado = pCertificado
						AND sga_certificados_otorg.alumno = pAlumno
			);
  
    -- Recupero el total de notas y la cantidad de examenes/promociones/equivalencias consideradas en el calculo.  
    SELECT SUM(e.valor_numerico), COUNT(*) 
      INTO _total_notas, _cantidad_actividades
      FROM _Tactividades as t,
           sga_escalas_notas_det as e
     WHERE (pConAplazos = 'S' OR (pConAplazos = 'N' AND t.resultado = 'A'))
       AND t.nota IS NOT NULL
       AND e.escala_nota = t.escala_nota
       AND e.nota = t.nota
       AND e.valor_numerico IS NOT NULL
       AND t.elemento IN (SELECT * FROM get_actividades_certificado(pCertificado, _PlanVersionAlumno));
          
    -- Promedio
    _promedio := _total_notas / _cantidad_actividades;
  END IF;


  -- Borro tablas temporales.
  DROP TABLE _Tactividades;
  DROP TABLE _Tactividades_aux;
  DROP TABLE _temp_prop_alumno;
  DROP TABLE _temp_relacion;
  
  -- Retorno el promedio
  RETURN _promedio;
    
END;
$$;
