create function negocio.f_insc_examen_inscribir(pllamadomesa integer, palumno integer, ppersona integer, pplanversionalumno integer, pactividad integer, pestadoinscripcion character, pfueradetermino character, pautorizadopor character varying, pinstancia integer, pinterfaz integer, pinscripcionunicollamado character, pcantinscexamenactividadporllamado integer, pcantinscexamenactividadporturno integer, pparaminscsiemprependiente character) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $fun$
DECLARE 
  cur_retorno type_retorno_inscripcion;
  _inscripcion Integer;
  _llamado Integer;
  _turno_examen Integer;
  _cantidad Integer;
  _cnt Integer;
  _mesa_examen Integer;
  _entidad Integer;
  _persona Integer;
  _fecha date;
  i Smallint;
  _PlanVersionAlumno integer;
  _fecha_inscripcion Timestamp;
  _nro_transaccion Integer;
  _estado_desc Varchar(30);
  _estado_inscripcion char(1);
  _fecha_actual Varchar(10);
  _error_mensaje text;



BEGIN
  
  -- Variables de retorno
  cur_retorno.resultado = 1;
  _inscripcion := NULL;
  _nro_transaccion := NULL;
  _cantidad := 0;
  _estado_desc := '';
  _cnt :=0;

  -- Recupero el id de la persona si no viene.
  IF pPersona IS NULL THEN
    SELECT persona INTO _persona FROM sga_alumnos WHERE alumno = pAlumno;
  ELSE
   _persona := pPersona;
  END IF;

  -- Instancia en la que se inscribe
  IF pInstancia IS NULL THEN
    cur_retorno.resultado := -1;
    cur_retorno.mensaje_indice := '800EXA_insc_examen_sin_instancia';
    RETURN cur_retorno;
  END IF;
   

  -- Obtengo datos del llamado y turno de la mesa de examen.
  -- El turno puede no existir, si son mesas fuera de turnos de examen.
  SELECT sga_llamados_mesa.llamado, sga_llamados_mesa.mesa_examen, sga_llamados_mesa.fecha, sga_llamados_mesa.entidad, sga_llamados_turno.turno_examen
    INTO _llamado, _mesa_examen, _fecha, _entidad, _turno_examen
    FROM sga_llamados_mesa 
         LEFT JOIN sga_llamados_turno ON sga_llamados_turno.llamado = sga_llamados_mesa.llamado
   WHERE llamado_mesa = pLlamadoMesa ; 
         

  -- Recupero la versión del plan del alumno si es nula
  IF pPlanVersionAlumno IS NULL THEN
    _fecha_actual := to_char(CURRENT_DATE, 'YYYY-MM-DD');
    _PlanVersionAlumno := get_plan_version_alumno(pAlumno, _fecha_actual);
  ELSE
    _PlanVersionAlumno := pPlanVersionAlumno;
  END IF;

  -- 1. Verifico que no tenga una inscripción en el llamado mesa por cualquier propuesta
  SELECT COUNT(*) INTO _cnt 
    FROM sga_alumnos,
         sga_insc_examen
    WHERE sga_insc_examen.llamado_mesa = pLlamadoMesa
      AND sga_alumnos.persona = _persona
      AND sga_insc_examen.alumno = sga_alumnos.alumno;
  IF _cnt > 0 THEN
    cur_retorno.resultado := -1;
    cur_retorno.mensaje_indice := '800EXA_insc_examen_existe_insc';
    RETURN cur_retorno;
  END IF;
  

  -- 2. Inscripcion unica por llamado en la misma actividad (cualquier mesa de la actividad en el turno)
  IF pInscripcionUnicoLlamado = 'S' AND _turno_examen IS NOT NULL THEN
     SELECT COUNT(*) INTO _cantidad
       FROM sga_alumnos,
            sga_insc_examen,
            sga_llamados_mesa,
            sga_llamados_turno,
            sga_mesas_examen
      WHERE sga_alumnos.persona = _persona
        AND sga_insc_examen.alumno = sga_alumnos.alumno
        AND sga_insc_examen.llamado_mesa <> pLlamadoMesa  -- otro llamado
        AND sga_llamados_mesa.llamado_mesa = sga_insc_examen.llamado_mesa
        AND sga_llamados_mesa.llamado <> _llamado
        AND sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen
        AND sga_mesas_examen.elemento    = pActividad
        AND sga_llamados_turno.llamado   = sga_llamados_mesa.llamado
        AND sga_llamados_turno.turno_examen = _turno_examen; 
       
    IF _cantidad > 0 THEN
       cur_retorno.resultado := -1;
       cur_retorno.mensaje_indice := '800EXA_insc_examen_ctrl_unico_llamado';
       RETURN cur_retorno;
    END IF;
  END IF; -- pIncripcionUnicoLlamado

  -- 3. Cantidad de inscripciones a la misma actividad en el mismo llamado en todas las propuestas del alumno.
  IF pCantInscExamenActividadPorLLamado > 0 THEN
      SELECT count(*) into _cantidad
        FROM sga_alumnos,
             sga_insc_examen,
             sga_llamados_mesa,
             sga_mesas_examen
       WHERE sga_alumnos.persona = _persona
         AND sga_insc_examen.alumno = sga_alumnos.alumno
         AND sga_llamados_mesa.llamado = _llamado
         AND sga_llamados_mesa.llamado_mesa = sga_insc_examen.llamado_mesa
         AND sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen
         AND sga_mesas_examen.elemento = pActividad;

    IF _cantidad >= pCantInscExamenActividadPorLLamado THEN
       cur_retorno.resultado := -1;
       cur_retorno.mensaje_indice := '800EXA_insc_examen_ctrl_llamado';
       cur_retorno.mensaje_param  := pCantInscExamenActividadPorLLamado;
       RETURN cur_retorno;
    END IF;
  END IF;

  -- 4. Cantidad de inscripciones a examen de la actividad en el turno de examen (en todas las propuestas del alumno)
  IF pCantInscExamenActividadPorTurno > 0 AND _turno_examen IS NOT NULL THEN
    SELECT count(*) into _cantidad
     FROM sga_alumnos,
          sga_insc_examen,
          sga_llamados_mesa,
          sga_llamados_turno,
          sga_mesas_examen
    WHERE sga_alumnos.persona = _persona
      AND sga_insc_examen.alumno = sga_alumnos.alumno
      AND sga_llamados_mesa.llamado_mesa = sga_insc_examen.llamado_mesa
      AND sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen
      AND sga_mesas_examen.elemento = pActividad
      AND sga_llamados_turno.llamado = sga_llamados_mesa.llamado
      AND sga_llamados_turno.turno_examen = _turno_examen;
      
    IF _cantidad >= pCantInscExamenActividadPorTurno THEN
       cur_retorno.resultado := -1;
       cur_retorno.mensaje_indice := '800EXA_insc_examen_ctrl_turno';
       cur_retorno.mensaje_param  := pCantInscExamenActividadPorTurno;
       RETURN cur_retorno;
    END IF;
  END IF;  


  -- 5. Verifico que el alumno no exista en la mesa de examen de ese llamado (por cualquier propuesta). Este o no incluido en acta.
  SELECT COUNT(*) INTO _cantidad
   FROM sga_alumnos,
        sga_eval_detalle_examenes,
        sga_evaluaciones
   WHERE sga_alumnos.persona = _persona
     AND sga_eval_detalle_examenes.alumno = sga_alumnos.alumno
     AND sga_evaluaciones.evaluacion = sga_eval_detalle_examenes.evaluacion
     AND sga_evaluaciones.entidad = _entidad;

  IF _cantidad > 0 THEN
     cur_retorno.resultado := -1;
     cur_retorno.mensaje_indice := '800EXA_insc_examen_ctrl_mesa';
     RETURN cur_retorno;
  END IF;

-- Comienzo transacción.
BEGIN


  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto la inscripcion 
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _fecha_inscripcion := CURRENT_TIMESTAMP;
  _nro_transaccion := (SELECT nextval('aud_nro_transaccion_seq')); 

  -- Estado final de la inscripcion.
  _estado_inscripcion := pEstadoInscripcion;
  IF pParamInscSiemprePendiente = 'S' THEN
    -- Seteo el estado de la inscripcion como Pendiente
    _estado_inscripcion := 'P';
  END IF;


  -- Inserto la inscripción a examen
  INSERT INTO sga_insc_examen (alumno, llamado_mesa, plan_version, instancia, fecha_inscripcion, fuera_de_termino, autorizado_por, nro_transaccion, interfaz, estado)
      VALUES (pAlumno, pLlamadoMesa, _PlanVersionAlumno, pInstancia, _fecha_inscripcion, pFueraDeTermino, pAutorizadoPor, _nro_transaccion, pInterfaz,  _estado_inscripcion);

  -- Recupero el Serial de la inscripcion
  _inscripcion := (SELECT currval('sga_insc_examen_seq'));


  -- Error.
  EXCEPTION 
     WHEN unique_violation THEN
        -- 23505 	UNIQUE VIOLATION
        cur_retorno.resultado := -1;
        cur_retorno.mensaje_indice := '800EXA_insc_examen_existe_insc';
        RETURN cur_retorno;
     WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.resultado := -1;
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en el insert...
        cur_retorno.resultado := -1;
        cur_retorno.mensaje_indice := '800EXA_insc_examen_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- Recupero el nombre del estado de la inscripcion
  SELECT nombre INTO _estado_desc FROM sga_inscripciones_estados WHERE estado = pEstadoInscripcion;
  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800EXA_insc_examen_ok';
  cur_retorno.mensaje_param  := _estado_desc || '$$$' || cast(_nro_transaccion as varchar) ;
  cur_retorno.inscripcion    := _inscripcion;
  cur_retorno.fecha          := _fecha_inscripcion;
  cur_retorno.estado         := pEstadoInscripcion;
  cur_retorno.nro_transaccion := _nro_transaccion;
  
  -- Retorno datos de la inscripcion OK.
  RETURN cur_retorno;

END;
$fun$;
