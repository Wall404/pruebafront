create function negocio.f_insc_cursada_eliminar(pinscripcion integer) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno type_retorno_inscripcion;
  _con_subcomisiones boolean;
  _cnt Smallint;
  _ComisionNombre varchar(100);
  _fecha_baja Timestamp;
  _nro_transaccion_baja Integer;
  _fecha_actual Varchar(10);
  _flag_baja char(1);
  
  -- Datos de la Inscripcion
  _insc  sga_insc_cursada%ROWTYPE;

BEGIN
  
  -- Variables 
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800SIU_baja_insc_cursada_ok';
  cur_retorno.mensaje_param  := NULL;
  
  _flag_baja := 'B'; 
  _nro_transaccion_baja := NULL;
  _con_subcomisiones := false;
  _cnt := 0;
  _ComisionNombre := '';

  -- ********************************************************************
  -- 1. Verifico que exista la inscripcion a dar de baja
  -- ********************************************************************
  SELECT * INTO _insc FROM sga_insc_cursada WHERE inscripcion = pInscripcion;
   
  IF NOT FOUND THEN
    -- No existe la inscripción a dar de baja.
    cur_retorno.resultado := -1;
    cur_retorno.mensaje_indice := '800SIU_baja_insc_cursada_no_existe_insc';
    cur_retorno.mensaje_param  := NULL;
    RETURN cur_retorno;
  END IF;

  -- ********************************************************************
  -- 2. Verifico que este en fecha para ser eliminada 
  -- ********************************************************************

  -- Este control ya esta realizado al momento de recuperar las inscripciones
  -- debido a que solo recupera inscripciones que estan en fecha para poder darlas de baja.  

  -- ********************************************************************
  -- 3. Verifico que no este incluida en un acta de la comision
  -- ********************************************************************
  -- Acta de Cursada o Promocion Cerrada
  SELECT Count(*) INTO _cnt
    FROM sga_actas,
         sga_actas_detalle
    WHERE sga_actas.comision = _insc.comision
      AND sga_actas_detalle.id_acta = sga_actas.id_acta
      AND sga_actas_detalle.alumno = _insc.alumno
	  AND sga_actas.estado = 'C';
  IF _cnt > 0 THEN
    SELECT nombre INTO _ComisionNombre FROM sga_comisiones WHERE comision = _insc.comision;
    cur_retorno.resultado := -1;
    cur_retorno.mensaje_indice := '800SIU_baja_insc_cursada_acta';
    cur_retorno.mensaje_param  := _ComisionNombre;
    RETURN cur_retorno;
  END IF;
  
  -- Acta de Cursada o Promocion abierta
  SELECT Count(*) INTO _cnt
    FROM sga_actas,
         sga_eval_detalle_cursadas
    WHERE sga_actas.comision = _insc.comision
      AND ((sga_eval_detalle_cursadas.id_acta_cursada = sga_actas.id_acta AND sga_eval_detalle_cursadas.instancia_cursada = 1 AND sga_actas.origen = 'R') OR
           (sga_eval_detalle_cursadas.id_acta_promocion = sga_actas.id_acta AND sga_eval_detalle_cursadas.instancia_promocion = 1 AND sga_actas.origen = 'P')
		  ) 
      AND sga_eval_detalle_cursadas.alumno = _insc.alumno
	  AND sga_actas.estado = 'A';
	  
  IF _cnt > 0 THEN
    SELECT nombre INTO _ComisionNombre FROM sga_comisiones WHERE comision = _insc.comision;
    cur_retorno.resultado := -1;
    cur_retorno.mensaje_indice := '800SIU_baja_insc_cursada_acta';
    cur_retorno.mensaje_param  := _ComisionNombre;
    RETURN cur_retorno;
  END IF;
  
  
  -- ++++++++++++++++++++ Fin Controles fijos ++++++++++++++++++++++++++++++++++++++++++

  -- Verifico si tiene subcomisiones
  SELECT COUNT(*) INTO _cnt
  FROM sga_subcomisiones
  WHERE comision IN (SELECT comision FROM sga_insc_cursada WHERE nro_transaccion = _insc.nro_transaccion);
  IF _cnt > 0 THEN
     _con_subcomisiones := true;
  END IF;

-- Comienza la Transacción
BEGIN

/* 
  -- ********************************************************************
  -- Actualizacion del cupo. Se pasó al trigger de delete de sga_insc_cursada y sga_insc_subcomision
  -- ********************************************************************
     IF _con_subcomisiones THEN
       IF _insc.tipo = 'I' THEN
         -- Actualizo el cupo en las subcomisiones si hay subcomisiones
         UPDATE sga_subcomisiones_cupo
            SET cant_inscriptos = cant_inscriptos - 1
          WHERE subcomision IN (SELECT subcomision FROM sga_insc_subcomision WHERE inscripcion = pInscripcion);

       ELSE
         -- Busco inscripciones por nro de transaccion
         UPDATE sga_subcomisiones_cupo
            SET cant_inscriptos = cant_inscriptos - 1
          WHERE subcomision IN (SELECT sga_insc_subcomision.subcomision 
                                 FROM sga_insc_cursada, 
                                      sga_insc_subcomision
                                WHERE sga_insc_cursada.nro_transaccion = _insc.nro_transaccion
                                  AND sga_insc_subcomision.inscripcion = sga_insc_cursada.inscripcion);
       END IF;
     END IF; -- con subcomisiones

     -- Actualizo el cupo en la comision
     IF _insc.tipo = 'I' THEN
         -- Actualizo el cupo en comision
         UPDATE sga_comisiones_cupo
            SET cant_inscriptos = cant_inscriptos - 1
          WHERE comision = _insc.comision;
     ELSE
       -- Inscripción por prioridades/alternativas
       -- Actualizo el cupo en las comisiones en las que se pre-inscribió el alumno (inscripcion con prioridad
       UPDATE sga_comisiones_cupo
          SET cant_inscriptos = cant_inscriptos - 1
        WHERE comision IN (SELECT comision FROM sga_insc_cursada WHERE nro_transaccion = _insc.nro_transaccion);
     END IF;
  -- ****************** FIN Actualizacion cupo **************************
*/

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Doy de baja la inscripcion
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _fecha_baja := CURRENT_TIMESTAMP;
  _nro_transaccion_baja := (SELECT nextval('aud_nro_transaccion_seq')); 

  -- Inserto el registro en la tabla de log.
  -- En el caso que sea inscripciones por prioridades, solo registra en el log la de prioridad 1.
  INSERT INTO sga_insc_cursada_log (
         inscripcion, comision, alumno, plan_version, tipo, prioridad, estado_preinscripcion, 
         fuera_de_termino, estado, sq_token, interfaz, fecha_inscripcion, nro_transaccion, exceptuado,
         operacion ,nro_transaccion_log, fecha_operacion)
   VALUES(pInscripcion, _insc.comision, _insc.alumno, _insc.plan_version, _insc.tipo, _insc.prioridad, _insc.estado_preinscripcion, 
         _insc.fuera_de_termino, _insc.estado, _insc.sq_token, _insc.interfaz, _insc.fecha_inscripcion, _insc.nro_transaccion, _insc.exceptuado,
         _flag_baja, _nro_transaccion_baja, _fecha_baja);
 --  AND prioridad = 1;

  -- Borro las inscripciones
  IF _con_subcomisiones THEN
    IF _insc.tipo = 'I' THEN
      -- Inscripcion sin prioridades  
      DELETE FROM sga_insc_subcomision WHERE inscripcion = pInscripcion;
    ELSE 
      -- Inscripcion con prioridades  
      DELETE FROM sga_insc_subcomision 
          WHERE inscripcion IN (SELECT inscripcion FROM sga_insc_cursada WHERE nro_transaccion = _insc.nro_transaccion);
    END IF;       
  END IF;
  
  IF _insc.tipo = 'I' THEN
    -- Inscripcion sin prioridades  
    DELETE FROM sga_insc_cursada_instancias WHERE inscripcion = pInscripcion;
    DELETE FROM sga_insc_cursada WHERE inscripcion = pInscripcion;
  ELSE
    -- Inscripcion con prioridades  
    DELETE FROM sga_insc_cursada_instancias
          WHERE inscripcion IN (SELECT inscripcion FROM sga_insc_cursada WHERE nro_transaccion = _insc.nro_transaccion);
    DELETE FROM sga_insc_cursada WHERE nro_transaccion = _insc.nro_transaccion;
  END IF;

  -- Bloque de excepciones. Sale por error.
  EXCEPTION 
      WHEN OTHERS THEN
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800SIU_baja_insc_cursada_error_db';
        cur_retorno.mensaje_param  := NULL;
        cur_retorno.sqlstate := SQLSTATE;
        cur_retorno.sqlerrm  := SQLERRM;
        RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  -- BAJA OK.
  -- Seteo valores para retorno
  cur_retorno.resultado       := 1;
  cur_retorno.mensaje_indice  := '800SIU_baja_insc_cursada_ok';
  cur_retorno.mensaje_param   := cast(_nro_transaccion_baja as varchar);
  cur_retorno.inscripcion     := pInscripcion;
  cur_retorno.fecha           := _fecha_baja;
  cur_retorno.nro_transaccion := _nro_transaccion_baja;
  
  -- Retorno datos de la baja de la inscripcion
  RETURN cur_retorno;

END;
$$;
