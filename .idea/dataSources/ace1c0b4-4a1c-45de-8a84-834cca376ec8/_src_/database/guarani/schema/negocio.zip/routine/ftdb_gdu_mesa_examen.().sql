create function negocio.ftdb_gdu_mesa_examen() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
      -- Quito los derechos a los docentes del rol a eliminar
      
      DELETE FROM gdu_derechos_personas
        USING sga_llamados_mesa,
             sga_docentes_mesa_llamado,
             sga_docentes
       WHERE sga_llamados_mesa.fecha >= CURRENT_DATE
         AND sga_docentes_mesa_llamado.llamado_mesa = sga_llamados_mesa.llamado_mesa
         AND sga_docentes_mesa_llamado.rol = OLD.rol
         AND sga_docentes.docente = sga_docentes_mesa_llamado.docente
         AND gdu_derechos_personas.persona = sga_docentes.persona
         AND gdu_derechos_personas.derecho = OLD.derecho
         AND gdu_derechos_personas.entidad = sga_llamados_mesa.entidad;
 
    RETURN OLD;
  END;
$$;
