create function negocio.get_localidad_indeterminada_pais(ppais integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
	_localidad_indeterminada integer;
BEGIN
	SELECT	mug_localidades.localidad INTO _localidad_indeterminada
	FROM	mug_localidades,
			mug_dptos_partidos,
			mug_provincias,
			mug_paises
	WHERE	mug_localidades.dpto_partido = mug_dptos_partidos.dpto_partido AND
			mug_dptos_partidos.provincia = mug_provincias.provincia AND
			mug_provincias.pais = mug_paises.pais AND
			mug_paises.pais = pPais AND
			mug_provincias.nombre = 'Indeterminada' AND
			mug_dptos_partidos.nombre = 'Indeterminado' AND
			mug_localidades.nombre = 'Indeterminada';

	RETURN _localidad_indeterminada;
END;
$$;
