create function negocio.ftia_sga_propuestas_aspira() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	-- Actualizo encuestas. Alta de encuestas genéricas vigentes.
	PERFORM f_encuestas_sync_inscripcion_propuesta(NEW.persona, NEW.propuesta, NEW.anio_academico, NEW.ubicacion, NEW.modalidad);

	RETURN NEW;
END;
$$;
