create function negocio.f_limpiar_acentos(text) returns text
LANGUAGE SQL
AS $$
SELECT translate(
    $1,
    'ÀÁÂÃÄÅàáâãäåÒÓÔÕÖØòóôõöøÈÉÊËèéêëÇçÌÍÎÏìíîïÙÚÛÜùúûüÿ',
    'AAAAAAaaaaaaOOOOOOooooooEEEEeeeeCcIIIIiiiiUUUUuuuuy'
);
$$;
