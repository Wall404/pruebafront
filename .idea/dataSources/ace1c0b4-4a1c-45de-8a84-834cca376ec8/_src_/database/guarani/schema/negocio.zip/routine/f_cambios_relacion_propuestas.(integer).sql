create function negocio.f_cambios_relacion_propuestas(prelacion integer) returns void
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _id_cambio integer;

BEGIN
	
  -- Cabecera del historico de cambios en relaciones entre propuestas	
  INSERT INTO his_propuestas_relacion_cambios DEFAULT VALUES;

  _id_cambio := (SELECT currval('his_propuestas_relacion_cambios_seq'));

  INSERT INTO his_propuestas_relacion (id_cambio, relacion, propuesta, plan, anio_academico, fecha_alta)
    SELECT _id_cambio, relacion, propuesta, plan, anio_academico, fecha_alta
      FROM sga_propuestas_relacion
     WHERE relacion = pRelacion;

  INSERT INTO his_propuestas_relacion_grupo (id_cambio, relacion_grupo, relacion, incluir_en_analitico, inscripcion_automatica)
    SELECT _id_cambio, relacion_grupo, relacion, incluir_en_analitico, inscripcion_automatica
      FROM sga_propuestas_relacion_grupo
     WHERE relacion = pRelacion;

  INSERT INTO his_propuestas_relacion_plan (id_cambio, relacion_plan, relacion_grupo, plan)
    SELECT _id_cambio, 
           sga_propuestas_relacion_plan.relacion_plan, 
           sga_propuestas_relacion_plan.relacion_grupo, 
           sga_propuestas_relacion_plan.plan
      FROM sga_propuestas_relacion_grupo,
           sga_propuestas_relacion_plan
     WHERE sga_propuestas_relacion_grupo.relacion = pRelacion
       AND sga_propuestas_relacion_grupo.relacion_grupo = sga_propuestas_relacion_plan.relacion_grupo;

END;
$$;
