create function negocio.ftdb_sga_comisiones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- Borro la evaluacion automÃ¡tica de la comision.
   DELETE FROM sga_evaluaciones 
      WHERE entidad = OLD.entidad
        AND evaluacion_tipo IN (SELECT evaluacion_tipo 
                               FROM sga_evaluaciones_tipos 
                              WHERE aplica_a = 'C' 
                                AND automatica = 'S');

   -- Borro tabla de cupos de la comision
   DELETE FROM sga_comisiones_cupo WHERE comision = OLD.comision;

   -- Borro tabla de excepciones de asistencia por alumno.
   DELETE FROM sga_alumnos_excep_asistencia  WHERE comision = OLD.comision;

   -- Derechos de los docentes sobre la comision
   DELETE FROM gdu_derechos_personas WHERE entidad = OLD.entidad;

   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Encuestas - Borro formularios y encuestados que esten asociados al formuario de la comision
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   DELETE FROM gde_formulario_items WHERE formulario IN (SELECT formulario FROM gde_formularios WHERE comision = OLD.comision);
   DELETE FROM gde_encuestas_pendientes WHERE formulario IN (SELECT formulario FROM gde_formularios WHERE comision = OLD.comision);
   DELETE FROM gde_items WHERE comision = OLD.comision;
   DELETE FROM gde_formularios WHERE comision = OLD.comision;
   
   RETURN OLD;
END;
$$;
