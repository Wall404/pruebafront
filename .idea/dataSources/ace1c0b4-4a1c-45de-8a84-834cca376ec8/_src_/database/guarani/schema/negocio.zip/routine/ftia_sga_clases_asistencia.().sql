create function negocio.ftia_sga_clases_asistencia() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
 
  -- Actualizo registro acumulado de inasistencias o inasist justificadas si fue modificado.
  PERFORM f_asistencia_actualizar_acumulado('I', NEW.alumno, NEW.clase, 0, 0, NEW.cant_inasistencias, NEW.cant_justificadas); 
    
  RETURN NEW;
END;
$$;
