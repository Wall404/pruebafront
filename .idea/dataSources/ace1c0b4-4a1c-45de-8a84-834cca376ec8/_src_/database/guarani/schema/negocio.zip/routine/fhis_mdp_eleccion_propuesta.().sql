create function negocio.fhis_mdp_eleccion_propuesta() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		 INSERT INTO his_eleccion_propuesta (dato_censal, mot_vocacion, mot_sugerencia_familiar, mot_reconocimiento_social, mot_insercion_laboral, mot_perfil_profesional, mot_mejora_economica, mot_util_sociedad, mot_otros) 
		 VALUES (NEW.dato_censal, NEW.mot_vocacion, NEW.mot_sugerencia_familiar, NEW.mot_reconocimiento_social, NEW.mot_insercion_laboral, NEW.mot_perfil_profesional, NEW.mot_mejora_economica, NEW.mot_util_sociedad, NEW.mot_otros);
	
		RETURN NEW;
	END;
$$;
