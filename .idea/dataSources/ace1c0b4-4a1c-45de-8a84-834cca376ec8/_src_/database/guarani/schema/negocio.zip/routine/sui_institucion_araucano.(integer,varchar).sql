create function negocio.sui_institucion_araucano(p_institucion_araucano integer, p_nombre character varying) returns void
LANGUAGE plpgsql
AS $$
BEGIN

  -- Inserta el titulo araucano
  INSERT INTO int_arau_instituciones (institucion_araucano, nombre) 
       VALUES (p_institucion_araucano, p_nombre);
  
  -- Existe la institucion, actualiza el nombre
  EXCEPTION 
     WHEN unique_violation THEN
        UPDATE int_arau_instituciones
		   SET nombre = p_nombre
		 WHERE institucion_araucano = p_institucion_araucano;
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Error Nro: %. %',SQLSTATE, SQLERRM;   

END;
$$;
