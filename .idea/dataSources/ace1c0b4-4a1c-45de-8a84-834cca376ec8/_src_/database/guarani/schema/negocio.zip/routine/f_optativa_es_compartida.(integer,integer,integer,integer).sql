create function negocio.f_optativa_es_compartida(poptativa integer, pplanversion integer, palumno integer, pgenerica integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _rtn integer;
 DECLARE _cnt integer;
 DECLARE _generica_actual integer;

BEGIN
  _cnt := 0;
  _rtn := 0; -- No esta compartida.
  _generica_actual := NULL;
  
  -- Verifico si la optativa esta compartida en mas de una generica o la actividad pasada por parametro no 
  -- forma parte de una generica (no es optativa)
  SELECT COUNT(1) INTO _cnt
    FROM vw_optativas_plan
   WHERE plan_version = pPlanVersion
	 AND elemento     = pOptativa;
	 
  IF _cnt <= 1 THEN
     -- La optativa no esta compartida o no es una actividad optativa
     RETURN 0;
  END IF;  
  
  IF _cnt > 1 AND pAlumno IS NULL THEN
     -- Se consulta sin el alumno, significa que se consulta si la actividad optativa esta en mas de una generica
     -- La optativa esta en mas de una generica.
     RETURN 1;
  END IF;  
  
  -- Es una optativa y esta compartida en mas de una generica.
  -- Verifico si el alumno ya hizo una eleccion de generica.
  SELECT generica INTO _generica_actual
	  FROM sga_alumnos_optativas
    WHERE alumno = pAlumno 
	  AND plan_version = pPlanVersion
      AND optativa = pOptativa;
	  
  IF NOT FOUND THEN
     -- El alumno aun no hizo ninguna asignacion de la optativa a alguna genérica.
     RETURN -1;
  ELSE
    -- La optativa esta asignada a una generica.
    IF pGenerica IS NULL OR (pGenerica IS NOT NULL AND pGenerica = _generica_actual) THEN
	   -- Esta asignada a una generica (la misma pasada por parametro).
	   RETURN 1;
	ELSE
	   -- La optativa esta asignada a una generica diferente por la que se esta consultando.
	   RETURN 2;
    END IF;	
	  
  END IF;
 
 -- Devuelvo el resultado por defecto.
 RETURN _rtn;
 
END;
$$;
