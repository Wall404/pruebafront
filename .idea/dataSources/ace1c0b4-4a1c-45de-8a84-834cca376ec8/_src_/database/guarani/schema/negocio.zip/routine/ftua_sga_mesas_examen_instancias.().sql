create function negocio.ftua_sga_mesas_examen_instancias() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion Integer;
BEGIN

   -- Si se modifico la escala de notas, actualizo la misma en los alumnos de la mesa de examen
   IF NEW.escala_nota <> OLD.escala_nota THEN
     SELECT sga_evaluaciones.evaluacion 
       INTO _evaluacion
      FROM sga_llamados_mesa,
           sga_evaluaciones,
           sga_evaluaciones_tipos
     WHERE sga_llamados_mesa.mesa_examen = NEW.mesa_examen
       AND sga_evaluaciones.entidad = sga_llamados_mesa.entidad
       AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
       AND sga_evaluaciones_tipos.automatica = 'S';
      
     -- Actualizo la escala de notas a los alumnos de esa instancia
     UPDATE sga_eval_detalle_examenes
        SET escala_nota = NEW.escala_nota,
            nota = NULL, 
            resultado = NULL 
      WHERE evaluacion = _evaluacion
        AND instancia = NEW.instancia;

     -- Actualizo las actas de examen de la mesa de examen (puede haber mas de un acta.. por cada llamado)
     -- Solo en actas abiertas (se supone que no se permite cambiar la escala de notas si hay algun acta cerrada)
     UPDATE sga_actas_instancias
        SET escala_nota = NEW.escala_nota
       FROM sga_actas
       WHERE sga_actas.evaluacion = _evaluacion
         AND sga_actas.origen = 'E'
         AND sga_actas_instancias.id_acta = sga_actas.id_acta
         AND sga_actas_instancias.instancia = NEW.instancia   
         AND sga_actas.estado = 'A';

   END IF;
   
   RETURN NEW;
END;
$$;
