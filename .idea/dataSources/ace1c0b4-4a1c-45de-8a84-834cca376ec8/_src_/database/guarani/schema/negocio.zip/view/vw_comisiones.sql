CREATE VIEW vw_comisiones AS SELECT sga_comisiones.comision,
    sga_comisiones.nombre AS comision_nombre,
    sga_comisiones.entidad,
    sga_comisiones.turno AS turno_cursada,
    sga_comisiones.catedra,
    sga_comisiones.ubicacion,
    sga_comisiones.elemento,
    sga_elementos.nombre AS elemento_nombre,
    sga_elementos.codigo AS elemento_codigo,
    sga_periodos.periodo,
    sga_periodos.nombre AS periodo_nombre,
    sga_comisiones.division,
    sga_comisiones.cupo,
    sga_comisiones.cupo_minimo,
    sga_comisiones_cupo.cant_inscriptos,
    sga_comisiones.inscripcion_habilitada,
    sga_periodos.anio_academico,
    sga_periodos.fecha_inicio,
    sga_periodos.fecha_fin,
    sga_periodos_lectivos.periodo_lectivo,
    sga_periodos.nombre AS periodo_lectivo_nombre,
    COALESCE(sga_comisiones_excep_perlect.fecha_inicio_dictado, sga_periodos_lectivos.fecha_inicio_dictado) AS fecha_inicio_dictado,
    COALESCE(sga_comisiones_excep_perlect.fecha_fin_dictado, sga_periodos_lectivos.fecha_fin_dictado) AS fecha_fin_dictado,
    sga_periodos_lectivos.fecha_tope_movimientos,
    sga_periodos_lectivos.fecha_inactivacion,
    sga_periodos_lectivos.entidad AS periodo_lectivo_entidad,
    sga_periodos.periodo_generico,
    sga_periodos_genericos.nombre AS periodo_generico_nombre,
    sga_periodos_lectivos_tipos.nombre AS periodos_lectivo_tipo,
    sga_periodos_genericos.orden_en_su_tipo AS orden,
    sga_comisiones.estado,
    sga_comisiones.cobrable,
    sga_comisiones.inscripcion_cerrada,
    sga_comisiones.inscripcion_cerrada_codigo
   FROM (((((((negocio.sga_comisiones
     LEFT JOIN negocio.sga_comisiones_excep_perlect ON ((sga_comisiones_excep_perlect.comision = sga_comisiones.comision)))
     JOIN negocio.sga_comisiones_cupo ON ((sga_comisiones_cupo.comision = sga_comisiones.comision)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_comisiones.elemento)))
     JOIN negocio.sga_periodos_lectivos ON ((sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo)))
     JOIN negocio.sga_periodos ON ((sga_periodos.periodo = sga_periodos_lectivos.periodo)))
     JOIN negocio.sga_periodos_genericos ON ((sga_periodos_genericos.periodo_generico = sga_periodos.periodo_generico)))
     JOIN negocio.sga_periodos_lectivos_tipos ON (((sga_periodos_lectivos_tipos.periodo_lectivo_tipo)::text = (sga_periodos_genericos.periodo_lectivo_tipo)::text)));
