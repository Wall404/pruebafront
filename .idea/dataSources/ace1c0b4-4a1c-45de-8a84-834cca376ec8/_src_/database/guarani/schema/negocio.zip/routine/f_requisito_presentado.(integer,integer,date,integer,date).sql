create function negocio.f_requisito_presentado(ppersona integer, prequisito integer, pfecha date, ppropuestaaspira integer, pfechatope date) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
  _cant smallint;
  _requisito_padre integer;
  _fecha_requisito_padre date;
BEGIN
	-- El requisito está presentado?
	SELECT	COUNT(sga_requisitos_presentados.requisito_presentado) INTO _cant
	FROM	sga_requisitos_presentados
	WHERE	sga_requisitos_presentados.persona = pPersona AND
			sga_requisitos_presentados.requisito = pRequisito AND
			sga_requisitos_presentados.fecha_presentacion IS NOT NULL AND
			(sga_requisitos_presentados.fecha_vencimiento IS NULL OR sga_requisitos_presentados.fecha_vencimiento > pFecha);

	IF _cant > 0 THEN
		RETURN TRUE;
	ELSE
		-- Existe un requisito padre?
		SELECT	sga_requisitos.requisito_subordinado_de INTO _requisito_padre
		FROM	sga_requisitos
		WHERE	sga_requisitos.requisito = pRequisito;

		IF _requisito_padre IS NULL THEN
			RETURN FALSE;
		ELSE
			-- Se recupera la fecha tope para el requisito padre.
			SELECT	COALESCE(sga_requisitos_aspirante.fecha_prorroga, sga_requisitos_ingreso_excep.fecha_tope, vw_periodos_insc_propuesta.fecha_cierre_requisitos) INTO _fecha_requisito_padre
			FROM	sga_propuestas_aspira
					JOIN vw_periodos_insc_propuesta ON sga_propuestas_aspira.periodo_insc = vw_periodos_insc_propuesta.periodo_insc
					JOIN sga_requisitos_aspirante ON (sga_propuestas_aspira.propuesta_aspira = sga_requisitos_aspirante.propuesta_aspira AND sga_requisitos_aspirante.requisito = _requisito_padre)
					LEFT JOIN sga_requisitos_ingreso_excep ON (sga_requisitos_ingreso_excep.periodo_inscripcion = vw_periodos_insc_propuesta.periodo_inscripcion AND sga_requisitos_ingreso_excep.requisito = sga_requisitos_aspirante.requisito)
			WHERE	sga_propuestas_aspira.propuesta_aspira = pPropuestaAspira;

			-- El requisito padre está presentado?
        	RETURN f_requisito_presentado(pPersona, _requisito_padre, pFecha, pPropuestaAspira, _fecha_requisito_padre);
        END IF;
    END IF;
END;
$$;
