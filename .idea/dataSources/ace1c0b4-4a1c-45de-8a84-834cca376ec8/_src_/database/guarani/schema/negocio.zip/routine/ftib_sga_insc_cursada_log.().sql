create function negocio.ftib_sga_insc_cursada_log() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    -- Genera un nro de Transaccion
    IF NEW.nro_transaccion_log IS NULL THEN
       NEW.nro_transaccion_log := f_nro_transaccion();
    END IF;   
    RETURN NEW;
  END;
$$;
