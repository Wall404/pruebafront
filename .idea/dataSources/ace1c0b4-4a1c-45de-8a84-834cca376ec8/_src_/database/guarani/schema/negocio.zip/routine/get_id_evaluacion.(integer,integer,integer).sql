create function negocio.get_id_evaluacion(pcomision integer, ptipoevaluacion integer, pposicion integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  cur1 record;
  cnt integer;
  id integer;
        
BEGIN
  cnt := 1;	
  id := NULL;	
  -- Recupero las evaluaciones de la comision
  FOR cur1 IN SELECT sga_evaluaciones.evaluacion
                FROM sga_comisiones,
                     sga_evaluaciones
               WHERE sga_comisiones.comision = pComision
                 AND sga_evaluaciones.entidad = sga_comisiones.entidad
                 AND sga_evaluaciones.evaluacion_tipo = pTipoEvaluacion
              ORDER BY sga_evaluaciones.fecha
  LOOP
      IF cnt = pPosicion THEN
         id := cur1.evaluacion;
         EXIT;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  -- Retorno la evaluacion si la encontró	
  RETURN id;
    
END;
$$;
