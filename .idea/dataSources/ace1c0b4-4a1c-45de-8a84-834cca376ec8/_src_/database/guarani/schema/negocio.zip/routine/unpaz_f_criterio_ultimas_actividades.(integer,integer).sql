create function negocio.unpaz_f_criterio_ultimas_actividades(_alumno integer, _propuesta integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _cnt numeric;
 DECLARE _mater numeric;
 DECLARE _result numeric;

BEGIN
	_cnt := 0;
	-- Busca la cantidad de actividades aprobadas
	SELECT COUNT(DISTINCT actividad_codigo) INTO _cnt
	FROM negocio.vw_hist_academica
	LEFT JOIN negocio.sga_planes_versiones AS plan1 ON (vw_hist_academica.plan_version = plan1.plan_version)
	LEFT JOIN negocio.sga_planes_versiones AS plan2 ON (plan1.plan = plan2.plan)
	JOIN negocio.sga_alumnos on (vw_hist_academica.alumno = sga_alumnos.alumno
			and vw_hist_academica.persona = sga_alumnos.persona
			and plan2.plan_version = sga_alumnos.plan_version)
	where vw_hist_academica.resultado = 'A'
	AND vw_hist_academica.alumno = _alumno;
/*LAURA: acá habría que agregar que el plan version sea el mismo del alumno ya que a apartir de la v3.15 esta vista muestra actividades de todos los planes*/
/* Listo */

	SELECT sga_planes_versiones.cnt_materias INTO _mater
	FROM negocio.sga_planes_versiones
	JOIN negocio.sga_planes ON (sga_planes_versiones.plan = sga_planes.plan)
	JOIN negocio.sga_propuestas ON (sga_planes.propuesta = sga_propuestas.propuesta and propuesta_tipo in (200,201))
	JOIN negocio.sga_alumnos ON (sga_propuestas.propuesta = sga_alumnos.propuesta and sga_planes_versiones.plan_version = sga_alumnos.plan_version)
	WHERE --sga_planes_versiones.estado ='V' AND 
	sga_alumnos.alumno = _alumno AND
	sga_propuestas.propuesta = _propuesta;

/*LAURA: acá miraría en que plan version se encuentra el alumno para contar la cantidad de materias*/
/* Listo */

	SELECT ((_cnt /_mater)* 100) INTO _result;
	
	IF _result >= 80 THEN
	-- Ultimas materias por aprobar
	RETURN 0;
	ELSE
	RETURN 1;
	END IF;
END;
$$;
