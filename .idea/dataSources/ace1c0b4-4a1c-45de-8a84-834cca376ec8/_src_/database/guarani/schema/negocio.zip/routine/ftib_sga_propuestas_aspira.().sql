create function negocio.ftib_sga_propuestas_aspira() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	   -- Genera un nro de Transaccion
       NEW.nro_transaccion := f_nro_transaccion();
       RETURN NEW;
  END;
$$;
