create function negocio.ftia_sga_alumnos_orient() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
  -- Registro la baja de la orientacion
  INSERT INTO sga_alumnos_orient_mov (alumno, plan, orientacion, fecha, tipo_movimiento)
       VALUES (NEW.alumno, NEW.plan, NEW.orientacion, NEW.fecha, 'Alta');
   
  RETURN NEW;
END;
$$;
