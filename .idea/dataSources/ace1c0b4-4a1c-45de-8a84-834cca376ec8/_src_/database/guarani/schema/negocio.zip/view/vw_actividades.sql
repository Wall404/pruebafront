CREATE VIEW vw_actividades AS SELECT e.elemento,
    e.codigo,
    e.nombre,
    e.nombre_abreviado,
    e.entidad_subtipo,
    est.entidad_tipo,
    est.nombre AS entidad_subtipo_nombre,
    e.entidad,
    e.compartible,
    e.estado,
    e.disponible_para,
    er.elemento_revision,
    er.regla,
    er.parametros
   FROM negocio.sga_elementos e,
    negocio.sga_g3entidades_subtipos est,
    negocio.sga_elementos_revision er
  WHERE (((e.entidad_subtipo = est.entidad_subtipo) AND (er.elemento = e.elemento)) AND (est.entidad_tipo = 2));
