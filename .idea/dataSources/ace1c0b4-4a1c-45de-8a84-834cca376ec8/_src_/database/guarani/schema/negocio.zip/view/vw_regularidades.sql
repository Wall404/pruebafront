CREATE VIEW vw_regularidades AS SELECT sga_comisiones.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    sga_periodos_perlect.anio_academico,
    sga_periodos_lectivos.periodo_lectivo,
    sga_periodos_perlect.nombre AS periodo_lectivo_nombre,
    sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.nro_acta,
    sga_actas.tipo_acta,
    sga_actas.origen,
    'Regularidad'::character varying(30) AS tipo,
    sga_actas.evaluacion,
    sga_actas.comision,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS nro_resolucion,
    NULL::character varying(30) AS nro_resolucion_descripcion,
    NULL::integer AS equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_actas_detalle.alumno AS alumno2,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
        CASE
            WHEN ((sga_actas_detalle.fecha_vigencia IS NULL) OR (sga_actas_detalle.fecha_vigencia >= ('now'::text)::date)) THEN 1
            ELSE 0
        END AS es_vigente,
    sga_actas_detalle.folio,
    sga_actas_detalle.renglon,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_actas_detalle.cond_regularidad,
    sga_actas_detalle.estado,
    sga_actas_detalle.pct_asistencia,
    sga_actas_detalle.observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    sga_instancias_resultado.descripcion AS resultado_descripcion,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta
   FROM ((((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.alumno = sga_alumnos.alumno)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_actas_detalle.escala_nota = sga_escalas_notas_det.escala_nota) AND ((sga_actas_detalle.nota)::text = (sga_escalas_notas_det.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto)))
     JOIN negocio.sga_actas ON ((sga_actas.id_acta = sga_actas_detalle.id_acta)))
     JOIN negocio.sga_comisiones ON ((sga_comisiones.comision = sga_actas.comision)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_comisiones.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = alu2.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_periodos_lectivos ON ((sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo)))
     JOIN negocio.sga_periodos sga_periodos_perlect ON ((sga_periodos_perlect.periodo = sga_periodos_lectivos.periodo)))
     JOIN negocio.sga_instancias_resultado ON (((sga_instancias_resultado.instancia = sga_actas_detalle.instancia) AND (sga_instancias_resultado.resultado = sga_actas_detalle.resultado))))
  WHERE (((((sga_actas.estado = 'C'::bpchar) AND (sga_actas.origen = 'R'::bpchar)) AND (sga_actas_detalle.rectificado = 'N'::bpchar)) AND (sga_actas_detalle.estado = 'A'::bpchar)) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_comisiones.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    sga_periodos_perlect.anio_academico,
    sga_periodos_lectivos.periodo_lectivo,
    sga_periodos_perlect.nombre AS periodo_lectivo_nombre,
    sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.nro_acta,
    sga_actas.tipo_acta,
    sga_actas.origen,
    'Promoción'::character varying(30) AS tipo,
    sga_actas.evaluacion,
    sga_actas.comision,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS nro_resolucion,
    NULL::character varying(30) AS nro_resolucion_descripcion,
    NULL::integer AS equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_actas_detalle.alumno AS alumno2,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
        CASE
            WHEN ((sga_actas_detalle.fecha_vigencia IS NULL) OR (sga_actas_detalle.fecha_vigencia >= ('now'::text)::date)) THEN 1
            ELSE 0
        END AS es_vigente,
    sga_actas_detalle.folio,
    sga_actas_detalle.renglon,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_actas_detalle.cond_regularidad,
    sga_actas_detalle.estado,
    sga_actas_detalle.pct_asistencia,
    sga_actas_detalle.observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    sga_instancias_resultado.descripcion AS resultado_descripcion,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta
   FROM ((((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.alumno = sga_alumnos.alumno)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_actas_detalle.escala_nota = sga_escalas_notas_det.escala_nota) AND ((sga_actas_detalle.nota)::text = (sga_escalas_notas_det.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_det.concepto = sga_escalas_notas_concepto.concepto)))
     JOIN negocio.sga_actas ON ((sga_actas.id_acta = sga_actas_detalle.id_acta)))
     JOIN negocio.sga_comisiones ON ((sga_comisiones.comision = sga_actas.comision)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_comisiones.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = alu2.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_periodos_lectivos ON ((sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo)))
     JOIN negocio.sga_periodos sga_periodos_perlect ON ((sga_periodos_perlect.periodo = sga_periodos_lectivos.periodo)))
     JOIN negocio.sga_instancias_resultado ON (((sga_instancias_resultado.instancia = sga_actas_detalle.instancia) AND (sga_instancias_resultado.resultado = sga_actas_detalle.resultado))))
  WHERE ((((((sga_actas.estado = 'C'::bpchar) AND (sga_actas.origen = 'P'::bpchar)) AND (sga_actas_detalle.rectificado = 'N'::bpchar)) AND (sga_actas_detalle.estado = 'A'::bpchar)) AND (NOT (EXISTS ( SELECT 1
           FROM negocio.sga_comisiones_instancias
          WHERE ((sga_comisiones_instancias.comision = sga_actas.comision) AND (sga_comisiones_instancias.instancia = 1)))))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_equiv_otorgada.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    NULL::integer AS anio_academico,
    NULL::integer AS periodo_lectivo,
    NULL::character varying(100) AS periodo_lectivo_nombre,
    NULL::integer AS id_acta,
    NULL::integer AS id_acta_original,
    NULL::character varying(30) AS nro_acta,
    NULL::character(1) AS tipo_acta,
    'C'::bpchar AS origen,
    'Equivalencia de Regularidad'::character varying(30) AS tipo,
    NULL::integer AS evaluacion,
    NULL::integer AS comision,
    sga_equiv_tramite.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_tramite.tipo_tramite,
    sga_equiv_tramite.documento AS nro_resolucion,
    sga_documentos.documento_numero AS nro_resolucion_descripcion,
    sga_equiv_otorgada.equivalencia,
    sga_alumnos.persona,
    alu2.alumno,
    sga_equiv_tramite.alumno AS alumno2,
    sga_equiv_tramite.plan_version,
    sga_equiv_otorgada.instancia,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.fecha_vigencia,
        CASE
            WHEN ((sga_equiv_otorgada.fecha_vigencia IS NULL) OR (sga_equiv_otorgada.fecha_vigencia >= ('now'::text)::date)) THEN 1
            ELSE 0
        END AS es_vigente,
    NULL::smallint AS folio,
    NULL::smallint AS renglon,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado,
    NULL::integer AS cond_regularidad,
    sga_equiv_otorgada.estado,
    NULL::numeric(5,2) AS pct_asistencia,
    sga_equiv_otorgada.temas_a_rendir AS observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_det.concepto,
    sga_escalas_notas_concepto.nombre AS concepto_descripcion,
    sga_escalas_notas_resultado.descripcion AS resultado_descripcion,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta
   FROM ((((((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_equiv_tramite ON ((sga_equiv_tramite.alumno = sga_alumnos.alumno)))
     LEFT JOIN negocio.sga_documentos ON ((sga_documentos.documento = sga_equiv_tramite.documento)))
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_equiv_otorgada.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_equiv_otorgada.nota)::text))))
     LEFT JOIN negocio.sga_escalas_notas_concepto ON ((sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_equiv_otorgada.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = alu2.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_escalas_notas_resultado ON ((sga_escalas_notas_resultado.resultado = sga_equiv_otorgada.resultado)))
  WHERE ((((((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.instancia = 11)) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar)) AND (sga_equiv_otorgada.estado = 'A'::bpchar)) AND (sga_equiv_otorgada.resultado = ANY (ARRAY['A'::bpchar, 'R'::bpchar]))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))));
