create function negocio.get_codigo_procedencia_araucano(ppersona integer, pcertificadotipo integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
	_origen_localidad_procedencia varchar(3);
	_nivel_titulo_anterior integer;
	_localidad_titulo_anterior integer;
	_origen_titulo_anterior varchar(3);
	_codigo_procedencia integer;
BEGIN
	SELECT	CASE
				WHEN get_pais_localidad(mdp_datos_personales.procedencia_localidad) IS NULL THEN 'NDI'
				WHEN get_pais_localidad(mdp_datos_personales.procedencia_localidad) = 54 THEN 'N'
				ELSE 'E'
			END INTO _origen_localidad_procedencia
	FROM	mdp_personas
			LEFT JOIN mdp_datos_censales ON mdp_datos_censales.dato_censal = (SELECT get_ultimo_dato_censal(mdp_personas.persona))
			LEFT JOIN mdp_datos_personales ON mdp_datos_censales.dato_censal = mdp_datos_personales.dato_censal
	WHERE	mdp_personas.persona = pPersona;

	IF pCertificadoTipo = 1 OR pCertificadoTipo = 2 THEN -- Grado y Pregrado.
		_nivel_titulo_anterior := 3; -- Secundario.
	ELSE -- Postítulo, Doctorado, Maestría y Especialización.
		_nivel_titulo_anterior := 5; -- Universitario.
	END IF;

	_localidad_titulo_anterior := NULL;
	_origen_titulo_anterior := NULL;
	SELECT		COALESCE(sga_instituciones.localidad, sga_colegios_secundarios.localidad),
				COALESCE(mdp_datos_estudios.institucion_otra_origen, mdp_datos_estudios.colegio_otro_origen) INTO _localidad_titulo_anterior, _origen_titulo_anterior
	FROM		mdp_datos_estudios
				LEFT JOIN sga_instituciones ON mdp_datos_estudios.institucion = sga_instituciones.institucion
				LEFT JOIN sga_colegios_secundarios ON mdp_datos_estudios.colegio = sga_colegios_secundarios.colegio
	WHERE		mdp_datos_estudios.persona = pPersona AND
				mdp_datos_estudios.nivel_estudio NOT IN (1, 7) AND -- No hizo Estudios, Desconoce.
				mdp_datos_estudios.nivel_estudio <= _nivel_titulo_anterior
	ORDER BY	mdp_datos_estudios.nivel_estudio DESC
	LIMIT		1;

	IF _localidad_titulo_anterior IS NOT NULL THEN
		SELECT	CASE
					WHEN get_pais_localidad(_localidad_titulo_anterior) = 54 THEN 'N'
					ELSE 'E'
				END INTO _origen_titulo_anterior;
	END IF;

	IF _origen_titulo_anterior IS NULL THEN
		_origen_titulo_anterior := 'NDI';
	END IF;

	IF _origen_localidad_procedencia = 'NDI' AND _origen_titulo_anterior = 'NDI' THEN
		_codigo_procedencia := 4;
	ELSEIF _origen_localidad_procedencia = 'E' AND _origen_titulo_anterior = 'E' THEN
		_codigo_procedencia := 1;
	ELSEIF _origen_localidad_procedencia = 'E' OR _origen_titulo_anterior = 'E' THEN
		_codigo_procedencia := 2;
	ELSE
		_codigo_procedencia := 3;
	END IF;

	RETURN _codigo_procedencia;
END;
$$;
