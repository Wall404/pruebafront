create function negocio.sui_paises(p_pais integer, p_nombre character varying, p_continente character varying, p_codigo_iso character varying) returns void
LANGUAGE plpgsql
AS $$
DECLARE vProvinciaIndet Integer;

BEGIN
  -- Genera el número de provincia indeterminada para el país
  vProvinciaIndet := p_pais * 100 + 98;

  -- Inserta el pais
  INSERT INTO mug_paises (pais, nombre, continente, codigo_iso) VALUES (p_pais, p_nombre, p_continente, p_codigo_iso);

  -- Cataloga la provincia indeterminada, sin permitir actualizaciones
  -- ya que, si existía la provincia, no podía ser la inteterminada del país, porque este no existía
  PERFORM sui_provincias (vProvinciaIndet, 'Indeterminada', p_pais);
  
  -- Existe el pais, entonces lo actualizo
  EXCEPTION 
     WHEN unique_violation THEN
       UPDATE mug_paises SET (nombre, continente, codigo_iso) = (p_nombre, p_continente, p_codigo_iso) WHERE pais = p_pais;
       -- Cataloga la provincia indeterminada
       -- PERFORM sui_provincias (vProvinciaIndet, 'Indeterminada', p_pais);  -- > porque? ya deberia existir esta provincia...
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Pais: %. Error Nro: %. %',pPais, SQLSTATE, SQLERRM;   

END;
$$;
