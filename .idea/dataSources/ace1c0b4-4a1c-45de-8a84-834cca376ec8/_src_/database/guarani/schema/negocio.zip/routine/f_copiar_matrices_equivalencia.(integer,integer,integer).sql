create function negocio.f_copiar_matrices_equivalencia(_plan_version_origen integer, _plan_version_destino integer, _matriz_origen integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _cnt_matrices integer;
  _eqmatriz_new integer;
  _eqgrupo_new integer;
  cur_eqmat record;
  cur_eqgrupos record;
BEGIN    
  _cnt_matrices := 0;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Opciones de Copia:
  --   1. Una matriz definida en una version de plan de estudios (no mira si esta activa)
  --   2. Matrices de Equivalencias activas definidas en el Plan-Version origen de la copia.
  -- No se copian las matrices que el Plan-version tenga definida con otra version del mismo plan de estudios.
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  FOR cur_eqmat IN SELECT matriz
        FROM sga_equiv_matrices
        WHERE (_matriz_origen IS NOT NULL AND matriz = _matriz_origen) 
           OR (_matriz_origen IS NULL AND plan_version_destino = _plan_version_origen AND alcance <> 'Version' AND activo = 'S')
  LOOP
    _cnt_matrices := _cnt_matrices + 1;

   -- Inserto la Matriz de Equivalencia.
   INSERT INTO sga_equiv_matrices (nombre, alcance, descripcion, nro_resolucion, fecha_entrada_vigencia, plan_version_destino, propuesta_origen, plan_origen, plan_version_origen, aplicacion_automatica, activo)
      SELECT nombre, alcance, descripcion, nro_resolucion, fecha_entrada_vigencia, _plan_version_destino, propuesta_origen, plan_origen, plan_version_origen, aplicacion_automatica, activo
        FROM sga_equiv_matrices
        WHERE matriz = cur_eqmat.matriz;
   
    -- Recupero el id de la nueva matriz de equivalencias
   _eqmatriz_new := (SELECT currval('sga_equiv_matrices_seq'));

    -- Recorro los grupos de equivalencias (activos) de la matriz.
    FOR cur_eqgrupos IN SELECT grupo_equivalencia
                        FROM sga_equiv_grupos
                        WHERE matriz = cur_eqmat.matriz
                          AND activo = 'S'
                        ORDER BY orden
    LOOP

      INSERT INTO sga_equiv_grupos (matriz, orden, nro_resolucion_alta, traslada_nota, fecha_entrada_vigencia, es_modificatoria, nro_resolucion_baja, fecha_baja, activo)
         SELECT _eqmatriz_new, orden, nro_resolucion_alta, traslada_nota, fecha_entrada_vigencia, es_modificatoria, nro_resolucion_baja, fecha_baja, activo 
           FROM sga_equiv_grupos
           WHERE grupo_equivalencia = cur_eqgrupos.grupo_equivalencia;

      -- Recupero el id del nuevo grupo de equivalencias de la matriz
      _eqgrupo_new := (SELECT currval('sga_equiv_grupos_seq'));
      
      -- Inserto las componentes del Grupo de Equivalencias.
      INSERT INTO sga_equiv_actividades (grupo_equivalencia, origen_destino, condicion, elemento, nota, tiene_vencimiento, temas_a_rendir)
         SELECT _eqgrupo_new, origen_destino, condicion, elemento, nota, tiene_vencimiento, temas_a_rendir
           FROM sga_equiv_actividades
           WHERE grupo_equivalencia = cur_eqgrupos.grupo_equivalencia
           ORDER BY actividad_equivalencia; 
        
     END LOOP; -- Grupos de Equivalencias
  END LOOP; -- Matrices de Equivalencias
  -- +++++++++++++++++++ Fin Matrices de Equivalencias ++++++++++++++++++++++++++++

  -- Retorna cantidad de matrices de equivalencias copiadas.
  RETURN _cnt_matrices;
    
END;
$$;
