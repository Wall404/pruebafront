create function negocio.ftdb_sga_subcomisiones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

   -- Borro tabla de cupos de la subcomision
   DELETE FROM sga_subcomisiones_cupo 
         WHERE subcomision = OLD.subcomision;

   RETURN OLD;
END;
$$;
