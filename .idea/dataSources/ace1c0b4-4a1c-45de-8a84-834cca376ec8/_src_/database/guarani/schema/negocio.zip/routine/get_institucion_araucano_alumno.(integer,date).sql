create function negocio.get_institucion_araucano_alumno(palumno integer, pfecha date) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
 _ubicacion integer;
 _ubicacion_actual integer;
 _propuesta integer;
 _inst_arau integer;
 
BEGIN
  _ubicacion   := NULL;
  _inst_arau   := NULL;
  SELECT ubicacion, propuesta  INTO _ubicacion_actual, _propuesta
    FROM sga_alumnos 
   WHERE alumno = pAlumno;
  
  -- Recupera la sede a la que pertenecia el alumno en la fecha dada.
 SELECT ubicacion INTO _ubicacion
   FROM sga_alumnos_hist_ubicacion
  WHERE alumno = pAlumno
    AND fecha = (SELECT MAX(hu2.fecha) FROM sga_alumnos_hist_ubicacion as hu2
	              WHERE hu2.alumno = pAlumno
		            AND Date(hu2.fecha) <= pFecha)
	LIMIT 1;

  IF NOT FOUND THEN
     -- Recupero la ubicacion actual del alumno
	 _ubicacion := _ubicacion_actual;
  END IF;
  
  -- Recupero el codigo de institucion araucano de la ubicacion
  SELECT institucion_araucano INTO _inst_arau FROM sga_ubicaciones WHERE ubicacion = _ubicacion;

  IF _inst_arau IS NULL THEN
    -- Si la ubicacion no tenia definida la sede, entonces busco la institucion de alguna de las responsables academicas de la propuesta
	SELECT sga_responsables_academicas.institucion_araucano 
	  INTO _inst_arau
	FROM	sga_responsables_academicas,
			sga_propuestas_ra
	WHERE	sga_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica AND
			sga_propuestas_ra.propuesta = _propuesta AND
			sga_responsables_academicas.institucion_araucano IS NOT NULL
	ORDER BY sga_responsables_academicas.institucion_araucano
	LIMIT 1;

  END IF;
								   
  -- Retorno la institucion araucano
  RETURN _inst_arau;
END;
$$;
