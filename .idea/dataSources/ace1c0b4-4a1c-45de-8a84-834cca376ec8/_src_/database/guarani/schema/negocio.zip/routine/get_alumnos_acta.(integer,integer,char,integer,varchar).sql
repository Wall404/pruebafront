create function negocio.get_alumnos_acta(pacta integer, pordenacta integer, pretorno character, pfolio integer, palumno character varying) returns SETOF negocio.type_alumnos_acta
LANGUAGE plpgsql
AS $$
DECLARE 
  _origen_acta char(1);
  _estado_acta char(1);
  _renglones_folio integer;
  _sql_1 text;
  _sql_2 text;
  _sql_acta text;
  _order_by  text;
  _where_acta  text;
  _cant_alumnos integer;
  _folio integer;
  _renglon integer;
  cur_det  record;
  cur_acta type_alumnos_acta;
BEGIN

/*
 Argumentos de la funcion:
 - pRetorno:  T = Todos los Alumnos  
              F = Alumnos de un Folio (pFolio)  
              A - Alumnos que coicidan con el apellido a buscar (pAlumno)
 - pOrdenActa: se obtiene del parámetro "cur_orden_detalle_actas": 
              1 - Legajo  
              2 - Apellido y Nombre  
              3 - Nro de Documento
*/

-- Recupero datos de la cabecera del Acta
SELECT renglones_folio, origen, estado 
  INTO _renglones_folio, _origen_acta, _estado_acta 
  FROM sga_actas 
 WHERE sga_actas.id_acta = pActa;
IF NOT FOUND THEN
  RETURN;
END IF; 

_sql_1 := '';
_sql_2 := '';
_where_acta := '';

IF _estado_acta = 'A' THEN
  -- Orden del Acta para actas abiertas 
  IF pOrdenActa = 1 THEN
     _order_by := ' ORDER BY sga_alumnos.legajo ';
  ELSEIF pOrdenActa = 2 THEN
     _order_by := ' ORDER BY vw_personas.apellido, vw_personas.nombres ';
  ELSEIF pOrdenActa = 3 THEN
     _order_by := ' ORDER BY vw_personas.nro_documento ';
  END IF;
ELSE
  -- Acta Cerrada o Anulada
  _order_by := ' ORDER BY sga_actas_detalle.folio, sga_actas_detalle.renglon ';
END IF;


-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   
-- Detalle del Acta   
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   
_sql_1 := 'SELECT '
       || '   vw_personas.persona  as persona, '
       || '   vw_personas.apellido as apellido, '
       || '   vw_personas.nombres  as nombres, '
       || '   vw_personas.nro_documento as nro_documento, '
       || '   vw_personas.tipo_nro_documento as tipo_nro_documento, '
       || '   vw_personas.id_imagen as id_imagen, '
       || '   sga_alumnos.alumno as alumno, '
       || '   sga_alumnos.legajo as legajo, ';


-- Estado del Acta = Abierta
IF _estado_acta = 'A' THEN
  IF _origen_acta = 'R' THEN
	-- Acta de Regulares
	_sql_2 := 'sga_eval_detalle_cursadas.cond_regularidad as cond_regularidad, '
           || 'sga_cond_regularidad.nombre as cond_regularidad_desc, '
           || 'sga_eval_detalle_cursadas.instancia_cursada as instancia, '
           || 'sga_eval_detalle_cursadas.pct_asistencia_cursada as pct_asistencia, '
           || 'to_char(sga_eval_detalle_cursadas.fecha_regular, ''DD/MM/YYYY'') as fecha, '
           || 'sga_eval_detalle_cursadas.escala_nota_cursada as escala_nota, '
           || 'sga_eval_detalle_cursadas.nota_cursada as nota, '
           || 'sga_escalas_notas_det.descripcion as nota_desc, '
           || 'sga_escalas_notas_concepto.nombre as concepto_desc, '
           || 'sga_eval_detalle_cursadas.resultado_cursada as resultado, '
           || 'irc.descripcion as resultado_desc, '
           || 'sga_eval_detalle_cursadas.observacion_cursada as observacion, '
           || '''A'' as estado, '
           || 'sga_actas_detalle_estado.nombre as estado_desc, '
           || 'cast(NULL as integer) as folio, '
           || 'cast(NULL as integer) as renglon, '
           || 'cast(NULL as char(1)) as rectificado '
           || 'FROM '
           || '  sga_eval_detalle_cursadas '
           || '    LEFT JOIN sga_cond_regularidad ON (sga_cond_regularidad.cond_regularidad = sga_eval_detalle_cursadas.cond_regularidad) '
           || '    LEFT JOIN sga_escalas_notas_det ON (sga_escalas_notas_det.escala_nota = sga_eval_detalle_cursadas.escala_nota_cursada AND '
           || '                                        sga_escalas_notas_det.nota = sga_eval_detalle_cursadas.nota_cursada) '
           || '    LEFT JOIN sga_instancias_resultado as irc ON (irc.instancia = 1 AND irc.resultado = sga_eval_detalle_cursadas.resultado_cursada) '
           || '    LEFT JOIN sga_escalas_notas_concepto ON (sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto), '
           || '  sga_alumnos, '
           || '  vw_personas, '
           || '  sga_actas_detalle_estado '
           || 'WHERE sga_eval_detalle_cursadas.id_acta_cursada = ' || pActa::text 
           || '  AND sga_actas_detalle_estado.estado = ''A'' ' 
           || '  AND sga_alumnos.alumno = sga_eval_detalle_cursadas.alumno '
           || '  AND vw_personas.persona = sga_alumnos.persona ';
  
  ELSEIF _origen_acta = 'P' THEN
    -- Acta de Promocion
	_sql_2 := 'sga_eval_detalle_cursadas.cond_regularidad as cond_regularidad, '
           || 'sga_cond_regularidad.nombre as cond_regularidad_desc, '
           || 'sga_eval_detalle_cursadas.instancia_promocion as instancia, '
           || 'sga_eval_detalle_cursadas.pct_asistencia_promocion as pct_asistencia, '
           || 'to_char(sga_eval_detalle_cursadas.fecha_promocion, ''DD/MM/YYYY'') as fecha, '
           || 'sga_eval_detalle_cursadas.escala_nota_promocion as escala_nota, '
           || 'sga_eval_detalle_cursadas.nota_promocion as nota, '
           || 'sga_escalas_notas_det.descripcion as nota_desc, '
           || 'sga_escalas_notas_concepto.nombre as concepto_desc, '
           || 'sga_eval_detalle_cursadas.resultado_promocion as resultado, '
           || 'sga_instancias_resultado.descripcion as resultado_desc, '
           || 'sga_eval_detalle_cursadas.observacion_promocion as observacion, '
           || '''A'' as estado, '
           || 'sga_actas_detalle_estado.nombre as estado_desc, '
           || 'cast(NULL as integer) as folio, '
           || 'cast(NULL as integer) as renglon, '
           || 'cast(NULL as char(1)) as rectificado '
           || 'FROM '
           || '  sga_eval_detalle_cursadas '
           || '    LEFT JOIN sga_cond_regularidad ON (sga_cond_regularidad.cond_regularidad = sga_eval_detalle_cursadas.cond_regularidad) '
           || '    LEFT JOIN sga_escalas_notas_det ON (sga_escalas_notas_det.escala_nota = sga_eval_detalle_cursadas.escala_nota_promocion AND '
           || '                                        sga_escalas_notas_det.nota        = sga_eval_detalle_cursadas.nota_promocion) '
           || '    LEFT JOIN sga_instancias_resultado ON (sga_instancias_resultado.instancia = 2 AND sga_instancias_resultado.resultado = sga_eval_detalle_cursadas.resultado_promocion) '
           || '    LEFT JOIN sga_escalas_notas_concepto ON (sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto), '
           || '  sga_alumnos, '
           || '  vw_personas, '
           || '  sga_actas_detalle_estado '
           || 'WHERE sga_eval_detalle_cursadas.id_acta_promocion = ' || pActa::text 
           || '  AND sga_actas_detalle_estado.estado = ''A'' ' 
           || '  AND sga_alumnos.alumno = sga_eval_detalle_cursadas.alumno '
           || '  AND vw_personas.persona = sga_alumnos.persona ';
           
  ELSEIF _origen_acta = 'E' THEN
    -- Acta de Examen
	_sql_2 := 'sga_eval_detalle_examenes.instancia as instancia, '
           || 'sga_instancias.nombre as instancia_desc, '
           || 'to_char(sga_eval_detalle_examenes.fecha, ''DD/MM/YYYY'') as fecha, '
           || 'sga_eval_detalle_examenes.escala_nota as escala_nota, '
           || 'sga_eval_detalle_examenes.nota as nota, '
           || 'sga_escalas_notas_det.descripcion as nota_desc, '
           || 'sga_escalas_notas_concepto.nombre as concepto_desc, '
           || 'sga_eval_detalle_examenes.resultado as resultado, '
           || 'sga_instancias_resultado.descripcion as resultado_desc, '
           || 'sga_eval_detalle_examenes.observaciones as observacion, '
           || '''A'' as estado, '
           || 'sga_actas_detalle_estado.nombre as estado_desc, '
           || 'cast(NULL as integer) as folio, '
           || 'cast(NULL as integer) as renglon, '
           || 'cast(NULL as char(1)) as rectificado '
           || 'FROM '
           || '  sga_eval_detalle_examenes '
           || '    LEFT JOIN sga_escalas_notas_det ON (sga_escalas_notas_det.escala_nota = sga_eval_detalle_examenes.escala_nota AND sga_escalas_notas_det.nota = sga_eval_detalle_examenes.nota) '
           || '    LEFT JOIN sga_instancias_resultado ON (sga_instancias_resultado.instancia = sga_eval_detalle_examenes.instancia AND sga_instancias_resultado.resultado = sga_eval_detalle_examenes.resultado) '
           || '    LEFT JOIN sga_escalas_notas_concepto ON (sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto), '
           || '  sga_alumnos, '
           || '  vw_personas, '
           || '  sga_actas_detalle_estado, '
           || '  sga_instancias '
           || 'WHERE sga_eval_detalle_examenes.id_acta = ' || pActa::text 
           || '  AND sga_actas_detalle_estado.estado = ''A'' ' 
           || '  AND sga_instancias.instancia = sga_eval_detalle_examenes.instancia ' 
           || '  AND sga_alumnos.alumno = sga_eval_detalle_examenes.alumno '
           || '  AND vw_personas.persona = sga_alumnos.persona ';
           
   END IF; -- Origen de las Actas
   
 ELSE
   -- Acta Cerrada o Anulada      
	_sql_2 := 'sga_actas_detalle.cond_regularidad as cond_regularidad, '
           || 'sga_cond_regularidad.nombre as cond_regularidad_desc, '
           || 'sga_actas_detalle.instancia as instancia, '
           || 'sga_instancias.nombre as instancia_desc, '
           || 'sga_actas_detalle.pct_asistencia as pct_asistencia, '
           || 'to_char(sga_actas_detalle.fecha, ''DD/MM/YYYY'') as fecha, '
           || 'sga_actas_detalle.escala_nota as escala_nota, '
           || 'sga_actas_detalle.nota as nota, '
           || 'sga_escalas_notas_det.descripcion as nota_desc, '
           || 'sga_escalas_notas_concepto.nombre as concepto_desc, '
           || 'sga_actas_detalle.resultado as resultado, '
           || 'sga_instancias_resultado.descripcion as resultado_desc, '
           || 'sga_actas_detalle.observaciones as observacion, '
           || 'sga_actas_detalle.estado as estado, '
           || 'sga_actas_detalle_estado.nombre as estado_desc, '
           || 'sga_actas_detalle.folio as folio, '
           || 'sga_actas_detalle.renglon as renglon, '
           || 'sga_actas_detalle.rectificado as rectificado '
           || 'FROM '
           || '  sga_actas_detalle '
           || '    LEFT JOIN sga_cond_regularidad ON (sga_cond_regularidad.cond_regularidad = sga_actas_detalle.cond_regularidad) '
           || '    LEFT JOIN sga_escalas_notas_det ON (sga_escalas_notas_det.escala_nota = sga_actas_detalle.escala_nota AND sga_escalas_notas_det.nota = sga_actas_detalle.nota) '
           || '    LEFT JOIN sga_instancias_resultado ON (sga_instancias_resultado.instancia = sga_actas_detalle.instancia AND sga_instancias_resultado.resultado = sga_actas_detalle.resultado) '
           || '    LEFT JOIN sga_escalas_notas_concepto ON (sga_escalas_notas_concepto.concepto = sga_escalas_notas_det.concepto), '
           || '  sga_alumnos, '
           || '  vw_personas, '
           || '  sga_actas_detalle_estado, '
           || '  sga_instancias '
           || 'WHERE sga_actas_detalle.id_acta = ' || pActa::text
           || '  AND sga_actas_detalle_estado.estado = sga_actas_detalle.estado ' 
           || '  AND sga_instancias.instancia = sga_actas_detalle.instancia ' 
           || '  AND sga_alumnos.alumno = sga_actas_detalle.alumno '
           || '  AND vw_personas.persona = sga_alumnos.persona ';
    
 END IF; 
  

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   
-- Detalle del Acta de Regularidad/Promoción/Examen  en estado Abierta o Cerrada  
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++   

-- Armo la query a ejecutar
_sql_acta := _sql_1 || _sql_2 || _order_by;

-- Recorro el cursor y devuelvo los datos del acta.
_folio := 1;
_renglon := 1;

FOR cur_det IN EXECUTE _sql_acta
LOOP

  -- Calculo folio y renglon
  IF _estado_acta = 'A' THEN
    -- Acta Abierta
    IF _renglon > _renglones_folio THEN
       _renglon := 1;
       _folio   := _folio + 1;
    END IF;  
  ELSE
    -- Acta Cerrada o Anulada
    _folio   := cur_det.folio;  
    _renglon := cur_det.renglon;  
  END IF;
   
  -- Retorno todos los alumnos o los alumnos de un folio o los alumnos que coincidan con la busqueda por apellido
  IF pRetorno = 'T' OR (pRetorno = 'F' AND pFolio = _folio) OR (pRetorno = 'A' AND cur_det.apellido ILIKE pAlumno || '%') THEN
     -- DETALLE
     cur_acta.alumno             := cur_det.alumno;
     cur_acta.apellido           := cur_det.apellido;
     cur_acta.nombres            := cur_det.nombres;
     cur_acta.tipo_nro_documento := cur_det.tipo_nro_documento;
     cur_acta.id_imagen          := cur_det.id_imagen;
     cur_acta.legajo             := cur_det.legajo;
     cur_acta.folio              := _folio;
     cur_acta.renglon            := _renglon;
     cur_acta.instancia          := cur_det.instancia;
     
     IF _origen_acta = 'E' THEN
       cur_acta.cond_regularidad      := NULL;
       cur_acta.cond_regularidad_desc := NULL;
       cur_acta.pct_asistencia        := NULL;
       cur_acta.instancia_desc        := cur_det.instancia_desc;
     ELSE
       cur_acta.cond_regularidad      := cur_det.cond_regularidad;
       cur_acta.cond_regularidad_desc := cur_det.cond_regularidad_desc;
       cur_acta.pct_asistencia        := cur_det.pct_asistencia;
       cur_acta.instancia_desc        := NULL;
     END IF;  
     
     cur_acta.fecha              := cur_det.fecha;
     cur_acta.escala_nota        := cur_det.escala_nota;
     cur_acta.nota               := cur_det.nota;
     cur_acta.nota_desc          := cur_det.nota_desc;
     cur_acta.concepto_desc      := cur_det.concepto_desc;
     cur_acta.resultado          := cur_det.resultado;
     cur_acta.resultado_desc     := cur_det.resultado_desc;
     cur_acta.observacion        := cur_det.observacion;
     cur_acta.estado             := cur_det.estado;
     cur_acta.estado_desc        := cur_det.estado_desc;

     -- Retorno la fila
     RETURN NEXT cur_acta;
 END IF;

 _renglon := _renglon + 1;
END LOOP;


END
$$;
