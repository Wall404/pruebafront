create function negocio.ftia_sga_elementos_plan() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
	_propuesta integer;
	_plan integer;
	_estado_plan char(1);
	_tipo_plan varchar(15);
BEGIN
	SELECT	sga_planes.propuesta,
			sga_planes.plan,
			sga_planes.estado,
			sga_planes.tipo_plan INTO _propuesta, _plan, _estado_plan, _tipo_plan
	FROM	sga_planes_versiones,
			sga_planes
	WHERE	sga_planes_versiones.plan = sga_planes.plan AND
			sga_planes_versiones.plan_version = NEW.plan_version;

	-- Si se está agregando un elemento a un plan de tipo "Personalizado" o "Convenio" en estado "Activo no Vigente" o "Activo Vigente"...
	IF (_tipo_plan = 'Personalizado' OR _tipo_plan = 'Convenio') AND (_estado_plan = 'A' OR _estado_plan = 'V') THEN
		-- Se incluye el plan en las comisiones vigentes del elemento que acepten planes personalizados.
		INSERT INTO sga_comisiones_propuestas (comision, propuesta, plan)
			SELECT	sga_comisiones.comision, _propuesta, _plan
			FROM	sga_comisiones,
					sga_periodos_lectivos,
					sga_periodos,
					sga_elementos_revision
			WHERE	sga_comisiones.periodo_lectivo = sga_periodos_lectivos.periodo_lectivo AND
					sga_periodos_lectivos.periodo = sga_periodos.periodo AND
					sga_comisiones.elemento = sga_elementos_revision.elemento AND
					sga_periodos.fecha_fin >= CURRENT_DATE AND
					sga_comisiones.acepta_planes_personalizados = 'S' AND
					sga_elementos_revision.elemento_revision = NEW.elemento_revision;

		-- Se incluye el plan en las mesas de examen de fecha futura del elemento que acepten planes personalizados.
		INSERT INTO sga_mesas_examen_propuestas (mesa_examen, propuesta, plan)
			SELECT	sga_mesas_examen.mesa_examen, _propuesta, _plan
			FROM	sga_mesas_examen,
					sga_llamados_mesa,
					sga_elementos_revision
			WHERE	sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen AND
					sga_mesas_examen.elemento = sga_elementos_revision.elemento AND
					sga_llamados_mesa.fecha >= CURRENT_DATE AND
					sga_mesas_examen.acepta_planes_personalizados = 'S' AND
					sga_elementos_revision.elemento_revision = NEW.elemento_revision;
	END IF;
	RETURN NEW;
END;
$$;
