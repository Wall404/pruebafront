create function negocio.ftia_sga_requisitos() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
	_orden INTEGER;
BEGIN
	-- Si el requisito es de tipo "Documental" se setea automáticamente la regla de evaluación "Evaluar Requisitos Presentables".
	-- Además, se vincula el requisito al punto de control 1 (Persona-Operación).
	IF NEW.requisito_tipo = 4 THEN
		UPDATE sga_requisitos SET regla = 200 WHERE requisito = NEW.requisito;

		SELECT	MAX(sga_requisitos_x_punto_control.orden) INTO _orden
		FROM	sga_requisitos_x_punto_control
		WHERE	sga_requisitos_x_punto_control.pto_control = 1;
		_orden := _orden + 1;
		INSERT INTO sga_requisitos_x_punto_control (pto_control, requisito, orden) VALUES (1, NEW.requisito, _orden);
	END IF;
	RETURN NEW;
END;
$$;
