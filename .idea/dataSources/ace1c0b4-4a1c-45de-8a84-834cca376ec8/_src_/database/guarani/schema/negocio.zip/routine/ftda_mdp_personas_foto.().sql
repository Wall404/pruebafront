create function negocio.ftda_mdp_personas_foto() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
	-- Se resetea el ID de imagen de la persona.
	UPDATE	mdp_personas
	SET		id_imagen = NULL
	WHERE	persona = OLD.persona;

	RETURN OLD;
END;
$$;
