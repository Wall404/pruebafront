create function negocio.ftua_sga_propuestas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Si se está dando de baja una propuesta, actualizo el aplanado
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	IF NEW.estado = 'B' AND OLD.estado <> 'B' THEN
		-- Aplanado de períodos de inscripción a propuesta.
		DELETE
		FROM	sga_periodos_inscripcion_aplanado
		USING	sga_periodos_inscripcion_fechas
		WHERE	sga_periodos_inscripcion_aplanado.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc AND
				sga_periodos_inscripcion_aplanado.propuesta = NEW.propuesta AND
				(NEW.fecha_baja BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR
				 NEW.fecha_baja <= sga_periodos_inscripcion_fechas.fecha_inicio);
	END IF;
	RETURN NEW;
END;
$$;
