create function negocio.ftib_sga_planes_versiones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
       -- Genera un registro en la tabla de entidades..
       NEW.entidad := f_generar_entidad(103);
       RETURN NEW;
  END;
$$;
