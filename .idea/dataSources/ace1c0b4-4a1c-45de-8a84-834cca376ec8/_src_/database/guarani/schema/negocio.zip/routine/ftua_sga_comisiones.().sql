create function negocio.ftua_sga_comisiones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

   -- Si cambó el cupo entonces cambio el valor en la tabla de cupos
   IF COALESCE(OLD.cupo, 0) <> COALESCE(NEW.cupo, 0) THEN
     UPDATE sga_comisiones_cupo
        SET cupo = COALESCE(NEW.cupo, 0)
      WHERE comision = NEW.comision;
   END IF;
   
   RETURN NEW;
END;
$$;
