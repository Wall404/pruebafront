create function negocio.ftia_sga_propuestas_ra() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE 
	_periodos_insc record;
	_requisitos_ingreso record;
	_requisitos_x_accion record;
	_entidad_ra integer;
	_entidad_institucion integer;
BEGIN
	-- Recupero la entidad de la RA y la institución.
	SELECT	sga_responsables_academicas.entidad,
			sga_instituciones.entidad INTO _entidad_ra, _entidad_institucion
	FROM	sga_responsables_academicas,
			sga_instituciones
	WHERE	sga_responsables_academicas.institucion = sga_instituciones.institucion AND
			sga_responsables_academicas.responsable_academica = NEW.responsable_academica;

	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de períodos de inscripción a propuesta, períodos lectivos y turnos de examen.
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	FOR _periodos_insc IN	SELECT	sga_periodos_inscripcion_entidad.periodo_insc
							FROM	sga_periodos_inscripcion_entidad,
									sga_periodos_inscripcion_fechas
							WHERE	sga_periodos_inscripcion_entidad.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc AND
									-- Sólo períodos vigentes o futuros.
									(CURRENT_DATE BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR CURRENT_DATE <= sga_periodos_inscripcion_fechas.fecha_inicio) AND
									sga_periodos_inscripcion_entidad.entidad IN (_entidad_ra, _entidad_institucion)
	LOOP
		INSERT INTO	sga_periodos_inscripcion_aplanado (periodo_insc, plan_version, propuesta)
		SELECT		_periodos_insc.periodo_insc,
					sga_planes_versiones.plan_version,
					NULL
		FROM		sga_planes,
					sga_planes_versiones
		WHERE		sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes.propuesta = NEW.propuesta AND
					sga_planes_versiones.estado IN ('V','A') AND
					sga_planes_versiones.plan_version NOT IN (	SELECT	sga_periodos_inscripcion_aplanado.plan_version
																FROM	sga_periodos_inscripcion_aplanado
																WHERE	sga_periodos_inscripcion_aplanado.periodo_insc = _periodos_insc.periodo_insc AND
																		sga_periodos_inscripcion_aplanado.plan_version IS NOT NULL);
	END LOOP;

	FOR _periodos_insc IN	SELECT	sga_periodos_inscripcion_entidad.periodo_insc
							FROM	sga_periodos_inscripcion_entidad,
									sga_periodos_inscripcion_fechas,
									sga_periodos_inscripcion
							WHERE	sga_periodos_inscripcion_entidad.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc AND
									sga_periodos_inscripcion_fechas.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion AND
									-- Sólo períodos vigentes o futuros.
									(CURRENT_DATE BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin OR CURRENT_DATE <= sga_periodos_inscripcion_fechas.fecha_inicio) AND
									-- Sólo períodos de inscripción a propuesta.
									sga_periodos_inscripcion.periodo_generico_tipo = 4 AND
									sga_periodos_inscripcion_entidad.entidad IN (_entidad_ra, _entidad_institucion)
	LOOP
		INSERT INTO	sga_periodos_inscripcion_aplanado (periodo_insc, plan_version, propuesta)
		SELECT		_periodos_insc.periodo_insc,
					NULL,
					sga_propuestas.propuesta
		FROM		sga_propuestas
		WHERE		sga_propuestas.propuesta = NEW.propuesta AND
					sga_propuestas.estado = 'A' AND
					sga_propuestas.propuesta NOT IN (	SELECT	sga_periodos_inscripcion_aplanado.propuesta
														FROM	sga_periodos_inscripcion_aplanado
														WHERE	sga_periodos_inscripcion_aplanado.periodo_insc = _periodos_insc.periodo_insc AND
																sga_periodos_inscripcion_aplanado.propuesta IS NOT NULL);
	END LOOP;

	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de requisitos de ingreso.
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	FOR _requisitos_ingreso IN	SELECT	sga_requisitos_ingreso_entidades.requisito_propuesta
								FROM	sga_requisitos_ingreso_entidades
								WHERE	sga_requisitos_ingreso_entidades.entidad IN (_entidad_ra, _entidad_institucion)
	LOOP
		INSERT INTO	sga_requisitos_ingreso_aplanado (requisito_propuesta, plan_version)
		SELECT		_requisitos_ingreso.requisito_propuesta,
					sga_planes_versiones.plan_version
		FROM		sga_planes,
					sga_planes_versiones
		WHERE		sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes.propuesta = NEW.propuesta AND
					sga_planes_versiones.estado IN ('V','A') AND
					sga_planes_versiones.plan_version NOT IN (	SELECT	sga_requisitos_ingreso_aplanado.plan_version
																FROM	sga_requisitos_ingreso_aplanado
																WHERE	sga_requisitos_ingreso_aplanado.requisito_propuesta = _requisitos_ingreso.requisito_propuesta);
	END LOOP;

	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	-- Aplanado de requisitos por acción.
	-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	FOR _requisitos_x_accion IN	SELECT	sga_requisitos_x_accion.requisito_accion
								FROM	sga_requisitos_x_accion,
										sga_requisitos_grupos
								WHERE	sga_requisitos_x_accion.grupo_requisito = sga_requisitos_grupos.grupo_requisito AND
										sga_requisitos_grupos.entidad IN (_entidad_ra, _entidad_institucion)
	LOOP
		-- La version del plan de estudios ya puede existir para el requisito_accion.
		INSERT INTO	sga_requisitos_aplanado (requisito_accion, plan_version)
		SELECT		_requisitos_x_accion.requisito_accion,
					sga_planes_versiones.plan_version
		FROM		sga_planes,
					sga_planes_versiones
		WHERE		sga_planes.plan = sga_planes_versiones.plan AND
					sga_planes.propuesta = NEW.propuesta AND
					sga_planes_versiones.estado IN ('V','A') AND
					sga_planes_versiones.plan_version NOT IN (	SELECT	sga_requisitos_aplanado.plan_version
																FROM	sga_requisitos_aplanado
																WHERE	sga_requisitos_aplanado.requisito_accion = _requisitos_x_accion.requisito_accion);
	END LOOP;
	RETURN NEW;
END;
$$;
