create function negocio.ftub_sga_tesis() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   NEW.fecha_ult_cambio = CURRENT_TIMESTAMP;
   RETURN NEW;
END;
$$;
