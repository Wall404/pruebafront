CREATE VIEW vw_perfil_de_datos_personas AS SELECT mdp_personas.persona,
    mdp_personas.apellido,
    mdp_personas.nombres,
    (((mdp_tipo_documento.desc_abreviada)::text || ' '::text) || (mdp_personas_documentos.nro_documento)::text) AS tipo_nro_documento,
    mdp_personas_documentos.nro_documento
   FROM ((negocio.mdp_personas
     LEFT JOIN negocio.mdp_personas_documentos ON ((mdp_personas_documentos.documento = mdp_personas.documento_principal)))
     LEFT JOIN negocio.mdp_tipo_documento ON ((mdp_tipo_documento.tipo_documento = mdp_personas_documentos.tipo_documento)));
