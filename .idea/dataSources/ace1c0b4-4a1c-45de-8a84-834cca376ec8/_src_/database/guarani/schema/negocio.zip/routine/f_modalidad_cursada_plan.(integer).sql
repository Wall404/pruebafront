create function negocio.f_modalidad_cursada_plan(pplan integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  modalidad_cursada  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   modalidad_cursada := NULL;
		
  -- Recupero el nombre de las modalidades de cursada
  FOR cur1 IN SELECT sga_modalidad_cursada.nombre as nombre
                FROM sga_planes_modalidad, sga_modalidad_cursada
               WHERE sga_planes_modalidad.plan = pPlan
                 AND sga_planes_modalidad.modalidad = sga_modalidad_cursada.modalidad
  LOOP
      IF cnt = 0 THEN		
         modalidad_cursada :=  cur1.nombre;
      ELSE
         modalidad_cursada :=  modalidad_cursada || '/' || cur1.nombre;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  RETURN modalidad_cursada;
    
  END;
$$;
