create function negocio.f_evaluacion_modificar_nota(pevaluacion integer, palumno integer, pfecha character varying, pnota character varying, presultado character, pcorregidopor character varying, pobservaciones character varying, pultimocambio character varying) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE 
  cur_retorno	type_retorno_funcion;
  _cnt integer;
  _ultimo_cambio timestamp with time zone;

BEGIN
/* Formato de los datos:
   pFecha        = DD/MM/YYYY
   pUltimoCambio = DD/MM/YYYY HH:MM:SS.SSS
*/  

  -- Variables de retorno
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800CUR_evaluacion_modif_ok';
  cur_retorno.mensaje_param  := NULL;
  
-- Comienzo transacción.
BEGIN

  -- Actualizo al alumno
  UPDATE sga_eval_detalle
  	SET fecha         = to_date(pFecha, 'DD/MM/YYYY'),
  	    nota          = pNota,
  	    resultado     = pResultado,
  	    corregido_por = pCorregidoPor,
  	    observaciones = pObservaciones
  	WHERE evaluacion  = pEvaluacion
  	  AND alumno      = pAlumno
  	  AND to_char(ultimo_cambio, 'DD/MM/YYYY HH24:MI:SS.MS') = pUltimoCambio;
  
  -- Si no hubo actualización es porque hubo algun error.
  IF NOT FOUND THEN
     cur_retorno.resultado      = -1;
     cur_retorno.mensaje_indice = '800CUR_evaluacion_modif_nota_error'; -- Error generico

     -- Recupero nombre y apellido  y lo guardo en los parámetros de retorno   	 
     SELECT p.apellido || ' ' || p.nombres 
       INTO cur_retorno.mensaje_param
       FROM  sga_alumnos as a, mdp_personas as p 
      WHERE a.alumno = pAlumno
        AND p.persona = a.alumno;
  	
    -- Si no encontro el registro veo a que se debe
    SELECT COUNT(*) INTO _cnt FROM sga_evaluaciones WHERE evaluacion = pEvaluacion;
    IF _cnt = 0 THEN
        -- No existe la evaluacion
    	cur_retorno.mensaje_indice := '800CUR_evaluacion_modif_no_existe';
    ELSE
      -- Verifico ultima modificacion del registro
      SELECT ultimo_cambio INTO _ultimo_cambio
        FROM sga_eval_detalle 
       WHERE evaluacion  = pEvaluacion
         AND alumno      = pAlumno;
      IF NOT FOUND THEN
         -- El alumno no existe en la evaluacion
         cur_retorno.mensaje_indice := '800CUR_evaluacion_alumno_no_existe';
      ELSE
        -- Alguien modifico datos del alumno entre que se levanto el registro y se actualizó
        IF to_char(_ultimo_cambio, 'DD/MM/YYYY HH24:MI:SS.MS') <> pUltimoCambio THEN
  	       cur_retorno.mensaje_indice := '800CUR_evaluacion_alumno_modificado';
        END IF;  
      END IF;  
    END IF;
    RETURN cur_retorno;
  END IF;  
  
  -- Error.
  EXCEPTION WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800CUR_evaluacion_modif_error_db';
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base

  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800CUR_evaluacion_modif_ok';
  
  RETURN cur_retorno;

END;
$$;
