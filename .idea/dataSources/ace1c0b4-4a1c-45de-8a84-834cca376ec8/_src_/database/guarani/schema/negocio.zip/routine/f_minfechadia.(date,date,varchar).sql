create function negocio.f_minfechadia(fecha_desde date, fecha_hasta date, diasemana character varying) returns date
LANGUAGE plpgsql
AS $$
DECLARE
 fecha_aux date;

BEGIN
fecha_aux := fecha_desde;

WHILE fecha_aux <= fecha_hasta
LOOP
 IF f_diadelasemana(fecha_aux::date, 1::smallint) = diasemana THEN
    RETURN fecha_aux;
 END IF;
 fecha_aux := fecha_aux + 1;
END LOOP;

fecha_aux := NULL;
RETURN fecha_aux;

END;
$$;
