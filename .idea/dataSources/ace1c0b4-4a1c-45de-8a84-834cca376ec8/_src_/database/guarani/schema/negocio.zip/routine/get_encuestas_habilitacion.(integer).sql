create function negocio.get_encuestas_habilitacion(_habilitacion integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	habilitacion_tipo INTEGER;
	cant SMALLINT;
	encuesta_nombre VARCHAR;
	retorno TEXT;
	cur RECORD;
BEGIN
	cant := 0;
	retorno := NULL;

	SELECT	gde_habilitaciones.tipo INTO habilitacion_tipo
	FROM	gde_habilitaciones
	WHERE	gde_habilitaciones.habilitacion = _habilitacion;

	-- Recupero el nombre de las encuestas.
	FOR cur IN	SELECT	gde_encuestas.nombre,
						gde_subtipos.nombre as subtipo_nombre
				FROM	gde_grupos,
						gde_encuestas,
						gde_subtipos
				WHERE	gde_grupos.encuesta = gde_encuestas.encuesta AND
						gde_encuestas.subtipo = gde_subtipos.subtipo AND
						gde_grupos.habilitacion = _habilitacion
	LOOP
		IF habilitacion_tipo = 3 THEN -- Si el grupo es de tipo "", se concatena el subtipo de cada encuesta.
			encuesta_nombre := cur.nombre || ' (' || cur.subtipo_nombre || ')';
		ELSE
			encuesta_nombre := cur.nombre;
		END IF;
		IF cant = 0 THEN		
			retorno := encuesta_nombre;
		ELSE
			retorno := retorno || '/' || encuesta_nombre;
		END IF;   
		cant := cant + 1;
	END LOOP;

	RETURN retorno;
END;
$$;
