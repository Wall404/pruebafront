create function negocio.f_encuestas_sync_alumno(palumno integer, pcomision integer, paccion character varying, pestadoanterior character, pestadonuevo character) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _subcomisiones Integer[];
  _tiene_subcomisiones integer;
  _persona Integer;
  _cnt_items Integer;
  _cnt_items_form Integer;
  cur_com record;
  _formulario integer;
  _habilitacion integer;
  cur_hab record;
  _nombre_actividad varchar(255);
  _cnt integer;
  _retorno smallint;
  
-- pAccion: A = Alta inscripcion / B = Borrar Inscripcion / R = Rechazar Inscripcion / CE = Cambiar estado de la inscripcion / CS = Cambio de subcomision
BEGIN
 _subcomisiones := NULL;
 _tiene_subcomisiones := 0;
 _cnt_items := 0;
 _cnt_items_form := 0;
 _retorno := 0; -- No se hizo nada.

 -- verifico si hay encuestas para la comision. Encuestas vigentes.
 SELECT COUNT(*) INTO _cnt_items 
   FROM gde_formularios as f, 
        gde_habilitaciones as h 
  WHERE f.comision = pComision
    AND f.habilitacion = h.habilitacion
    AND h.fecha_hasta >= CURRENT_DATE;

 IF _cnt_items = 0 THEN
   -- No hay encuestas para esta comision
   RETURN _retorno;
 END IF;

 SELECT persona INTO _persona FROM sga_alumnos WHERE alumno = pAlumno;
 IF NOT FOUND THEN
    RETURN 0;
 END IF;

BEGIN
  -- Si cambia de estado la inscripcion a cursada, saco al alumno de las encuestas que tuviere en esa comision
  IF ((pAccion = 'B' OR pAccion = 'R' OR pAccion = 'CS') AND pEstadoAnterior = 'A') OR
     (pAccion = 'CE' AND pEstadoAnterior = 'A' AND pEstadoNuevo = 'P') THEN
     
     DELETE FROM gde_encuestas_pendientes
      WHERE persona = _persona
        AND formulario IN (SELECT formulario FROM gde_formularios WHERE comision = pComision)
        AND fecha_respuesta IS NULL;

    IF pAccion = 'B' OR pAccion = 'R' OR pAccion = 'CE' THEN
       _retorno := 2;
    END IF;
  END IF;  -- Fin cambio de Aceptado a Pendiente
 
  -- Cambio de Subcomision / Cambio de Estado de la inscripcion / Alta inscripcion en estado Aceptado.   
  -- Las encuestas solo se generan a inscripciones con estado Aceptado.
  IF (pAccion = 'CS' AND pEstadoAnterior = 'A') OR 
     (pAccion = 'CE' AND pEstadoAnterior = 'P' AND pEstadoNuevo = 'A') OR
     (pAccion = 'A' AND pEstadoNuevo = 'A') THEN
      
    SELECT count(*) INTO _tiene_subcomisiones FROM sga_subcomisiones WHERE comision = pComision;
     
    IF _tiene_subcomisiones = 0 THEN
       -- Encuestas asociadas a comisiones
       INSERT INTO gde_encuestas_pendientes (formulario, persona)
          SELECT formulario, _persona 
            FROM gde_formularios as f, 
                 gde_habilitaciones as h 
           WHERE f.comision = pComision
             AND f.habilitacion = h.habilitacion
             AND h.fecha_hasta >= CURRENT_DATE
             AND NOT EXISTS (SELECT 1 FROM gde_encuestas_pendientes as e 
                               WHERE e.formulario = f.formulario
                                 AND e.persona  = _persona );
    END IF;

    -- Comision con subcomisiones
    IF _tiene_subcomisiones > 0 THEN
       -- Combinacion de subcomisiones en las que esta inscripto el alumno
       _subcomisiones := f_encuestas_subcom_alumnos(pAlumno, pComision);
       IF _subcomisiones IS NULL THEN
           -- El alumno debe estar inscripto en subcomisiones pero no lo esta. No hago nada con este alumno en esta comision
           RETURN -1; -- Le faltan inscripciones a subcomisiones al alumno.
       END IF;

        -- Asigno al formulario el nombre de la actividad.  
        SELECT sga_elementos.nombre 
          INTO _nombre_actividad
          FROM sga_comisiones, sga_elementos
         WHERE sga_comisiones.comision = pComision
           AND sga_elementos.elemento = sga_comisiones.elemento;

        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        -- Recorro las diferentes habilitaciones para la comision con fecha de finalizacion mayor a hoy.
        -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
        FOR cur_hab IN SELECT DISTINCT i.habilitacion
                         FROM gde_items as i, 
                              gde_habilitaciones as h
                         WHERE i.comision = pComision
                           AND h.habilitacion = i.habilitacion
                           AND h.fecha_hasta >= CURRENT_DATE
        LOOP

          -- Verifico si existe un formulario con la combinacion de subcomisiones en las que esta inscripto el alumno, 
          -- Si no existe formulario se crea y se asigna la encuesta al alumno
          -- Aca considera que la encuesta es académica y de actuacion docente (por las subcomisiones)
          SELECT formulario INTO _formulario
            FROM gde_formularios
           WHERE comision      = pComision
             AND subcomisiones = _subcomisiones
             AND habilitacion  = cur_hab.habilitacion;

          IF FOUND THEN
            -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
            -- EXISTE un formulario para la comision/subcomisones y habilitacion
            -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
            SELECT count(*) INTO _cnt FROM gde_encuestas_pendientes WHERE formulario = _formulario AND persona = _persona;
            IF _cnt = 0 THEN
               -- Agrego al alumno para que responda la encuesta
               INSERT INTO gde_encuestas_pendientes (formulario, persona) VALUES (_formulario, _persona);
               _retorno := 1;
            END IF;
        
          ELSE
             -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
             -- NO EXISTE un formulario para la combinacion de habilitacion/comision/subcomisiones 
             -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 
          
             SELECT COUNT(*) INTO _cnt_items_form
               FROM gde_items
              WHERE gde_items.habilitacion = cur_hab.Habilitacion
                AND gde_items.comision     = pComision
                AND (gde_items.subcomision = ANY (_subcomisiones) OR   -- Items de los docentes por subcomision (docente)
                     (gde_items.subcomision IS NULL AND gde_items.docente IS NULL) -- Item de la comision (academica) 
                     );
            
             -- Solo si hay al menos un item para el formulario, entonces lo creo
             IF _cnt_items_form > 0 THEN
                 
                 -- Marco la habilitacion para que se vuelva a re-sincronizar
                 UPDATE gde_habilitaciones
                   SET kolla_sincronizado = 'N'
                 WHERE habilitacion = cur_hab.habilitacion
                   AND kolla_sincronizado = 'S';
                 
                 -- Inserto el formulario para la comision y subcomisiones del alumno
                 INSERT INTO gde_formularios (titulo, habilitacion, comision, subcomisiones, estado) 
                      VALUES (_nombre_actividad, cur_hab.habilitacion, pComision, _subcomisiones, 'A');
                 _formulario := (SELECT currval('gde_formularios_seq'));
                 
                 -- inserto los items de la comision y subcomisiones involucradas
                 INSERT INTO gde_formulario_items (formulario, item) 
                      SELECT _formulario, gde_items.item
                        FROM gde_items
                       WHERE gde_items.habilitacion = cur_hab.Habilitacion
                         AND gde_items.comision     = pComision
                         AND (gde_items.subcomision = ANY (_subcomisiones) OR   -- Items de los docentes por subcomision (docente)
                              (gde_items.subcomision IS NULL AND gde_items.docente IS NULL) -- Item de la comision (academica) 
                             );
                 
                 -- Asocio el formulario de encuesta a la persona para que quede pendiente de responder
                 INSERT INTO gde_encuestas_pendientes (formulario, persona) VALUES (_formulario, _persona);
             
             END IF; -- _cnt_items_form > 0 
             
             _retorno := 1;
          END IF;
          
        END LOOP; -- Habilitaciones
      END IF; -- Comision con subcomisiones
  END IF; -- Fin cambio de Pendiente a Aceptado


  EXCEPTION 
    WHEN unique_violation THEN
       RETURN 3; -- Ya existe el alumno asociado a la encuesta (formulario)
   WHEN OTHERS THEN
       RETURN -1;

END;

-- OK
RETURN _retorno;

END;
$$;
