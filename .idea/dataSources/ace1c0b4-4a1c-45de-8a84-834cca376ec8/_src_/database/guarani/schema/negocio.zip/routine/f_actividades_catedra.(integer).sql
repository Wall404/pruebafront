create function negocio.f_actividades_catedra(pcatedra integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _actividades  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _actividades := NULL;
		
  -- Recupero el nombre de los docentes
  FOR cur1 IN 
	SELECT 
		sga_elementos.nombre_abreviado
	FROM 
		sga_catedras_actividades,
		sga_elementos
	WHERE
		sga_catedras_actividades.elemento = sga_elementos.elemento
		AND sga_catedras_actividades.catedra = pCatedra
	ORDER BY 
		sga_elementos.nombre_abreviado
  LOOP
      IF cnt = 0 THEN
         _actividades :=  cur1.nombre_abreviado;
      ELSE
         _actividades :=  _actividades || ' - ' || cur1.nombre_abreviado;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _actividades;
    
END;
$$;
