create function negocio.f_equiv_evaluar_grupo(pid integer, pgrupoequivalencia integer, pesautomatica boolean, palumno integer, pplanversion integer, ppersona integer, ppropuestaorigen integer, pplanorigen integer, pversionorigen integer, pparamcontrolarcorrelativas character, pparamajustarnota character, pparampasardesaprobados character, pparamregistrarvencoriginal character, pparampasarregularidad character, pparampasarregularidadconnota character) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 

  _GRUPOEQUIV  sga_equiv_grupos%ROWTYPE;
  _EQUIV_INT   sga_equiv_internas%ROWTYPE;
  
  cur_R record;
  _equiv_escala_nota_origen integer[];
  _equiv_nota_origen varchar(10)[];
  _escala_nota_reg integer[]; -- usado para regularidades
  _nota_reg varchar(10)[];
  _hay_equiv_regularidad_para_pasar boolean;
  cur_origen   record;
  cur_destino  record;
  _actividad_origen integer;
  _origen_ok   boolean;
  _cant        smallint;
  _cant2       smallint;
  _escala_nota  integer;
  _escala_nota_origen integer;
  _nota         varchar(10);
  _cant_notas   smallint;
  _cant_notas_promedio smallint;
  _cant_act_origen  smallint;
  _cant_act_destino smallint;     
  i_destino integer;
  _fecha_equiv date;
  _fecha_origen date;
  _fecha_vigencia date;
  _fecha_vigencia_aux date;
  _fecha_vigencia_origen date;
  ID_RETORNO  integer;
  _traslada_nota boolean;
  _actividad_esta_aprobada boolean;
  _otorgar_equivalencia boolean;
  _ajustar_nota boolean;
  _mismo_resultado_nota_origen boolean;
  _act_destino_esta_aprobada boolean;
  _act_destino_esta_regularizada boolean;
  _instancia integer;
  
  
  -- Constantes
  _ORIGEN char(1);
  _DESTINO char(1);
  _INSTANCIA_TOTAL integer;
  _INSTANCIA_REGULARIDAD integer;
  _INSTANCIA_PARCIAL integer;
  _GE_ALCANCE_TOTAL char(1);
  _GE_ALCANCE_REGULARIDAD char(1);
  _GE_ALCANCE_PARCIAL char(1);
  _APROBADO char(1);
  _DESAPROBADO char(1);
  
  _ORIGEN_CURSADA char(1);
  _ORIGEN_PROMOCION char(1);
  _ORIGEN_RESOLUCION char(1);
  _ORIGEN_EXAMEN char(1);
  _ORIGEN_EQUIVALENCIA_TOTAL char(1);
  _ORIGEN_EQUIVALENCIA_REGULARIDAD char(1);
  
  _EQUIV_INT_ORIGEN_EXAMEN varchar(20);
  _EQUIV_INT_ORIGEN_EQUIVALENCIA varchar(20);
  _EQUIV_INT_ORIGEN_CURSADA varchar(20);
  _EQUIV_INT_ORIGEN_RESOLUCION varchar(20);
  _EQUIV_INT_ORIGEN_PROMOCION varchar(20);

  _ESCALA_NOTA_PARCIAL integer;
  _ESCALA_NOTA_TOTAL integer;
  _ESCALA_NOTA_REGULARIDAD integer;
  
BEGIN
  -- Seteo Constantes
  _fecha_equiv         := CURRENT_DATE; 
  _origen_ok           := true;
  _traslada_nota       := false;
  _ORIGEN              := 'O';
  _DESTINO             := 'D';
  _INSTANCIA_TOTAL       := 10;  -- Antes = T;
  _INSTANCIA_REGULARIDAD := 11;  -- Antes = R;
  _INSTANCIA_PARCIAL     := 12;  -- Antes = P
  _GE_ALCANCE_TOTAL       := 'T';
  _GE_ALCANCE_REGULARIDAD := 'R';
  _GE_ALCANCE_PARCIAL     := 'P';
  _APROBADO            := 'A';
  _DESAPROBADO         := 'R';
  
  _ORIGEN_CURSADA      := 'R'; -- sga_actas.origen
  _ORIGEN_PROMOCION    := 'P'; -- sga_actas.origen
  _ORIGEN_EXAMEN       := 'E'; -- sga_actas.origen
  _ORIGEN_EQUIVALENCIA_TOTAL := 'B'; 
  _ORIGEN_RESOLUCION   := 'A'; -- Aprobaciones por resolucion
  _ORIGEN_EQUIVALENCIA_REGULARIDAD := 'C'; -- vw_regularidades.origen
  
  _EQUIV_INT_ORIGEN_EXAMEN       := 'Examen';
  _EQUIV_INT_ORIGEN_PROMOCION	 := 'Promocion';
  _EQUIV_INT_ORIGEN_EQUIVALENCIA := 'Equivalencia';
  _EQUIV_INT_ORIGEN_CURSADA      := 'Cursada';
  _EQUIV_INT_ORIGEN_RESOLUCION   := 'Resolucion';

  _mismo_resultado_nota_origen := true;

  IF pParamAjustarNota = 'S' THEN
    -- Recupera la nota de la escala de notas destino mas cercana que coincida con la nota origen.
    _ajustar_nota := false; 
  ELSE
    -- solo devuelve una nota si la nota origen coincide con una nota de la escala de notas destino. 
    _ajustar_nota := true; 
  END IF;
  
  ID_RETORNO           := pID; -- Continua desde el ultimo ID insertado.
  _cant_notas          := 0;
  _cant_notas_promedio := 0;
  _cant_act_origen     := 0;
  _cant_act_destino    := 0;     
  
  
  -- Recupero los datos del Grupo de Equivalencia a evaluar
  SELECT * INTO _GRUPOEQUIV FROM sga_equiv_grupos WHERE grupo_equivalencia = pGrupoEquivalencia;
  
  -- Recupero cantidad de actividades del origen y del destino
  SELECT SUM(CASE origen_destino WHEN _ORIGEN THEN 1 ELSE 0 END), SUM(CASE origen_destino WHEN _DESTINO THEN 1 ELSE 0 END)
    INTO _cant_act_origen, _cant_act_destino     
    FROM sga_equiv_actividades 
   WHERE grupo_equivalencia = pGrupoEquivalencia ;
  
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- ACTIVIDADES ORIGEN. Recorro las actividades del grupo de equivalencias para analizar su cumplimiento.
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  FOR cur_origen IN SELECT condicion, elemento, nota FROM sga_equiv_actividades WHERE grupo_equivalencia = pGrupoEquivalencia AND origen_destino = _ORIGEN
  LOOP
    -- 2 = Tener la actividad regularizada y aprobada Examen/Promoción/Equivalencia total/por Resolución)
    _nota := NULL;
    _cant := 0;
    _actividad_esta_aprobada := false;

    -- Verifico si esta aprobada por examen/equivalencia total / promocion / resolucion
    SELECT escala_nota, nota INTO _escala_nota, _nota  
      FROM _TempHA 
     WHERE elemento = cur_origen.elemento 
       AND resultado = _APROBADO 
     ORDER BY fecha DESC LIMIT 1;

    IF FOUND THEN 
       _actividad_esta_aprobada := true;
    END IF;
           		      
    -- Si la condicion origen es que tenga la actividad regularizada        		      
    IF cur_origen.condicion = 'R' OR cur_origen.condicion = '2' THEN
      IF NOT _actividad_esta_aprobada THEN
        -- Regularizada. Recupera la ultima cursada de la actividad.
        SELECT escala_nota, nota INTO _escala_nota, _nota  
          FROM _TempReg 
          WHERE elemento = cur_origen.elemento 
            AND resultado = _APROBADO 
            AND es_vigente = 1
          ORDER BY fecha DESC LIMIT 1; 
             
        IF NOT FOUND THEN 
          _origen_ok := false;
        END IF;
      END IF;
    END IF; 
       
    -- Tener la actividad aprobada (por Examen/Promoción/Equivalencia total/por Resolución)
    IF (cur_origen.condicion = 'A' OR cur_origen.condicion = '2') AND _origen_ok THEN 
      _origen_ok := _actividad_esta_aprobada;
    END IF; 
       
    -- Si no cumple con el origen, salgo de las actividades del origen..
    IF NOT _origen_ok THEN 
      EXIT;
    END IF;
    
    -- Verifico si traslada la nota, y si la actividad participa en el pasaje de la nota entonces voy agregando la nota y escala de notas al array para luego usarlo en el calculo de las notas
    -- de las equivalencias a otorgar
    
    IF _GRUPOEQUIV.traslada_nota = 'S' AND cur_origen.nota = 'S' AND _nota IS NOT NULL AND _escala_nota IS NOT NULL THEN
      _traslada_nota       := true;
      _cant_notas_promedio := _cant_notas_promedio + 1;
      _equiv_escala_nota_origen[_cant_notas_promedio] := _escala_nota;
      _equiv_nota_origen[_cant_notas_promedio]        := _nota;
    END IF; 
    
  END LOOP;
  -- ++++++++++++++ Fin actividades del origen del grupo de equivalencias ++++++++++++++++++++++
 
  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- ACTIVIDADES DESTINO a otorgar por equivalencia
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  i_destino := 0; 
  FOR cur_destino IN 
              SELECT ea.condicion, 
                     ea.elemento, 
                     ea.tiene_vencimiento, 
                     ea.nota,
                     ea.temas_a_rendir,
                     get_escala_nota (pPlanVersion, ea.elemento, 
                                      CASE ea.condicion
                                        WHEN _GE_ALCANCE_TOTAL       THEN 'EQUIVALENCIA_TOTAL'
                                        WHEN _GE_ALCANCE_REGULARIDAD THEN 'EQUIVALENCIA_REGULARIDAD'
                                        WHEN _GE_ALCANCE_PARCIAL     THEN 'EQUIVALENCIA_PARCIAL'
                                      END
                                      ) as escala_nota
                FROM sga_equiv_actividades as ea
               WHERE ea.grupo_equivalencia = pGrupoEquivalencia 
                 AND ea.origen_destino = _DESTINO
  
  LOOP
  
    i_destino := i_destino + 1; 
    
    -- Limpio variables
    _fecha_vigencia := NULL;
    _escala_nota    := NULL;
    _nota           := NULL;
    _otorgar_equivalencia := true;
    _act_destino_esta_aprobada := false;
    _act_destino_esta_regularizada := false;

    -- -------------------------------------------------------------------
    -- 1. Otorgo la equivalencia de cada una de las actividades del destino
    -- -------------------------------------------------------------------
    IF _origen_ok THEN
      -- Verifico si debo o no otorgar la equivalencia. 
      -- Busco si esta aprobada en cualquier propuesta la actividad a otorogar la equivalencia...
      SELECT COUNT(*) INTO _cant FROM _TempHA WHERE elemento = cur_destino.elemento AND resultado = _APROBADO;
      
      IF _cant > 0 THEN
         _act_destino_esta_aprobada := true;  
        _otorgar_equivalencia := false;
      ELSE
         -- Verifico si ya le di la equivalencia total en este mismo proceso automatico
         SELECT COUNT(*) INTO _cant FROM _Equiv WHERE elemento = cur_destino.elemento AND resultado = _APROBADO AND instancia = _INSTANCIA_TOTAL;
         IF _cant > 0 THEN
            _act_destino_esta_aprobada := true;  
            _otorgar_equivalencia     := false;
         END IF; 
      END IF; 
      
      -- Busco si esta regularizada (vigente o no) en cualquier propuesta
      SELECT COUNT(*) INTO _cant FROM _TempReg  WHERE elemento = cur_destino.elemento AND resultado = _APROBADO;
      IF _cant > 0 THEN
         _act_destino_esta_regularizada := true;
      ELSE
         -- Verifico si ya le di la equivalencia de regularidad en este mismo proceso automatico
         SELECT COUNT(*) INTO _cant FROM _Equiv WHERE elemento = cur_destino.elemento AND resultado = _APROBADO AND instancia = _INSTANCIA_REGULARIDAD;
         IF _cant > 0 THEN
           _act_destino_esta_regularizada := true;
         END IF; 
      END IF;   
      
      -- Es una equivalencia de regularidad
      IF cur_destino.condicion = _GE_ALCANCE_REGULARIDAD AND (_act_destino_esta_regularizada OR _act_destino_esta_aprobada) THEN
         _otorgar_equivalencia := false;
      END IF;
      
      -- Equivalencia Parcial
      IF cur_destino.condicion = _GE_ALCANCE_PARCIAL AND _otorgar_equivalencia THEN
         -- Busco si esta otorgada una equivalencia parcial por la materia destino a la persona en cualquier propuesta
         SELECT COUNT(*) INTO _cant FROM vw_equiv_parciales_basica WHERE persona = pPersona AND elemento = cur_destino.elemento AND resultado = _APROBADO;
         IF _cant > 0 THEN
           _otorgar_equivalencia := false;

         ELSE
           
           -- Verifico si ya le di la equivalencia parcial en este mismo proceso automatico
           SELECT COUNT(*) INTO _cant FROM _Equiv WHERE elemento = cur_destino.elemento AND resultado = _APROBADO AND instancia = _INSTANCIA_PARCIAL;
           IF _cant > 0 THEN
              _otorgar_equivalencia := false;
           END IF; 
         END IF;
      END IF;
      
      
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- Controlo correlativas solo si es de aplicacion automática. @@FALTA
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      IF pParamControlarCorrelativas = 'S' AND _otorgar_equivalencia AND pEsAutomatica THEN
         IF cur_destino.condicion = _GE_ALCANCE_TOTAL OR cur_destino.condicion = _GE_ALCANCE_PARCIAL THEN
            -- Correlativas de Examen
         END IF;
         
         IF cur_destino.condicion = _GE_ALCANCE_REGULARIDAD THEN
           -- Correlativas de Cursada
         END IF;

      END IF;
      
      
      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- Otorgo la equivalencia 
      -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      IF _otorgar_equivalencia THEN
         
         -- Vencimiento
         IF cur_destino.tiene_vencimiento = 'S' THEN
         
            -- Verifico si debo pasar el vencimiento de la regularidad de la actividad del origen. Solo cuando hay una sola actividad.
            IF cur_destino.condicion = _GE_ALCANCE_REGULARIDAD AND pParamRegistrarVencOriginal = 'S' AND _cant_act_origen = 1 THEN

               -- Busco la actividad del origen. 
               SELECT elemento INTO _actividad_origen  FROM sga_equiv_actividades WHERE grupo_equivalencia = pGrupoEquivalencia AND origen_destino = _ORIGEN;
               IF FOUND THEN 
                 -- Registro el vencimiento de la ultima cursada de la actividad del origen (vigente o no..)
                 -- _fecha_vigencia := get_ultima_cursada_fecha_vigencia (pAlumnoOrigen, cur_origen.elemento, 1);  
                 SELECT fecha_vigencia INTO _fecha_vigencia FROM _TempReg WHERE elemento = _actividad_origen  AND resultado = _APROBADO  ORDER BY fecha DESC LIMIT 1;
               END IF;
            END IF;
            
            -- Si no se otorga el vencimiento original o el mismo es nulo, seteo un nuevo vencimiento en base a la fecha de la equivalencia.       
            IF _fecha_vigencia IS NULL THEN
			   IF cur_destino.condicion = _GE_ALCANCE_TOTAL THEN 
			     _instancia = _INSTANCIA_TOTAL;
			   ELSEIF cur_destino.condicion = _GE_ALCANCE_REGULARIDAD THEN 
			     _instancia = _INSTANCIA_REGULARIDAD;
			   ELSEIF cur_destino.condicion = _GE_ALCANCE_PARCIAL THEN 
			     _instancia = _INSTANCIA_PARCIAL;
			   END IF;	
               _fecha_vigencia := f_fin_vigencia_equivalencia(pAlumno, _instancia, _fecha_equiv);
            END IF;   
         END IF; -- tiene vencimiento
         
         -- Nota de la Equivalencia. Solo si se definió que se traslada la nota y la equivalencia se le define nota.
         -- Y que del origen se haya definido al menos una materia que es la que participa en el cálculo de la nota de las equivalencias
         IF _GRUPOEQUIV.traslada_nota = 'S' AND cur_destino.nota = 'S' AND array_length(_equiv_escala_nota_origen, 1) > 0 THEN
           -- Calcula la nota en base a las notas de las actividades del origen y segun escala de notas de la actividad destino 
           _nota := get_equiv_nota(_equiv_escala_nota_origen, _equiv_nota_origen, _APROBADO, cur_destino.escala_nota, _mismo_resultado_nota_origen, _ajustar_nota);
         END IF;              

         ID_RETORNO := ID_RETORNO + 1;
         
         -- Registro la Equivalencia
         INSERT INTO _Equiv (id, elemento, instancia, fecha, fecha_vigencia, escala_nota, nota, resultado, temas_a_rendir, grupo_equivalencia, matriz)
              VALUES (ID_RETORNO, cur_destino.elemento, 
			          CASE cur_destino.condicion 
					    WHEN _GE_ALCANCE_TOTAL THEN _INSTANCIA_TOTAL
					    WHEN _GE_ALCANCE_REGULARIDAD THEN _INSTANCIA_REGULARIDAD
					    WHEN _GE_ALCANCE_PARCIAL THEN _INSTANCIA_PARCIAL
					  END,
					  _fecha_equiv, _fecha_vigencia, cur_destino.escala_nota, _nota, _APROBADO, cur_destino.temas_a_rendir, pGrupoEquivalencia, _GRUPOEQUIV.matriz);

         -- Registra el origen que da pie a la equivalencia. Uno por cada actividad del origen
         FOR cur_origen IN 
            SELECT condicion, elemento, tiene_vencimiento
              FROM sga_equiv_actividades 
             WHERE grupo_equivalencia = pGrupoEquivalencia 
               AND origen_destino = _ORIGEN
         LOOP
           
           -- El origen es actividad aprobada por examen/promocion/equivalencia..
           IF cur_origen.condicion = 'A' OR cur_origen.condicion = '2' THEN	
              INSERT INTO _EquivInt (id, propuesta, elemento, fecha, nota, resultado, origen)
                  SELECT ID_RETORNO, t.propuesta2, cur_origen.elemento, t.fecha, t.nota, t.resultado,
                         CASE t.origen 
                            WHEN _ORIGEN_EXAMEN       THEN _EQUIV_INT_ORIGEN_EXAMEN
                            WHEN _ORIGEN_EQUIVALENCIA_TOTAL THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                            WHEN _ORIGEN_PROMOCION    THEN _EQUIV_INT_ORIGEN_PROMOCION
                            WHEN _ORIGEN_RESOLUCION   THEN _EQUIV_INT_ORIGEN_RESOLUCION
                            WHEN _ORIGEN_CURSADA      THEN _EQUIV_INT_ORIGEN_CURSADA
                            WHEN _ORIGEN_EQUIVALENCIA_REGULARIDAD THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                         END
                  FROM _TempHA as t
                  WHERE t.elemento  = cur_origen.elemento
                    AND t.resultado = _APROBADO
                  ORDER BY t.fecha DESC
                  LIMIT 1;  
              
           END IF;
           
           -- El origen es una regularidad vigente. Recupero la ultima regularidad que encuentro de la actividad.
           IF cur_origen.condicion = 'R' OR cur_origen.condicion = '2' THEN
              INSERT INTO _EquivInt (id, propuesta, elemento, fecha, nota, resultado, origen)
                  SELECT ID_RETORNO, t.propuesta2, cur_origen.elemento, t.fecha, t.nota, t.resultado,
                         CASE t.origen 
                            WHEN _ORIGEN_CURSADA   THEN _EQUIV_INT_ORIGEN_CURSADA
                            WHEN _ORIGEN_PROMOCION THEN _EQUIV_INT_ORIGEN_PROMOCION
                            WHEN _ORIGEN_EQUIVALENCIA_REGULARIDAD THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                            WHEN _ORIGEN_EXAMEN       THEN _EQUIV_INT_ORIGEN_EXAMEN
                            WHEN _ORIGEN_EQUIVALENCIA_TOTAL THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                            WHEN _ORIGEN_RESOLUCION   THEN _EQUIV_INT_ORIGEN_RESOLUCION
                         END
                  FROM _TempReg as t
                  WHERE t.elemento   = cur_origen.elemento
                    AND t.resultado  = _APROBADO
                    AND t.es_vigente = 1
                  ORDER BY t.fecha DESC  
                  LIMIT 1;  

               IF NOT FOUND THEN
                  -- Si no tiene la cursada, registro la aprobacion total de la materia que dio origen a la equiv de regularidad.
                  INSERT INTO _EquivInt (id, propuesta, elemento, fecha, nota, resultado, origen)
                      SELECT ID_RETORNO, t.propuesta2, cur_origen.elemento, t.fecha, t.nota, t.resultado,
                             CASE t.origen 
                                WHEN _ORIGEN_EXAMEN       THEN _EQUIV_INT_ORIGEN_EXAMEN
                                WHEN _ORIGEN_EQUIVALENCIA_TOTAL THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                                WHEN _ORIGEN_PROMOCION    THEN _EQUIV_INT_ORIGEN_PROMOCION
                                WHEN _ORIGEN_RESOLUCION   THEN _EQUIV_INT_ORIGEN_RESOLUCION
                                WHEN _ORIGEN_CURSADA      THEN _EQUIV_INT_ORIGEN_CURSADA
                                WHEN _ORIGEN_EQUIVALENCIA_REGULARIDAD THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                             END
                      FROM _TempHA as t
                      WHERE t.elemento  = cur_origen.elemento
                        AND t.resultado = _APROBADO
                      ORDER BY t.fecha DESC
                      LIMIT 1;  
               END IF;   
           END IF;
         
         END LOOP; -- Actividades del origen para registrar sga_equiv_internas
         
      END IF; -- _otorgar_equivalencia
    END IF; -- _origen_ok
    -- +++++++++++++++++++++++++++ Fin otorgar equivalencias +++++++++++++++++++++++
  
  
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    -- Recorro las actividades del origen para pasar EXAMENES/EQUIVALENCIAS DESAPROBADAS
    -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    FOR cur_origen IN 
           SELECT condicion, elemento, tiene_vencimiento, nota
             FROM sga_equiv_actividades 
            WHERE grupo_equivalencia = pGrupoEquivalencia 
              AND origen_destino = _ORIGEN
    LOOP

      -- -----------------------------------------------------------------------------------------------------
      -- 2. Paso los examenes/equivalencias DESAPROBADAS. 
      --    * Solo si cantidad de actividades del grupo origen = 1, la condicion origen es Aprobada/Ambas y la instancia es TOTAL
      --    * pParamPasarDesaprobados = '1' -> Solo pasa para la primer actividad del grupo destino de la equivalencia
      --                                'T' -> Pasa los desaprobados para todas las materias del destino
      -- -----------------------------------------------------------------------------------------------------
      IF _cant_act_origen = 1 AND 
         cur_destino.condicion = _GE_ALCANCE_TOTAL AND
         (pParamPasarDesaprobados = '1' OR pParamPasarDesaprobados = 'T') AND
         (cur_origen.condicion = 'A' OR cur_origen.condicion = '2') THEN
          
         -- Si solo pasa desaprobados a la primer actividad del destino, entonces sale en la 2da actividad
         IF (pParamPasarDesaprobados = '1' AND i_destino = 1) OR pParamPasarDesaprobados = 'T' THEN
            
             -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
             -- Actividades Desaprobadas del Origen. Solo examenes y equivalencias
             -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
             FOR cur_R IN SELECT * FROM _TempHA 
                           WHERE resultado = _DESAPROBADO
                             AND elemento  = cur_origen.elemento
                             AND origen    IN (_ORIGEN_EXAMEN, _ORIGEN_EQUIVALENCIA_TOTAL)
                           
             LOOP
                -- Verifico que ya no tenga registrada una equivalencia desaprobada de la actividad relacionado con este examen
                -- Equivalencia relacionado con el mismo examen/equivalencia origen.
                SELECT COUNT(*) INTO _cant 
                  FROM _TempHA as t
                 WHERE t.elemento  = cur_destino.elemento
                   AND t.resultado = _DESAPROBADO
                   AND t.origen    = _ORIGEN_EQUIVALENCIA_TOTAL
                   AND EXISTS (SELECT 1 FROM sga_equiv_internas as i
                                WHERE i.equivalencia = t.equivalencia
                                  AND i.elemento     = cur_R.elemento
                                  AND i.propuesta    = cur_R.propuesta2
                                  AND i.fecha        = cur_R.fecha
                                  AND i.nota         = cur_R.nota
                                  AND i.resultado    = cur_R.resultado
                               );
                
                -- Si ya tiene registrada una equivalencia por ese examen desaprobado, entonces continuo con el próximo examen desaprobado..   
                IF _cant > 0 THEN 
                    -- Ya se otorgó la equivalencia desaprobada
                   CONTINUE;
                ELSE
                   -- Verifico que ya no le haya dado la equivalencia total desaprobada por este mismo proceso automatico.
                   /*
                   -- Controlo que el desaprobado corresponda al mismo origen (fecha, nota, elemento.)
                   -- Esto no se puede controlar si la evaluacion de la matriz viene desde la operacion "Otorgar Equivalencias"
                   -- porque no se usa la funcion f_equiv_otorgar_equivalencia
                   SELECT COUNT(*) INTO _cant2 FROM _TEquiv
                    WHERE elemento     = cur_destino.elemento 
                      AND instancia    = _INSTANCIA_TOTAL 
                      AND resultado    = _DESAPROBADO 
                      AND int_elemento = cur_R.elemento
                      AND (int_fecha   = cur_R.fecha OR (int_fecha IS NULL AND cur_R.fecha IS NULL))
                      AND int_nota     = cur_R.nota
                      AND int_resultado = cur_R.resultado;
                   */
                   
                   -- Consulto en las tablas temporales actuales
                   SELECT COUNT(*) INTO _cant 
                     FROM _Equiv as E, _EquivInt as I
                    WHERE I.id = E.id
                      AND E.elemento  = cur_destino.elemento 
                      AND E.instancia = _INSTANCIA_TOTAL 
                      AND E.resultado = _DESAPROBADO 
                      AND I.elemento  = cur_R.elemento
                      AND (I.fecha    = cur_R.fecha OR (I.fecha IS NULL AND cur_R.fecha IS NULL))
                      AND I.nota      = cur_R.nota
                      AND I.resultado = cur_R.resultado;

                   IF _cant > 0 THEN
                      -- Ya se otorgó la equivalencia desaprobada
                      CONTINUE;   
                   END IF;
                END IF;
                                
                _nota := NULL;
                _nota := get_equiv_nota(array[cur_R.escala_nota::integer], array[cur_R.nota], _DESAPROBADO, cur_destino.escala_nota, _mismo_resultado_nota_origen, _ajustar_nota);

                ID_RETORNO := ID_RETORNO + 1;

                -- Registro la Equivalencia
                INSERT INTO _Equiv (id, elemento, instancia, fecha, fecha_vigencia, escala_nota, nota, resultado, temas_a_rendir, grupo_equivalencia, matriz)
                  VALUES (ID_RETORNO, cur_destino.elemento, _INSTANCIA_TOTAL, _fecha_equiv, cast(NULL as date), cur_destino.escala_nota, _nota, _DESAPROBADO, cast(NULL as text), pGrupoEquivalencia, _GRUPOEQUIV.matriz);

                -- Registra el origen que da pie a la equivalencia
                INSERT INTO _EquivInt (id, propuesta, elemento, fecha, nota, resultado, origen)
                     VALUES (ID_RETORNO, cur_R.propuesta2, cur_R.elemento, cur_R.fecha, cur_R.nota, cur_R.resultado,
                             CASE cur_R.origen 
                               WHEN _ORIGEN_EXAMEN THEN _EQUIV_INT_ORIGEN_EXAMEN
                               WHEN _ORIGEN_EQUIVALENCIA_TOTAL THEN _EQUIV_INT_ORIGEN_EQUIVALENCIA
                             END);

             END LOOP; -- Actividades desaprobadas del origen
          END IF; -- pParamPasarDesaprobados = 'S' AND i_destino > 1
       END IF; 
       -- **************************** Fin pasar exámenes Desaprobados ***************************************

    END LOOP; -- Actividades del Origen del Grupo de Equivalencias -- EXAMENES/EQUIVALENCIAS DESAPROBADAS

    
    -- -----------------------------------------------------------------------------------------------------
    --                          Pasaje automático de REGULARIDADES  
    --   * Considera la ultima regularidad "vigente aprobada" de cada actividad del origen cuya condiciones es "Aprobada"
    --   * No otorga la equivalencia de regularidad si el alumno ya tiene la actividad aprobada (por examen/promocion/equiv total) o regularizada (vigente o no)...
    --     por cualquiera de las propuestas del alumno.
    --   * Solo se otorga una la equivalencia de regularidad para cada actividad del destino cuyo alcance es "Equivalencia Total"
    --   * Se promedian las notas de las equivalencias de regularidad del origen solo en el caso que se pase nota segun lo definido
    --     en el parámetro equiv_automatica_otorgar_regularidades_con_nota. No importa si en el grupo de equivalencias se definio
    --     que traslada o no traslada nota (esto es solo para las equivalencias directas definidas en el grupo de equivalencias)
    --   * pParamPasarRegularidades = '1' -> Solo pasa la regularidad de la actividad si se cumple el origen
    --                                '2' -> Se pasa la regularidad siempre, este o no cumplido el origen
    --   * pParamRegistrarVencOriginal: El vencimiento de la equivalencia de Regularidad a otorgar se calcula en base a 
    --     la fecha de la equivalencia o se pasa el vencimiento de la regularidad original. Parámetro "equiv_automatica_vencimiento_origen"
    --   * Si se recupera mas de una regularidad (de diferntes materias), si hay vencimiento y se pasa el vencimiento origen
    --     se pasará el vencimiento con fecha mayor. 
    -- -----------------------------------------------------------------------------------------------------

    IF ((pParamPasarRegularidad = '1' AND _origen_ok) OR pParamPasarRegularidad = '2') AND
       cur_destino.condicion = _GE_ALCANCE_TOTAL AND
       NOT _act_destino_esta_aprobada AND
       NOT _act_destino_esta_regularizada THEN
       
       _hay_equiv_regularidad_para_pasar := false;
       _cant_notas_promedio := 0;
       _fecha_vigencia_aux  := NULL;
       _fecha_vigencia      := NULL;
       

       -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       -- Recorro las actividades del origen para pasar REGULARIDADES en forma automática
       -- Recupera la ultima regularidad aprobada vigente de cada actividad del origen.
       -- Solo considera actividades del origen donde la condiciones es A-Aprobada o 2-Aprobada y Regularizada
       -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       FOR cur_origen IN 
           SELECT condicion, elemento, tiene_vencimiento, nota
             FROM sga_equiv_actividades 
            WHERE grupo_equivalencia = pGrupoEquivalencia 
              AND origen_destino = _ORIGEN
              AND condicion IN ('A','2')
       LOOP

         -- Limpio variables
         _fecha_vigencia_origen := NULL;
         _escala_nota_origen    := NULL;
        
         -- Recupero la ultima regularidad vigente aprobada de la materia origen del grupo de equivalencias.
         SELECT propuesta2, fecha, fecha_vigencia, escala_nota, nota, resultado 
           INTO _EQUIV_INT.propuesta, _EQUIV_INT.fecha, _fecha_vigencia_origen, _escala_nota_origen, _EQUIV_INT.nota, _EQUIV_INT.resultado
           FROM _TempReg 
          WHERE elemento   = cur_origen.elemento 
            AND resultado  = _APROBADO
            AND es_vigente = 1
          ORDER BY fecha DESC
          LIMIT 1;
         
         -- Si encontró una regularidad aprobada y vigente, entonces la pasa
         IF FOUND THEN
            IF NOT _hay_equiv_regularidad_para_pasar THEN
              -- Es la primera vez que pasa por aca. Para relacionar las equivalencias origen internas con la equivalencia a otorgar.
              ID_RETORNO := ID_RETORNO + 1;
            END IF;
            
            _hay_equiv_regularidad_para_pasar := true;
           
            -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            -- FIN DE VIGENCIA: Verifico si otorga la fecha de fin de vigencia original o se calcula una nueva
            -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            IF pParamRegistrarVencOriginal = 'S' THEN
              _fecha_vigencia_aux := _fecha_vigencia_origen;
            ELSE
              _fecha_vigencia_aux := f_fin_vigencia_equivalencia (pAlumno, _INSTANCIA_REGULARIDAD, _fecha_equiv);
            END IF;
            
            -- Asigno como fecha de fin de vigencia la mayor fecha de vigencia de las n-regularidades origen...
            IF _fecha_vigencia IS NULL OR (_fecha_vigencia IS NOT NULL AND _fecha_vigencia < _fecha_vigencia_aux) THEN
              _fecha_vigencia := _fecha_vigencia_aux;
            END IF;
         
            -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            -- NOTA: Se calcula la nota de la equivalencia de regularidad solo si las 
            -- regularidades se pasan con nota segun lo definido en el parámetro equiv_automatica_pasar_regularidades_con_nota
            -- (_GRUPOEQUIV.traslada_nota = 'N' OR (_GRUPOEQUIV.traslada_nota = 'S' AND cur_origen.nota = 'S')) AND
            -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
            IF pParamPasarRegularidadConNota = 'S' AND _escala_nota_origen IS NOT NULL AND _EQUIV_INT.nota IS NOT NULL THEN 
               _cant_notas_promedio := _cant_notas_promedio + 1;
               _equiv_escala_nota_origen[_cant_notas_promedio] := _escala_nota_origen;
               _equiv_nota_origen[_cant_notas_promedio]        := _EQUIV_INT.nota;
            END IF;
            
            -- Registra la regularidad origen que da pie a la unica equivalencia de regularidad a otorgar               
            INSERT INTO _EquivInt (id, propuesta, elemento, fecha, nota, resultado, origen)
                 VALUES (ID_RETORNO, _EQUIV_INT.propuesta, cur_origen.elemento, _EQUIV_INT.fecha, _EQUIV_INT.nota, _EQUIV_INT.resultado, _EQUIV_INT_ORIGEN_CURSADA);
                 
         END IF; -- Encontró una regularidad vigente aprobada de las actividades origen
      
      END LOOP; -- Actividades del Origen del Grupo de Equivalencias -- REGULARIDADES automática
    
      -- Registra una sola regularidad para la materia destino del grupo de equivalencias.
      IF _hay_equiv_regularidad_para_pasar THEN

         _escala_nota := NULL;  
         _nota        := NULL;
    
         -- Se calcula la nota promedio de la equivalencias de regularidad a otorgar.
         -- Solo si las regularidades se pasan con nota (parámetro del sistema) y si el arreglo de notas tiene alguna nota.
         IF pParamPasarRegularidadConNota = 'S' AND array_length(_equiv_escala_nota_origen, 1) > 0 THEN 
            -- Calcula la nota y escala de notas a otorgar en la equivalencia de regularidad automática
            _escala_nota := get_escala_nota (pPlanVersion, cur_destino.elemento, 'EQUIVALENCIA_REGULARIDAD');  
            _nota        := get_equiv_nota (_equiv_escala_nota_origen, _equiv_nota_origen, _APROBADO, _escala_nota, _mismo_resultado_nota_origen, _ajustar_nota);
         END IF;
      
         -- Registra la equivalencia de regularidad de la materia destino
         INSERT INTO _Equiv (id, elemento, instancia, fecha, fecha_vigencia, escala_nota, nota, resultado, temas_a_rendir, grupo_equivalencia, matriz)
              VALUES (ID_RETORNO, cur_destino.elemento, _INSTANCIA_REGULARIDAD, _fecha_equiv, _fecha_vigencia, _escala_nota, _nota, _APROBADO, NULL, pGrupoEquivalencia, _GRUPOEQUIV.matriz);
      
      END IF; -- _hay_equiv_regularidad_para_pasar = true
    
    END IF; -- Pasaje de regularidades
    -- ************************** FIN Pasar la regularidad automatica de las actividades del grupo origen *****************************

 END LOOP; -- Actividades Destino del Grupo de Equivalencias

 -- Cantidad de equivalencias otorgadas  
 RETURN ID_RETORNO;
 
END;
$$;
