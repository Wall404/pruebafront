CREATE VIEW vw_mesas_examen AS SELECT COALESCE(periodo_turno.anio_academico, (sga_mesas_examen.anio_academico)::numeric) AS anio_academico,
    sga_turnos_examen.turno_examen,
    periodo_turno.periodo AS turno_examen_periodo,
    periodo_turno.nombre AS turno_examen_nombre,
    periodo_turno.fecha_inicio AS turno_examen_fecha_inicio,
    periodo_turno.fecha_fin AS turno_examen_fecha_fin,
    sga_turnos_examen.fecha_publicacion_mesas AS turno_examen_fecha_publicacion_mesas,
    sga_turnos_examen.fecha_inactivacion AS turno_examen_fecha_inactivacion,
    sga_turnos_examen.fecha_citacion_docentes AS turno_examen_fecha_citacion_docentes,
    sga_llamados_turno.llamado,
    periodo_llamado.periodo AS llamado_periodo,
    periodo_llamado.nombre AS llamado_nombre,
    periodo_llamado.fecha_inicio AS llamado_fecha_inicio,
    periodo_llamado.fecha_fin AS llamado_fecha_fin,
    sga_llamados_mesa.llamado_mesa,
    sga_llamados_mesa.entidad AS llamado_mesa_entidad,
    sga_llamados_mesa.estado AS llamado_mesa_estado,
    sga_llamados_mesa.motivo AS llamado_mesa_motivo,
    sga_llamados_mesa.fecha AS mesa_examen_fecha,
    sga_llamados_mesa.hora_inicio AS mesa_examen_hora_inicio,
    sga_llamados_mesa.hora_finalizacion AS mesa_examen_hora_finalizacion,
    sga_llamados_mesa.espacio AS mesa_examen_espacio,
    sga_mesas_examen.mesa_examen,
    sga_mesas_examen.nombre AS mesa_examen_nombre,
    sga_mesas_examen.elemento AS mesa_examen_elemento,
    sga_mesas_examen.catedra AS mesa_examen_catedra,
    sga_mesas_examen.ubicacion AS mesa_examen_ubicacion,
    sga_mesas_examen.entidad AS mesa_examen_entidad,
    sga_mesas_examen.mesa_en_turno_examen AS mesa_examen_en_turno
   FROM (((((negocio.sga_mesas_examen
     JOIN negocio.sga_llamados_mesa ON ((sga_llamados_mesa.mesa_examen = sga_mesas_examen.mesa_examen)))
     LEFT JOIN negocio.sga_llamados_turno ON ((sga_llamados_turno.llamado = sga_llamados_mesa.llamado)))
     LEFT JOIN negocio.sga_periodos periodo_llamado ON ((periodo_llamado.periodo = sga_llamados_turno.periodo)))
     LEFT JOIN negocio.sga_turnos_examen ON ((sga_turnos_examen.turno_examen = sga_llamados_turno.turno_examen)))
     LEFT JOIN negocio.sga_periodos periodo_turno ON ((periodo_turno.periodo = sga_turnos_examen.periodo)));
