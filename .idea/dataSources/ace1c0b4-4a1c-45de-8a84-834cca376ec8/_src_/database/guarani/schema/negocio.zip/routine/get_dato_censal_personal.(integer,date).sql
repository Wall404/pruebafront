create function negocio.get_dato_censal_personal(ppersona integer, pfecha date) returns integer
LANGUAGE plpgsql
AS $$
DECLARE iDatoCensal Integer;
DECLARE vFecha DATE;
BEGIN
   iDatoCensal := NULL;
   vFecha := COALESCE(pFecha, CURRENT_DATE);
   
   SELECT dato_censal_per INTO iDatoCensal
   	 FROM his_datos_censales, his_datos_personales
	WHERE his_datos_censales.persona = pPersona
	  AND his_datos_personales.dato_censal = his_datos_censales.dato_censal
      AND DATE(his_datos_personales.fecha_alta) <= vFecha
	ORDER BY his_datos_personales.fecha_alta DESC
   LIMIT 1;
   
   IF iDatoCensal IS NULL THEN
     -- Busco el dato censal mas proximo siguiente a la fecha.
     SELECT dato_censal_per INTO iDatoCensal
   	   FROM his_datos_censales, his_datos_personales
	  WHERE his_datos_censales.persona = pPersona
	    AND his_datos_personales.dato_censal = his_datos_censales.dato_censal
        AND DATE(his_datos_personales.fecha_alta) > vFecha
	  ORDER BY his_datos_personales.fecha_alta DESC  
     LIMIT 1;
   END IF;

  -- Retorno el id del Dato Censal personal
  Return iDatoCensal;
	
END;
$$;
