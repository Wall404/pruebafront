create function negocio.ftib_sga_insc_cursada() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   IF NEW.nro_transaccion IS NULL THEN
    -- Si las inscripciones son por prioridad, el nro de transacción ya se generó.
    -- Genera un nro de Transaccion. 
    NEW.nro_transaccion := f_nro_transaccion();
   END IF; 
   
   RETURN NEW;
  END;
$$;
