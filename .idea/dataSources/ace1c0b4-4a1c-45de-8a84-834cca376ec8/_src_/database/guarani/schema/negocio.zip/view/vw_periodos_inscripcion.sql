CREATE VIEW vw_periodos_inscripcion AS SELECT sga_periodos_inscripcion_fechas.periodo_insc,
    sga_periodos_inscripcion_fechas.tipo,
    sga_periodos_inscripcion_fechas.tipo_fin,
    sga_periodos_inscripcion_fechas.tipo_tope_bajas,
    sga_periodos_inscripcion_fechas.fecha_inicio,
    to_char(sga_periodos_inscripcion_fechas.fecha_inicio, 'DD/MM/YYYY'::text) AS sfecha_inicio,
        CASE sga_periodos_inscripcion.periodo_generico_tipo
            WHEN 3 THEN
            CASE sga_periodos_inscripcion_fechas.tipo_fin
                WHEN 1 THEN to_char(sga_periodos_inscripcion_fechas.fecha_fin, 'DD/MM/YYYY'::text)
                WHEN 2 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.dias_previos_fin)::text) || ' dias antes del examen'::text)
                WHEN 3 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.dias_previos_fin)::text) || ' dias hábiles antes del examen'::text)
                WHEN 4 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.hs_previas_fin)::text) || ' hs antes del examen'::text)
                WHEN 5 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.hs_previas_fin)::text) || ' hs hábiles antes del examen'::text)
                ELSE NULL::text
            END
            ELSE to_char(sga_periodos_inscripcion_fechas.fecha_fin, 'DD/MM/YYYY'::text)
        END AS sfecha_fin,
    sga_periodos_inscripcion_fechas.fecha_fin,
    sga_periodos_inscripcion_fechas.dias_previos_fin,
    sga_periodos_inscripcion_fechas.hs_previas_fin,
        CASE sga_periodos_inscripcion.periodo_generico_tipo
            WHEN 3 THEN
            CASE sga_periodos_inscripcion_fechas.tipo_tope_bajas
                WHEN 1 THEN to_char(sga_periodos_inscripcion_fechas.fecha_tope_bajas, 'DD/MM/YYYY'::text)
                WHEN 2 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.dias_previos_tope_bajas)::text) || ' dias antes del examen'::text)
                WHEN 3 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.dias_previos_tope_bajas)::text) || ' dias hábiles antes del examen'::text)
                WHEN 4 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.hs_previas_tope_bajas)::text) || ' hs antes del examen'::text)
                WHEN 5 THEN (('Hasta '::text || (sga_periodos_inscripcion_fechas.hs_previas_tope_bajas)::text) || ' hs hábiles antes del examen'::text)
                ELSE NULL::text
            END
            ELSE to_char(sga_periodos_inscripcion_fechas.fecha_tope_bajas, 'DD/MM/YYYY'::text)
        END AS sfecha_tope_bajas,
    sga_periodos_inscripcion_fechas.fecha_tope_bajas,
    sga_periodos_inscripcion_fechas.dias_previos_tope_bajas,
    sga_periodos_inscripcion_fechas.hs_previas_tope_bajas,
    sga_periodos_inscripcion_fechas.habilitado,
    sga_periodos_inscripcion_fechas.habilitado_interfaz,
    sga_periodos_inscripcion.periodo_inscripcion,
    sga_periodos_inscripcion.nombre,
    sga_periodos_inscripcion.descripcion,
    sga_periodos_inscripcion.periodo,
    sga_periodos_inscripcion.periodo_generico_tipo
   FROM negocio.sga_periodos_inscripcion_fechas,
    negocio.sga_periodos_inscripcion
  WHERE (sga_periodos_inscripcion_fechas.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion);
