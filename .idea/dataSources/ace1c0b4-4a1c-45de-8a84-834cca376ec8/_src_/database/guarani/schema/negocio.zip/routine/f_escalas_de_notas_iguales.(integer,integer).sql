create function negocio.f_escalas_de_notas_iguales(_escala1 integer, _escala2 integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _cnt_notas1 smallint;
 DECLARE _cnt_notas2 smallint;
 DECLARE _rec_notas  record;
 
BEGIN
  IF _escala1 IS NULL OR _escala2 IS NULL THEN
    Return 0;
  END IF;
  IF _escala1 = _escala2 THEN
    -- Iguales ecalas de notas
    Return 1;	
  END IF;
  
  -- Recupero la cantidad de notas de cada escala de notas.
  SELECT COUNT(*) INTO _cnt_notas1
    FROM sga_escalas_notas_det
    WHERE escala_nota = _escala1;
  SELECT COUNT(*) INTO _cnt_notas2
    FROM sga_escalas_notas_det
    WHERE escala_nota = _escala2;
  
  -- Diferente cantidad de notas.  
  IF _cnt_notas1 <> _cnt_notas2 THEN
    RETURN 0;
  END IF;
  
  -- Igual cantidad de notas, verifico que sean las mismas.
  FOR _rec_notas IN
   (SELECT a.nota FROM sga_escalas_notas_det as a WHERE a.escala_nota = _escala1
     UNION
     SELECT b.nota FROM sga_escalas_notas_det as b WHERE b.escala_nota = _escala2)
   EXCEPT
   (SELECT a.nota FROM sga_escalas_notas_det as a WHERE a.escala_nota = _escala1
     INTERSECT
     SELECT b.nota FROM sga_escalas_notas_det as b WHERE b.escala_nota = _escala2)
  LOOP
    -- No son iguales. Si retorna registros la consulta, es porque encontro notas que no estan en la otra escala de notas.
    RETURN 0;
  END LOOP;   
     
  -- Escalas de notas iguales!
  RETURN 1;
  
END;
$$;
