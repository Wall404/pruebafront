create function negocio.f_buscar_alumnos_mesa_examen(pllamadomesa integer, palumnospagina integer, pordenacta integer, palumno character varying) returns SETOF negocio.type_buscar_alumnos_mesa_examen
LANGUAGE plpgsql
AS $$
DECLARE 
	_pagina integer;
	_renglon integer;
	_evaluacion integer;
	cur record;
	cur_retorno type_buscar_alumnos_mesa_examen;
	_sql text;
	_order_by text;
	
BEGIN
   
   -- Recupero el id de la evaluacion
   SELECT sga_evaluaciones.evaluacion 
     INTO _evaluacion
 	 FROM sga_llamados_mesa,
		  sga_evaluaciones,
		  sga_evaluaciones_tipos
	WHERE sga_evaluaciones.entidad = sga_llamados_mesa.entidad
	  AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
	  AND sga_evaluaciones_tipos.automatica = 'S'
	  AND sga_evaluaciones_tipos.aplica_a = 'M'
	  AND sga_llamados_mesa.llamado_mesa = pLlamadoMesa;
   IF NOT FOUND THEN
     -- Salgo
     Return;
   END IF;
   
  -- Orden de los alumnos en la mesa.
  IF pOrdenActa = 1 THEN
     _order_by := ' ORDER BY sga_alumnos.legajo ';
  ELSEIF pOrdenActa = 2 THEN
     _order_by := ' ORDER BY vw_personas.apellido, vw_personas.nombres ';
  ELSEIF pOrdenActa = 3 THEN
     _order_by := ' ORDER BY vw_personas.nro_documento ';
  END IF;

  -- Armo la query con el order by
  _sql :=  'SELECT '
        || '       sga_alumnos.alumno as alumno, '
        || '       vw_personas.apellido as apellido, '
        || '       vw_personas.nombres as nombres '
        || ' FROM sga_eval_detalle_examenes,'
        || '      sga_alumnos, '
        || '      vw_personas '
        || ' WHERE sga_eval_detalle_examenes.evaluacion = ' || cast(_evaluacion as text)
        || '   AND sga_alumnos.alumno  = sga_eval_detalle_examenes.alumno '
        || '   AND vw_personas.persona = sga_alumnos.persona '
        || _order_by;
   
	_pagina := 1;
	_renglon := 1;
    FOR cur IN EXECUTE _sql
	LOOP
		IF _renglon > pAlumnosPagina THEN
			_renglon := 1;
			_pagina := _pagina + 1;
		END IF;
		IF cur.apellido ILIKE '%' || pAlumno || '%' THEN
			cur_retorno.alumno   := cur.alumno;
			cur_retorno.apellido := cur.apellido;
			cur_retorno.nombres  := cur.nombres;
			cur_retorno.pagina   := _pagina;
			RETURN NEXT cur_retorno;
		END IF;
		_renglon := _renglon + 1;
	END LOOP;
END;
$$;
