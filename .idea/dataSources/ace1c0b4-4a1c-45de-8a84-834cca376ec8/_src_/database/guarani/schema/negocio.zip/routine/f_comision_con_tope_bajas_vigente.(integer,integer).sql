create function negocio.f_comision_con_tope_bajas_vigente(integer, integer) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE 

id_plan_version ALIAS for $1;
id_comision ALIAS for $2;
fecha RECORD;

BEGIN
    
  FOR fecha IN (
    SELECT COALESCE(sga_comisiones_excep_perinsc.fecha_tope_bajas, sga_periodos_inscripcion_fechas.fecha_tope_bajas) as fecha_tope_bajas
      FROM sga_comisiones,
           sga_periodos_lectivos,
           sga_periodos_inscripcion,
           sga_periodos_inscripcion_aplanado,
           sga_periodos_inscripcion_fechas
             LEFT JOIN sga_comisiones_excep_perinsc ON (sga_comisiones_excep_perinsc.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc 
              											AND sga_comisiones_excep_perinsc.comision = id_comision)                                              
     WHERE sga_comisiones.comision = id_comision 
       AND sga_comisiones.inscripcion_habilitada = 'S'				
	   AND sga_periodos_inscripcion_fechas.habilitado = 'S'
       AND sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo 
	   AND sga_periodos_inscripcion.periodo = sga_periodos_lectivos.periodo 
	   AND sga_periodos_inscripcion_fechas.periodo_inscripcion = sga_periodos_inscripcion.periodo_inscripcion  
	   AND sga_periodos_inscripcion_aplanado.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc 
	   AND sga_periodos_inscripcion_aplanado.plan_version = id_plan_version
              ) LOOP
           
            IF (CURRENT_TIMESTAMP <= fecha.fecha_tope_bajas) THEN 
                RETURN TRUE;
            END IF;    

  END LOOP;
         
  RETURN FALSE;
END
$$;
