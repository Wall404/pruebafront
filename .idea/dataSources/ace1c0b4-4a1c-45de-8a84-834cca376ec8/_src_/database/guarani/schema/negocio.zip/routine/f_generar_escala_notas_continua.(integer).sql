create function negocio.f_generar_escala_notas_continua(pescalanotas integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
   _nota_inicial numeric;
   _nota_final numeric;
   _i numeric;
   _ii numeric;
   _k integer;
   _nota integer;
   _nota_int integer;
   _cant_notas integer;
   _decimales 	integer;
   _separador 	character;
   _nota_txt	text; -- character varying;
   _nota_num	numeric;
   _nota_desc	varchar(100);
   _resultado_id	character;
   _resultado_fin	numeric;
   _concepto_id	integer;
   _concepto_fin	numeric;
   _orden integer;
BEGIN

_resultado_fin := NULL;
_concepto_fin := NULL;

SELECT nota_inicial, nota_final, cantidad_decimales, separador_decimal
  INTO _nota_inicial, _nota_final, _decimales, _separador
FROM sga_escalas_notas
WHERE escala_nota = pEscalaNotas;

-- Calculo la cantidad de notas a generar
_cant_notas := ((_nota_final * 10^_decimales) - (_nota_inicial * 10^_decimales))::integer ;

_k := 0;
_orden := 1;
_nota := (_nota_inicial * 10^_decimales)::integer;

WHILE _k <= _cant_notas
LOOP
    
  -- Se determinan los decimales
  IF (_decimales > 0) THEN
    _nota_num := _nota / (10^_decimales);
    _nota_int := trunc(_nota_num, 0);
    _nota_txt := _nota_int::text || _separador || lpad(substring(_nota::text from (length(_nota::text) - _decimales + 1) for _decimales), _decimales, '0');
  ELSE
    _nota_num := _nota;
    _nota_txt := _nota_num::text;
  END IF;
    
    -- Se determina la descripción en mayúscula
    _nota_desc := f_numero_a_texto(_nota_num, 1);
    
    -- Se determina el resultado
    IF (_resultado_fin IS NULL OR _nota_num > _resultado_fin) THEN
       SELECT COALESCE(resultado, NULL), COALESCE(nota_final, NULL)
         INTO _resultado_id, _resultado_fin
       FROM sga_escalas_notas_rangos_resultados
       WHERE escala_nota = pEscalaNotas
       AND _nota_num BETWEEN nota_inicial AND nota_final;
    END IF;
    
    -- Se determina el concepto
    IF (_concepto_fin IS NULL OR _nota_num > _concepto_fin) THEN
       SELECT COALESCE(concepto, NULL), COALESCE(nota_final, NULL)
         INTO _concepto_id, _concepto_fin
         FROM sga_escalas_notas_rangos_conceptos
        WHERE escala_nota = pEscalaNotas
          AND _nota_num BETWEEN nota_inicial AND nota_final;
    END IF;
    
    INSERT INTO sga_escalas_notas_det (escala_nota, nota, descripcion, resultado, concepto,  valor_numerico, orden)
         VALUES (pEscalaNotas, _nota_txt, _nota_desc, _resultado_id, _concepto_id, _nota_num, _orden);
    
  -- incremento el contador
  _nota := _nota + 1;
  _k := _k + 1;
  _orden := _orden + 1;
END LOOP; -- while

-- cantidad de notas generadas
RETURN _k;
END;
$$;
