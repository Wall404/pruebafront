CREATE VIEW vw_actividades_genericas_plan AS SELECT sga_propuestas.propuesta,
    sga_planes.plan,
    sga_planes_versiones.plan_version,
    sga_elementos_plan.elemento_revision,
    sga_elementos.elemento,
    sga_elementos.codigo,
    sga_elementos_plan.nombre,
    sga_elementos_plan.nombre_abreviado,
    sga_elementos.entidad_subtipo,
    sga_g3entidades_subtipos.nombre AS entidad_subtipo_nombre
   FROM negocio.sga_propuestas,
    negocio.sga_planes,
    negocio.sga_planes_versiones,
    negocio.sga_elementos_plan,
    negocio.sga_elementos_revision,
    negocio.sga_elementos,
    negocio.sga_g3entidades_subtipos
  WHERE ((((((((sga_planes.propuesta = sga_propuestas.propuesta) AND (sga_planes_versiones.plan = sga_planes.plan)) AND (sga_elementos_plan.plan_version = sga_planes_versiones.plan_version)) AND (sga_elementos_revision.elemento_revision = sga_elementos_plan.elemento_revision)) AND (sga_elementos.elemento = sga_elementos_revision.elemento)) AND (sga_g3entidades_subtipos.entidad_subtipo = sga_elementos.entidad_subtipo)) AND (sga_g3entidades_subtipos.entidad_tipo = 1)) AND (sga_g3entidades_subtipos.entidad_subtipo = 2));
