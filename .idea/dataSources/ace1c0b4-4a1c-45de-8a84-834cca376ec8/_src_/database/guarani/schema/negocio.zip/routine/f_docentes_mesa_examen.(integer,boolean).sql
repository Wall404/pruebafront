create function negocio.f_docentes_mesa_examen(pllamadomesa integer, pmostrarrol boolean DEFAULT false) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _docentes  text;
  cur1 record;

  BEGIN
   cnt := 0;
   _docentes := NULL;

  -- Recupero el nombre de los docentes
  FOR cur1 IN SELECT mdp_personas.apellido as apellido, 
                     mdp_personas.nombres as nombre,
                     sga_tribunal_roles.nombre as rol_nombre 
                FROM sga_docentes_mesa_llamado,
                     sga_tribunal_roles, 
                     sga_docentes, 
                     mdp_personas
               WHERE sga_docentes_mesa_llamado.llamado_mesa = pLlamadoMesa
                 AND sga_docentes.docente = sga_docentes_mesa_llamado.docente
                 AND mdp_personas.persona = sga_docentes.persona
                 AND sga_tribunal_roles.rol = sga_docentes_mesa_llamado.rol
            ORDER BY mdp_personas.apellido,
                     mdp_personas.nombres
  LOOP
      IF cnt = 0 THEN
         _docentes :=  cur1.apellido || ' ' || cur1.nombre;
      ELSE
         _docentes :=  _docentes || ', ' || cur1.apellido || ' ' || cur1.nombre;
      END IF;   

      IF pMostrarRol THEN
         _docentes :=  _docentes || ' (' || cur1.rol_nombre || ')';
      END IF;
      cnt := cnt + 1;
	  
  END LOOP;

  RETURN _docentes;
    
END;
$$;
