create function negocio.ftua_sga_insc_cursada() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _evaluacion integer;
  DECLARE _escala_nota_cursada integer;
  DECLARE _escala_nota_promocion integer;
  DECLARE _cursada smallint;
  DECLARE _promocion smallint;
  DECLARE existe_detalle char(1);
  DECLARE _instancia_cursada smallint;
  DECLARE _instancia_promocion smallint;
  DECLARE _rtn_encuestas smallint;
  BEGIN
    -- Si acepto la inscripción
    IF (NEW.estado = 'A' AND OLD.estado = 'P') OR (NEW.estado = 'P' AND OLD.estado = 'A') THEN
      -- Actualizo encuestas
      _rtn_encuestas := f_encuestas_sync_alumno (NEW.alumno, NEW.comision, 'CE', OLD.estado, NEW.estado);
    END IF;
      
    IF (NEW.estado = 'A' AND OLD.estado = 'P') THEN
    
      -- Recupero la evaluacion automática de la comision
      SELECT sga_evaluaciones.evaluacion
        INTO _evaluacion
      FROM sga_comisiones, 
           sga_evaluaciones,
           sga_evaluaciones_tipos
      WHERE sga_comisiones.comision      = NEW.comision
        AND sga_evaluaciones.entidad     = sga_comisiones.entidad
        AND sga_evaluaciones_tipos.evaluacion_tipo = sga_evaluaciones.evaluacion_tipo
        AND sga_evaluaciones_tipos.automatica = 'S'; -- Generación Automática
          
        IF _evaluacion IS NOT NULL THEN
          
          -- me fijo porque puede haberse agregado el alumno sin tener la inscripcion.
          SELECT instancia_cursada, instancia_promocion INTO _cursada, _promocion
             FROM sga_eval_detalle_cursadas
             WHERE sga_eval_detalle_cursadas.evaluacion = _evaluacion
               AND sga_eval_detalle_cursadas.alumno = NEW.alumno;
          
          IF NOT FOUND THEN
            existe_detalle := 'N';
          ELSE
            existe_detalle := 'S';
          END IF;     
          
          -- Instancia: Cursada 		  
          SELECT 	sga_comisiones_instancias.escala_nota 
		  INTO 		_escala_nota_cursada
		  FROM 		sga_insc_cursada_instancias,
					sga_comisiones_instancias
		  WHERE 	sga_insc_cursada_instancias.instancia = 1
					AND sga_insc_cursada_instancias.inscripcion = NEW.inscripcion
					AND sga_insc_cursada_instancias.instancia = sga_comisiones_instancias.instancia
					AND sga_comisiones_instancias.comision = NEW.comision;
		
          
          -- Si existe la instancia de cursada.
          IF NOT FOUND THEN
             _instancia_cursada := 0;
          ELSE
             _instancia_cursada := 1;
          END IF;
		  
          -- Instancia: Promocion
		  SELECT 	sga_comisiones_instancias.escala_nota 
		  INTO 		_escala_nota_promocion
		  FROM 		sga_insc_cursada_instancias,
					sga_comisiones_instancias
		  WHERE 	sga_insc_cursada_instancias.instancia = 2
					AND sga_insc_cursada_instancias.inscripcion = NEW.inscripcion
					AND sga_insc_cursada_instancias.instancia = sga_comisiones_instancias.instancia
					AND sga_comisiones_instancias.comision = NEW.comision;
					
          IF NOT FOUND THEN
             _instancia_promocion := 0;
          ELSE
             _instancia_promocion := 1;
          END IF;
          
		  
          -- Si el alumno no esta en la evaluación automática entonces lo agrego.                 
          IF existe_detalle = 'N' THEN
             INSERT INTO sga_eval_detalle_cursadas (evaluacion, alumno, instancia_cursada, escala_nota_cursada, instancia_promocion, escala_nota_promocion, inscripto, plan_version)         
                VALUES (_evaluacion, NEW.alumno, _instancia_cursada, _escala_nota_cursada, _instancia_promocion, _escala_nota_promocion, 'S', NEW.plan_version);
          END IF;
          
          -- El alumno existe en la evaluacion automática. Verifico si hubo algun cambio en las instancias (Regular/Promocion)
          IF existe_detalle = 'S' AND
             ((_cursada = 0 and _instancia_cursada = 1) OR (_promocion = 0 and _instancia_promocion = 1)) THEN
             UPDATE sga_eval_detalle_cursadas
                SET instancia_cursada = _instancia_cursada,
                    escala_nota_cursada = _escala_nota_cursada,
                    instancia_promocion = _instancia_promocion,
                    escala_nota_promocion = _escala_nota_promocion,
                    inscripto = 'S'
             WHERE evaluacion = _evaluacion
               AND alumno = NEW.alumno;
          END IF;
          		
       END IF; -- evaluacion
    END IF;	-- cambio de estado de la inscripcion     
     
    RETURN NEW;
  END;
$$;
