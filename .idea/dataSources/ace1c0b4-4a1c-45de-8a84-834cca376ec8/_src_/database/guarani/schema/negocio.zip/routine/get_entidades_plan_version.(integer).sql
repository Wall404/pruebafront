create function negocio.get_entidades_plan_version(integer) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE
	_plan_version ALIAS FOR $1;
	entidades record;
BEGIN
	FOR entidades IN
		SELECT	sga_planes.entidad
		FROM	sga_planes_versiones,
				sga_planes
		WHERE	sga_planes_versiones.plan = sga_planes.plan AND	
				sga_planes_versiones.plan_version = _plan_version
		UNION
		SELECT	sga_propuestas.entidad
		FROM	sga_planes_versiones,
				sga_planes,
				sga_propuestas
		WHERE	sga_planes_versiones.plan = sga_planes.plan AND
				sga_planes.propuesta = sga_propuestas.propuesta AND
				sga_planes_versiones.plan_version = _plan_version
		UNION        
		SELECT	sga_responsables_academicas.entidad
		FROM	sga_planes_versiones,
				sga_planes,
				sga_propuestas,
				sga_propuestas_ra,
				sga_responsables_academicas
		WHERE	sga_planes_versiones.plan = sga_planes.plan AND
				sga_planes.propuesta = sga_propuestas.propuesta AND
				sga_propuestas.propuesta = sga_propuestas_ra.propuesta AND
				sga_propuestas_ra.responsable_academica = sga_responsables_academicas.responsable_academica AND
				sga_planes_versiones.plan_version = _plan_version
		UNION
		SELECT	sga_instituciones.entidad
		FROM	sga_planes_versiones,
				sga_planes,
				sga_propuestas,
				sga_propuestas_ra,
				sga_responsables_academicas,
				sga_instituciones
		WHERE	sga_planes_versiones.plan = sga_planes.plan AND
				sga_planes.propuesta = sga_propuestas.propuesta AND
				sga_propuestas.propuesta = sga_propuestas_ra.propuesta AND
				sga_propuestas_ra.responsable_academica = sga_responsables_academicas.responsable_academica AND
				sga_responsables_academicas.institucion = sga_instituciones.institucion AND
				sga_planes_versiones.plan_version = _plan_version
	LOOP
		RETURN NEXT entidades.entidad;
	END LOOP;
END;
$$;
