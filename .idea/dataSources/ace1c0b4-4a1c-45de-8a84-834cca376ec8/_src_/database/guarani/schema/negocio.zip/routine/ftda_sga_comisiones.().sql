create function negocio.ftda_sga_comisiones() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- Borro tabla de cupos
   DELETE FROM sga_comisiones_cupo WHERE comision = OLD.comision;

   -- Borro el registro en la tabla de entidades..
   DELETE FROM sga_g3entidades WHERE entidad = OLD.entidad;
   RETURN OLD;
END;
$$;
