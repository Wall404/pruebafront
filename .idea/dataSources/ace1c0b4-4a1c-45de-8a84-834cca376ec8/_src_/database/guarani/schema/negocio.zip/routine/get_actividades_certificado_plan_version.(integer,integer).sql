create function negocio.get_actividades_certificado_plan_version(integer, integer) returns SETOF integer
LANGUAGE plpgsql
AS $$
DECLARE
  _certificado ALIAS for $1;
  _plan_version ALIAS for $2;
  requisitos record;
  actividades record;
BEGIN
  -- Recupero las actividades/modulos definidos en el cumplimiento del certificado en la version de plan de estudios.
  FOR requisitos IN
   SELECT DISTINCT sga_elementos.elemento,
          sga_elementos_revision.elemento_revision,
          sga_g3entidades_subtipos.entidad_tipo
     FROM	sga_certificados,
          sga_condiciones,
          sga_condiciones_grupos,
          sga_condiciones_requisitos,
          sga_g3entidades,
          sga_g3entidades_subtipos,
          sga_elementos,
          sga_elementos_revision,
          sga_elementos_plan
    WHERE sga_certificados.entidad = sga_condiciones.entidad AND
          sga_condiciones.condicion = sga_condiciones_grupos.condicion AND
          sga_condiciones_grupos.grupo_condicion = sga_condiciones_requisitos.grupo_condicion AND
          sga_condiciones_requisitos.entidad = sga_g3entidades.entidad AND
          sga_g3entidades.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo AND
          sga_g3entidades.entidad = sga_elementos.entidad AND
          sga_elementos.elemento = sga_elementos_revision.elemento AND
          sga_elementos_revision.elemento_revision = sga_elementos_plan.elemento_revision AND
          sga_elementos_plan.plan_version = _plan_version AND
          sga_certificados.certificado = _certificado AND
          sga_condiciones.plan_version = _plan_version
   LOOP
     -- Si es un Módulo, recupero las componentes del módulo.
     IF requisitos.entidad_tipo = 1 THEN
        FOR actividades IN
            -- Recupero el contenido del módulo y devuelvo solo las actividades..
            SELECT DISTINCT get_elemento_contenido.elemento
                FROM get_elemento_contenido(requisitos.elemento_revision, _plan_version, FALSE, TRUE),
                     sga_g3entidades_subtipos
                WHERE get_elemento_contenido.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo AND
                      sga_g3entidades_subtipos.entidad_tipo = 2  -- Actividad
            LOOP
              RETURN NEXT actividades.elemento;
            END LOOP;
        ELSE
          -- Es una actividad.
          RETURN NEXT requisitos.elemento;
        END IF;
 END LOOP;
END;
$$;
