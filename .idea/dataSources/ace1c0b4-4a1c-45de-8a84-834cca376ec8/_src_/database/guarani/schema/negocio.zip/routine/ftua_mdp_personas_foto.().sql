create function negocio.ftua_mdp_personas_foto() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
	-- Si cambió la imagen...
	IF OLD.imagen <> NEW.imagen THEN
		-- Se marca la foto como "no sincronizada".
		UPDATE	mdp_personas_foto
		SET		sincronizada = 0
		WHERE	foto_persona = NEW.foto_persona;

		-- Se resetea el ID de imagen de la persona.
		UPDATE	mdp_personas
		SET		id_imagen = NULL
		WHERE	persona = NEW.persona;
	END IF;

	RETURN NEW;
END;
$$;
