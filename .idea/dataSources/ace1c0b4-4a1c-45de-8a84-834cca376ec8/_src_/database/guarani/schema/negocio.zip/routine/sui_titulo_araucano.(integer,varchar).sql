create function negocio.sui_titulo_araucano(p_titulo_araucano integer, p_nombre character varying) returns void
LANGUAGE plpgsql
AS $$
BEGIN

  -- Inserta el titulo araucano
  INSERT INTO int_arau_titulos (titulo_araucano, nombre) 
       VALUES (p_titulo_araucano, p_nombre);
  
  -- Existe el titulo araucano, actualiza el nombre
  EXCEPTION 
     WHEN unique_violation THEN
        UPDATE int_arau_titulos 
		   SET nombre = p_nombre
		 WHERE titulo_araucano = p_titulo_araucano;
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Error Nro: %. %',SQLSTATE, SQLERRM;   

END;
$$;
