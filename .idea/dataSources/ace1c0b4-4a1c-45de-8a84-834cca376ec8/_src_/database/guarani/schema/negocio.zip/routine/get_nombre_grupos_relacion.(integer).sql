create function negocio.get_nombre_grupos_relacion(_relacion integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	cant SMALLINT;
	retorno TEXT;
	cur RECORD;
BEGIN
	cant := 0;
	retorno := NULL;

	-- Recupero el nombre de los grupos.
	FOR cur IN	SELECT	get_nombre_planes_relacion_grupo(sga_propuestas_relacion_grupo.relacion_grupo) as nombre
				FROM	sga_propuestas_relacion_grupo
				WHERE	sga_propuestas_relacion_grupo.relacion = _relacion
	LOOP
		IF cant = 0 THEN		
			retorno := cur.nombre;
		ELSE
			retorno := retorno || ' o ' || cur.nombre;
		END IF;   
		cant := cant + 1;
	END LOOP;

	RETURN retorno;
END;
$$;
