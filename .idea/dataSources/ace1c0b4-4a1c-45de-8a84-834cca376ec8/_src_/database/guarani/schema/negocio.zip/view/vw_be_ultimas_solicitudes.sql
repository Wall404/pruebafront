CREATE VIEW vw_be_ultimas_solicitudes AS SELECT sol1.id,
    sol1.hash,
    sol1.url_formulario_sube,
    sol1.persona,
    sol1.fecha_solicitud,
    sol1.condicion,
    sol1.observaciones,
    sol1.respuesta,
    sol1.respuesta_fecha,
    sol1.respuesta_desc,
    sol1.operacion,
    sol1.procesado
   FROM negocio.mbe_solicitudes sol1
  WHERE (sol1.fecha_solicitud = ( SELECT max(sol2.fecha_solicitud) AS max
           FROM negocio.mbe_solicitudes sol2
          WHERE (sol1.persona = sol2.persona)));
