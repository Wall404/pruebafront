CREATE VIEW vw_actas AS SELECT sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.nro_acta,
    sga_actas.tipo_acta,
    sga_actas.origen,
    sga_actas.evaluacion,
    sga_actas.comision,
    sga_actas.llamado_mesa,
    sga_actas_detalle.alumno,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
    sga_actas_detalle.folio,
    sga_actas_detalle.renglon,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_actas_detalle.cond_regularidad,
    sga_actas_detalle.estado,
    sga_actas_detalle.pct_asistencia,
    sga_actas_detalle.observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_instancias_resultado.descripcion AS resultado_descripcion
   FROM (((negocio.sga_actas
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.id_acta = sga_actas.id_acta)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_escalas_notas_det.escala_nota = sga_actas_detalle.escala_nota) AND ((sga_escalas_notas_det.nota)::text = (sga_actas_detalle.nota)::text))))
     JOIN negocio.sga_instancias_resultado ON (((sga_instancias_resultado.instancia = sga_actas_detalle.instancia) AND (sga_instancias_resultado.resultado = sga_actas_detalle.resultado))))
  WHERE ((sga_actas.estado = 'C'::bpchar) AND (sga_actas_detalle.rectificado = 'N'::bpchar));
