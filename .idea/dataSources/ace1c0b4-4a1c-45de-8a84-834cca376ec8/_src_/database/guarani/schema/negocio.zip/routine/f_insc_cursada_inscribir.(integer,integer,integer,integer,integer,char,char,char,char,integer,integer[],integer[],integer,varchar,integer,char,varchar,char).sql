create function negocio.f_insc_cursada_inscribir(pcomision integer, palumno integer, ppersona integer, pplanversionalumno integer, pprioridad integer, pestadoinscripcion character, ptipoinscripcion character, pestadopreinscripcion character, pfueradetermino character, pnrotransaccion integer, pinstancias integer[], psubcomisiones integer[], pinterfaz integer, pautorizado_por character varying, pperiodolectivo integer, pcontrolarcupo character, pcontrolarcupopor character varying, pparamestadopendiente character) returns negocio.type_retorno_inscripcion
LANGUAGE plpgsql
AS $fun$
DECLARE 
  cur_retorno	type_retorno_inscripcion;
  _inscripcion	Integer;
  _persona Integer;
  _cnt Smallint;
  i Smallint;
  n Smallint;
  _cupo Integer;
  _actividad Integer;
  _cant_inscriptos Integer;
  _con_subcomisiones boolean;
  _PlanVersionAlumno integer;
  _SubcomNombre Varchar(100);
  _ComisionNombre Varchar(100);
  _PerLectNombre  Varchar(100);
  _fecha_inscripcion Timestamp;
  _nro_transaccion Integer;
  _estado_desc Varchar(30);
  _estado_inscripcion char(1);
  _fecha_actual Varchar(10);
  _prioridad Integer;
  _error_mensaje text;
  _cant_instancias smallint;
  _existe_instancia boolean;
  _nombre_instancia varchar(50);

BEGIN
  
  -- Variables de retorno
  cur_retorno.resultado := 1;
  cur_retorno.mensaje_indice := '800SIU_insc_cursada_ok';
  cur_retorno.mensaje_param  := NULL;
  
  _cant_instancias := 0;
  _inscripcion := NULL;
  _nro_transaccion := NULL;
  _con_subcomisiones := false;
  _cnt := 0;
  _estado_desc := '';
  _SubcomNombre := '';
  _ComisionNombre := '';
  _estado_inscripcion := pEstadoInscripcion;
  _cupo := 0;
  _cant_inscriptos := 0;
  _nombre_instancia := '';

  -- Recupero el id de la persona si no viene.
  IF pPersona IS NULL THEN
    SELECT persona INTO _persona FROM sga_alumnos WHERE alumno = pAlumno;
  ELSE
   _persona := pPersona;
  END IF;

  -- Controlo que al menos exista una instancia en la que se va a inscribir.
  IF pInstancias IS NULL THEN
    cur_retorno.resultado      := -1;
    cur_retorno.mensaje_indice := '800SIU_insc_cursada_sin_instancias';
    cur_retorno.mensaje_param  := NULL;
    RETURN cur_retorno;
  ELSE
    -- _cant_instancias := array_lenght(pInstancias[]); -- para postgres 8.4 y superior
    _cant_instancias := (select array_upper( pInstancias, 1) - array_lower( pInstancias ,1) + 1);
  END IF;

  -- Obtengo datos de la comision
  SELECT nombre, elemento, cupo
    INTO _ComisionNombre, _actividad, _cupo
    FROM sga_comisiones
   WHERE comision = pComision; 

  -- ****************************************************************************
  -- 1. Verifico que no tenga una inscripción a la comisión por cualquier propuesta
  -- ****************************************************************************
  SELECT Count(*) INTO _cnt 
    FROM sga_alumnos,
         sga_insc_cursada 
    WHERE sga_insc_cursada.comision = pComision 
      AND sga_alumnos.persona = _persona
      AND sga_insc_cursada.alumno = sga_alumnos.alumno;
  IF _cnt > 0 THEN
    cur_retorno.resultado      := -1;
    cur_retorno.mensaje_indice := '800SIU_insc_cursada_existe_insc';
    cur_retorno.mensaje_param  := _ComisionNombre;
    
    RETURN cur_retorno;
  END IF;

  -- Recupero la versión del plan del alumno si es nula
  IF pPlanVersionAlumno IS NULL THEN
    _fecha_actual := to_char(CURRENT_DATE, 'YYYY-MM-DD');
    _PlanVersionAlumno := get_plan_version_alumno(pAlumno, _fecha_actual);
  ELSE
    _PlanVersionAlumno := pPlanVersionAlumno;
  END IF;


  -- Inscripcion por prioridad.
  IF pPrioridad IS NULL OR pPrioridad <= 0 THEN
    _prioridad := 1;
  ELSE
    _prioridad := pPrioridad;
  END IF;
  
  -- Verifico si tiene subcomisiones
  -- n := array_lenght(pSubcomisiones[]);
  IF pSubcomisiones IS NOT NULL THEN
    n := (select array_upper( pSubcomisiones , 1) - array_lower( pSubcomisiones ,1) + 1);
    IF n > 0 THEN
      _con_subcomisiones := true;
    END IF;
  END IF;
  
-- Comienzo transacción.
BEGIN

  -- ********************************************************************
  -- Control de Cupo. Se realiza siempre el update de cupo.
  -- Si tiene subcomisiones controla el cupo en cada subcomision a la que se inscribe.
  -- Si no tiene subcomisiones, controla el cupo en la comisión.
  -- ********************************************************************

  -- Actualizo siempre el cupo en la comisión. Sea con/sin subcomisiones.
  UPDATE sga_comisiones_cupo  
     SET cant_inscriptos = cant_inscriptos + 1
   WHERE comision = pComision;

  IF _con_subcomisiones THEN
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- Controlo el cupo en las subcomisiones en las que se inscribe el alumno.
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- n := array_lenght(pSubcomisiones[]);
      n := (select array_upper( pSubcomisiones , 1) - array_lower( pSubcomisiones ,1) + 1);
      FOR i IN 1 .. n 
      LOOP
        -- Actualizo el cupo en la subcomision solo si hay cupo
        UPDATE sga_subcomisiones_cupo
           SET cant_inscriptos = cant_inscriptos + 1
         WHERE subcomision = pSubcomisiones[i];

        IF pControlarCupo = 'S' AND pPrioridad = 1 THEN
          IF pControlarCupoPor = 'comision' THEN
             -- Controlo solo los inscriptos a la comision
             SELECT cupo, cant_inscriptos INTO _cupo, _cant_inscriptos
               FROM sga_subcomisiones_cupo
              WHERE subcomision = pSubcomisiones[i];
          
          ELSE
             -- Recupero el cupo de la subcomision.
             SELECT cupo INTO _cupo FROM sga_subcomisiones WHERE subcomision = pSubcomisiones[i];
             
             -- Controlo todos los inscriptos a las subcomisiones del mismo aula de la subcomision
             SELECT COALESCE(SUM(sga_subcomisiones_cupo.cant_inscriptos),0) 
               INTO _cant_inscriptos
               FROM sga_subcomisiones_cupo
              WHERE sga_subcomisiones_cupo.subcomision IN ( 
                     SELECT DISTINCT sga_subcomisiones_bh.subcomision
                       FROM sga_comisiones_bh,
                            sga_subcomisiones_bh
                      WHERE sga_subcomisiones_bh.banda_horaria = sga_comisiones_bh.banda_horaria
                        AND sga_comisiones_bh.asignacion IN (
                              SELECT sga_comisiones_bh.asignacion
                                FROM sga_subcomisiones_bh, sga_comisiones_bh 
                               WHERE sga_subcomisiones_bh.subcomision = pSubcomisiones[i]
                                 AND sga_comisiones_bh.banda_horaria = sga_subcomisiones_bh.banda_horaria)
                     );
          END IF;

          IF _cupo IS NOT NULL AND _cupo > 0 AND _cant_inscriptos > _cupo THEN
           
             -- Recupero el nombre de la subcomision
             SELECT nombre INTO _SubcomNombre FROM sga_subcomisiones WHERE subcomision = pSubcomisiones[i];
           
             -- Seteo valores para retorno
             cur_retorno.resultado      := -1;
             cur_retorno.mensaje_indice := '800SIU_insc_cursada_sin_cupo_subcom';
             cur_retorno.mensaje_param  := _SubcomNombre;
             -- cur_retorno.sqlerrm  := SQLERRM;
             -- cur_retorno.sqlstate := SQLSTATE;
           
             -- Retorno con error en el control de cupo de la subcomision
             -- Lo manda al Exception 
             RAISE EXCEPTION 'No hay cupo disponible en la subcomisión %', _SubcomNombre;
          END IF; -- Sin cupo.   
        END IF;   -- pControlarCupo
      END LOOP;   -- subcomisiones
      
    END IF; -- con subcomisiiones
 
    IF NOT _con_subcomisiones THEN
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      -- Controlo el cupo en la comisión. No es con subcomisiones
      -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
      IF pControlarCupo = 'S' AND pPrioridad = 1 THEN
        IF pControlarCupoPor = 'comision' THEN
           -- Controla cupo de la comision
           SELECT cupo, cant_inscriptos INTO _cupo, _cant_inscriptos
             FROM sga_comisiones_cupo
            WHERE comision = pComision;
        ELSE
           -- Controla cupo del aula. Inscriptos en todas las comisiones de este aula/asignación horaria de la misma actividad u otras que compartan aula.
           -- Para el cupo, toma el definido en la comision a la que se inscribe.
           SELECT COALESCE(SUM(sga_comisiones_cupo.cant_inscriptos) ,0)
             INTO _cant_inscriptos
             FROM sga_comisiones_cupo 
            WHERE sga_comisiones_cupo.comision IN (
                    SELECT DISTINCT bh2.comision 
                      FROM sga_comisiones_bh,
                           sga_comisiones_bh as bh2
                     WHERE sga_comisiones_bh.comision = pComision
                       AND bh2.asignacion = sga_comisiones_bh.asignacion
                      );

        END IF;

        IF _cupo IS NOT NULL AND _cupo > 0 AND _cant_inscriptos > _cupo THEN

           -- Seteo valores para retorno
           cur_retorno.resultado      := -1;
           cur_retorno.mensaje_indice := '800SIU_insc_cursada_sin_cupo_com';
           cur_retorno.mensaje_param  := _ComisionNombre;
           -- cur_retorno.sqlerrm  := SQLERRM;
           -- cur_retorno.sqlstate := SQLSTATE;

           -- Lo manda al Exception 
           RAISE EXCEPTION 'No hay cupo disponible en la comisión %', _ComisionNombre;
        END IF;  -- Superó el cupo
      END IF;  -- pControlar Cupo
  END IF; -- _con_subcomisiones
  -- ****************** FIN Control de cupo **************************

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto la inscripcion en la comision
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _fecha_inscripcion := CURRENT_TIMESTAMP;
  IF pNroTransaccion IS NULL THEN
    _nro_transaccion := (SELECT nextval('aud_nro_transaccion_seq')); 
  ELSE
    _nro_transaccion := pNroTransaccion; 
  END IF;

  -- Estado final de la inscripcion.
  IF pParamEstadoPendiente = 'S' THEN
    -- Seteo el estado de la inscripcion como Pendiente
    _estado_inscripcion := 'P';
  END IF;

  -- Inserto la inscripción a cursada.
  INSERT INTO sga_insc_cursada (comision, alumno, plan_version, tipo, prioridad, estado_preinscripcion, estado, fuera_de_termino, interfaz, fecha_inscripcion, nro_transaccion, autorizado_por)
      VALUES (pComision, pAlumno, _PlanVersionAlumno, pTipoInscripcion, _prioridad, pEstadoPreinscripcion, _estado_inscripcion, pFueraDeTermino, pInterfaz, _fecha_inscripcion, _nro_transaccion, pAutorizado_por);

  -- Recupero el Serial de la inscripcion
  _inscripcion := (SELECT currval('sga_insc_cursada_seq'));

  -- Inserto las instancias en las que se inscribe
  FOR i IN 1 .. _cant_instancias 
  LOOP
    INSERT INTO sga_insc_cursada_instancias (inscripcion, instancia) VALUES (_inscripcion, pInstancias[i]);
  END LOOP;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto las inscripciones a subcomisiones
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF _con_subcomisiones THEN
    -- n := array_lenght(pSubcomisiones[]); 
    n := (select array_upper( pSubcomisiones , 1) - array_lower( pSubcomisiones ,1) + 1);
    FOR i IN 1 .. n 
    LOOP
      INSERT INTO sga_insc_subcomision (inscripcion, subcomision) VALUES (_inscripcion, pSubcomisiones[i]);
    END LOOP;
  END IF; -- Subcomisiones.

  -- Error.
  EXCEPTION WHEN OTHERS THEN
      IF cur_retorno.resultado = -1 then
         -- El error viene desde el RAISE EXCEPTION.
         cur_retorno.sqlerrm := SQLERRM;
      ELSE
        -- El error se produjo en los inserts...
        cur_retorno.resultado      := -1;
        cur_retorno.mensaje_indice := '800SIU_insc_cursada_error_db';
        cur_retorno.mensaje_param  := NULL;
        cur_retorno.sqlerrm  := SQLERRM;
        cur_retorno.sqlstate := SQLSTATE;
      END IF; 
      RETURN cur_retorno;

END; -- Fin bloque de actualizacion en la base


  -- Recupero el nombre del estado de la inscripcion
  SELECT nombre INTO _estado_desc FROM sga_inscripciones_estados  WHERE estado = _estado_inscripcion;
  
  -- Seteo valores para retorno
  cur_retorno.resultado      := 1;
  cur_retorno.mensaje_indice := '800SIU_insc_cursada_ok';
  IF pTipoInscripcion = 'I' THEN
    cur_retorno.mensaje_param  := _estado_desc || '$$$' || cast(_nro_transaccion as varchar);
  ELSE
    cur_retorno.mensaje_param  := 'Pendiente (de procesamiento y asignación)' || '$$$' || cast(_nro_transaccion as varchar);
  END IF;
  cur_retorno.inscripcion := _inscripcion;
  cur_retorno.fecha       := _fecha_inscripcion;
  cur_retorno.estado      := _estado_inscripcion;
  cur_retorno.nro_transaccion := _nro_transaccion;
  
  -- Retorno datos de la inscripcion OK.
  RETURN cur_retorno;

END;
$fun$;
