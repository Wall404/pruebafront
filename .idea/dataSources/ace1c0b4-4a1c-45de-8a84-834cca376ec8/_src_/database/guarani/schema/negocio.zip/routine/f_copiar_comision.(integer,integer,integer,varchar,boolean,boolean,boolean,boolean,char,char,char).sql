create function negocio.f_copiar_comision(pcomisionorigen integer, pactividaddestino integer, pperiodolectivodestino integer, pcomisionnombre character varying, pcopiarsubcomisiones boolean, pcopiardocentes boolean, pcopiarbandashorarias boolean, pcopiardivision boolean, pasistenciaporhoras character, pasistenciacantidadinasist character, pcomisionestado character) returns SETOF negocio.type_comision_copiado_generacion
LANGUAGE plpgsql
AS $$
DECLARE 
  comision_nueva  INTEGER;
  _periodo_lectivo_destino Integer;
  _periodo_lectivo_origen Integer;
  _nombre_comision VARCHAR(100); 
  subcomision_origen  INTEGER;
  subcomision_nueva  INTEGER;
  _observaciones  text;
  _division integer;
  _catedra  integer;
  _estado_catedra char(1);
  _nombre_catedra varchar(100);
  _fecha_desde DATE;
  _fecha_hasta DATE;
  _fecha_inicio_dictado DATE;
  _fecha_fin_dictado DATE;
  _insc_habilitada char(1);
  _insc_habilitada_orig char(1);
  _elemento  integer;
  _ubicacion_destino integer;
  _ActividadOrigen Integer;
  _asignacion integer;
  cnt  SMALLINT;
  _actividad   text; 
  cur_subc record;
  cur_docentes record;
  cur_asign record;
  cur_retorno   type_comision_copiado_generacion; -- para retornar datos de la comision creada
        
  BEGIN
  cur_retorno.codigo_retorno := 0; -- OK. COMISION COPIADA
  _observaciones := NULL;
  _insc_habilitada := 'S';

  
  -- Recupero datos de la comision origen.
  SELECT '(' || sga_elementos.codigo || ') ' || sga_elementos.nombre, 
         sga_comisiones.nombre, 
	 sga_comisiones.elemento, 
         sga_comisiones.periodo_lectivo, 
         sga_comisiones.inscripcion_habilitada, 
         sga_comisiones.division, 
         sga_comisiones.ubicacion,
         sga_comisiones.catedra,
         sga_catedras.nombre, 
         sga_catedras.estado
     INTO _actividad, 
          _nombre_comision, 
          _elemento, 
          _periodo_lectivo_origen, 
          _insc_habilitada_orig,
          _division,
          _ubicacion_destino,
          _catedra, _nombre_catedra, _estado_catedra
          
     FROM sga_comisiones
            LEFT JOIN sga_catedras ON sga_catedras.catedra = sga_comisiones.catedra,
        sga_elementos
     WHERE sga_elementos.elemento = sga_comisiones.elemento
     AND sga_comisiones.comision = pComisionOrigen;
     
  IF NOT FOUND THEN	
     -- Salgo.  
    cur_retorno.codigo_retorno := 1; -- Comision no copiada
    cur_retorno.observaciones  := 'La comisión a copiar no existe';
    RETURN NEXT cur_retorno;
    RETURN; -- Salgo
  END IF;

  _ActividadOrigen := _elemento; 
  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Esto es para el caso que se duplica una comision del mismo período lectivo.
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF pComisionNombre IS NOT NULL THEN
    -- Se pasa un nuevo nombre de Comision.
    _nombre_comision := pComisionNombre;
  END IF;

  IF pPeriodoLectivoDestino IS NULL THEN
    -- Se asigna el mismo periodo lectivo que la comision original
    _periodo_lectivo_destino := _periodo_lectivo_origen;
    
    -- Para que copie la fecha desde y hasta de los docentes de la comision origen
    _fecha_inicio_dictado := NULL;
    _fecha_fin_dictado := NULL;
    _insc_habilitada := NULL;
  ELSE
    _periodo_lectivo_destino := pPeriodoLectivoDestino;

  	SELECT	sga_periodos_lectivos.fecha_inicio_dictado,
  			sga_periodos_lectivos.fecha_fin_dictado
  	INTO	_fecha_inicio_dictado,
  			_fecha_fin_dictado
  	FROM	sga_periodos_lectivos
  	WHERE	sga_periodos_lectivos.periodo_lectivo = pPeriodoLectivoDestino;

  	IF NOT FOUND THEN	
		-- Salgo.  
    	cur_retorno.codigo_retorno := 1; -- Comision no copiada
    	cur_retorno.observaciones  := 'El período lectivo destino no existe';
    	RETURN NEXT cur_retorno;
    	RETURN; -- Salgo
  	END IF;
  END IF;
  
  IF pActividadDestino IS NOT NULL THEN
    -- Puede ser que a la actividad donde se generará la comision es otra actividad
    _elemento := pActividadDestino;
  END IF;
  
  -- Verifico que no exista una comision con el mismo nombre para la actividad, periodo lectivo y ubicacion destino.
  SELECT Count(*) INTO cnt
     FROM sga_comisiones
     WHERE elemento        = _elemento
       AND periodo_lectivo = _periodo_lectivo_destino
       AND ubicacion = _ubicacion_destino
       AND nombre = _nombre_comision;
  IF cnt > 0  THEN	
     -- Salgo.  
    cur_retorno.codigo_retorno := 1; -- Comision no copiada
    cur_retorno.observaciones  := 'La comisión ' || _nombre_comision || ' no se copió porque ya existe en el período lectivo y ubicación destino';
    RETURN NEXT cur_retorno;
    RETURN; 
  END IF;

  -- Verifico si la catedra esta activa
  IF _catedra IS NOT NULL AND _estado_catedra <> 'A' THEN
    cur_retorno.codigo_retorno := 1; -- Comision no copiada
    cur_retorno.observaciones  := 'La cátedra ' || _nombre_catedra || ' de la comisión esta dada de baja';
    RETURN NEXT cur_retorno;
    RETURN; 
  END IF;

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Inserto la comision
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  INSERT INTO sga_comisiones (
            nombre, periodo_lectivo, elemento, turno, catedra, ubicacion, letra_desde, letra_hasta, 
            cupo_minimo, cupo, inscripcion_habilitada, division, asistencia_por_horas, asistencia_cantidad_inasist, 
			cobrable, estado, inscripcion_cerrada, inscripcion_cerrada_codigo)
    SELECT _nombre_comision, _periodo_lectivo_destino, _elemento, turno, _catedra, ubicacion, letra_desde, letra_hasta, 
	   cupo_minimo, cupo, COALESCE(_insc_habilitada, _insc_habilitada_orig), 
           CASE WHEN pCopiarDivision THEN _division ELSE cast(NULL as integer) END,
           CASE WHEN pAsistenciaPorHoras IS NOT NULL THEN pAsistenciaPorHoras ELSE asistencia_por_horas END,  
           CASE WHEN pAsistenciaCantidadInasist IS NOT NULL THEN pAsistenciaCantidadInasist ELSE asistencia_cantidad_inasist END,
	   cobrable, 
	   CASE WHEN pComisionEstado IS NOT NULL THEN pComisionEstado ELSE estado END, 
	   inscripcion_cerrada, inscripcion_cerrada_codigo
      FROM sga_comisiones 
     WHERE comision = pComisionOrigen;
      
  -- Recupero el Serial de la comision
  comision_nueva := (SELECT currval('sga_comisiones_seq'));
  
  -- Seteo valores para retorno
  cur_retorno.comision        :=  comision_nueva;
  cur_retorno.nombre_comision :=  _nombre_comision;

  
  -- Modalidad de Cursada.
  INSERT INTO sga_comisiones_modalidad (comision, modalidad)
     SELECT comision_nueva, modalidad
     FROM sga_comisiones_modalidad 
     WHERE comision = pComisionOrigen;
       
  -- Propuestas y Planes de la comision
  IF pActividadDestino IS NULL OR _elemento = pActividadDestino THEN
    IF pPeriodoLectivoDestino = _periodo_lectivo_origen THEN
      -- Esta duplicando una comision de la misma actividad en el mismo periodo lectivo 
      INSERT INTO sga_comisiones_propuestas (comision, propuesta, plan)
           SELECT comision_nueva, propuesta, plan  
             FROM sga_comisiones_propuestas 
            WHERE comision = pComisionOrigen;
    ELSE
      -- Esta copiando comisiones de un período lectivo a otro. Solo asignar planes de estudios activos (vigentes o no vigentes)
      INSERT INTO sga_comisiones_propuestas (comision, propuesta, plan)
           SELECT DISTINCT comision_nueva, cp.propuesta, cp.plan  
             FROM sga_comisiones_propuestas as cp,
                  sga_planes as p,
                  sga_planes_versiones as v 
             WHERE cp.comision = pComisionOrigen
               AND p.plan = cp.plan
               AND v.plan = cp.plan
               AND p.estado IN ('A', 'V')
               AND v.estado IN ('A', 'V');
    END IF;       
  ELSE
    -- La actividad destino no es la misma que la actividad de la comision origen
    -- Inserto propuestas y planes (activos) en los que se encuentra la actividad destino
    INSERT INTO sga_comisiones_propuestas (comision, propuesta, plan)
         SELECT DISTINCT comision_nueva, propuesta, plan  
           FROM vw_actividades_plan as vw,
                sga_planes as p,
                sga_planes_versiones as v 
           WHERE vw.elemento = _elemento
             AND p.plan = vw.plan
             AND v.plan = vw.plan
             AND p.estado IN ('A', 'V')
             AND v.estado IN ('A', 'V');
  END IF;
  
  -- Instancias de la comision
  INSERT INTO sga_comisiones_instancias (comision, instancia, escala_nota, porc_asistencia)
     SELECT comision_nueva, instancia, escala_nota, porc_asistencia
       FROM sga_comisiones_instancias
      WHERE comision = pComisionOrigen;

  -- Docentes de la comision
  IF pCopiarDocentes THEN
    FOR cur_docentes IN SELECT sga_docentes_comision.docente, 
                             sga_docentes_comision.responsabilidad, 
                             sga_docentes_comision.fecha_desde, 
                             sga_docentes_comision.fecha_hasta, 
                             sga_docentes.estado, 
                             '(' || sga_docentes.legajo || ') ' || mdp_personas.apellido || ' ' ||  mdp_personas.nombres as nombre_docente
                         FROM sga_docentes_comision, 
                              sga_docentes,
                              mdp_personas
                         WHERE sga_docentes_comision.comision = pComisionOrigen
                         AND sga_docentes.docente = sga_docentes_comision.docente
                         AND mdp_personas.persona = sga_docentes.persona
   LOOP
     -- Si el docente esta dado de baja, entonces no copio el docente.
     IF cur_docentes.estado <> 'A' THEN
        cur_retorno.codigo_retorno = 2;
        _observaciones := COALESCE(_observaciones || ' - ', '');
        _observaciones := _observaciones || 'El docente ' || cur_docentes.nombre_docente || ' no se copió porque esta dado de baja';
        CONTINUE;
     END IF;
     
     INSERT INTO sga_docentes_comision (comision, docente, responsabilidad, fecha_desde, fecha_hasta)
          VALUES (comision_nueva,
                  cur_docentes.docente, 
                  cur_docentes.responsabilidad, 
                  COALESCE(_fecha_inicio_dictado, cur_docentes.fecha_desde), 
                  COALESCE(_fecha_fin_dictado, cur_docentes.fecha_hasta)
                 );

     -- Docentes - Dedicacion horaria
     INSERT INTO sga_docentes_dedicacion_hs (comision, docente, tipo_dedicacion, cnt_horas)
        SELECT comision_nueva, ddh.docente, ddh.tipo_dedicacion, ddh.cnt_horas
          FROM sga_docentes_dedicacion_hs as ddh
         WHERE ddh.comision = pComisionOrigen
           AND ddh.docente = cur_docentes.docente;
    END LOOP;
  END IF; -- Copiar Docentes

  -- Comparto bandas horarias de la comision origen en la comision destino
  IF pCopiarBandasHorarias THEN 
    -- Recorro todas las asignaciones de la comision origen y copio las bandas horarias con las 
	-- fechas de inicio y fin de dictado de la comision
    FOR cur_asign IN SELECT asignacion, tipo_clase
	                   FROM sga_comisiones_bh as bh 
                      WHERE bh.comision = pComisionOrigen
	LOOP
	   -- Genera una nueva asignacion para la comisión.
	   INSERT INTO sga_asignaciones (
	       dia_semana, fecha_desde, fecha_hasta, periodicidad, hora_inicio, hora_finalizacion, 
	       cantidad_horas, asignacion_tipo, espacio, observaciones)
	   SELECT dia_semana, _fecha_inicio_dictado, _fecha_fin_dictado, periodicidad, hora_inicio, hora_finalizacion, 
	          cantidad_horas, asignacion_tipo, espacio, observaciones
	     FROM sga_asignaciones
	    WHERE asignacion = cur_asign.asignacion;
	   
	   -- Recupero el ID de la asignacion
	   _asignacion := (SELECT currval('sga_asignaciones_seq'));

	   -- Inserto la banda horaria en la comision
	   INSERT INTO sga_comisiones_bh (asignacion, comision, tipo_clase)
            SELECT _asignacion, comision_nueva, tipo_clase
              FROM sga_comisiones_bh
             WHERE comision   = pComisionOrigen
			   AND asignacion = cur_asign.asignacion;
	
    END LOOP;
  END IF;
  -- ++++++++++++++++++++++ Fin asignaciones y bandas horarias ++++++++++++++++++++++++++++++++

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- SUBCOMISIONES
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  IF pCopiarSubcomisiones OR pCopiarSubcomisiones IS NULL THEN

     -- Recupero los elementos del Plan (modulos y actividades)
     FOR cur_subc IN SELECT subcomision, tipo_clase, nombre, letra_desde, letra_hasta, cupo
                       FROM sga_subcomisiones
                      WHERE comision = pComisionOrigen
     LOOP
          -- Genero la Subcomision
          INSERT INTO sga_subcomisiones (comision, tipo_clase, nombre, letra_desde, letra_hasta, cupo, inscripcion_habilitada)
             VALUES (comision_nueva, cur_subc.tipo_clase, cur_subc.nombre, cur_subc.letra_desde, cur_subc.letra_hasta, cur_subc.cupo, 'S'); 
          
          -- Recupero el Serial de la subcomision
          subcomision_nueva := (SELECT currval('sga_subcomisiones_seq'));
       
          -- Docentes de la subcomision. Solo docentes Activos.
          IF pCopiarDocentes THEN 
            INSERT INTO sga_docentes_subcomision (subcomision, docente, fecha_desde, fecha_hasta)
             SELECT subcomision_nueva, sga_docentes_subcomision.docente, _fecha_desde, _fecha_hasta
               FROM sga_docentes_subcomision, sga_docentes
                WHERE sga_docentes_subcomision.subcomision = cur_subc.subcomision
                  AND sga_docentes.docente = sga_docentes_subcomision.docente
                  AND sga_docentes.estado  = 'A';
          END IF;
          
          -- Comparto bandas horarias con la subcomisiones origen
          IF pCopiarBandasHorarias THEN 
            INSERT INTO sga_subcomisiones_bh (subcomision, banda_horaria)
                 SELECT subcomision_nueva, banda_horaria FROM sga_subcomisiones_bh WHERE subcomision = cur_subc.subcomision;
          END IF;
     END LOOP;
  END IF; -- Subcomisiones
   
  -- Excepciones a períodos de inscripcion: Solo cuando es el mismo período lectivo y copia de comisiones de una actividad a otra
  IF _ActividadOrigen <> pActividadDestino AND _periodo_lectivo_origen = _periodo_lectivo_destino THEN
    INSERT INTO sga_comisiones_excep_perinsc (comision, periodo_insc, fecha_inicio, fecha_fin, fecha_tope_bajas)
         SELECT comision_nueva, periodo_insc, fecha_inicio, fecha_fin, fecha_tope_bajas  
           FROM sga_comisiones_excep_perinsc 
          WHERE comision = pComisionOrigen;
  END IF;      
 
   
  -- asigno las observaciones. 
  cur_retorno.observaciones  := _observaciones; 
  
  -- Retorno datos de la comisión.
  RETURN NEXT cur_retorno;
  RETURN;

END;
$$;
