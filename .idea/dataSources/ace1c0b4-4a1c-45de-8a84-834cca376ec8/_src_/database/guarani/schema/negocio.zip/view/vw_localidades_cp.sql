CREATE VIEW vw_localidades_cp AS SELECT mug_localidades.localidad,
    mug_localidades.nombre AS localidad_nombre,
    mug_localidades.nombre_abreviado AS localidad_nombre_abreviado,
    mug_localidades.ddn AS localidad_ddn,
    mug_cod_postales.codigo_postal AS localidad_codigo_postal,
    mug_dptos_partidos.dpto_partido,
    mug_dptos_partidos.nombre AS dpto_partido_nombre,
    mug_dptos_partidos.estado AS dpto_partido_estado,
    mug_provincias.provincia,
    mug_provincias.nombre AS provincia_nombre,
    mug_paises.pais,
    mug_paises.nombre AS pais_nombre,
    mug_paises.codigo_iso AS paises_codigo_iso,
    mug_continentes.continente,
    mug_continentes.nombre AS continente_nombre
   FROM (negocio.mug_localidades
     LEFT JOIN negocio.mug_cod_postales ON ((mug_cod_postales.localidad = mug_localidades.localidad))),
    negocio.mug_dptos_partidos,
    negocio.mug_provincias,
    negocio.mug_paises,
    negocio.mug_continentes
  WHERE ((((mug_localidades.dpto_partido = mug_dptos_partidos.dpto_partido) AND (mug_dptos_partidos.provincia = mug_provincias.provincia)) AND (mug_provincias.pais = mug_paises.pais)) AND (mug_paises.continente = mug_continentes.continente));
