create function negocio.fhis_mdp_eleccion_institucion() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		INSERT INTO his_eleccion_institucion (dato_censal, mot_economico, mot_prestigio, mot_difusion, mot_recomendacion_estudiantes, mot_recomendacion_amigos, mot_sistema_ingreso, mot_ubicacion, mot_otros, insc_otra_institucion, insc_otra_institucion_desc, como_conocio_institucion) 
		VALUES (NEW.dato_censal, NEW.mot_economico, NEW.mot_prestigio, NEW.mot_difusion, NEW.mot_recomendacion_estudiantes, NEW.mot_recomendacion_amigos, NEW.mot_sistema_ingreso, NEW.mot_ubicacion, NEW.mot_otros, NEW.insc_otra_institucion, NEW.insc_otra_institucion_desc, NEW.como_conocio_institucion);
	
		RETURN NEW;
	END;
$$;
