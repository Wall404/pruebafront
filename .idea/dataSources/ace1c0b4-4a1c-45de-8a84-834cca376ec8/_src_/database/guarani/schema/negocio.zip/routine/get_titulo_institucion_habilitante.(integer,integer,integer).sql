create function negocio.get_titulo_institucion_habilitante(palumno integer, pcertificado integer, pdevolver integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE
	_nombre_titulo text;
	_nombre_institucion text;
	_persona integer;
	_TipoPropuesta integer;
	_CertificadoTipo integer;
	_origen char(1);
	_nivel_estudio integer;
	_nivel_estudio_desc varchar(100);
	_convalidado_revalidado varchar(30);
	_nro_resolucion_convalidacion varchar(30);
BEGIN
/*
  pDevolver:  0 = Nombre Titulo | Nombre Institucion | Origen Institucion | Nivel Estudio | Revalidado/convalidado/No Rev-Conv | Nro Resolucion Convalidacion
              1 = Nombre Titulo 
			  2 = Nombre Institucion 
			  3 = Origen de la institucion (N = Nacional / E = Extranjero)
              4 = Nivel de estudios del titulo anterior
              5 = Si el titulo fue revalidado/convalidado por el Ministerio de Educacion.
			      Convalidado / Revalidado / No Convalidado-Revalidado
              6 = Nro de resolucion de revalidacion/convalidacion del titulo por el Ministerio de Educacion.
*/
 _nombre_titulo := '';
 _nombre_institucion := '';
 _origen := 'N'; -- Nacional
 _CertificadoTipo := NULL;
 _TipoPropuesta := NULL;
 _nivel_estudio_desc := '';
 _convalidado_revalidado := '';
 _nro_resolucion_convalidacion := '';
 
 -- Recupero el tipo de propuesta
 SELECT a.persona, propuesta_tipo 
   INTO _persona, _TipoPropuesta
   FROM sga_alumnos as a, sga_propuestas as p
  WHERE a.alumno = pAlumno
    AND p.propuesta = a.propuesta;

 -- Obtengo el tipo de certificado	
 SELECT certificado_tipo INTO _CertificadoTipo FROM sga_certificados WHERE certificado = pCertificado; 
 

/* Tipos de Certificados:
 1 - Grado
 2 - Pregrado
 3 - Postítulo
 4 - Doctorado
 5 - Maestría
 6 - Especialización
 7 - Terciario no Universitario
 8 - Competencias
 9 - Ciclo cumplido
 10 - Postgrado

Tipos de Propuestas:
200 - Grado
201 - Pregrado
202 - Posgrado
203 - Ciclo Básico o Común
204 - Curso de Ingreso
205 - Postítulo
206 - Terciario
207 - Vocacional
208 - Cursos
209 - Convenio
*/

 -- Si es de PosGrado o PosTitulo 
 IF _TipoPropuesta = 202 OR _TipoPropuesta = 205 THEN
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Recupero el titulo de nivel universitario
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   SELECT 
        COALESCE(i.nombre, e.institucion_otra) as nombre_institucion,
        COALESCE(tit.nombre, e.titulo_otro) as nombre_titulo,
		CASE
		  WHEN e.institucion IS NOT NULL THEN 
		     (SELECT (CASE p.pais WHEN 54 THEN 'N' ELSE 'E' END)
			    FROM mug_localidades as l
				     JOIN mug_dptos_partidos as dp ON dp.dpto_partido = l.dpto_partido
				     JOIN mug_provincias as p ON p.provincia = dp.provincia
			   WHERE l.localidad = i.localidad)
		  ELSE COALESCE(e.institucion_otra_origen,'N')
		END as origen,
		ne.descripcion as nivel_estudio_desc,
		CASE e.titulo_ext_revalidado
		  WHEN 'R' THEN 'Revalidado'
		  WHEN 'C' THEN 'Convalidado'
		  WHEN 'N' THEN 'No Revalidado-Convalidado'
		  ELSE ''
		END,
        e.titulo_ext_resol_ministerial
	INTO _nombre_institucion, _nombre_titulo, _origen, _nivel_estudio_desc, _convalidado_revalidado, _nro_resolucion_convalidacion
    FROM mdp_datos_estudios as e
         LEFT JOIN sga_instituciones as i ON i.institucion = e.institucion
         LEFT JOIN mdp_titulos as tit ON tit.titulo = e.titulo
		 LEFT JOIN mdp_nivel_estudio as ne ON ne.nivel_estudio = e.nivel_estudio
	WHERE e.persona = _persona
	  AND e.nivel_estudio in (4, 5) -- Superior / Universitario
	ORDER BY e.nivel_estudio DESC, e.fecha_egreso DESC
	LIMIT 1;
 ELSE
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   -- Recupero el titulo secundario
   -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
   SELECT 
        COALESCE(c.nombre, e.colegio_otro) as nombre_institucion,
        COALESCE(tit.nombre, e.titulo_otro) as nombre_titulo,
		CASE
		  WHEN e.colegio IS NOT NULL THEN 
		     COALESCE((SELECT (CASE p.pais WHEN 54 THEN 'N' ELSE 'E' END)
			            FROM mug_localidades as l
				             JOIN mug_dptos_partidos as dp ON dp.dpto_partido = l.dpto_partido
				             JOIN mug_provincias as p ON p.provincia = dp.provincia
			           WHERE l.localidad = c.localidad)
					   , 'N')
		  ELSE COALESCE(e.colegio_otro_origen,'N')
		END as origen,
		ne.descripcion as nivel_estudio_desc,
		CASE e.titulo_ext_revalidado
		  WHEN 'R' THEN 'Revalidado'
		  WHEN 'C' THEN 'Convalidado'
		  WHEN 'N' THEN 'No Revalidado-Convalidado'
		  ELSE ''
		END,
        e.titulo_ext_resol_ministerial
	INTO _nombre_institucion, _nombre_titulo, _origen, _nivel_estudio_desc, _convalidado_revalidado, _nro_resolucion_convalidacion
    FROM mdp_datos_estudios as e
         LEFT JOIN sga_colegios_secundarios as c ON c.colegio = e.colegio
         LEFT JOIN mdp_titulos as tit ON tit.titulo = e.titulo
		 LEFT JOIN mdp_nivel_estudio as ne ON ne.nivel_estudio = e.nivel_estudio
	WHERE e.persona = _persona
	  AND e.nivel_estudio = 3 -- Secundario
	ORDER BY e.fecha_egreso DESC
	LIMIT 1;
 
 END IF; 

 IF pDevolver = 0 THEN
	RETURN _nombre_titulo || '|' || _nombre_institucion || '|' || _origen || '|' || _nivel_estudio_desc || '|' || _convalidado_revalidado || '|' || _nro_resolucion_convalidacion;
 ELSEIF pDevolver = 1 THEN
   -- Denominacion titulo
   RETURN _nombre_titulo;
 ELSEIF pDevolver = 2 THEN
   -- Nombre de institucion que expidió el titulo
   RETURN _nombre_institucion;
 ELSEIF pDevolver = 3 THEN
   -- Origen de la institucion que expidió el titulo
   RETURN _origen;
 ELSEIF pDevolver = 4 THEN
   -- Nivel de estudios del titulo
   RETURN _nivel_estudio_desc;
 ELSEIF pDevolver = 5 THEN
   -- Si fue convalidado/revalidado por el ministerio de educacion.
   RETURN _convalidado_revalidado;
 ELSEIF pDevolver = 6 THEN
   -- Nro de resolucion Ministerial de convalidacion/revalidacion.
   RETURN _nro_resolucion_convalidacion;
 END IF;  
END;
$$;
