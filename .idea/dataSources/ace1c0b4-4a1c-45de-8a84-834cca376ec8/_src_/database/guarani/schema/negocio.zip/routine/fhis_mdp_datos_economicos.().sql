create function negocio.fhis_mdp_datos_economicos() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		INSERT INTO his_datos_economicos (dato_censal, costeo_estudios_familiar, costeo_estudios_plan_social, costeo_estudios_trabajo, costeo_estudios_beca, costeo_estudios_otro, costeo_estudios_descripcion, beca, beca_fuente_universidad, beca_fuente_nacional, beca_fuente_provincial, beca_fuente_municipal, beca_fuente_internacional, beca_fuente_otra, beca_tipo_economica, beca_tipo_servicios, beca_tipo_investigacion, beca_economica_transporte, beca_economica_efectivo, beca_economica_fotocopias, beca_economica_habitacional, beca_economica_comedor, trabajo_existe, trabajo_hace, trabajo_familiar, trabajo_con_descuentos_jubilatorios, trabajo_recibe_pago, trabajo_ocupacion, trabajo_hora_sem, trabajo_carrera, trabajo_tarea_descripcion) 
		VALUES (NEW.dato_censal, NEW.costeo_estudios_familiar, NEW.costeo_estudios_plan_social, NEW.costeo_estudios_trabajo, NEW.costeo_estudios_beca, NEW.costeo_estudios_otro, NEW.costeo_estudios_descripcion, NEW.beca, NEW.beca_fuente_universidad, NEW.beca_fuente_nacional, NEW.beca_fuente_provincial, NEW.beca_fuente_municipal, NEW.beca_fuente_internacional, NEW.beca_fuente_otra, NEW.beca_tipo_economica, NEW.beca_tipo_servicios, NEW.beca_tipo_investigacion, NEW.beca_economica_transporte, NEW.beca_economica_efectivo, NEW.beca_economica_fotocopias, NEW.beca_economica_habitacional, NEW.beca_economica_comedor, NEW.trabajo_existe, NEW.trabajo_hace, NEW.trabajo_familiar, NEW.trabajo_con_descuentos_jubilatorios, NEW.trabajo_recibe_pago, NEW.trabajo_ocupacion, NEW.trabajo_hora_sem, NEW.trabajo_carrera, NEW.trabajo_tarea_descripcion);
	
		RETURN NEW;
	END;
$$;
