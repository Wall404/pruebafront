create function negocio.ftia_sga_docentes() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _cnt smallint;
BEGIN

  -- Asigno el tipo de usuario "Docente" al alumno.
  SELECT COUNT(*) INTO _cnt 
    FROM mdp_personas_tipo_usuario 
   WHERE persona = NEW.persona
     AND tipo_usuario = 'Docente';
  IF _cnt = 0 THEN
    INSERT INTO mdp_personas_tipo_usuario (persona, tipo_usuario) VALUES (NEW.persona, 'Docente');
  END IF;

  RETURN NEW;
END;
$$;
