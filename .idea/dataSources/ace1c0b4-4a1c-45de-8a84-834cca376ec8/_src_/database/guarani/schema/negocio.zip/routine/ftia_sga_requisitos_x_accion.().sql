create function negocio.ftia_sga_requisitos_x_accion() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   
   -- Inserto el requisito en todas las operaciones de la acción del grupo de requisitos al que pertenece.
   INSERT INTO sga_requisitos_conf_x_oper (operacion, interfaz, requisito_accion, actua_como, activo)
      SELECT sga_acciones_operacion.operacion, acc_interfaces.interfaz, NEW.requisito_accion, 'ESTRICTO', 'S'
        FROM sga_requisitos_grupos,
             sga_acciones_operacion,
             acc_interfaces
       WHERE sga_requisitos_grupos.grupo_requisito = NEW.grupo_requisito
         AND sga_acciones_operacion.accion = sga_requisitos_grupos.accion;

   RETURN NEW;
END;
$$;
