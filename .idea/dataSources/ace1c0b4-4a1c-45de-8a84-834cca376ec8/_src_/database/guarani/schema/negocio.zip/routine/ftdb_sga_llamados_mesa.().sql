create function negocio.ftdb_sga_llamados_mesa() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- Borro las evaluaciones Automáticas
   DELETE FROM sga_evaluaciones 
      WHERE entidad = OLD.entidad
      AND evaluacion_tipo IN (SELECT evaluacion_tipo 
                                FROM sga_evaluaciones_tipos 
                               WHERE aplica_a = 'M' 
                                 AND automatica = 'S');
   
   RETURN OLD;
END;
$$;
