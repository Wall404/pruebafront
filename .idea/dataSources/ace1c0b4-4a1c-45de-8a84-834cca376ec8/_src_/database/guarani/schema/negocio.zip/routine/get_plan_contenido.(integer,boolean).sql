create function negocio.get_plan_contenido(integer, boolean) returns SETOF negocio.type_plan_contenido
LANGUAGE plpgsql
AS $$
DECLARE 

id_plan_version ALIAS for $1;
modulo_raiz record;
hijos record;
cant integer;
BEGIN

SELECT COUNT (relname) INTO cant FROM pg_class WHERE relname = 'temp_seq';
IF (cant = 0) THEN 
	CREATE TEMP sequence temp_seq;
END IF;	

	-- elementos contenidos
	FOR hijos IN (	
			SELECT 	orden_arbol,
				elemento_revision,
				elemento,
				codigo,
				nombre,
				entidad_tipo,
				entidad_subtipo,
				entidad_clase_gui,
				elemento_comp,
				elemento_revision_padre,
				elemento_padre,
				orden
			FROM get_plan_contenido(id_plan_version, true, true)

	) LOOP
		RETURN NEXT hijos;
	END LOOP;

IF (cant = 0) THEN 
	DROP sequence temp_seq;	
END IF;	

END
$$;
