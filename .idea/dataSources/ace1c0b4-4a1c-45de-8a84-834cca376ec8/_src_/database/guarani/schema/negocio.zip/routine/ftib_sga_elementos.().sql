create function negocio.ftib_sga_elementos() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
       -- Genera un registro en la tabla de entidades..
       NEW.entidad := f_generar_entidad(NEW.entidad_subtipo);    -- NEW.entidad := f_generar_entidad(xxxx);
       RETURN NEW;
  END;
$$;
