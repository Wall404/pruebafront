create function negocio.ftdb_sga_actas() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- No se permite borrar un acta si esta cerrada o dada de baja
   IF OLD.estado = 'C' THEN
      raise exception 'No se puede sacar alumnos del acta porque esta Cerrada';
   ELSEIF OLD.estado = 'B' THEN
      raise exception 'No se puede sacar alumnos del acta porque esta Anulada';
   END IF ;
   
   RETURN OLD;
END;
$$;
