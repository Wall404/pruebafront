create function negocio.f_replace_array(ptexto text, preemplazar character varying[], preemplazarpor character varying[]) returns text
LANGUAGE plpgsql
AS $$
DECLARE
   i smallint;
   n int;
   rtn text;
   
BEGIN
/*
   pTexto = Catena de texto en donde se reemplazaran los datos
   pReemplazar = Array que contiene cada uno de los textos a reemplazar
   pReemplazarPor = 
   Ejemplo: select * from f_replace_array ('Esto es una prueba', array['es','una','ba'], array['A','B','C'])
*/
 rtn := pTexto;

 n := (select array_upper(pReemplazar,1) - array_lower(pReemplazar,1) + 1);
 FOR i IN 1 .. n
 LOOP
   IF pReemplazar[i] IS NOT NULL AND (pReemplazar[i]) <> '' THEN
	rtn := replace(rtn, pReemplazar[i], COALESCE(pReemplazarPor[i],''));
   END IF;
 END LOOP;
 Return rtn;
END;
$$;
