create function negocio.f_configuracion_email_actualizar(ppersona integer, pmail character varying, ptipomail character varying, precibemailmensajes smallint) returns void
LANGUAGE plpgsql
AS $$
BEGIN

  -- Actualizo configuracion de recepción de mails
  UPDATE mdp_configuracion 
	SET recibe_mail_mensajes = pRecibeMailMensajes
  WHERE persona = pPersona;

  
  -- Actualizo el Mail Principal
  IF pMail IS NOT NULL THEN
    UPDATE mdp_personas_contactos  
       SET email = pMail 
     WHERE persona = pPersona
       AND contacto_tipo = pTipoMail; 
  
    -- Si no existe, lo creo.                     
    IF NOT FOUND THEN
     INSERT INTO mdp_personas_contactos (persona, email, contacto_tipo) VALUES (pPersona, pMail, pTipoMail); 
    END IF;
  END IF;  

    
  -- Bloque de excepciones. Que salga sin error.  
  EXCEPTION 
    WHEN OTHERS THEN
  

END;
$$;
