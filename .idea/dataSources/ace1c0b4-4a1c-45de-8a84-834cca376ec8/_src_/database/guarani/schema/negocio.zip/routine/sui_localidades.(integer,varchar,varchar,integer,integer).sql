create function negocio.sui_localidades(p_localidad integer, p_nombre character varying, p_nombre_abreviado character varying, p_dpto_partido integer, p_ddn integer) returns void
LANGUAGE plpgsql
AS $$
BEGIN

  -- Inserta la localidad
  INSERT INTO mug_localidades (localidad, nombre, nombre_abreviado, dpto_partido, ddn)
      VALUES (p_localidad, p_nombre, p_nombre_abreviado, p_dpto_partido, p_ddn);

  -- Falla el insert por primary key, existe la localidad, entonces actualizo los datos
  EXCEPTION 
    WHEN unique_violation THEN
      -- Actualiza la localidad
      UPDATE mug_localidades 
         SET (nombre, nombre_abreviado, dpto_partido, ddn) = (p_nombre, p_nombre_abreviado, p_dpto_partido, p_ddn)
       WHERE localidad = p_localidad;
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Localidad: % - %. Error Nro: %. %',p_localidad, p_nombre, SQLSTATE, SQLERRM;   

END;
$$;
