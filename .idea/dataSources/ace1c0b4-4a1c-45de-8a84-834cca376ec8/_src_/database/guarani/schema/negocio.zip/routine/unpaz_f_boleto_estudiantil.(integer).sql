create function negocio.unpaz_f_boleto_estudiantil(_persona integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _alumno integer;
 DECLARE _ingresante integer;

BEGIN
	_alumno := 0;
	_ingresante := 0;
	SELECT count(nro_documento) INTO _alumno
	FROM(
		Select DISTINCT apellido, nombres, nro_documento from (
		SELECT apellido, nombres, nro_documento, persona, alumno, count(elemento) as totales, sum(cumple) as cumplir FROM (
		SELECT distinct apellido, nombres, nro_documento, p.persona, h.alumno, h.elemento
		,CASE WHEN (date_part('month', now()) >= 1 and date_part('month', now()) <=6) THEN
			CASE WHEN (fecha BETWEEN to_date(((date_part('year', now())-1)||'-10-01'), 'YYYY-MM-DD') AND to_date(((date_part('year', now()))||'-03-31'), 'YYYY-MM-DD'))
			THEN 1
			ELSE 0 END
		ELSE
			CASE WHEN (fecha BETWEEN to_date(((date_part('year', now()))||'-04-01'), 'YYYY-MM-DD') AND to_date(((date_part('year', now()))||'-09-31'), 'YYYY-MM-DD'))
			THEN 1
			ELSE 0 END
		END AS cumple
		,fecha
		FROM (Select distinct * from (
		select elemento, actividad_codigo, nota, resultado, fecha, plan_version, origen, alumno, persona, anio_academico from negocio.vw_hist_academica as h) as historia
		where --anio_academico = (date_part('year', now())) 
		CASE WHEN (date_part('month', now()) >= 1 and date_part('month', now()) <=6) THEN
			fecha BETWEEN to_date(((date_part('year', now())-1)||'-04-01'), 'YYYY-MM-DD') AND to_date(((date_part('year', now()))||'-03-31'), 'YYYY-MM-DD')
		ELSE
			fecha BETWEEN to_date(((date_part('year', now())-1)||'-10-01'), 'YYYY-MM-DD') AND to_date(((date_part('year', now()))||'-09-31'), 'YYYY-MM-DD')
		END

		and resultado = 'A' and plan_version not in (
		SELECT sga_planes_versiones.plan_version
		  FROM negocio.sga_planes_versiones
		  JOIN negocio.sga_planes on (sga_planes_versiones.plan = sga_planes.plan)
		  JOIN negocio.sga_propuestas on (sga_planes.propuesta = sga_propuestas.propuesta)
		  WHERE
		  propuesta_tipo in (204,208)
		) and origen not in ('B')
		AND historia.persona = _persona
		) as h
		 join negocio.vw_personas as p on (h.persona=p.persona)
		order by 1,2

		)AS CONSULTA
		group by apellido, nombres, nro_documento, persona, alumno
		order by 6
		) as CONSULTAS
		where totales >= 3 and cumplir>=1
		/* Preguntar */
		AND exists (
			SELECT distinct 1
			  FROM negocio.sga_insc_cursada
			  JOIN negocio.vw_comisiones on (sga_insc_cursada.comision = vw_comisiones.comision)
			  WHERE now() BETWEEN fecha_inicio AND fecha_fin
			  AND sga_insc_cursada.alumno =CONSULTAS.alumno
		)
		/* Preguntar */
	) as Alumnos;
	
	SELECT count(nro_documento) INTO _ingresante
	FROM(
		SELECT distinct apellido, nombres, nro_documento 
		FROM negocio.vw_personas as p
		  JOIN negocio.sga_alumnos on (sga_alumnos.persona = p.persona)
		  JOIN negocio.sga_propuestas_aspira on (sga_propuestas_aspira.propuesta = sga_alumnos.propuesta and sga_propuestas_aspira.persona = sga_alumnos.persona)
		  JOIN negocio.sga_propuestas on (sga_propuestas.propuesta = sga_propuestas_aspira.propuesta and sga_propuestas.propuesta = sga_alumnos.propuesta)
		WHERE
		anio_academico = date_part('year', now())
		AND sga_alumnos.persona = _persona
		and (sga_propuestas_aspira.propuesta =24 or propuesta_tipo in (200, 201))
		and situacion_asp in (1,2)
		/* Preguntar */
		AND exists (
			SELECT distinct 1
			  FROM negocio.sga_insc_cursada
			  JOIN negocio.vw_comisiones on (sga_insc_cursada.comision = vw_comisiones.comision)
			  WHERE now() BETWEEN fecha_inicio AND fecha_fin
			  AND sga_insc_cursada.alumno =sga_alumnos.alumno
		)
		/* Preguntar */
	)AS Ingresantes;

	IF _ingresante > 0 OR _alumno > 0 THEN
		RETURN 1;
	ELSE
		RETURN 0;
	END IF;
END;
$$;
