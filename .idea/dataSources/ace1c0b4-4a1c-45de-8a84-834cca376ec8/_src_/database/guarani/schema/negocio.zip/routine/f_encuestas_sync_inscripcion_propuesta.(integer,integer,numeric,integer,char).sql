create function negocio.f_encuestas_sync_inscripcion_propuesta(ppersona integer, ppropuesta integer, panioacademico numeric, pubicacion integer, pmodalidad character) returns void
LANGUAGE plpgsql
AS $$
DECLARE
	cur_formularios RECORD;
	_cantidad INTEGER;

BEGIN
	-- Encuestas genéricas (tipo = 4) activas para la ubicación y modalidad del alumno, no asociadas previamente al mismo.
	-- De las genericas se verifica si estan definidas por propuesta. Si es por propuesta solo se asigna el formulario relacionado con la propuesta.
	FOR cur_formularios IN
		SELECT	gde_formularios.formulario,
				gde_habilitaciones.habilitacion,
				gde_habilitaciones.alcance,
				gde_habilitaciones.alumnos,
				gde_habilitaciones.alumnos_inscriptos,
				gde_habilitaciones.alumnos_reinscriptos
		FROM	gde_formularios,
				gde_habilitaciones,
				gde_ubicaciones,
				gde_modalidades
		WHERE	gde_formularios.habilitacion = gde_habilitaciones.habilitacion AND
				gde_habilitaciones.habilitacion = gde_ubicaciones.habilitacion AND
				gde_ubicaciones.ubicacion = pUbicacion AND
				gde_habilitaciones.habilitacion = gde_modalidades.habilitacion AND
				gde_modalidades.modalidad = pModalidad AND
				gde_habilitaciones.tipo = 4 AND
				gde_habilitaciones.fecha_hasta >= CURRENT_DATE AND
				(gde_habilitaciones.encuesta_por_propuesta = 'N' OR
 				 (gde_habilitaciones.encuesta_por_propuesta = 'S' AND 
				  EXISTS (SELECT 1 FROM gde_formulario_items as fi, gde_items as i 
				           WHERE fi.formulario = gde_formularios.formulario 
					  	     AND i.item = fi.item  
					 		 AND i.propuesta = pPropuesta
						 )
				 )			 
				) AND 
				NOT EXISTS (SELECT	gde_encuestas_pendientes.respuesta
							FROM	gde_encuestas_pendientes
							WHERE	gde_encuestas_pendientes.formulario = gde_formularios.formulario AND
									gde_encuestas_pendientes.persona = pPersona)
	LOOP
		IF cur_formularios.alcance = 2 THEN -- Alcance: Responsables Académicas.
			SELECT	COUNT(gde_responsables_academicas.responsable_academica) INTO _cantidad
			FROM	gde_responsables_academicas,
					sga_propuestas_ra
			WHERE	gde_responsables_academicas.responsable_academica = sga_propuestas_ra.responsable_academica AND
					gde_responsables_academicas.habilitacion = cur_formularios.habilitacion AND
					sga_propuestas_ra.propuesta = pPropuesta;
			IF _cantidad = 0 THEN
				CONTINUE;
			END IF;
		ELSEIF cur_formularios.alcance = 3 THEN	-- Alcance: Tipos de Propuestas.
			SELECT	COUNT(gde_propuestas_tipos.propuesta_tipo) INTO _cantidad
			FROM	gde_propuestas_tipos,
					sga_propuestas
			WHERE	gde_propuestas_tipos.propuesta_tipo = sga_propuestas.propuesta_tipo AND
					gde_propuestas_tipos.habilitacion = cur_formularios.habilitacion AND
					sga_propuestas.propuesta = pPropuesta;
			IF _cantidad = 0 THEN
				CONTINUE;
			END IF;
		ELSEIF cur_formularios.alcance = 4 THEN -- Alcance: Propuestas.
			SELECT	COUNT(gde_propuestas.propuesta) INTO _cantidad
			FROM	gde_propuestas
			WHERE	gde_propuestas.habilitacion = cur_formularios.habilitacion AND
					gde_propuestas.propuesta = pPropuesta;
			IF _cantidad = 0 THEN
				CONTINUE;
			END IF;
		END IF;

		IF cur_formularios.alumnos = 'A' THEN -- Sólo algunos alumnos.
			IF cur_formularios.alumnos_inscriptos = 'S' THEN -- Inscriptos en años académicos.
				SELECT	COUNT(gde_anios_academicos.anio_academico) INTO _cantidad
				FROM	gde_anios_academicos
				WHERE	gde_anios_academicos.habilitacion = cur_formularios.habilitacion AND
						gde_anios_academicos.anio_academico = pAnioAcademico;
				IF _cantidad = 0 THEN
					CONTINUE;
				END IF;
			ELSE -- Reinscriptos en años académicos.
				-- La función se invoca desde el alta de inscripciones a propuesta, no pueden existir reinscripciones para el alumno.
				CONTINUE;
			END IF;
		ELSEIF cur_formularios.alumnos = 'E' THEN -- Alumnos según estado de tesis.
			-- La función se invoca desde el alta de inscripciones a propuesta, no pueden existir tesis para el alumno.
			CONTINUE;
		END IF;

		-- Se asocia la encuesta a la persona.
		INSERT INTO gde_encuestas_pendientes (persona, formulario) VALUES (pPersona, cur_formularios.formulario);
	END LOOP;
END;
$$;
