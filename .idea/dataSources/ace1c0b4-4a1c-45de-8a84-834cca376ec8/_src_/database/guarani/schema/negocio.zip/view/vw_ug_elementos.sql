CREATE VIEW vw_ug_elementos AS SELECT vw_ug_propuestas_sin_gestionar_actividades.unidad_gestion,
    vw_elementos_plan.elemento
   FROM negocio.vw_ug_propuestas_sin_gestionar_actividades,
    negocio.vw_elementos_plan
  WHERE (vw_ug_propuestas_sin_gestionar_actividades.propuesta = vw_elementos_plan.propuesta)
UNION
 SELECT sga_ug_responsables_academicas.unidad_gestion,
    sga_elementos_ra.elemento
   FROM negocio.sga_ug_responsables_academicas,
    negocio.sga_elementos_ra
  WHERE (sga_ug_responsables_academicas.responsable_academica = sga_elementos_ra.responsable_academica);
