create function negocio.ftdb_sga_requisitos_x_accion() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- Borro el registro en la tabla de entidades..
   DELETE FROM sga_requisitos_conf_x_oper
     WHERE sga_requisitos_conf_x_oper.requisito_accion = OLD.requisito_accion;
   
   RETURN OLD;
END;
$$;
