create function negocio.f_instancias_acta(pacta integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _retorno := NULL;
		
  -- Recupero el nombre de las modalidades de cursada
  FOR cur1 IN SELECT sga_instancias.nombre as nombre
                FROM sga_actas_instancias, sga_instancias
               WHERE sga_actas_instancias.id_acta = pActa
                 AND sga_actas_instancias.instancia = sga_instancias.instancia
  LOOP
      IF cnt = 0 THEN		
         _retorno :=  cur1.nombre;
      ELSE
         _retorno :=  _retorno || '/' || cur1.nombre;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
