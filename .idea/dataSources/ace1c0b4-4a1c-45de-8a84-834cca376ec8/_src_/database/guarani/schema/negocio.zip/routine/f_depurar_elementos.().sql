create function negocio.f_depurar_elementos() returns text
LANGUAGE plpgsql
AS $$
DECLARE
  _rtn_mensaje text;
  _cantidad integer;
  _cant_grupos integer;
  _cant_requisitos integer;
  cur1 record;
  cur2 record;
BEGIN
  _rtn_mensaje := '1,OK';
  _cantidad := 0;
  _cant_grupos := 0;
  _cant_requisitos := 0;
  
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Recupero las revisiones de los elementos que:
  -- a. Son modulos 
  -- b. NO son compartibles. 
  -- c. NO tienen revision
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  	
  CREATE TEMP TABLE tmp_elementos (elemento integer, entidad integer);
	
  INSERT INTO tmp_elementos (elemento, entidad)
    SELECT sga_elementos.elemento, sga_elementos.entidad
      FROM sga_elementos, 
           sga_g3entidades_subtipos
     WHERE sga_elementos.entidad_subtipo = sga_g3entidades_subtipos.entidad_subtipo
       AND sga_elementos.compartible = 'N'            -- No es compartible.
       AND sga_g3entidades_subtipos.entidad_tipo = 1  -- Modulos
       AND sga_elementos.entidad_subtipo <> 2         -- No sea Materia Genérica
       AND elemento NOT IN (SELECT DISTINCT elemento FROM sga_elementos_revision);
  
  -- Verifico si hay elementos para borrar
  SELECT COUNT(*) INTO _cantidad FROM tmp_elementos;   
  IF _cantidad = 0 THEN
    DROP TABLE tmp_elementos;
    _rtn_mensaje := '0, No hay elementos para borrar';
    RETURN _rtn_mensaje;
  END IF;

  -- Borro condiciones (correlativas, etc..) asociadas al elemento
  -- Recorro cada modulo a borrar
  FOR cur1 IN SELECT elemento, entidad FROM tmp_elementos
  LOOP
      -- Recorro condiciones que tengan como requisito a este modulo
      FOR cur2 IN SELECT cr.requisito_condicion,
                         cr.grupo_condicion,
                         cg.condicion
                    FROM sga_condiciones_requisitos as cr,
                         sga_condiciones_grupos as cg 
                   WHERE cr.entidad = cur1.entidad
                     AND cg.grupo_condicion = cr.grupo_condicion
                     AND cr.tipo = 'E'
      LOOP
         -- Verifico cantidad de reguisitos del grupo y cantidad de grupos de la condición.
         SELECT COUNT(*) INTO _cant_requisitos FROM sga_condiciones_requisitos WHERE grupo_condicion = cur2.grupo_condicion;
         SELECT COUNT(*) INTO _cant_grupos FROM sga_condiciones_grupos WHERE condicion = cur2.condicion;

         -- Borro el modulo que esta como requisito. 
         DELETE FROM sga_condiciones_requisitos WHERE requisito_condicion = cur2.requisito_condicion;
         
         -- Borro el grupo si era el único requisito del grupo
         IF _cant_requisitos = 1 THEN
           DELETE FROM sga_condiciones_grupos WHERE grupo_condicion = cur2.grupo_condicion;
         END IF;
         
         -- Borro la condición si era el único grupo de la condición de correlativas/certificados.
         IF _cant_grupos = 1 AND _cant_requisitos = 1 THEN
            DELETE FROM sga_condiciones WHERE condicion = cur2.condicion;
         END IF;

      END LOOP; -- Condiciones

  END LOOP; -- Elementos


  -- Atributos de los elementos sin revisiion. 
  DELETE FROM sga_elementos_atrib WHERE elemento IN (SELECT elemento FROM tmp_elementos);

  -- Responsables academicas asociadas
  DELETE FROM sga_elementos_ra WHERE elemento IN (SELECT elemento FROM tmp_elementos);

  -- Borro el módulo. Por trigger se borra sga_g3entidades
  DELETE FROM sga_elementos WHERE elemento IN (SELECT elemento FROM tmp_elementos);

  -- Borro tabla temporal
  DROP TABLE tmp_elementos;
    
  -- Salgo.
  _rtn_mensaje := '1,OK';
  RETURN _rtn_mensaje;
  
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Error.
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  EXCEPTION 
     WHEN OTHERS THEN
       _rtn_mensaje := '-1,Error: ' || cast(SQLSTATE as varchar) || '. ' || SQLERRM;
       RETURN _rtn_mensaje;

END;
$$;
