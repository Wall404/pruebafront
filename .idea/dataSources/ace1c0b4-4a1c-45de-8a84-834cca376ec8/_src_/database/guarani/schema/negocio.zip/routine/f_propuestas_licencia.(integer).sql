create function negocio.f_propuestas_licencia(_licencia integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _retorno := NULL;
		
  -- Recupero el nombre de las propuestas.
  FOR cur1 IN 	SELECT 	DISTINCT sga_propuestas.nombre_abreviado as nombre
				FROM 	sga_licencias_propuestas, 
						sga_propuestas
                WHERE 	sga_licencias_propuestas.licencia = _licencia
						AND sga_licencias_propuestas.propuesta = sga_propuestas.propuesta
  LOOP
      IF cnt = 0 THEN		
         _retorno :=  cur1.nombre;
      ELSE
         _retorno :=  _retorno || ' / ' || cur1.nombre;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
