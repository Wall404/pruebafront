CREATE VIEW vw_insc_cursada_instancias AS SELECT sga_insc_cursada_instancias.inscripcion,
    sga_insc_cursada_instancias.instancia
   FROM negocio.sga_insc_cursada_instancias
UNION ALL
 SELECT his_insc_cursada_instancias.inscripcion,
    his_insc_cursada_instancias.instancia
   FROM negocio.his_insc_cursada_instancias;
