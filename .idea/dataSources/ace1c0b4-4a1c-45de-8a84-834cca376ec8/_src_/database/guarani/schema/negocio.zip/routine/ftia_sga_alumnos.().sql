create function negocio.ftia_sga_alumnos() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
  _cnt smallint;
  _propuesta_tipo smallint;
  _rtn_equiv_auto  type_retorno_funcion;
BEGIN

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Acceso a autogestion
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Verifico si esta inscripto en una propuesta de tipo curso, entonces le asigno el acceso a "Cursos"
  SELECT propuesta_tipo INTO _propuesta_tipo FROM sga_propuestas WHERE propuesta = NEW.propuesta;

  IF _propuesta_tipo = 208 THEN
     -- Es propuesta de tipo Cursos. Inserto el acceso de autogestion por el perfil Cursos.
     SELECT COUNT(*) INTO _cnt FROM mdp_personas_tipo_usuario WHERE persona = NEW.persona AND tipo_usuario = 'Cursos';
     IF _cnt = 0 THEN
         INSERT INTO mdp_personas_tipo_usuario (persona, tipo_usuario) VALUES (NEW.persona, 'Cursos');
     END IF;		 
  
  ELSE
  
     -- Asigno el tipo de usuario "Alumno" generico al alumno.
     SELECT COUNT(*) INTO _cnt FROM mdp_personas_tipo_usuario WHERE persona = NEW.persona AND tipo_usuario = 'Alumno';
     IF _cnt = 0 THEN
        INSERT INTO mdp_personas_tipo_usuario (persona, tipo_usuario) VALUES (NEW.persona, 'Alumno');
     END IF;
  END IF;

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Otorgar Equivalencias Automáticas
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _rtn_equiv_auto := f_equiv_otorgar_equivalencias('NUEVA_PROPUESTA', NEW.Alumno, NULL, NULL, NULL, NULL);


  RETURN NEW;
END;
$$;
