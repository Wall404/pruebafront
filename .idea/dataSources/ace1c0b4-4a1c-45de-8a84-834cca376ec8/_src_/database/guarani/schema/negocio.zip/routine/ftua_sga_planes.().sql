create function negocio.ftua_sga_planes() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
    -- Si se esta activando el Plan, entonces cambio el estado de la Propuesta
    IF OLD.estado = 'N' AND (NEW.estado = 'A' OR NEW.estado = 'V') THEN
       -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
       -- Activo el estado de la Propuesta si esta en estado Nuevo.
       -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
       UPDATE sga_propuestas 
          SET estado = 'A'
        WHERE sga_propuestas.propuesta = NEW.propuesta
          AND sga_propuestas.estado = 'N';
           
       -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
       -- Si es Personalizado, entonces lo incluyo en las comisiones y mesas de examen vigentes
       -- que acepten planes personalizados
       -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++    
       IF NEW.tipo_plan = 'Personalizado' OR NEW.tipo_plan = 'Convenio' THEN
          INSERT INTO sga_comisiones_propuestas (comision, propuesta, plan)
              SELECT sga_comisiones.comision, NEW.propuesta, NEW.plan
                FROM sga_comisiones, 
                     sga_periodos_lectivos,
                     sga_periodos
               WHERE sga_periodos_lectivos.periodo_lectivo = sga_comisiones.periodo_lectivo
                 AND sga_periodos.periodo = sga_periodos_lectivos.periodo
                 AND sga_periodos.fecha_fin >= CURRENT_DATE
                 AND sga_comisiones.acepta_planes_personalizados = 'S'
				 AND sga_comisiones.elemento IN (SELECT sga_elementos_revision.elemento 
												 FROM	sga_elementos_plan, 
														sga_planes_versiones, 
														sga_elementos_revision
												 WHERE	sga_planes_versiones.plan = NEW.plan
													AND sga_elementos_plan.plan_version = sga_planes_versiones.plan_version
													AND sga_elementos_revision.elemento_revision = sga_elementos_plan.elemento_revision
												);
          
          -- Mesas de Examen de fechas futuras
          INSERT INTO sga_mesas_examen_propuestas (mesa_examen, propuesta, plan)
              SELECT sga_mesas_examen.mesa_examen, NEW.propuesta, NEW.plan
                FROM sga_mesas_examen, 
                     sga_llamados_mesa
               WHERE sga_llamados_mesa.mesa_examen = sga_mesas_examen.mesa_examen
                 AND sga_llamados_mesa.fecha >= CURRENT_DATE
                 AND sga_mesas_examen.acepta_planes_personalizados = 'S'
 				 AND sga_mesas_examen.elemento IN (SELECT sga_elementos_revision.elemento 
												   FROM	sga_elementos_plan, 
														sga_planes_versiones, 
														sga_elementos_revision
                                                   WHERE sga_planes_versiones.plan = NEW.plan
                                                    AND sga_elementos_plan.plan_version = sga_planes_versiones.plan_version
                                                    AND sga_elementos_revision.elemento_revision = sga_elementos_plan.elemento_revision
												);
             
       END IF;     
    END IF;
    RETURN NEW;
  END;
$$;
