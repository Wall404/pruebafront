CREATE VIEW vw_insc_subcomision AS SELECT sga_insc_subcomision.inscripcion,
    sga_insc_subcomision.subcomision
   FROM negocio.sga_insc_subcomision
UNION ALL
 SELECT his_insc_subcomision.inscripcion,
    his_insc_subcomision.subcomision
   FROM negocio.his_insc_subcomision;
