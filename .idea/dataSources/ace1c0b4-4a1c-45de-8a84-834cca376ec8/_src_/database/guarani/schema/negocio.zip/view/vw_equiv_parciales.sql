CREATE VIEW vw_equiv_parciales AS SELECT sga_equiv_otorgada.elemento,
    sga_elementos_revision.elemento_revision,
    sga_elementos.codigo AS actividad_codigo,
    COALESCE(sga_elementos_plan.nombre, sga_elementos.nombre) AS actividad_nombre,
    COALESCE(sga_elementos_plan.nombre_abreviado, sga_elementos.nombre_abreviado) AS actividad_nombre_abreviado,
    'D'::character(1) AS origen,
    'Equivalencia Parcial'::character varying(30) AS tipo,
    sga_equiv_tramite.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_tramite.tipo_tramite,
    sga_equiv_tramite.documento AS nro_resolucion,
    sga_documentos.documento_numero AS nro_resolucion_descripcion,
    sga_equiv_otorgada.equivalencia,
    sga_alumnos.persona,
    sga_equiv_tramite.alumno,
    sga_equiv_tramite.plan_version,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.fecha_vigencia,
    sga_equiv_otorgada.temas_a_rendir,
        CASE
            WHEN ((sga_equiv_otorgada.fecha_vigencia IS NULL) OR (sga_equiv_otorgada.fecha_vigencia >= ('now'::text)::date)) THEN 1
            ELSE 0
        END AS es_vigente,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado,
    sga_equiv_otorgada.estado,
    sga_equiv_otorgada.temas_a_rendir AS observaciones,
    sga_escalas_notas_det.descripcion AS nota_descripcion,
    sga_escalas_notas_resultado.descripcion AS resultado_descripcion
   FROM ((((((((negocio.sga_equiv_tramite
     LEFT JOIN negocio.sga_documentos ON ((sga_documentos.documento = sga_equiv_tramite.documento)))
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     LEFT JOIN negocio.sga_escalas_notas_det ON (((sga_equiv_otorgada.escala_nota = sga_escalas_notas_det.escala_nota) AND ((sga_equiv_otorgada.nota)::text = (sga_escalas_notas_det.nota)::text))))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_equiv_otorgada.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_equiv_tramite.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
     JOIN negocio.sga_alumnos ON ((sga_alumnos.alumno = sga_equiv_tramite.alumno)))
     JOIN negocio.sga_escalas_notas_resultado ON ((sga_escalas_notas_resultado.resultado = sga_equiv_otorgada.resultado)))
  WHERE (((((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.instancia = 12)) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar)) AND (sga_equiv_otorgada.estado = 'A'::bpchar)) AND (sga_equiv_otorgada.resultado = ANY (ARRAY['A'::bpchar, 'R'::bpchar])));
