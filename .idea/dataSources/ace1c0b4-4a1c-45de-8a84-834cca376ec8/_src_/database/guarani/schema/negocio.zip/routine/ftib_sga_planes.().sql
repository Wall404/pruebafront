create function negocio.ftib_sga_planes() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
       -- Genera un registro en la tabla de entidades..
       NEW.entidad := f_generar_entidad(102);
       RETURN NEW;
  END;
$$;
