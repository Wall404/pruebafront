create function negocio.f_equiv_otorgar_equivalencias(paccion character varying, palumno integer, ppropuestaorigen integer, pplanorigen integer, pplanversionorigen integer, pactividad integer DEFAULT NULL::integer) returns negocio.type_retorno_funcion
LANGUAGE plpgsql
AS $$
DECLARE 
 /*
  Valores de parámetros de la funcion:

  pAccion = Indica cual es la accion realizada sobre el alumno para ver que matrices debe aplicar. Valores:
            NUEVA_PROPUESTA  : llamada desde el trigger de insert de sga_alumnos
            CAMBIO_DE_VERSION: llamada desde el trigger de update de sga_alumnos
            CAMBIO_DE_PLAN   : llamada desde el trigger de update de sga_alumnos 
            APLICAR_MATRICES : esta opcion es para cuando se quiere aplicar matrices de equivalencias luego de
			                   que el alumno haya aprobado alguna actividad. Para este caso viene seteado el parametro pActividad.

  Todas estas acciones son llamadas desde el trigger de insert y update de sga_alumnos.
  
  pActividad = Si viene este dato es para aplicar equivalencias respecto de una actividad (actividad que fue aprobada x examen/etc)
 */
 
 -- Datos del Trámite
 _fecha_actual date;
 _origen smallint;
 _documento integer;
 _documento_version integer;
 _documento_plan integer;
 _NUA integer;
 _ESTADO_CERRADO char(1);
 _TIPO_TRAMITE char(1);
 _AUTOMATICA char(1);
 _MATRIZ_OFICIAL char(1);
 _equivalencia_tramite integer;
 
 _Plan Integer;
 _Persona Integer;
 _Propuesta Integer;
 _PlanVersion Integer;
 cur_matrices record;
 cur_equiv record;
 _id_anterior integer;
 _matriz_anterior integer; 
 _elemento_anterior integer;
 i integer;
 _equivalencia integer;
 _rtn type_retorno_funcion;
 _cant_equiv integer;
 _ID integer;

 -- Variables de Parámetros del Sistema  
 _EquivalenciasAutomaticas char(1);
 _ParamControlarCorrelativas char(1);
 _ParamAjustarNota char(1);
 _ParamPasarDesaprobados char(1);
 _ParamRegistrarVencOriginal char(1);
 _ParamPasarRegularidad char(1);
 _ParamPasarRegularidadConNota char(1);
 _ParamGenerarTramite varchar(10);
  
BEGIN
 
 -- Plan Actual del Alumno y datos de documentos respaldatorios...
 SELECT a.persona, a.propuesta, a.plan_version, v.plan, v.documento_alta, p.documento_alta
   INTO _Persona, _Propuesta, _PlanVersion, _Plan, _documento_version , _documento_plan
   FROM sga_alumnos as a,
        sga_planes_versiones as v, 
        sga_planes as p
  WHERE a.alumno = pAlumno
    AND v.plan_version = a.plan_version
    AND v.plan = p.plan;

 -- Recupero valores de los Parámetros del Sistema.
 _EquivalenciasAutomaticas := get_valor_parametro_plan( 'equiv_automatica_generar', _Plan);
 
 IF _EquivalenciasAutomaticas = 'N' THEN
    _rtn.resultado := 1;
    RETURN _rtn;
 END IF;

 -- Seteo Variables
 _cant_equiv     := 0;
 _TIPO_TRAMITE   := 'N';
 _AUTOMATICA     := 'S';
 _MATRIZ_OFICIAL := 'S';
 _TIPO_TRAMITE   := 'N';
 _ESTADO_CERRADO := 'C';
 _fecha_actual   := CURRENT_DATE;
 
 -- Origen de aplicacion de la equivalencia automatica.
 IF pAccion = 'NUEVA_PROPUESTA' THEN
   _origen := 2; -- Cambio de Propuesta
 ELSEIF pAccion = 'CAMBIO_DE_PLAN' THEN
   _origen := 3; -- Cambio de plan de estudios
 ELSEIF pAccion = 'CAMBIO_DE_VERSION' THEN
   _origen := 4; -- Cambio de Version de plan de estudios
 ELSEIF pAccion = 'APLICAR_MATRICES' THEN
   _origen := 1; -- Interna. Aplica a todo (nueva propuesta, cambio de plan, cambio de version de plan)
 ELSE
   _origen := 1; -- Interna Libre
 END IF;
 
 -- Recupero parámetros utilizados en la evaluación de los grupos de equivalencias 
 _ParamControlarCorrelativas := get_valor_parametro_plan('equiv_automatica_controlar_correlativas', _Plan);
 _ParamAjustarNota           := get_valor_parametro_plan('equiv_automatica_ajustar_nota', _Plan);
 _ParamPasarDesaprobados     := get_valor_parametro_plan('equiv_automatica_pasar_desaprobados', _Plan);
 _ParamRegistrarVencOriginal := get_valor_parametro_plan('equiv_automatica_vencimiento_origen', _Plan);
 _ParamPasarRegularidad      := get_valor_parametro_plan('equiv_automatica_pasar_regularidades', _Plan);
 _ParamPasarRegularidadConNota := get_valor_parametro_plan('equiv_automatica_pasar_regularidades_con_nota', _Plan);
 _ParamGenerarTramite        := get_valor_parametro_plan('equiv_automatica_tramites_a_generar_x_alumno', _Plan);


BEGIN -- Comienza la transacción
 DROP TABLE IF EXISTS _TEquiv;
 CREATE TEMP TABLE _TEquiv 
 (
   id Integer,
   matriz Integer,
   grupo_equivalencia Integer,
   elemento Integer,
   instancia integer, -- antes: alcance Char(1) 
   fecha Date,
   escala_nota Integer,
   nota Varchar(10),
   resultado Char(1),
   fecha_vigencia Date,
   temas_a_rendir Text,
   int_propuesta Integer,
   int_elemento Integer,
   int_fecha Date,
   int_nota Varchar(10),
   int_origen Varchar(12),
   int_resultado Char(1)
 );

 -- Recupero las matrices de equivalencias a aplicar
 DROP TABLE IF EXISTS _TMatriz;
 CREATE TEMP TABLE _TMatriz (matriz Integer, propuesta_origen integer, plan_origen integer, plan_version_origen integer);

 -- Tabla que recupera las matrices que en el grupo de equivalencias origen tiene a la actividad pasada por parametro.
 DROP TABLE IF EXISTS _TMatrizActividad;
 CREATE TEMP TABLE _TMatrizActividad (matriz Integer);
 IF pActividad IS NOT NULL THEN
   INSERT INTO _TMatrizActividad (matriz)
   SELECT DISTINCT m.matriz
     FROM sga_equiv_matrices as m, 
          sga_equiv_grupos as g, 
          sga_equiv_actividades as a
    WHERE m.aplicacion_automatica = 'S' 
      AND m.activo = 'S' 
      AND g.matriz = m.matriz
      AND g.activo = 'S' 
      AND a.grupo_equivalencia = g.grupo_equivalencia
      AND a.elemento = pActividad
      AND a.origen_destino = 'O';
 END IF;	  



 -- 1. Alance General
 INSERT INTO _TMatriz (matriz)
    SELECT matriz FROM sga_equiv_matrices  
     WHERE plan_version_destino = _PlanVersion AND aplicacion_automatica = 'S' AND activo = 'S' AND alcance = 'General'  
       AND (pActividad IS NULL OR  matriz IN (SELECT matriz FROM _TMatrizActividad)); -- Donde la actividad es parte del origen de grupo de equivalencias.

 -- Alta en una nueva propuesta
 IF pAccion = 'NUEVA_PROPUESTA' OR pAccion = 'APLICAR_MATRICES' THEN
  
   -- Contra otra propuesta, cualquier plan
   INSERT INTO _TMatriz (matriz, propuesta_origen, plan_origen, plan_version_origen)
       SELECT m.matriz, a.propuesta, pv.plan, a.plan_version
         FROM sga_equiv_matrices as m, 
              sga_alumnos as a,
              sga_planes_versiones as pv
        WHERE m.plan_version_destino = _PlanVersion 
          AND m.aplicacion_automatica = 'S' 
          AND m.activo = 'S' 
          AND m.alcance = 'Propuesta'
          AND a.persona = _Persona
          AND a.alumno <> pAlumno
          AND pv.plan_version = a.plan_version
          AND m.propuesta_origen = a.propuesta  
          AND (pActividad IS NULL OR m.matriz IN (SELECT matriz FROM _TMatrizActividad)); -- Donde la actividad es parte del origen de grupo de equivalencias.

   -- Contra otra propuesta y plan del alumno
   INSERT INTO _TMatriz (matriz, propuesta_origen, plan_origen, plan_version_origen)
       SELECT m.matriz, a.propuesta, pv.plan, a.plan_version 
         FROM sga_equiv_matrices as m, 
              sga_alumnos as a, 
              sga_planes_versiones as pv
        WHERE m.plan_version_destino = _PlanVersion 
          AND m.aplicacion_automatica = 'S' 
          AND m.activo = 'S' 
          AND m.alcance = 'Propuesta-Plan'
          AND a.persona = _Persona
          AND a.alumno <> pAlumno
          AND pv.plan_version = a.plan_version
          AND m.propuesta_origen = a.propuesta
          AND m.plan_origen = pv.plan  
          AND (pActividad IS NULL OR m.matriz IN (SELECT matriz FROM _TMatrizActividad)); -- Donde la actividad es parte del origen de grupo de equivalencias.
          
 END IF;

 -- Cambio de Plan de Estudios
 IF pAccion = 'CAMBIO_DE_PLAN' OR pAccion = 'APLICAR_MATRICES' THEN
   -- Matrices contra cualquier otro plan de la propuesta o contra el plan anterior del alumno
   INSERT INTO _TMatriz (matriz, propuesta_origen, plan_origen, plan_version_origen)
       SELECT m.matriz, pPropuestaOrigen, pPlanOrigen, pPlanVersionOrigen 
         FROM sga_equiv_matrices as m
        WHERE m.plan_version_destino = _PlanVersion 
          AND m.aplicacion_automatica = 'S' 
          AND m.activo = 'S' 
          AND m.alcance = 'Plan'
          AND m.propuesta_origen = pPropuestaOrigen
          AND (m.plan_origen IS NULL OR m.plan_origen = pPlanOrigen)  
          AND (pActividad IS NULL OR m.matriz IN (SELECT matriz FROM _TMatrizActividad)); -- Donde la actividad es parte del origen de grupo de equivalencias.
 END IF;

 -- Cambio de Version de Plan de Estudios
 IF pAccion = 'CAMBIO_DE_VERSION' OR pAccion = 'APLICAR_MATRICES' THEN
   -- Matrices contra cualquier otra version de plan de la propuesta o contra la version anterior del plan del alumno
   INSERT INTO _TMatriz (matriz, propuesta_origen, plan_origen, plan_version_origen)
       SELECT m.matriz, pPropuestaOrigen, pPlanOrigen, pPlanVersionOrigen 
         FROM sga_equiv_matrices as m
        WHERE m.plan_version_destino = _PlanVersion 
          AND m.aplicacion_automatica = 'S' 
          AND m.activo = 'S' 
          AND m.alcance = 'Version'
          AND m.propuesta_origen = pPropuestaOrigen
          AND m.plan_origen = pPlanOrigen
          AND (m.plan_version_origen IS NULL OR m.plan_version_origen = pPlanVersionOrigen)   
          AND (pActividad IS NULL OR m.matriz IN (SELECT matriz FROM _TMatrizActividad)); -- Donde la actividad es parte del origen de grupo de equivalencias.
 END IF;

 _ID := 0;
 -- Recupero las matrices a ejecutar. Matrices de aplicación automática
 FOR cur_matrices IN SELECT DISTINCT matriz, propuesta_origen, plan_origen, plan_version_origen FROM _TMatriz
 LOOP
 
   -- Ejecuto la matriz y cargo las equivalencias en la tabla temporal.
   INSERT INTO _TEquiv (id, matriz, grupo_equivalencia, elemento, instancia, fecha, escala_nota, nota, resultado, fecha_vigencia, 
                        temas_a_rendir, int_propuesta, int_elemento,int_fecha, int_nota, int_origen, int_resultado)
     SELECT * FROM f_equiv_evaluar_matriz(_ID, cur_matrices.matriz, pActividad, true, 
                                          pAlumno, _PlanVersion, _Persona, 
                                          cur_matrices.propuesta_origen, cur_matrices.plan_origen, cur_matrices.plan_version_origen,
                                          _ParamControlarCorrelativas, _ParamAjustarNota, _ParamPasarDesaprobados,
                                          _ParamRegistrarVencOriginal, _ParamPasarRegularidad, _ParamPasarRegularidadConNota);

                                          -- pPropuestaOrigen, pPlanOrigen, pPlanVersionOrigen, 
   SELECT MAX(id) INTO _ID FROM _TEquiv;
   _ID := COALESCE(_ID, 0);
   
 END LOOP; -- Matrices a Ejecutar 
 
 -- Inicializo variables 
 _id_anterior       := -1;
 _matriz_anterior   := -1; 
 _elemento_anterior := -1;
 _equivalencia_tramite := NULL;
 i := 0;
  
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- Registro las equivalencias 
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 FOR cur_equiv IN SELECT * FROM _TEquiv 
                   ORDER BY (CASE _ParamGenerarTramite
                              WHEN 'alumno' THEN id
                              WHEN 'matriz' THEN matriz
                              WHEN 'actividad' THEN elemento
                             END), id
 LOOP              
   i := i + 1;
   
   -- *******************************************************************************
   -- Genero la cabecera del trámite de equivalencias
   -- *******************************************************************************
   IF (_ParamGenerarTramite = 'alumno' AND i = 1) OR
      (_ParamGenerarTramite = 'matriz' AND cur_equiv.matriz <> _matriz_anterior) OR
      (_ParamGenerarTramite = 'actividad' AND cur_equiv.elemento <> _elemento_anterior) THEN

      _documento := NULL;
      _NUA := NULL;
       
      -- Recupero el documento respaldatorio de la matriz de equivalencias.
      IF _ParamGenerarTramite = 'matriz' THEN
           SELECT nro_resolucion INTO _documento FROM sga_equiv_matrices WHERE matriz = cur_equiv.matriz;
      END IF;
      
      --  Nro de resolucion de la version de plan o plan de estudios...     
      IF _documento IS NULL THEN
         IF _documento_version IS NOT NULL THEN
            _documento := _documento_version;
         ELSE   
            _documento := _documento_plan;
         END IF;
      END IF;   
      
      -- institucion, responsable_academica, operador,
      INSERT INTO sga_equiv_tramite (alumno, plan_version, fecha, tipo_tramite, origen, documento, generacion_automatica, matriz_oficial,propuesta, plan, nua, fecha_cierre, estado)
          VALUES (pAlumno, _PlanVersion, _fecha_actual, _TIPO_TRAMITE, _origen, _documento, _AUTOMATICA, _MATRIZ_OFICIAL, pPropuestaOrigen, pPlanOrigen, _NUA, _fecha_actual, _ESTADO_CERRADO);  
      
      -- recupero el serial del tramite      
      _equivalencia_tramite := (SELECT currval('sga_equiv_tramite_seq'));
   END IF;

   -- *******************************************************************************
   -- Inserto la equivalencia 
   -- *******************************************************************************
   IF cur_equiv.id <> _id_anterior THEN
     INSERT INTO sga_equiv_otorgada (equivalencia_tramite, elemento, instancia, fecha, escala_nota, nota, resultado, fecha_vigencia, temas_a_rendir, grupo_equivalencia)
          VALUES (_equivalencia_tramite, cur_equiv.elemento, cur_equiv.instancia, cur_equiv.fecha, cur_equiv.escala_nota, cur_equiv.nota, 
                  cur_equiv.resultado, cur_equiv.fecha_vigencia, cur_equiv.temas_a_rendir, cur_equiv.grupo_equivalencia);
        
      -- Recupero el serial de la equivalencia  
      _equivalencia := (SELECT currval('sga_equiv_otorgada_seq'));
      _id_anterior  := cur_equiv.id;

      _cant_equiv := _cant_equiv + 1;
   END IF;
   
   -- *******************************************************************************
   -- Inserto el origen de las equivalencias
   -- Se supone que siempre trae al menos un registro que indica el origen de la equivalencia.
   -- *******************************************************************************
   IF cur_equiv.id = _id_anterior THEN
     -- Cuando el grupo de equivalencias es N a 1 o N a M, habrá mas de un origen de la equivalencia...
     IF cur_equiv.int_propuesta IS NOT NULL AND cur_equiv.int_elemento IS NOT NULL THEN
       INSERT INTO sga_equiv_internas (equivalencia, propuesta, elemento, fecha, nota, resultado, origen)
          VALUES (_equivalencia, cur_equiv.int_propuesta, cur_equiv.int_elemento, cur_equiv.int_fecha, cur_equiv.int_nota, cur_equiv.int_resultado, cur_equiv.int_origen);
     END IF;     
   END IF;
   
   -- Actualizo valores
   _matriz_anterior   := cur_equiv.matriz;
   _id_anterior       := cur_equiv.id;
   _elemento_anterior := cur_equiv.elemento;
   
 END LOOP;
  
 -- Borro tabla temporal 
 DROP TABLE IF EXISTS _TEquiv;
 DROP TABLE IF EXISTS _TMatriz;
  
 -- Bloque de excepciones 
 EXCEPTION
   WHEN OTHERS THEN
     _rtn.resultado := -1;
     _rtn.sqlerrm   := SQLERRM;
     _rtn.sqlstate  := SQLSTATE;
     RETURN _rtn;
    
END; -- Fin Transacción

 -- Sale OK
 IF _cant_equiv > 0 THEN
   _rtn.resultado := _cant_equiv;
 ELSE
   _rtn.resultado := 1;
 END IF;

 RETURN _rtn;
  
END;
$$;
