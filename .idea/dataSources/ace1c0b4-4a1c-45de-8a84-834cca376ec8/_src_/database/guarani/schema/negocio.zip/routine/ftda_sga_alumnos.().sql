create function negocio.ftda_sga_alumnos() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE _cnt smallint;
BEGIN

  -- Borro el tipo de usuario asociado a la persona si la misma no se encuentra en otra propuesta
  SELECT COUNT(*) INTO _cnt 
    FROM sga_alumnos
   WHERE persona = OLD.persona
     AND propuesta <> OLD.propuesta;
  IF _cnt = 0 THEN
    DELETE FROM mdp_personas_tipo_usuario WHERE persona = OLD.persona AND tipo_usuario = 'Alumno';
  END IF;

  RETURN OLD;
END;
$$;
