create function negocio.f_instancias_comision_id(pcomision integer) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  cnt smallint;
  _retorno  text;
  cur1 record;
        
  BEGIN
   cnt := 0;	
   _retorno := NULL;
		
  -- Recupero el id de las instancias de la comision
  FOR cur1 IN SELECT sga_instancias.instancia as instancia
                FROM sga_comisiones_instancias, sga_instancias
               WHERE sga_comisiones_instancias.comision = pComision
                 AND sga_comisiones_instancias.instancia = sga_instancias.instancia
  LOOP
      IF cnt = 0 THEN		
         _retorno :=  cur1.instancia;
      ELSE
         _retorno :=  _retorno || ',' || cur1.instancia;
      END IF;   
      cnt := cnt + 1;
  END LOOP;
	
  RETURN _retorno;
    
  END;
$$;
