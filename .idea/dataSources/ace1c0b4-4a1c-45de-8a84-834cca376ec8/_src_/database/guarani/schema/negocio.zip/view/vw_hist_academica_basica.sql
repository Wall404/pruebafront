CREATE VIEW vw_hist_academica_basica AS SELECT sga_comisiones.elemento,
    sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.tipo_acta,
    sga_actas.origen,
    sga_actas.comision,
    sga_actas.llamado_mesa,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS equivalencia,
    NULL::integer AS reconocimiento_nro_tramite,
    NULL::integer AS reconocimiento_act,
    sga_alumnos.persona,
    alu2.alumno,
    sga_actas_detalle.alumno AS alumno2,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    'N'::text AS homologada
   FROM ((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.alumno = sga_alumnos.alumno)))
     JOIN negocio.sga_actas ON ((sga_actas.id_acta = sga_actas_detalle.id_acta)))
     JOIN negocio.sga_comisiones ON ((sga_comisiones.comision = sga_actas.comision)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_comisiones.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_actas_detalle.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
  WHERE (((((sga_actas.estado = 'C'::bpchar) AND (sga_actas.origen = 'P'::bpchar)) AND (sga_actas_detalle.estado = 'A'::bpchar)) AND (sga_actas_detalle.rectificado = 'N'::bpchar)) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_mesas_examen.elemento,
    sga_actas.id_acta,
        CASE sga_actas.tipo_acta
            WHEN 'N'::bpchar THEN sga_actas.id_acta
            WHEN 'R'::bpchar THEN sga_actas.acta_referencia
            ELSE NULL::integer
        END AS id_acta_original,
    sga_actas.tipo_acta,
    sga_actas.origen,
    sga_actas.comision,
    sga_actas.llamado_mesa,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS equivalencia,
    NULL::integer AS reconocimiento_nro_tramite,
    NULL::integer AS reconocimiento_act,
    sga_alumnos.persona,
    alu2.alumno,
    sga_actas_detalle.alumno AS alumno2,
    sga_actas_detalle.plan_version,
    sga_actas_detalle.instancia,
    sga_actas_detalle.fecha,
    sga_actas_detalle.fecha_vigencia,
    sga_actas_detalle.escala_nota,
    sga_actas_detalle.nota,
    sga_actas_detalle.resultado,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    'N'::text AS homologada
   FROM (((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_actas_detalle ON ((sga_actas_detalle.alumno = sga_alumnos.alumno)))
     JOIN negocio.sga_actas ON ((sga_actas.id_acta = sga_actas_detalle.id_acta)))
     JOIN negocio.sga_llamados_mesa ON ((sga_llamados_mesa.llamado_mesa = sga_actas.llamado_mesa)))
     JOIN negocio.sga_mesas_examen ON ((sga_mesas_examen.mesa_examen = sga_llamados_mesa.mesa_examen)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_mesas_examen.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_actas_detalle.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
  WHERE ((((((sga_actas.estado = 'C'::bpchar) AND (sga_actas.origen = 'E'::bpchar)) AND (sga_actas_detalle.estado = 'A'::bpchar)) AND (sga_actas_detalle.rectificado = 'N'::bpchar)) AND (sga_actas_detalle.instancia = ANY (ARRAY[3, 4, 7]))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_equiv_otorgada.elemento,
    NULL::integer AS id_acta,
    NULL::integer AS id_acta_original,
    NULL::character(1) AS tipo_acta,
    'B'::bpchar AS origen,
    NULL::integer AS comision,
    NULL::integer AS llamado_mesa,
    sga_equiv_tramite.equivalencia_tramite,
        CASE sga_equiv_tramite.tipo_tramite
            WHEN 'N'::bpchar THEN sga_equiv_tramite.equivalencia_tramite
            WHEN 'R'::bpchar THEN sga_equiv_tramite.rectifica_a
            ELSE NULL::integer
        END AS equivalencia_tramite_original,
    sga_equiv_tramite.tipo_tramite,
    sga_equiv_otorgada.equivalencia,
    NULL::integer AS reconocimiento_nro_tramite,
    NULL::integer AS reconocimiento_act,
    sga_alumnos.persona,
    alu2.alumno,
    sga_equiv_tramite.alumno AS alumno2,
    sga_equiv_tramite.plan_version,
    sga_equiv_otorgada.instancia,
    sga_equiv_otorgada.fecha,
    sga_equiv_otorgada.fecha_vigencia,
    sga_equiv_otorgada.escala_nota,
    sga_equiv_otorgada.nota,
    sga_equiv_otorgada.resultado,
    sga_elementos_plan.creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    'N'::text AS homologada
   FROM (((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_equiv_tramite ON ((sga_equiv_tramite.alumno = sga_alumnos.alumno)))
     JOIN negocio.sga_equiv_otorgada ON ((sga_equiv_otorgada.equivalencia_tramite = sga_equiv_tramite.equivalencia_tramite)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_equiv_otorgada.elemento)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_equiv_tramite.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
  WHERE ((((((sga_equiv_tramite.estado = 'C'::bpchar) AND (sga_equiv_otorgada.instancia = 10)) AND (sga_equiv_otorgada.rectificado = 'N'::bpchar)) AND (sga_equiv_otorgada.estado = 'A'::bpchar)) AND (sga_equiv_otorgada.resultado = ANY (ARRAY['A'::bpchar, 'R'::bpchar]))) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))))
UNION ALL
 SELECT sga_reconocimiento_act.elemento,
    NULL::integer AS id_acta,
    NULL::integer AS id_acta_original,
    NULL::character(1) AS tipo_acta,
    'A'::bpchar AS origen,
    NULL::integer AS comision,
    NULL::integer AS llamado_mesa,
    NULL::integer AS equivalencia_tramite,
    NULL::integer AS equivalencia_tramite_original,
    NULL::character(1) AS tipo_tramite,
    NULL::integer AS equivalencia,
    sga_reconocimiento_act.nro_tramite AS reconocimiento_nro_tramite,
    sga_reconocimiento_act.reconocimiento_act,
    sga_alumnos.persona,
    alu2.alumno,
    sga_reconocimiento.alumno AS alumno2,
    sga_reconocimiento.plan_version,
    NULL::integer AS instancia,
    sga_reconocimiento.fecha,
    NULL::date AS fecha_vigencia,
    sga_reconocimiento_act.escala_nota,
    sga_reconocimiento_act.nota,
    'A'::bpchar AS resultado,
    COALESCE(sga_reconocimiento_act.creditos, sga_elementos_plan.creditos) AS creditos,
        CASE
            WHEN (sga_alumnos.alumno <> alu2.alumno) THEN true
            ELSE false
        END AS origen_otra_propuesta,
    sga_reconocimiento_act.homologada
   FROM (((((((negocio.sga_alumnos alu2
     JOIN negocio.sga_alumnos ON ((sga_alumnos.persona = alu2.persona)))
     JOIN negocio.sga_reconocimiento ON ((sga_reconocimiento.alumno = sga_alumnos.alumno)))
     JOIN negocio.sga_reconocimiento_act ON ((sga_reconocimiento_act.nro_tramite = sga_reconocimiento.nro_tramite)))
     JOIN negocio.sga_elementos ON ((sga_elementos.elemento = sga_reconocimiento_act.elemento)))
     JOIN negocio.sga_elementos_revision ON ((sga_elementos_revision.elemento = sga_elementos.elemento)))
     JOIN negocio.sga_g3entidades_subtipos ON ((sga_g3entidades_subtipos.entidad_subtipo = sga_elementos.entidad_subtipo)))
     LEFT JOIN negocio.sga_elementos_plan ON (((sga_elementos_plan.plan_version = sga_reconocimiento.plan_version) AND (sga_elementos_plan.elemento_revision = sga_elementos_revision.elemento_revision))))
  WHERE ((((sga_reconocimiento.estado = 'C'::bpchar) AND (sga_reconocimiento_act.reconocimiento_total = 'S'::bpchar)) AND (sga_g3entidades_subtipos.entidad_tipo = 2)) AND ((alu2.alumno = sga_alumnos.alumno) OR (alu2.plan_version IN ( SELECT ep2.plan_version
           FROM negocio.sga_elementos_plan ep2
          WHERE (ep2.elemento_revision = sga_elementos_revision.elemento_revision)))));
