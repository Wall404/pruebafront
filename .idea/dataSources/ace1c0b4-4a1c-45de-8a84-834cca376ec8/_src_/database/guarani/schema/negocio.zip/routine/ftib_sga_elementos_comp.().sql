create function negocio.ftib_sga_elementos_comp() returns trigger
LANGUAGE plpgsql
AS $$
DECLARE
BEGIN
    
   -- verifico que se haya cargado alguno de los hijos.
   IF NEW.elemento_hijo IS NULL THEN
      RAISE EXCEPTION 'Es obligatorio ingresar una actividad o un módulo a la composición de la revisión del elemento.';
   END IF;
   
   RETURN NEW;
END;
$$;
