create function negocio.unpaz_f_criterio_cursa_primera_vez(_alumno integer, _elemento integer, _periodo_lectivo integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _cnt integer;

BEGIN
	_cnt := 0;
	-- Cuenta inscripciones anteriores a la actividad
	SELECT COUNT(*) INTO _cnt
	FROM negocio.sga_insc_cursada
	join negocio.sga_comisiones on (sga_insc_cursada.comision = sga_comisiones.comision)
	where sga_insc_cursada.alumno = _alumno
	and sga_comisiones.elemento = _elemento
	and sga_comisiones.periodo_lectivo <> _periodo_lectivo;

/*LAURA: fijarse que el alumno tenga las correlativas anteriores aprobadas*/
  
	IF _cnt > 0 THEN
	-- Tiene inscripciones anteriores
	RETURN 1;
	ELSE
	-- No tiene inscripciones anteriores
	RETURN 0;
	END IF;
END;
$$;
