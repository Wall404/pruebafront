create function negocio.get_elemento_contenido(integer, integer, boolean, boolean) returns SETOF negocio.type_plan_contenido
LANGUAGE plpgsql
AS $$
DECLARE 

id__revision ALIAS for $1;
id__plan_version ALIAS for $2;
mostrarme ALIAS for $3;
mostrar_hijos ALIAS for $4;
elementos record;
BEGIN
	FOR elementos IN 	
		SELECT 	orden_arbol,
			elemento_revision,
			elemento,
			codigo,
			nombre,
			entidad_tipo,
			entidad_subtipo,
			entidad_clase_gui,
			elemento_comp,
			elemento_revision_padre,
			elemento_padre,
			orden
		FROM get_elemento_contenido( id__revision, id__plan_version, mostrarme, mostrar_hijos, true)
	LOOP
		RETURN NEXT elementos;
	END LOOP;
END;
$$;
