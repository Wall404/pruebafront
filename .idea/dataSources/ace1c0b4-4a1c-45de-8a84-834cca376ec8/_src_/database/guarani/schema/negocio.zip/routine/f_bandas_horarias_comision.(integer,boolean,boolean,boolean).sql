create function negocio.f_bandas_horarias_comision(pcomision integer, pconhorario boolean, pcontipoclase boolean, pdiaabreviado boolean) returns text
LANGUAGE plpgsql
AS $$
DECLARE 
  _horario text;
  _clase text;
  _dia varchar(10);
  _horainiciofin varchar(15); 
  i smallint;     
  cur_bh record;
BEGIN
  
  _horario := '';
  i := 0;
  FOR cur_bh IN 
   (
   SELECT sga_asignaciones.dia_semana as dia_semana,
          to_char(sga_asignaciones.hora_inicio, 'HH24:MI') as inicio,
          to_char(sga_asignaciones.hora_finalizacion, 'HH24:MI') as fin,
          sga_clases_tipos.nombre as tipo_clase
     FROM sga_comisiones_bh,
          sga_asignaciones,
          sga_clases_tipos
      WHERE sga_comisiones_bh.comision = pComision
        AND sga_asignaciones.asignacion = sga_comisiones_bh.asignacion
        AND sga_clases_tipos.tipo_clase = sga_comisiones_bh.tipo_clase
     ORDER BY CASE sga_asignaciones.dia_semana
                WHEN 'Lunes' THEN 1
                WHEN 'Martes' THEN 2
                WHEN 'Miercoles' THEN 3
                WHEN 'Jueves' THEN 4
                WHEN 'Viernes' THEN 5
                WHEN 'Sabado' THEN 6
                WHEN 'Domingo' THEN 7
                ELSE 0
              END, 2   
        
   )
  LOOP
   IF i > 0 THEN
    _horario := _horario || ' - ' ;
   END IF;
   
   _horainiciofin := '';  
   _clase := '';  
   
   IF pDiaAbreviado THEN
     _dia := substring(cur_bh.dia_semana from 1 for 3);
   ELSE
     _dia := cur_bh.dia_semana;
   END IF;
   IF pConHorario THEN
     _horainiciofin := ' ' || cur_bh.inicio || ' a ' || cur_bh.fin;
   END IF;
   IF pConTipoClase THEN
     _clase := ' (' || cur_bh.tipo_clase || ')';
   END IF;
   
   _horario := _horario || _dia || _horainiciofin || _clase;
   i := i + 1;
  END LOOP;
    
  -- Retorno los dias y horarios de la subcomision
  RETURN _horario;
    
END;
$$;
