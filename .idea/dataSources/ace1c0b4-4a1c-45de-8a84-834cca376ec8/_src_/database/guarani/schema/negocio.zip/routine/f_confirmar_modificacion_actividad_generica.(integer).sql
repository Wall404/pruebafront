create function negocio.f_confirmar_modificacion_actividad_generica(pgenerica integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE 
  _revision_generica  Integer;
  optativas record;
  _orden Integer;
     
BEGIN
      
  -- Obtengo la revisión de la materia genérica.
  SELECT elemento_revision INTO _revision_generica
    FROM sga_elementos_revision
   WHERE elemento = pGenerica;
  
  -- Recupero el maximo orden de las optativas   
  SELECT MAX(orden) INTO _orden 
    FROM sga_elementos_revision,
         sga_elementos_comp
   WHERE sga_elementos_revision.elemento = pGenerica
     AND sga_elementos_comp.elemento_padre = sga_elementos_revision.elemento_revision;
  IF _orden IS NULL OR _orden <= 0 THEN
    _orden := 1;
  END IF;  
  
  -- ----------------------------------------------------------------------------------
  -- 1. Recorro cada una de las optativas que fueron agregadas a la generica
  -- ----------------------------------------------------------------------------------

  -- recupero las optativas agregadas ordenadas por nombre.
  FOR optativas IN 
         SELECT sga_elementos_comp_aux.elemento_comp as elemento_comp,
                sga_elementos_comp_aux.elemento_padre as elemento_padre,
                sga_elementos_comp_aux.elemento_hijo as revision_optativa,
                sga_elementos_comp_aux.puntaje as puntaje
           FROM sga_elementos_comp_aux,
                sga_elementos_revision,
                sga_elementos
          WHERE sga_elementos_comp_aux.elemento_padre = _revision_generica
            AND sga_elementos_comp_aux.elemento_hijo = sga_elementos_revision.elemento_revision
            AND sga_elementos.elemento = sga_elementos_revision.elemento
       ORDER BY sga_elementos.nombre ASC
  LOOP     

     -- Inserto la optativa en la genérica 
     _orden := _orden + 1;
     INSERT INTO sga_elementos_comp (elemento_comp, elemento_padre, elemento_hijo, puntaje, orden)
         VALUES (optativas.elemento_comp, optativas.elemento_padre, optativas.revision_optativa, optativas.puntaje, _orden);

     -- Paso los atributos de la optativa por cada version de plan de estudios en la que se encuentra la genérica
     -- Solo para optativas que NO estan en el plan de estudios con anterioridad.
     INSERT INTO sga_elementos_plan (
              elemento_plan,
              plan_version,
              elemento_revision,
              nombre,
              nombre_abreviado,
              anio_de_cursada,
              periodo_de_cursada,
              escala_nota_cursada_regular,
              escala_nota_cursada_promocion,
              escala_nota_examen,
              escala_nota_equivalencia,
              creditos,
              creditos_min,
              creditos_max,
              coeficiente,
              horas_semanales,
              horas_totales,
              requiere_cursada,
              requiere_examen,
              permite_promocion,
              permite_rendir_libre,
              aprobacion_x_resolucion,
              vigencia,
              plazo,
              promediable,
              sale_listado,
              cantidad_de_aplazos,
			  cobrable)
       SELECT 
              elemento_plan,
              plan_version,
              elemento_revision,
              nombre,
              nombre_abreviado,
              anio_de_cursada,
              periodo_de_cursada,
              escala_nota_cursada_regular,
              escala_nota_cursada_promocion,
              escala_nota_examen,
              escala_nota_equivalencia,
              creditos,
              creditos_min,
              creditos_max,
              coeficiente,
              horas_semanales,
              horas_totales,
              requiere_cursada,
              requiere_examen,
              permite_promocion,
              permite_rendir_libre,
              aprobacion_x_resolucion,
              vigencia,
              plazo,
              promediable,
              sale_listado,
              cantidad_de_aplazos,
			  cobrable
        FROM sga_elementos_plan_aux
       WHERE elemento_revision  = optativas.revision_optativa
         AND optativa_existe_en_plan = 'N';

       -- Inserto modalidad de Cursada de cada optativa
       INSERT INTO sga_elementos_plan_modalidad (elemento_plan, modalidad)
          SELECT m.elemento_plan, m.modalidad
            FROM sga_elementos_plan_aux as e,
                 sga_elementos_plan_modalidad_aux as m
           WHERE e.elemento_revision  = optativas.revision_optativa
             AND e.optativa_existe_en_plan = 'N'
             AND m.elemento_plan  = e.elemento_plan;

  END LOOP;  -- Optativas 

  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- 2. Borro Optativas de las tablas auxiliares.
  --    Solo las optativas que esten por esta genérica y no por otra generica a la vez.
  -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  
  -- Recupero solo las optativas agregadas a la genérica que no estan agregadas a otra genérica
  -- y editandose al mismo momento.
  CREATE TEMP TABLE _temp_opt (elemento_revision integer NOT NULL);
  CREATE TEMP TABLE _temp_opt_otra_generica (elemento_revision integer NOT NULL);
  
  INSERT INTO _temp_opt (elemento_revision)
     SELECT elemento_hijo
       FROM sga_elementos_comp_aux
      WHERE elemento_padre = _revision_generica
        AND NOT EXISTS (SELECT d.elemento_hijo 
                          FROM sga_elementos_comp_aux as d 
                         WHERE d.elemento_hijo = sga_elementos_comp_aux.elemento_hijo 
                           AND d.elemento_padre <> _revision_generica);

  -- optitivas que estan agregadas en mas de una generica temporalmente. 
  INSERT INTO _temp_opt_otra_generica (elemento_revision)
     SELECT elemento_hijo
       FROM sga_elementos_comp_aux
      WHERE elemento_padre = _revision_generica
     EXCEPT
     SELECT elemento_revision FROM _temp_opt;
  
  -- Actualizo la tabla temporal de atributos de las optativas cambiando a que la optativa existira ahora en el plan
  -- Solo de las versiones de plan donde esta la generica que se esta confirmando su modificacion.
  -- Las otras genéricas que comparten las optativas modificadas podrian estar en otros planes que no se encuentre
  -- la genérica que se esta modificando.
  UPDATE sga_elementos_plan_aux
     SET optativa_existe_en_plan = 'S'
   WHERE elemento_revision IN (SELECT elemento_revision FROM _temp_opt_otra_generica)
     AND plan_version IN (SELECT plan_version FROM sga_elementos_plan WHERE elemento_revision = _revision_generica);
  
  -- Modalidad de cursada de las optativas por cada plan
  DELETE FROM sga_elementos_plan_modalidad_aux 
        WHERE elemento_plan IN (SELECT a.elemento_plan 
                                  FROM sga_elementos_plan_aux as a, _temp_opt as t
                                 WHERE t.elemento_revision = a.elemento_revision);

  -- Optativas en el Plan                                     
  DELETE FROM sga_elementos_plan_modalidad_aux  
        WHERE elemento_plan IN (SELECT a.elemento_plan 
                                  FROM sga_elementos_plan_aux as a, _temp_opt as t
                                 WHERE t.elemento_revision = a.elemento_revision);

  -- Solo borro los atributos de las optativas de la generica que solo estan editandose por esta genérica
  DELETE FROM sga_elementos_plan_aux 
        WHERE elemento_revision IN (SELECT elemento_revision FROM _temp_opt);

  -- Borro las optativas de la generica
  DELETE FROM sga_elementos_comp_aux WHERE elemento_padre = _revision_generica;
 
 
  -- Borro tablas temporales
  DROP TABLE _temp_opt;
  DROP TABLE _temp_opt_otra_generica;
 
-- Salgo de la funcion.
RETURN;
 
END;
$$;
