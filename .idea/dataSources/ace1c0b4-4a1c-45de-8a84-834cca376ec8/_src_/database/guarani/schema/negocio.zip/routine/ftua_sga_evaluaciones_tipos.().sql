create function negocio.ftua_sga_evaluaciones_tipos() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- No permito cambiar el valor del campo "automatico"
   IF (NEW.automatica <> OLD.automatica) THEN
      RAISE EXCEPTION 'No se puede cambiar el valor del campo "Automático".';
   END IF;     
   RETURN NEW;
  END;
$$;
