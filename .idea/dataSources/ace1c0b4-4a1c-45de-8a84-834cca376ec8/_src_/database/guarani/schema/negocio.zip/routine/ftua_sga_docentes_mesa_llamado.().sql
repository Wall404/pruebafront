create function negocio.ftua_sga_docentes_mesa_llamado() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN

  -- Si cambia el rol del docente en la mesa
  IF OLD.rol <> NEW.rol THEN
    -- Borro los derechos asignados al docente en la mesa
    DELETE FROM gdu_derechos_personas
       USING sga_llamados_mesa, 
             sga_docentes
       WHERE sga_llamados_mesa.llamado_mesa = OLD.llamado_mesa
         AND sga_docentes.docente = OLD.docente
         AND gdu_derechos_personas.entidad = sga_llamados_mesa.entidad
         AND gdu_derechos_personas.persona = sga_docentes.persona;

      -- Pego los derechos del rol del docente.    
      INSERT INTO gdu_derechos_personas (entidad, derecho, persona)
           SELECT sga_llamados_mesa.entidad, 
                  gdu_mesa_examen.derecho, 
                  sga_docentes.persona
             FROM sga_llamados_mesa,
                  sga_docentes,
                  gdu_mesa_examen
            WHERE sga_llamados_mesa.llamado_mesa = NEW.llamado_mesa
              AND gdu_mesa_examen.rol = NEW.rol
              AND sga_docentes.docente = NEW.docente;
  END IF;     

  RETURN NEW;
END;
$$;
