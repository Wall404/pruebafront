create function negocio.f_es_ingresante_periodos_insc_cursada(palumno integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _anio_ingreso integer;
 DECLARE _anio_academico_periodo_insc_cursada integer;
 DECLARE _plan_version_alumno INTEGER;
 DECLARE _es_ingresante smallint;

BEGIN
 _anio_ingreso := NULL;
 _anio_academico_periodo_insc_cursada := NULL;
 _es_ingresante := 0;

 -- Recupero el año académico de la inscripción a propuesta del alumno en estado Aceptada o Pendiente
 SELECT sga_propuestas_aspira.anio_academico, sga_alumnos.plan_version
   INTO _anio_ingreso, _plan_version_alumno
  FROM sga_alumnos, 
       sga_propuestas_aspira,
       sga_situacion_aspirante
  WHERE sga_alumnos.alumno = pAlumno
    AND sga_propuestas_aspira.persona   = sga_alumnos.persona
    AND sga_propuestas_aspira.propuesta = sga_alumnos.propuesta
    AND sga_situacion_aspirante.situacion_asp = sga_propuestas_aspira.situacion_asp
    AND sga_situacion_aspirante.resultado_asp IN ('A','P');
 
 -- Recupero el año académico de las inscripciones a cursdas de periodos lectivos vigentes para el alumno.
 -- Tomo el 1ero que encuentro en orden descendente
 SELECT sga_periodos.anio_academico 
   INTO _anio_academico_periodo_insc_cursada
   FROM sga_periodos_inscripcion_fechas,
        sga_periodos_inscripcion_aplanado,
        sga_periodos_inscripcion,
        sga_periodos
  WHERE CURRENT_DATE BETWEEN sga_periodos_inscripcion_fechas.fecha_inicio AND sga_periodos_inscripcion_fechas.fecha_fin
    AND sga_periodos_inscripcion.periodo_inscripcion = sga_periodos_inscripcion_fechas.periodo_inscripcion
    AND sga_periodos_inscripcion.periodo_generico_tipo = 1  
    AND sga_periodos.periodo = sga_periodos_inscripcion.periodo
    AND sga_periodos_inscripcion_aplanado.periodo_insc = sga_periodos_inscripcion_fechas.periodo_insc
    AND sga_periodos_inscripcion_aplanado.plan_version = _plan_version_alumno
  ORDER BY sga_periodos.anio_academico DESC
  LIMIT 1;
 
   
 -- Si los años academicos coinciden o el período de inscripcion a cursada es menor al año de ingreso entonces es un alumno ingresante.   
 IF _anio_ingreso = _anio_academico_periodo_insc_cursada OR _anio_ingreso > _anio_academico_periodo_insc_cursada THEN
    _es_ingresante := 1;
 END IF;

 -- Retorna si es ingresante o no.
 RETURN _es_ingresante;
 
END;
$$;
