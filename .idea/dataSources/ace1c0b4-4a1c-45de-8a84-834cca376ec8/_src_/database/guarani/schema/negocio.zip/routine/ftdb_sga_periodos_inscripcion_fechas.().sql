create function negocio.ftdb_sga_periodos_inscripcion_fechas() returns trigger
LANGUAGE plpgsql
AS $$
-- Variables locales
DECLARE _tipo smallint;

BEGIN
  -- Borro excepciones al periodo de inscripcion en el caso que existan
  SELECT sga_periodos_inscripcion.periodo_generico_tipo 
    INTO _tipo
    FROM sga_periodos_inscripcion
   WHERE sga_periodos_inscripcion.periodo_inscripcion = OLD.periodo_inscripcion;
   
   -- tipo: 1 = Período Lectivo / 2 = Turno de Examen / 3 - Llamado / 4 - Propuestas
   IF _tipo = 1 THEN
     -- Excepciones a los periodos de inscripcion de los períodos lectivos
     DELETE FROM sga_comisiones_excep_perinsc WHERE periodo_insc = OLD.periodo_insc;
   END IF;
   
   IF _tipo = 3 THEN
     -- Excepciones a los periodos de inscripcion de los llamados
     DELETE FROM sga_llamados_mesa_excep_perinsc WHERE periodo_insc = OLD.periodo_insc;
   END IF;
   
  RETURN OLD;
END;
$$;
