create function negocio.f_criterio_tiene_hijos(ppersona integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _Hijos integer;
 
BEGIN
  _Hijos := 1; -- No tiene hijos
  
  -- Recupero cantidad de hijos...   
  SELECT mdp_datos_personales.cantidad_hijos 
    INTO _Hijos
    FROM mdp_datos_censales, 
         mdp_datos_personales
   WHERE mdp_datos_censales.persona = pPersona
     AND mdp_datos_personales.dato_censal = mdp_datos_censales.dato_censal;
     
  IF _Hijos > 0 THEN
    -- Tiene Hijos
    RETURN 0;
  ELSE  
    -- No tiene Hijos
    RETURN 1;
  END IF;  

END;
$$;
