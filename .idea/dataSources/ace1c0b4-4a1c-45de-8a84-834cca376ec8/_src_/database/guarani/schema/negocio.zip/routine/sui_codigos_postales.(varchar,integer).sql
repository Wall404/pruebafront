create function negocio.sui_codigos_postales(p_codigo_postal character varying, p_localidad integer) returns void
LANGUAGE plpgsql
AS $$
BEGIN

  -- Inserta el codigo postal y localidad
  INSERT INTO mug_cod_postales (codigo_postal, localidad) VALUES (p_codigo_postal, p_localidad);

  EXCEPTION 
    WHEN unique_violation THEN
       -- Existe el codigo postal y localidad, no hace nada
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Código Postal: %. Localidad: %. Error Nro: %. %', p_codigo_postal, p_localidad, SQLSTATE, SQLERRM;   
END;
$$;
