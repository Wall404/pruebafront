create function negocio.sui_departamentos_partidos(p_dpto_partido integer, p_nombre character varying, p_provincia integer, p_estado character) returns void
LANGUAGE plpgsql
AS $$
DECLARE vLocalidadIndet    Integer;

BEGIN

  -- Genera el número de localidad indeterminada para el departamento
  vLocalidadIndet := p_dpto_partido;
  
  -- Inserta el departamento / partido
  INSERT INTO mug_dptos_partidos ( dpto_partido, nombre, provincia, estado) 
       VALUES (p_dpto_partido, p_nombre, p_provincia, p_estado );
 
  -- Cataloga la localidad indeterminada, sin permitir actualizaciones
  -- ya que, si existía la localidad, no podía ser la inteterminada del departamento, porque este no existía
  PERFORM sui_localidades (vLocalidadIndet, 'Indeterminada', 'Indeterminada', p_dpto_partido, NULL);

 -- Existe el departamento, entonces lo actualizo
 EXCEPTION 
    WHEN unique_violation THEN
       UPDATE mug_dptos_partidos  SET (nombre, provincia, estado) = (p_nombre, p_provincia, p_estado) WHERE dpto_partido = p_dpto_partido;

       -- Actualiza la localidad indeterminada para el departamento
       --PERFORM sui_localidades ( vLocalidadIndet, 'Indeterminada', 'Indeterminada', p_dpto_partido, NULL);  --> no existe esto ya?
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Depto/Partido: % - %.Error Nro: %. %',p_dpto_partido, p_nombre, SQLSTATE, SQLERRM;   

END;
$$;
