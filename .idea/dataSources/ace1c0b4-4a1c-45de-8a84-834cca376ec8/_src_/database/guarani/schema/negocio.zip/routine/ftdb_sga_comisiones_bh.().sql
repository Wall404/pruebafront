create function negocio.ftdb_sga_comisiones_bh() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
   -- Borro las clases de la banda horaria
   DELETE FROM sga_clases WHERE banda_horaria = OLD.banda_horaria;
   
   RETURN OLD;
END;
$$;
