create function negocio.sui_continentes(p_continente character varying, p_nombre character varying) returns void
LANGUAGE plpgsql
AS $$
BEGIN

  -- Inserta el continente
  INSERT INTO mug_continentes (continente, nombre) VALUES (p_continente, p_nombre);
  
  -- Existe el continente, entonces lo actualizo
  EXCEPTION 
     WHEN unique_violation THEN
        -- Actualiza el continente
        UPDATE mug_continentes  SET nombre = p_nombre  WHERE continente = p_continente;
    WHEN OTHERS THEN
       RAISE EXCEPTION 'Error Nro: %. %',SQLSTATE, SQLERRM;   

END;
$$;
