create function negocio.get_institucion_instalacion() returns integer
LANGUAGE plpgsql
AS $$
DECLARE
	_inst integer;
BEGIN
  _inst := NULL;
	SELECT cast(valor as integer) INTO _inst
	  FROM negocio.par_configuraciones 
	 WHERE nombre = 'institucion_instalacion';

	RETURN _inst;
END;
$$;
