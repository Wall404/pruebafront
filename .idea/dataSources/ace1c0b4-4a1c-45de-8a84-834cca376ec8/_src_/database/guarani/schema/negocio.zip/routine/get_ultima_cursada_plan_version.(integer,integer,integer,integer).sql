create function negocio.get_ultima_cursada_plan_version(palumno integer, pactividad integer, paprobada integer, pvigente integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _retorno  integer;
  cur1 record;

BEGIN
  -- Retorna Version del Plan de estudios
  _retorno := NULL;

  -- Recupero las cursadas ordenadas en forma descendente considerando primera la ultma cursada
  FOR cur1 IN
        SELECT vw_regularidades_basica.plan_version, vw_regularidades_basica.resultado, vw_regularidades_basica.es_vigente
          FROM vw_regularidades_basica 
          WHERE vw_regularidades_basica.alumno   = pAlumno
            AND vw_regularidades_basica.elemento = pActividad
            AND vw_regularidades_basica.origen IN ('R', 'P') -- Acta de Regularidad y/o Promoción.
          ORDER BY vw_regularidades_basica.fecha DESC
  LOOP
    IF (pAprobada <> 1 OR (pAprobada = 1 AND cur1.resultado = 'A')) AND
       (pVigente  <> 1 OR (pVigente = 1  AND cur1.es_vigente = 1 )) THEN
       -- Si encontró la condición buscada salgo del FOR.
      _retorno := cur1.plan_version;
      EXIT;
    END IF; 
  END LOOP;

  RETURN _retorno;

END;
$$;
