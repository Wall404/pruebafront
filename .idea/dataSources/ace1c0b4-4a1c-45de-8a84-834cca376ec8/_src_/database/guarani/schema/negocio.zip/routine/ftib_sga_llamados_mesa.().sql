create function negocio.ftib_sga_llamados_mesa() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	   -- Genera un registro en la tabla de entidades..
       NEW.entidad := f_generar_entidad(401);
       RETURN NEW;
  END;
$$;
