create function negocio.f_copiar_correlativa(pactividadorigen integer, pplanversionorigen integer, pactividaddestino integer, pplanversiondestino integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _entidad_destino integer;
  _condicion_new integer;
  _cnt integer;
  _grupo_new integer;
  cur_cond record;
  cur_grupo record;
  
BEGIN

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- Si es la misma actividad y Version de Plan no se copia nada.
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
IF pActividadOrigen = pActividadDestino AND pPlanVersionOrigen = pPlanVersionDestino THEN
  RETURN -1;
END IF;

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- Si la actividad no existe en la version del Plan destino, no se copia nada.
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SELECT COUNT(*) INTO _cnt 
  FROM vw_elementos_plan 
 WHERE elemento = pActividadDestino 
   AND plan_version = pPlanVersionDestino;
IF _cnt = 0 THEN
  -- No existe la actividad en el plan destino.
  RETURN -2;
END IF;

-- Recupero la entidad de la actividad de destino de las correlativas
SELECT entidad INTO _entidad_destino FROM sga_elementos WHERE elemento = pActividadDestino;
_cnt := 0;

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- Si ya tiene definida alguna correlativa, no permito copiar.
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
SELECT COUNT(*) INTO _cnt 
  FROM sga_condiciones as c
 WHERE c.entidad = _entidad_destino
   AND c.condicion_tipo IN ('1', '2')
   AND c.plan_version = pPlanVersionDestino;

IF _cnt > 0 THEN
  -- La actividad ya tiene definida correlativas. No permito copiar.
  RETURN -3;
END IF;

-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
-- Tipos de Condiciones: 1 - Correlativas para Cursar / 2 - Correlativas para Rendir
-- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
FOR cur_cond IN 
    SELECT sga_condiciones.condicion, sga_condiciones.condicion_tipo
      FROM sga_elementos,
           sga_condiciones
     WHERE sga_elementos.elemento  = pActividadOrigen
       AND sga_condiciones.entidad = sga_elementos.entidad
       AND sga_condiciones.plan_version = pPlanVersionOrigen
       AND sga_condiciones.condicion_tipo IN ('1', '2')
       -- AND NOT EXISTS (SELECT 1 FROM sga_condiciones as c
       --                 WHERE c.entidad = _entidad_destino
       --                   AND c.condicion_tipo = sga_condiciones.condicion_tipo
       --                   AND c.plan_version = pPlanVersionDestino)
LOOP
  _cnt := 1;
  -- Inserto registro en la cabecera
  INSERT INTO sga_condiciones (entidad, condicion_tipo, plan_version) VALUES (_entidad_destino, cur_cond.condicion_tipo, pPlanVersionDestino);
  -- Recupero el serial.	
  _condicion_new := (SELECT currval('sga_condiciones_seq'));
  
  -- 1. Grupos de Condiciones
  FOR cur_grupo IN SELECT sga_condiciones_grupos.condicion, sga_condiciones_grupos.grupo_condicion, sga_condiciones_grupos.orden
    FROM sga_condiciones_grupos
    WHERE sga_condiciones_grupos.condicion = cur_cond.condicion
  LOOP 
     -- Grupo de condiciones
     INSERT INTO sga_condiciones_grupos (condicion, orden) VALUES (_condicion_new, cur_grupo.orden);
     _grupo_new := (SELECT currval('sga_condiciones_grupos_seq'));
  
    -- Requisitos del Grupo.		
    INSERT INTO sga_condiciones_requisitos (grupo_condicion, orden, operador_not, tipo, requisito, origen, entidad, estado, regla, parametros)
       SELECT _grupo_new, orden, operador_not, tipo, requisito, origen, entidad, estado, regla, parametros
         FROM sga_condiciones_requisitos 
        WHERE grupo_condicion = cur_grupo.grupo_condicion;

  END LOOP; -- Grupos de Condiciones.
END LOOP; -- Condiciones
 
-- Salgo de la funcion.
RETURN _cnt;
 
END;
$$;
