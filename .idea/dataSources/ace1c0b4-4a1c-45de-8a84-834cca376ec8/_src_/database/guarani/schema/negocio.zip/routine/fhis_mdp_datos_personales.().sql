create function negocio.fhis_mdp_datos_personales() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
	
		INSERT INTO his_datos_personales (dato_censal, estado_civil, unido_hecho, situacion_padre, situacion_madre, cantidad_hijos, cantidad_familia, turno_preferido, cobertura_salud, tipo_vivienda, vive_con, periodo_lectivo_calle, periodo_lectivo_numero, periodo_lectivo_piso, periodo_lectivo_departamento, periodo_lectivo_unidad, periodo_lectivo_localidad, periodo_lectivo_barrio, periodo_lectivo_codigo_postal, procedencia_calle, procedencia_numero, procedencia_piso, procedencia_departamento, procedencia_unidad, procedencia_localidad, procedencia_barrio, procedencia_codigo_postal, es_celiaco) 
		VALUES (NEW.dato_censal, NEW.estado_civil, NEW.unido_hecho, NEW.situacion_padre, NEW.situacion_madre, NEW.cantidad_hijos, NEW.cantidad_familia, NEW.turno_preferido, NEW.cobertura_salud, NEW.tipo_vivienda, NEW.vive_con, NEW.periodo_lectivo_calle, NEW.periodo_lectivo_numero, NEW.periodo_lectivo_piso, NEW.periodo_lectivo_departamento, NEW.periodo_lectivo_unidad, NEW.periodo_lectivo_localidad, NEW.periodo_lectivo_barrio, NEW.periodo_lectivo_codigo_postal, NEW.procedencia_calle, NEW.procedencia_numero, NEW.procedencia_piso, NEW.procedencia_departamento, NEW.procedencia_unidad, NEW.procedencia_localidad, NEW.procedencia_barrio, NEW.procedencia_codigo_postal, NEW.es_celiaco);
	
		RETURN NEW;
	END;
$$;
