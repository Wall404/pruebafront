create function negocio.f_insc_cursada_eliminar_preinsc(pinscripcion integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
  _retorno integer;
  _con_subcomisiones boolean;
  _cnt Smallint;
  _fecha_rechazo Timestamp;
  _nro_transaccion_rechazo Integer;
  _fecha_actual Varchar(10);
  _flag_rechazo char(1);
  
  -- Datos de la Inscripcion
  _insc  sga_insc_cursada%ROWTYPE;
  _insc_subco  sga_insc_subcomision%ROWTYPE;

BEGIN
  -- Variables 
  _retorno := 1;
  _flag_rechazo := 'R'; 
  _nro_transaccion_rechazo := NULL;
  _con_subcomisiones := false;
  _cnt := 0;

  -- ********************************************************************
  -- Verifico que exista la inscripcion a dar de baja
  -- ********************************************************************
  SELECT * INTO _insc FROM sga_insc_cursada WHERE inscripcion = pInscripcion;
   
  IF NOT FOUND THEN
    -- No existe la inscripción a dar de baja.
    _retorno := -1;
    RETURN _retorno;
  END IF;

  -- ********************************************************************
  -- Verifico si tiene subcomisiones
  -- ********************************************************************
  SELECT COUNT(*) INTO _cnt
  FROM sga_insc_subcomision
  WHERE inscripcion = pInscripcion;
  IF _cnt > 0 THEN
     _con_subcomisiones := true;
  END IF;

-- Comienza la Transacción
BEGIN

  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  -- Doy de baja la inscripcion
  -- ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  _fecha_rechazo := CURRENT_TIMESTAMP;
  _nro_transaccion_rechazo := (SELECT nextval('aud_nro_transaccion_seq')); 

  -- Inserto el registro en la tabla de log.
  INSERT INTO sga_insc_cursada_log (
         inscripcion, comision, alumno, plan_version, tipo, prioridad, estado_preinscripcion, 
         fuera_de_termino, estado, interfaz, fecha_inscripcion, nro_transaccion, exceptuado,
         operacion ,nro_transaccion_log, fecha_operacion)
   VALUES(pInscripcion, _insc.comision, _insc.alumno, _insc.plan_version, _insc.tipo, _insc.prioridad, _insc.estado_preinscripcion, 
         _insc.fuera_de_termino, _insc.estado, _insc.interfaz, _insc.fecha_inscripcion, _insc.nro_transaccion, _insc.exceptuado,
         _flag_rechazo, _nro_transaccion_rechazo, _fecha_rechazo);
	
  
  IF _con_subcomisiones THEN    
    -- Inserto en el log de subcomisiones
	INSERT INTO sga_insc_subcomision_log(inscripcion, subcomision) 
	SELECT inscripcion, subcomision FROM sga_insc_subcomision WHERE inscripcion = pInscripcion;
    -- Borro las subcomisiones
	DELETE 
	FROM 	sga_insc_subcomision 
	WHERE 	inscripcion = pInscripcion;
  END IF;
  
  -- Inserto en el log de instancias
  INSERT INTO sga_insc_cursada_instancias_log(inscripcion, instancia) 
  SELECT inscripcion, instancia FROM sga_insc_cursada_instancias WHERE inscripcion = pInscripcion;
  -- Borro las instancias
  DELETE FROM sga_insc_cursada_instancias WHERE inscripcion = pInscripcion;
  
  -- Borro la inscripción a cursada
  DELETE FROM sga_insc_cursada WHERE inscripcion = pInscripcion;

  -- Bloque de excepciones. Sale por error.
  EXCEPTION 
      WHEN OTHERS THEN
        _retorno := -1;
        RETURN _retorno;

END; -- Fin bloque de actualizacion en la base
  
RETURN _retorno;

END;
$$;
