create function negocio.f_es_ingresante(palumno integer, panioacademico integer) returns integer
LANGUAGE plpgsql
AS $$
-- Variables locales
 DECLARE _cnt integer;
 DECLARE _es_ingresante smallint;

BEGIN
 _cnt := 0;
 _es_ingresante := 0;

   
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 -- Verifica el año académico de la inscripción a propuesta del alumno en estado Aceptada o Pendiente
 -- +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
 SELECT COUNT(*) INTO _cnt
  FROM sga_alumnos, 
       sga_propuestas_aspira,
       sga_situacion_aspirante
  WHERE sga_alumnos.alumno = pAlumno
    AND sga_propuestas_aspira.persona   = sga_alumnos.persona
    AND sga_propuestas_aspira.propuesta = sga_alumnos.propuesta
    AND sga_situacion_aspirante.situacion_asp = sga_propuestas_aspira.situacion_asp
    AND sga_situacion_aspirante.resultado_asp IN ('A','P')
    AND sga_propuestas_aspira.anio_academico = pAnioAcademico;
    
 IF _cnt > 0 THEN
    _es_ingresante := 1;
 END IF;

 -- Retorna si es ingresante o no.
 RETURN _es_ingresante;
 
END;
$$;
