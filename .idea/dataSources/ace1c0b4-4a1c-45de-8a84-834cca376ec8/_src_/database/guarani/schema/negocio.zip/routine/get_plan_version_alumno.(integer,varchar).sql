create function negocio.get_plan_version_alumno(_alumno integer, _sfecha character varying) returns integer
LANGUAGE plpgsql
AS $$
DECLARE _plan_version integer;
DECLARE _fecha date;
BEGIN

 _plan_version := NULL;
 
 IF _alumno IS NULL OR _sfecha IS NULL OR _sfecha = '' THEN
   RETURN _plan_version;
 END IF;
 
 -- Convierto la fecha a date. La fecha debe venir en formato: yyyy-mm-dd
 _fecha := _sfecha::date;
 
 -- Busco el plan y version del alumno para la fecha dada. 
 -- Recupera la maxima fecha de cambio de plan/version que sea menor o igual a la fecha a buscar.
 -- En el caso que exista mas de un cambio de version el mismo dia, tomara el ultimo cambio de ese dia.
 SELECT plan_version INTO _plan_version
    FROM sga_alumnos_hist_planes
    WHERE alumno = _alumno
    AND fecha = (SELECT max(sga_alumnos_hist_planes.fecha) 
                   FROM sga_alumnos_hist_planes 
                   WHERE sga_alumnos_hist_planes.alumno = _alumno
                     AND Cast(sga_alumnos_hist_planes.fecha as date) <= _fecha
                 );
  
 -- Si no encontró el plan y version del alumno en la fecha indicada, recupero el plan y version actual   
 IF NOT FOUND THEN
   SELECT plan_version INTO _plan_version
     FROM sga_alumnos WHERE alumno = _alumno;
 END IF;
 
 -- Retorno la version de plan del alumno
 RETURN _plan_version;

END
$$;
