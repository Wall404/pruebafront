create function get_anio_academico_ingreso_alumno(palumno integer, pingresoa integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE 
 _propuesta integer;
 _persona integer;
 _plan_insc integer;
 _plan_actual integer;
 _plan_version_actual integer;
 _plan_version_insc integer;
 _anio_insc_propuesta integer;
 _periodo_insc_propuesta integer;
 _anio_academico_ingreso integer;
 _anio_ingreso_ciclo_basico integer;

 cur_cb RECORD;

BEGIN
  _anio_academico_ingreso := NULL;
  _anio_ingreso_ciclo_basico := NULL;
  _anio_insc_propuesta := NULL;
  
  
  
 SELECT a.persona, pa.propuesta, pa.plan_version, plan_insc.plan, pa.anio_academico, a.plan_version, plan_actual.plan, pi.periodo_inscripcion 
   INTO _persona, _propuesta, _plan_version_insc, _plan_insc, _anio_insc_propuesta, _plan_version_actual, _plan_actual, _periodo_insc_propuesta
   FROM sga_alumnos as a,
	sga_planes_versiones as plan_actual,
        sga_propuestas_aspira as pa, 
        sga_planes_versiones as plan_insc,
        sga_situacion_aspirante as sa,
        sga_periodos_inscripcion_fechas as pif, 
        sga_periodos_inscripcion as pi
  WHERE a.alumno = pAlumno
    AND plan_actual.plan_version = a.plan_version
    AND pa.propuesta = a.propuesta
    AND pa.persona   = a.persona
    AND plan_insc.plan_version = pa.plan_version
    AND sa.situacion_asp = pa.situacion_asp 
    AND sa.resultado_asp IN ('P','A') 
    AND pif.periodo_insc = pa.periodo_insc
    AND pi.periodo_inscripcion = pif.periodo_inscripcion;

  
  _anio_academico_ingreso := _anio_insc_propuesta;

  IF pIngresoA = 1 THEN
     
     SELECT MIN(pa.anio_academico)
       INTO _anio_academico_ingreso
       FROM sga_alumnos as a,
    		sga_planes_versiones as plan_actual,
            sga_propuestas_aspira as pa, 
            sga_planes_versiones as plan_insc,
            sga_situacion_aspirante as sa
      WHERE a.persona = _persona
        AND plan_actual.plan_version = a.plan_version
        AND pa.propuesta = a.propuesta
        AND pa.persona   = a.persona
        AND plan_insc.plan_version = pa.plan_version
        AND sa.situacion_asp = pa.situacion_asp 
        AND sa.resultado_asp IN ('P','A');

  ELSIF pIngresoA = 2 THEN
     
     _anio_academico_ingreso := _anio_insc_propuesta;

  ELSIF pIngresoA = 3 THEN	 

      
      SELECT MIN(pa.anio_academico)
        INTO _anio_ingreso_ciclo_basico       
       FROM (SELECT cast(get_relacion_propuesta as integer) as relacion FROM get_relacion_propuesta(pAlumno)) as r,
            sga_propuestas_relacion as pr,
            sga_propuestas_relacion_grupo as g,
            sga_propuestas_relacion_plan as rp,
            sga_planes as plan_ciclo_basico, 
            sga_propuestas as prop_ciclo_basico,
            sga_propuestas_aspira as pa,
            sga_situacion_aspirante as sa
      WHERE pr.relacion = r.relacion
        AND g.relacion = r.relacion
        AND rp.relacion_grupo = g.relacion_grupo
        AND plan_ciclo_basico.plan = rp.plan
        AND prop_ciclo_basico.propuesta = plan_ciclo_basico.propuesta
        AND prop_ciclo_basico.propuesta_tipo = 203 
        AND pa.propuesta = prop_ciclo_basico.propuesta
        AND pa.persona = _persona
        AND sa.situacion_asp = pa.situacion_asp 
        AND sa.resultado_asp IN ('P','A'); 

	
    IF FOUND THEN
	   _anio_academico_ingreso := _anio_ingreso_ciclo_basico;
    END IF;	
  END IF;
  
  
  RETURN _anio_academico_ingreso;
END;
$$;
