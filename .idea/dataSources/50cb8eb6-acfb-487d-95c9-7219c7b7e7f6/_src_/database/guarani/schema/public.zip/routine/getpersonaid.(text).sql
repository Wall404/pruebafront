create function getpersonaid(pdocumento text) returns refcursor
LANGUAGE plpgsql
AS $$
DECLARE
      ref refcursor;
    BEGIN
      OPEN ref FOR select p.persona as Id
		from guarani.negocio.mdp_personas as p left join guarani.negocio.mdp_personas_documentos as doc on p.persona = doc.persona
		where doc.nro_documento = pdocumento;
      RETURN ref;
    END;

$$;
